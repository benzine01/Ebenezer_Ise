<?php

return [
    'fields_not_accepted' => 'ستونهای :field قایل قبول در جستجوی دوباره نیستند',
];
