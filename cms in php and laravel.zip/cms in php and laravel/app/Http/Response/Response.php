<?php

namespace App\Http\Response;

use Litepie\Http\Response as LitepieResponse;

abstract class Response extends LitepieResponse
{

}
