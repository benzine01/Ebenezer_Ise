<?php

namespace App\Http\Response\Auth;

use App\Http\Response\Response as BaseResponse;

class Response extends BaseResponse
{

}
