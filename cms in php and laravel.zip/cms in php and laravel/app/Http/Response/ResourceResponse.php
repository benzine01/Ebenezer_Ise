<?php

namespace App\Http\Response;


class ResourceResponse extends Response
{

}
