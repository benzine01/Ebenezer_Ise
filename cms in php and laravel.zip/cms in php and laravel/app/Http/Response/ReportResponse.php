<?php

namespace App\Http\Response;


class ReportResponse extends Response
{

}
