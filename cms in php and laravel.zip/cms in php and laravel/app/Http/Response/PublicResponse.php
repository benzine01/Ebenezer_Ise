<?php

namespace App\Http\Response;


class PublicResponse extends Response
{

}
