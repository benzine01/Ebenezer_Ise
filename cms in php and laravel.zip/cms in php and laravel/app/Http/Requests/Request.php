<?php

namespace App\Http\Requests;

use Litepie\Http\Request as LitepieRequest;

abstract class Request extends LitepieRequest
{

}
