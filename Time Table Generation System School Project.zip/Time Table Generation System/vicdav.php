 <html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Simple PHP form</title>
</head>
<body>
<h2>Simple PHP form</h2>
<form method="get" action="testi.php">
Name: <input type="text" name="name" /> <br />
Value 1: <input type="text" name="value1" /> <br />
Value 2: <input type="text" name="value2" /> <br />
<input type="submit" value="Submit" />
</form>
<?php
if (isset($_GET['name'])) {
  $val1=$_GET['value1'];
  $val2=$_GET['value2'];
  
  echo "The user submited form  ".$_GET['name']. ' <br />';
  echo "Values submited are: $val1, $val2";
}
?>



</body>
</html>
