<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>TIMETABLE GENERATION SYSTEM</title>
<style type="text/css">
<!--
.style1 {color: #000000}
-->
</style>
</head>

<body>
<table width="1011" height="168" border="1">
  <tr>
    <td width="74" bgcolor="#666600">MONDAY</td>
    <td width="921"><table width="921" height="123" border="1">
      <tr>
        <td width="52" bgcolor="#0000FF">CLASS</td>
        <td width="129" bgcolor="#009900">8AM-10AM</td>
        <td width="136" bgcolor="#FFFF00">10AM-12PM</td>
        <td width="141" bgcolor="#FF00FF">12PM-1PM</td>
        <td width="136" bgcolor="#3366CC">1PM-2PM</td>
        <td width="146" bgcolor="#FF0000">2PM-4PM</td>
        <td width="135" bgcolor="#FFCCFF">4PM-6PM</td>
      </tr>
      <tr>
	  <?php
	  $hostname = 'localhost';
	  $username = 'root';
	  $pword = '';
	  $dbname = 'timet';
	  $con = mysql_connect($hostname, $username, $pword);
	  if(!$con){
	  die('cannot connect to mysql ' . msql_error());
	  }
	  $db = mysql_select_db($dbname);
	  if(!$db){
	  die('cannot communicate with the specified database ' .mysql_error());
	  
	  }
	  $day = 'MONDAY';
	  $time = '8am-10am';
	  $nd1msql ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs = mysql_query($nd1msql);
	  if(!$nd1msqlrs){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr=mysql_fetch_array($nd1msqlrs)){
	  echo  "<td>" . "NDI" . "</td>";
	  echo  "<td>" . $nd1mr['CODE']. "(" .$nd1mr['HALL']. ")" . "</td>";
	  }
	  ?>
	  
        <?php
		$day = 'MONDAY';
	  $time = '10am-12Pm';
	  $nd1msql2 ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs2 = mysql_query($nd1msql2);
	  if(!$nd1msqlrs2){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr2=mysql_fetch_array($nd1msqlrs2)){
	  
	  echo  "<td>" . $nd1mr2['CODE']. "(" .$nd1mr2['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
       $day = 'MONDAY';
	  $time = '12PM-1PM';
	  $nd1msql3 ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs3 = mysql_query($nd1msql3);
	  if(!$nd1msqlrs3){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr3=mysql_fetch_array($nd1msqlrs3)){
	  
	  echo  "<td>" . $nd1mr3['CODE']. "(" .$nd1mr3['HALL']. ")" . "</td>";
	  }
	  ?>
	   
        
        <td><div align="center">BREAK</div></td>
		<?PHP
		$day = 'MONDAY';
	  $time = '2PM-4PM';
	  $nd1msql4 ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs4 = mysql_query($nd1msql4);
	  if(!$nd1msqlrs4){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr4=mysql_fetch_array($nd1msqlrs4)){
	  
	  echo  "<td>" . $nd1mr4['CODE']. "(" .$nd1mr4['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
	  $day = 'MONDAY';
	  $time = '4PM-6PM';
	  $nd1msql5 ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs5 = mysql_query($nd1msql5);
	  if(!$nd1msqlrs5){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr5=mysql_fetch_array($nd1msqlrs5)){
	  
	  echo  "<td>" . $nd1mr5['CODE']. "(" .$nd1mr5['HALL']. ")" . "</td>";
	  }
	  ?>
	  
 
  
      </tr>
      <tr>
	  <?PHP
	  $day = 'MONDAY';
	  $time = '8am-10am';
	  $nd2msql ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs = mysql_query($nd2msql);
	  if(!$nd2msqlrs){
	  die('error: ' . mysql_error());
	  }
	   echo  "<td>" . "NDII" . "</td>";
	  
	  while($nd2mr=mysql_fetch_array($nd2msqlrs)){
	 
	  
	  echo  "<td>" . $nd2mr['CODE']. "(" .$nd2mr['HALL']. ")" . "</td>";
	  }
	  
	  ?>
	  
        <?php
		$day = 'MONDAY';
	  $time = '10AM-12PM';
	  $nd2msql2 ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs2 = mysql_query($nd2msql2);
	  if(!$nd2msqlrs2){
	  die('error: ' . mysql_error());
	  }
	  while($nd2mr2=mysql_fetch_array($nd2msqlrs2)){
	  
	  echo  "<td>" . $nd2mr2['CODE']. "(" .$nd2mr2['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
       $day = 'MONDAY';
	  $time = '12PM-1PM';
	  $nd2msql3 ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs3 = mysql_query($nd2msql3);
	  if(!$nd2msqlrs3){
	  die('error: ' . mysql_error());
	  }
	  while($nd2mr3=mysql_fetch_array($nd2msqlrs3)){
	  
	  echo  "<td>" . $nd2mr3['CODE']. "(" .$nd2mr3['HALL']. ")" . "</td>";
	  }
	  ?>
	   
        
        <td><div align="center">BREAK</div></td>
		<?PHP
		$day = 'MONDAY';
	  $time = '2PM-4PM';
	  $nd2msql4 ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs4 = mysql_query($nd2msql4);
	  if(!$nd2msqlrs4){
	  die('error: ' . mysql_error());
	  }
	  while($nd2mr4=mysql_fetch_array($nd2msqlrs4)){
	  
	  echo  "<td>" . $nd2mr4['CODE']. "(" .$nd2mr4['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
	  $day = 'MONDAY';
	  $time = '4PM-6PM';
	  $nd2msql5 ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs5 = mysql_query($nd2msql5);
	  if(!$nd2msqlrs5){
	  die('error: ' . mysql_error());
	  }
	  while($nd2mr5=mysql_fetch_array($nd2msqlrs5)){
	  
	  echo  "<td>" . $nd2mr5['CODE']. "(" .$nd2mr5['HALL']. ")" . "</td>";
	  }
	  ?>
	  
 
  
        
      </tr>
      <tr>
	   <?PHP
	  $day = 'MONDAY';
	  $time = '8am-10am';
	  $Hnd1msql ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs = mysql_query($Hnd1msql);
	  if(!$Hnd1msqlrs){
	  die('error: ' . mysql_error());
	  }
	   echo  "<td>" . "HNDI" . "</td>";
	 
	  
	  while($Hnd1mr=mysql_fetch_array($Hnd1msqlrs)){
	 
	  
	  echo  "<td>" . $Hnd1mr['CODE']. "(" .$Hnd1mr['HALL']. ")" . "</td>";
	  }
	  
	  ?>
	  
        <?php
		$day = 'MONDAY';
	  $time = '10AM-12PM';
	  $Hnd1msql2 ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs2 = mysql_query($Hnd1msql2);
	  if(!$Hnd1msqlrs2){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd1mr2=mysql_fetch_array($Hnd1msqlrs2)){
	  
	  echo  "<td>" . $Hnd1mr2['CODE']. "(" .$Hnd1mr2['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
       $day = 'MONDAY';
	  $time = '12PM-1PM';
	  $Hnd1msql3 ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs3 = mysql_query($Hnd1msql3);
	  if(!$Hnd1msqlrs3){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd1mr3=mysql_fetch_array($Hnd1msqlrs3)){
	  
	  echo  "<td>" . $Hnd1mr3['CODE']. "(" .$Hnd1mr3['HALL']. ")" . "</td>";
	  }
	  ?>
	   
        
        <td><div align="center">BREAK</div></td>
		<?PHP
		$day = 'MONDAY';
	  $time = '2PM-4PM';
	  $Hnd1msql4 ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs4 = mysql_query($Hnd1msql4);
	  if(!$Hnd1msqlrs4){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd1mr4=mysql_fetch_array($Hnd1msqlrs4)){
	  
	  echo  "<td>" . $Hnd1mr4['CODE']. "(" .$Hnd1mr4['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
	  $day = 'MONDAY';
	  $time = '4PM-6PM';
	  $Hnd1msql5 ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs5 = mysql_query($Hnd1msql5);
	  if(!$Hnd1msqlrs5){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd1mr5=mysql_fetch_array($Hnd1msqlrs5)){
	  
	  echo  "<td>" . $Hnd1mr5['CODE']. "(" .$Hnd1mr5['HALL']. ")" . "</td>";
	  }
	  ?>
	  
 
  
     
      </tr>
      <tr>
	  <?PHP
	  $day = 'MONDAY';
	  $time = '8am-10am';
	  $Hnd2msql ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs = mysql_query($Hnd2msql);
	  if(!$Hnd2msqlrs){
	  die('error: ' . mysql_error());
	  }
	   echo  "<td>" . "HNDII" . "</td>";
	 
	  while($Hnd2mr=mysql_fetch_array($Hnd2msqlrs)){
	 
	  
	  echo  "<td>" . $Hnd2mr['CODE']. "(" .$Hnd2mr['HALL']. ")" . "</td>";
	  }
	 
	  ?>
	  
        <?php
		$day = 'MONDAY';
	  $time = '10AM-12PM';
	  $Hnd2msql2 ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs2 = mysql_query($Hnd2msql2);
	  if(!$Hnd2msqlrs2){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd2mr2=mysql_fetch_array($Hnd2msqlrs2)){
	  
	  echo  "<td>" . $Hnd2mr2['CODE']. "(" .$Hnd2mr2['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
       $day = 'MONDAY';
	  $time = '12PM-1PM';
	  $Hnd2msql3 ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs3 = mysql_query($Hnd2msql3);
	  if(!$Hnd2msqlrs3){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd2mr3=mysql_fetch_array($Hnd2msqlrs3)){
	  
	  echo  "<td>" . $Hnd2mr3['CODE']. "(" .$Hnd2mr3['HALL']. ")" . "</td>";
	  }
	  ?>
	   
        
        <td><div align="center">BREAK</div></td>
		<?PHP
		$day = 'MONDAY';
	  $time = '2PM-4PM';
	  $Hnd2msql4 ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs4 = mysql_query($Hnd2msql4);
	  if(!$Hnd2msqlrs4){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd2mr4=mysql_fetch_array($Hnd2msqlrs4)){
	  
	  echo  "<td>" . $Hnd2mr4['CODE']. "(" .$Hnd2mr4['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
	  $day = 'MONDAY';
	  $time = '4PM-6PM';
	  $Hnd2msql5 ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs5 = mysql_query($Hnd2msql5);
	  if(!$Hnd2msqlrs5){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd2mr5=mysql_fetch_array($Hnd2msqlrs5)){
	  
	  echo  "<td>" . $Hnd2mr5['CODE']. "(" .$Hnd2mr5['HALL']. ")" . "</td>";
	  }
	  ?>
	  
        </tr>
    </table></td>
  </tr>
  <tr>
    <td bgcolor="#FFFF33" class="style1">TUESDAY</td>
    <td><table width="919" height="123" border="1">
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td bgcolor="#00FFFF" class="style1">WEDNESDAY</td>
    <td><table width="919" height="123" border="1">
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td bgcolor="#999999" class="style1">THURSDAY</td>
    <td><table width="919" height="123" border="1">
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td bgcolor="#006699" class="style1">FRIDAY</td>
    <td><table width="919" height="123" border="1">
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
