<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>::TIMETABLE GENERATION SYSTEM:</title>
<style type="text/css">
<!--
.style1 {
	color: #99CC00;
	font-family: Georgia, "Times New Roman", Times, serif;
}
.style6 {font-size: 18px}
.style10 {
	font-size: 24;
	font-family: "Comic Sans MS";
	color: #0000CC;
}
-->
</style>
</head>

<body bgcolor="#FFFFCC">
<div align="center"><img src="images/hdr_bg.jpg" alt="FPN"  width="900" height="150" border="1" longdesc="http://www.fepolynasonline.com" /></div>
 
<h1 align="center" class="style1"><marquee> AUTOMATED TIMETABLE GENERATION SYSTEM</marquee></h1><BR />

 <img src="images/timetable.png"  height="400" width="400" <div align="LEFT">
     <table width="264" align="right" bgcolor="#94BE94">
            <tr bgcolor="#009933">
              <td colspan="3" align="left" valign="top" style="font-weight: bold; text-align: center;">ADMIN LOGIN</td>
            </tr>
            <tr>
              <td width="69" align="left" valign="top" bgcolor="#009933" style="font-weight: bold">Username:</td>
              <td width="183" colspan="2" align="left" valign="top" bgcolor="#94BE94"><label>
              <input type="text" name="user" id="textfield" size="30" />
              </label></td>
            </tr>
            <tr>
              <td align="left" valign="top" bordercolor="#94BE94" bgcolor="#009933"><span style="font-weight: bold">Password</span>:</td>
              <td colspan="2" align="left" valign="top" bgcolor="#94BE94"><label>
              <input type="password" name="pass" id="textfield2" size="30" />
              </label></td>
            </tr>
            <tr bgcolor="#009933">
              <td colspan="3" align="left" valign="top" style="text-align: right"><label>
                <b><?php
				$hostname = 'localhost';
	  $username = 'root';
	  $pword = '';
	  $dbname = 'timet';
	  $con = mysql_connect($hostname, $username, $pword);
	  if(!$con){
	  die('cannot connect to mysql ' . msql_error());
	  }
	  $db = mysql_select_db($dbname);
	  if(!$db){
	  die('cannot communicate with the specified database ' .mysql_error());
	  
	  }
	  
				 if(isset($_POST['Stafflog'])){
							
							$user=$_POST['user'];
							$pass=$_POST['pass'];
							if(empty($user)){
							 echo "<font color=red><b>Enter valid username</b></font>";
							}
							else if(empty($pass)){
							echo "<font color=red><b>Enter valid password</b></font>";
							}
							else{
							//session_start();
							   mysql_connect("localhost","root","") or die("Error: ".mysql_error());
							   mysql_select_db("timet") or die("Error: ".mysql_error());
							   $sql="SELECT * FROM adminsecure WHERE Username='$user' AND Password='$pass'";
							   $result=mysql_query($sql) or die("Error ".mysql_error());
							   $count=mysql_fetch_row($result);
							   if($count>1){
							     $name=$count[0];
								 //session_register("name");
								 $_SESSION['name']=$name;
								 echo "<meta http-equiv='Refresh' content='0; form.php'>";
							   }
							else{
							 echo "<font color=red><h2><b>Invalid username or password</b></h2></font>";
							}
							}
                        }

			?>		  
</b><input type="submit" name="Stafflog" id="Stafflog" value="Login" />
              </label></td>
            </tr>
   </table>
   </P>
</div>
</body>
</html>
