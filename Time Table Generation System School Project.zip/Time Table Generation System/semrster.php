<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TIMETABLE GENERATION SYSTEM</title>
<link rel="stylesheet" type="text/css" href="style.css" />
<style type="text/css">
<!--
.style1 {
	font-size: 18px;
	font-weight: bold;
}
.style2 {
	font-family: "Comic Sans MS";
	font-size: 16px;
}
.style3 {font-size: 17px}
-->
</style>
</head>
<body>
<div id="top_menu">
                    <ul class="menu">
                        <li><a href="index.html" class="nav">HOME</a></li>
                        <li><a href="main_login.php" class="nav">ADMIN</a></li>
                        <li><a href="#" class="nav">TIMETABLE</a></li>
                        <li><a href="gallery.html" class="nav">ABOUT</a></li>
                        <li><a href="contact.html" class="nav">CONTACT</a></li>
                    </ul>
</div>
<div id="main_content">
	<div id="top_banner">
    <a href="index.html"></a>    </div>
    
    <div id="page_content_left">
    	<div class="title style1">
        ::<span class="style3">SELECT SEMESTER TO VIEW TIMETABLE</span>::        </div>
        <div class="content_text">
         <a href="first.php"> <font size="+1">click here to view first semester timetable</font></a><br />
		 <a href="second.php"> <font size="+1">click here to view second semester timetable</font></a></div><br /><br /><br /><br /><br /><br /><br />
  </div>
    <div id="page_content_right">
      <div class="more"><img src="images/timetable.png" alt="save time" width="300" height="300"  align="right"/></div>
    </div>
    
    
  <div id="page_bottom"></div>
		
</div>

<div id="footer">
<div id="footer_content">
<div id="copyrights">
Timetable Solution.&copy; All Rights Reserved Group Four 2012/2013
</div>
	<div>
                    <ul class="footer_menu">
                        <li><a href="#" class="nav2">home </a></li>
                        <li><a href="#" class="nav2">Admin</a></li>
                        <li><a href="#" class="nav2">Timetable</a></li>
                        <li><a href="#" class="nav2">contact</a></li>
                    </ul>
    </div>
</div>
</div>


</body>
</html>