<?php
session_start();
	  $hostname = 'localhost';
	  $username = 'root';
	  $pword = '';
	  $dbname = 'timet';
	  $con = mysql_connect($hostname, $username, $pword);
	  if(!$con){
	  die('cannot connect to mysql ' . msql_error());
	  }
	  $db = mysql_select_db($dbname);
	  if(!$db){
	  die('cannot communicate with the specified database ' .mysql_error());
	  
	  }
	  ?>
<?php

$time = $_POST['time'];
$day = $_POST['day'];
$hall = $_POST['hall'];
$ccode = $_POST['code'];
$level = $_POST['level'];
$esql = "select * from $level where time = '$time' && hall = '$hall'";
$er = mysql_query($esql);
if(!$er){
die('error: ' . mysql_error());
}
$num = mysql_num_rows($er);
if ($num != 0 ){
echo "data already exists here, just modify";
//modify here to edit data later
exit;
}
else{
if($level != 'ndi'){
$csql1 = "select * from NDi where HALL = '$hall' && day = '$day' && time = '$time'";
$cr1 = mysql_query($csql1);
if(!$cr1){
die('error: ' .mysql_error());
}
$num1 = mysql_num_rows($cr1);
if(num1 > 0){
echo "ndi students are having lectures by this time in the same hall, pls choose another hall";
exit;
}
}
elseif($level != 'ndii'){
$csql2 = "select from ndii where hall = '$hall' && day = '$day' && time = '$time'";
$cr2 = mysql_query($csql2);
if(!$cr2){
die('error: ' .mysql_error());
}
$num2 = mysql_num_rows($cr2);
if(num2 > 0){
echo "ndii students are having lectures by this time in the same hall, pls choose another hall";
exit;
}
}
elseif($level != 'hndi'){
$csql3 = "select from hndi where hall = '$hall' && day = '$day' && time = '$time'";
$cr3 = mysql_query($csql3);
if(!$cr3){
die('error: ' .mysql_error());
}
$num3 = mysql_num_rows($cr3);
if(num3 > 0){
echo "hndi students are having lectures by this time in the same hall, pls choose another hall";
exit;
}
}
elseif($level != 'hndii'){
$csql4 = "select from hndii where hall = '$hall' && day = '$day' && time = '$time'";
$cr4 = mysql_query($csql4);
if(!$cr4){
die('error: ' .mysql_error());
}
$num4 = mysql_num_rows($cr4);
if(num4 > 0){
echo "hndii students are having lectures by this time in the same hall, pls choose another hall";
exit;
}
}

echo "enter the new record into the database";
//insertion code goes here

}
?>

