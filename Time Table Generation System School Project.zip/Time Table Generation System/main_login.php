<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TIMETABLE GENERATION SYSTEM</title>
<link rel="stylesheet" type="text/css" href="style.css" />
<style type="text/css">
<!--
.style1 {
	font-size: 18px;
	font-weight: bold;
}
.style2 {
	font-family: "Comic Sans MS";
	font-size: 16px;
}
.style3 {font-size: 17px}
-->
</style>
</head>
<body>
<div id="top_menu">
                    <ul class="menu">
                        <li><a href="index.html" class="nav">HOME</a></li>
                        <li><a href="main_login.php" class="nav">ADMIN</a></li>
                        <li><a href="#" class="nav">TIMETABLE</a></li>
                        <li><a href="gallery.html" class="nav">ABOUT</a></li>
                        <li><a href="contact.html" class="nav">CONTACT</a></li>
                    </ul>
</div>
<div id="main_content">
	<div id="top_banner">
    <a href="index.html"></a>    </div>
    
    <div id="page_content_left">
	<table width="300" border="0" align="CENTER" cellpadding="0" cellspacing="1" bgcolor="#CCCCCC">
<tr>
<form name="form1" method="post" action="checklogin.php">
<td>
<table width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="#ffffff">
<tr><td
colspan="3"><strong>Admin Login</strong></td>
</tr>
<tr>
<td width = "78">Username</td>
<td width="6">:</td>
<td width="294"><input name="myusername" type="text" id="myusername" ></td>
</tr>
<tr>
<td>Password</td>
<td>:</td>
<td><input name="mypassword" type="text" id="mypassword" ></td>
</tr>
<td><input type="submit" name="Submit" value="Login" ></td>
</tr>
</table>
</td>
</form>
</tr>
</table>
<br />
      <br /><br /><br /><br /><br /><br />
  </div>
    <div id="page_content_right">
      <div class="more"><img src="images/timetable.png" alt="save time" width="300" height="300"  align="right"/></div>
    </div>
    
    
  <div id="page_bottom"></div>
		
</div>

<div id="footer">
<div id="footer_content">
<div id="copyrights">
Timetable Solutions.&copy; All Rights Reserved Group Four 2012/2013
</div>
	<div>
                    <ul class="footer_menu">
                        <li><a href="#" class="nav2">home </a></li>
                        <li><a href="#" class="nav2">Admin</a></li>
                        <li><a href="#" class="nav2">Timetable</a></li>
                        <li><a href="#" class="nav2">contact</a></li>
                    </ul>
    </div>
</div>
</div>


</body>
</html>