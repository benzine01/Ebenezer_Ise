<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TIMETABLE GENERATION SYSTEM</title>
<link rel="stylesheet" type="text/css" href="style.css" />
<style type="text/css">
<!--
.style1 {
	font-size: 18px;
	font-weight: bold;
}
.style13 {
	font-weight: bold;
	color: #000000;
}
.style15 {
	font-weight: bold;
	color: #000000;
}
.style17 {
	font-weight: bold;
	color: #000000;
}
.style21 {
	font-weight: bold;
	color: #000000;
}
.style23 {
	font-weight: bold;
	color: #000000;
}
.style25 {
	font-weight: bold;
	color: #000000;
}
.style29 {
	font-weight: bold;
	color: #000000;
}
.style31 {
	font-weight: bold;
	color: #000000;
}
.style33 {
	font-weight: bold;
	color: #000000;
}
.style37 {
	font-weight: bold;
	color: #000000;
}
.style39 {
	font-weight: bold;
	color: #000000;
}
.style41 {
	font-weight: bold;
	color: #000000;
}
.style45 {
	font-weight: bold;
	color: #000000;
}
.style47 {
	font-weight: bold;
	color: #000000;
}
.style49 {
	font-weight: bold;
	color: #000000;
}
.style52 {color: #000000}
.style53 {color: #FF0000}
-->
</style>
</head>
<body>
<div id="top_menu">
                    <ul class="menu">
                        <li><a href="index.html" class="nav">HOME</a></li>
                        <li><a href="main_login.php" class="nav">ADMIN</a></li>
                        <li><a href="#" class="nav">TIMETABLE</a></li>
                        <li><a href="gallery.html" class="nav">ABOUT</a></li>
                        <li><a href="contact.html" class="nav">CONTACT</a></li>
                    </ul>
</div>
<div id="main_content">
	<div id="top_banner">
    <a href="index.html"></a>    </div>
    
     <div id="page_bottom">
	 </div>
	 <div align="center"><span class="style52">FEDERAL POLYTECHNIC NASARAWA,COMPUTER SCIENCE DEPARTMENT, FIERST SEMESTER TENTATIVE TIMETABLE,    2012/2013.</b></span>
	   </P>
     </div>
  <table width="500" height="160" border="1" align = "center">
  <tr>
    <td width="100" bgcolor="#666600" class="style1 ">MONDAY</td>
    <td width="100"><table width="100" height="123" border="1">
      <tr>
        <td width="92" bgcolor="#0000FF" class="style52"><span class="style52"><strong>CLASS</strong></span></td>
        <td width="158" bgcolor="#009900" class="style52"><strong>8AM-10AM</strong></td>
        <td width="125" bgcolor="#FFFF00" class="style52"><strong>10AM-12PM</strong></td>
        <td width="125" bgcolor="#FF00FF" class="style52"><strong>12PM-1PM</strong></td>
        <td width="125" bgcolor="#3366CC" class="style52"><strong>1PM-2PM</strong></td>
        <td width="125" bgcolor="#FF0000" class="style52"><strong>2PM-4PM</strong></td>
        <td width="125" bgcolor="#FFCCFF" class="style52"><strong>4PM-6PM</strong></td>
      </tr>
      <tr>
	  <?php
	  $hostname = 'localhost';
	  $username = 'root';
	  $pword = '';
	  $dbname = 'timet';
	  $con = mysql_connect($hostname, $username, $pword);
	  if(!$con){
	  die('cannot connect to mysql ' . msql_error());
	  }
	  $db = mysql_select_db($dbname);
	  if(!$db){
	  die('cannot communicate with the specified database ' .mysql_error());
	  
	  }
	  $day = 'MONDAY';
	  $time = '8am-10am';
	  $nd1msql ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs = mysql_query($nd1msql);
	  if(!$nd1msqlrs){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr=mysql_fetch_array($nd1msqlrs)){
	  echo  "<td>" . "NDI" . "</td>";
	  echo  "<td>" . $nd1mr['CODE']. "(" .$nd1mr['HALL']. ")" . "</td>";
	  }
	  ?>
	  
        <?php
		$day = 'MONDAY';
	  $time = '10am-12Pm';
	  $nd1msql2 ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs2 = mysql_query($nd1msql2);
	  if(!$nd1msqlrs2){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr2=mysql_fetch_array($nd1msqlrs2)){
	  
	  echo  "<td>" . $nd1mr2['CODE']. "(" .$nd1mr2['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
       $day = 'MONDAY';
	  $time = '12PM-1PM';
	  $nd1msql3 ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs3 = mysql_query($nd1msql3);
	  if(!$nd1msqlrs3){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr3=mysql_fetch_array($nd1msqlrs3)){
	  
	  echo  "<td>" . $nd1mr3['CODE']. "(" .$nd1mr3['HALL']. ")" . "</td>";
	  }
	  ?>
	   
        
        <td class="style13"><div align="center" class="style53">BREAK</div></td>
		<?PHP
		$day = 'MONDAY';
	  $time = '2PM-4PM';
	  $nd1msql4 ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs4 = mysql_query($nd1msql4);
	  if(!$nd1msqlrs4){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr4=mysql_fetch_array($nd1msqlrs4)){
	  
	  echo  "<td>" . $nd1mr4['CODE']. "(" .$nd1mr4['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
	  $day = 'MONDAY';
	  $time = '4PM-6PM';
	  $nd1msql5 ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs5 = mysql_query($nd1msql5);
	  if(!$nd1msqlrs5){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr5=mysql_fetch_array($nd1msqlrs5)){
	  
	  echo  "<td>" . $nd1mr5['CODE']. "(" .$nd1mr5['HALL']. ")" . "</td>";
	  }
	  ?>
      </tr>
      <tr>
	  <?PHP
	  $day = 'MONDAY';
	  $time = '8am-10am';
	  $nd2msql ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs = mysql_query($nd2msql);
	  if(!$nd2msqlrs){
	  die('error: ' . mysql_error());
	  }
	   echo  "<td>" . "NDII" . "</td>";
	  
	  while($nd2mr=mysql_fetch_array($nd2msqlrs)){
	 
	  
	  echo  "<td>" . $nd2mr['CODE']. "(" .$nd2mr['HALL']. ")" . "</td>";
	  }
	  
	  ?>
	  
        <?php
		$day = 'MONDAY';
	  $time = '10AM-12PM';
	  $nd2msql2 ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs2 = mysql_query($nd2msql2);
	  if(!$nd2msqlrs2){
	  die('error: ' . mysql_error());
	  }
	  while($nd2mr2=mysql_fetch_array($nd2msqlrs2)){
	  
	  echo  "<td>" . $nd2mr2['CODE']. "(" .$nd2mr2['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
       $day = 'MONDAY';
	  $time = '12PM-1PM';
	  $nd2msql3 ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs3 = mysql_query($nd2msql3);

	  if(!$nd2msqlrs3){
	  die('error: ' . mysql_error());
	  }
	  while($nd2mr3=mysql_fetch_array($nd2msqlrs3)){
	  
	  echo  "<td>" . $nd2mr3['CODE']. "(" .$nd2mr3['HALL']. ")" . "</td>";
	  }
	  ?>
	   
        
        <td class="style13"><div align="center" class="style53">BREAK</div></td>
		<?PHP
		$day = 'MONDAY';
	  $time = '2PM-4PM';
	  $nd2msql4 ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs4 = mysql_query($nd2msql4);
	  if(!$nd2msqlrs4){
	  die('error: ' . mysql_error());
	  }
	  while($nd2mr4=mysql_fetch_array($nd2msqlrs4)){
	  
	  echo  "<td>" . $nd2mr4['CODE']. "(" .$nd2mr4['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
	  $day = 'MONDAY';
	  $time = '4PM-6PM';
	  $nd2msql5 ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs5 = mysql_query($nd2msql5);
	  if(!$nd2msqlrs5){
	  die('error: ' . mysql_error());
	  }
	  while($nd2mr5=mysql_fetch_array($nd2msqlrs5)){
	  
	  echo  "<td>" . $nd2mr5['CODE']. "(" .$nd2mr5['HALL']. ")" . "</td>";
	  }
	  ?>
      </tr>
      <tr>
	   <?PHP
	  $day = 'MONDAY';
	  $time = '8am-10am';
	  $Hnd1msql ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs = mysql_query($Hnd1msql);
	  if(!$Hnd1msqlrs){
	  die('error: ' . mysql_error());
	  }
	   echo  "<td>" . "HNDI" . "</td>";
	 
	  
	  while($Hnd1mr=mysql_fetch_array($Hnd1msqlrs)){
	 
	  
	  echo  "<td>" . $Hnd1mr['CODE']. "(" .$Hnd1mr['HALL']. ")" . "</td>";
	  }
	  
	  ?>
	  
        <?php
		$day = 'MONDAY';
	  $time = '10AM-12PM';
	  $Hnd1msql2 ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs2 = mysql_query($Hnd1msql2);
	  if(!$Hnd1msqlrs2){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd1mr2=mysql_fetch_array($Hnd1msqlrs2)){
	  
	  echo  "<td>" . $Hnd1mr2['CODE']. "(" .$Hnd1mr2['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
       $day = 'MONDAY';
	  $time = '12PM-1PM';
	  $Hnd1msql3 ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs3 = mysql_query($Hnd1msql3);
	  if(!$Hnd1msqlrs3){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd1mr3=mysql_fetch_array($Hnd1msqlrs3)){
	  
	  echo  "<td>" . $Hnd1mr3['CODE']. "(" .$Hnd1mr3['HALL']. ")" . "</td>";
	  }
	  ?>
	   
        
        <td class="style15"><div align="center" class="style53">BREAK</div></td>
		<?PHP
		$day = 'MONDAY';
	  $time = '2PM-4PM';
	  $Hnd1msql4 ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs4 = mysql_query($Hnd1msql4);
	  if(!$Hnd1msqlrs4){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd1mr4=mysql_fetch_array($Hnd1msqlrs4)){
	  
	  echo  "<td>" . $Hnd1mr4['CODE']. "(" .$Hnd1mr4['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
	  $day = 'MONDAY';
	  $time = '4PM-6PM';
	  $Hnd1msql5 ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs5 = mysql_query($Hnd1msql5);
	  if(!$Hnd1msqlrs5){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd1mr5=mysql_fetch_array($Hnd1msqlrs5)){
	  
	  echo  "<td>" . $Hnd1mr5['CODE']. "(" .$Hnd1mr5['HALL']. ")" . "</td>";
	  }
	  ?>
      </tr>
      <tr>
	  <?PHP
	  $day = 'MONDAY';
	  $time = '8am-10am';
	  $Hnd2msql ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs = mysql_query($Hnd2msql);
	  if(!$Hnd2msqlrs){
	  die('error: ' . mysql_error());
	  }
	   echo  "<td>" . "HNDII" . "</td>";
	 
	  while($Hnd2mr=mysql_fetch_array($Hnd2msqlrs)){
	 
	  
	  echo  "<td>" . $Hnd2mr['CODE']. "(" .$Hnd2mr['HALL']. ")" . "</td>";
	  }
	 
	  ?>
	  
        <?php
		$day = 'MONDAY';
	  $time = '10AM-12PM';
	  $Hnd2msql2 ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs2 = mysql_query($Hnd2msql2);
	  if(!$Hnd2msqlrs2){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd2mr2=mysql_fetch_array($Hnd2msqlrs2)){
	  
	  echo  "<td>" . $Hnd2mr2['CODE']. "(" .$Hnd2mr2['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
       $day = 'MONDAY';
	  $time = '12PM-1PM';
	  $Hnd2msql3 ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs3 = mysql_query($Hnd2msql3);
	  if(!$Hnd2msqlrs3){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd2mr3=mysql_fetch_array($Hnd2msqlrs3)){
	  
	  echo  "<td>" . $Hnd2mr3['CODE']. "(" .$Hnd2mr3['HALL']. ")" . "</td>";
	  }
	  ?>
	   
        
        <td class="style17"><div align="center" class="style53">BREAK</div></td>
		<?PHP
		$day = 'MONDAY';
	  $time = '2PM-4PM';
	  $Hnd2msql4 ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs4 = mysql_query($Hnd2msql4);
	  if(!$Hnd2msqlrs4){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd2mr4=mysql_fetch_array($Hnd2msqlrs4)){
	  
	  echo  "<td>" . $Hnd2mr4['CODE']. "(" .$Hnd2mr4['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
	  $day = 'MONDAY';
	  $time = '4PM-6PM';
	  $Hnd2msql5 ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs5 = mysql_query($Hnd2msql5);
	  if(!$Hnd2msqlrs5){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd2mr5=mysql_fetch_array($Hnd2msqlrs5)){
	  
	  echo  "<td>" . $Hnd2mr5['CODE']. "(" .$Hnd2mr5['HALL']. ")" . "</td>";
	  }
	  ?>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td bgcolor="#FFFF33" class="style1 ">TUESDAY</td>
    <td><table width="200" height="123" border="1">
	<?php
	  $hostname = 'localhost';
	  $username = 'root';
	  $pword = '';
	  $dbname = 'timet';
	  $con = mysql_connect($hostname, $username, $pword);
	  if(!$con){
	  die('cannot connect to mysql ' . msql_error());
	  }
	  $db = mysql_select_db($dbname);
	  if(!$db){
	  die('cannot communicate with the specified database ' .mysql_error());
	  
	  }
	  $day = 'MONDAY';
	  $time = '8am-10am';
	  $nd1msql ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs = mysql_query($nd1msql);
	  if(!$nd1msqlrs){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr=mysql_fetch_array($nd1msqlrs)){
	  echo  "<td>" . "NDI" . "</td>";
	  echo    "<td>" . $nd1mr['CODE']. "(" .$nd1mr['HALL']. ")" . "</td>";
	  }
	  ?>
	  
        <?php
		$day = 'MONDAY';
	  $time = '10am-12Pm';
	  $nd1msql2 ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs2 = mysql_query($nd1msql2);
	  if(!$nd1msqlrs2){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr2=mysql_fetch_array($nd1msqlrs2)){
	  
	  echo  "<td>" . $nd1mr2['CODE']. "(" .$nd1mr2['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
       $day = 'MONDAY';
	  $time = '12PM-1PM';
	  $nd1msql3 ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs3 = mysql_query($nd1msql3);
	  if(!$nd1msqlrs3){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr3=mysql_fetch_array($nd1msqlrs3)){
	  
	  echo  "<td>" . $nd1mr3['CODE']. "(" .$nd1mr3['HALL']. ")" . "</td>";
	  }
	  ?>
	   
        
        <td class="style17"><div align="center" class="style53">BREAK</div></td>
		<?PHP
		$day = 'MONDAY';
	  $time = '2PM-4PM';
	  $nd1msql4 ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs4 = mysql_query($nd1msql4);
	  if(!$nd1msqlrs4){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr4=mysql_fetch_array($nd1msqlrs4)){
	  
	  echo  "<td>" . $nd1mr4['CODE']. "(" .$nd1mr4['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
	  $day = 'MONDAY';
	  $time = '4PM-6PM';
	  $nd1msql5 ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs5 = mysql_query($nd1msql5);
	  if(!$nd1msqlrs5){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr5=mysql_fetch_array($nd1msqlrs5)){
	  
	  echo  "<td>" . $nd1mr5['CODE']. "(" .$nd1mr5['HALL']. ")" . "</td>";
	  }
	  ?>
	  
 
  
      </tr>
      <tr>
	  <?PHP
	  $day = 'MONDAY';
	  $time = '8am-10am';
	  $nd2msql ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs = mysql_query($nd2msql);
	  if(!$nd2msqlrs){
	  die('error: ' . mysql_error());
	  }
	   echo  "<td>" . "NDII" . "</td>";
	  
	  while($nd2mr=mysql_fetch_array($nd2msqlrs)){
	 
	  
	  echo  "<td>" . $nd2mr['CODE']. "(" .$nd2mr['HALL']. ")" . "</td>";
	  }
	  
	  ?>
	  
        <?php
		$day = 'MONDAY';
	  $time = '10AM-12PM';
	  $nd2msql2 ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs2 = mysql_query($nd2msql2);
	  if(!$nd2msqlrs2){
	  die('error: ' . mysql_error());
	  }
	  while($nd2mr2=mysql_fetch_array($nd2msqlrs2)){
	  
	  echo  "<td>" . $nd2mr2['CODE']. "(" .$nd2mr2['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
       $day = 'MONDAY';
	  $time = '12PM-1PM';
	  $nd2msql3 ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs3 = mysql_query($nd2msql3);
	  if(!$nd2msqlrs3){
	  die('error: ' . mysql_error());
	  }
	  while($nd2mr3=mysql_fetch_array($nd2msqlrs3)){
	  
	  echo  "<td>" . $nd2mr3['CODE']. "(" .$nd2mr3['HALL']. ")" . "</td>";
	  }
	  ?>
	   
        
        <td class="style21"><div align="center" class="style53">BREAK</div></td>
		<?PHP
		$day = 'MONDAY';
	  $time = '2PM-4PM';
	  $nd2msql4 ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs4 = mysql_query($nd2msql4);
	  if(!$nd2msqlrs4){
	  die('error: ' . mysql_error());
	  }
	  while($nd2mr4=mysql_fetch_array($nd2msqlrs4)){
	  
	  echo  "<td>" . $nd2mr4['CODE']. "(" .$nd2mr4['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
	  $day = 'MONDAY';
	  $time = '4PM-6PM';
	  $nd2msql5 ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs5 = mysql_query($nd2msql5);
	  if(!$nd2msqlrs5){
	  die('error: ' . mysql_error());
	  }
	  while($nd2mr5=mysql_fetch_array($nd2msqlrs5)){
	  
	  echo  "<td>" . $nd2mr5['CODE']. "(" .$nd2mr5['HALL']. ")" . "</td>";
	  }
	  ?>
      </tr>
      <tr>
	   <?PHP
	  $day = 'MONDAY';
	  $time = '8am-10am';
	  $Hnd1msql ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs = mysql_query($Hnd1msql);
	  if(!$Hnd1msqlrs){
	  die('error: ' . mysql_error());
	  }
	   echo  "<td>" . "HNDI" . "</td>";
	 
	  
	  while($Hnd1mr=mysql_fetch_array($Hnd1msqlrs)){
	 
	  
	  echo  "<td>" . $Hnd1mr['CODE']. "(" .$Hnd1mr['HALL']. ")" . "</td>";
	  }
	  
	  ?>
	  
        <?php
		$day = 'MONDAY';
	  $time = '10AM-12PM';
	  $Hnd1msql2 ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs2 = mysql_query($Hnd1msql2);
	  if(!$Hnd1msqlrs2){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd1mr2=mysql_fetch_array($Hnd1msqlrs2)){
	  
	  echo  "<td>" . $Hnd1mr2['CODE']. "(" .$Hnd1mr2['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
       $day = 'MONDAY';
	  $time = '12PM-1PM';
	  $Hnd1msql3 ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs3 = mysql_query($Hnd1msql3);
	  if(!$Hnd1msqlrs3){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd1mr3=mysql_fetch_array($Hnd1msqlrs3)){
	  
	  echo  "<td>" . $Hnd1mr3['CODE']. "(" .$Hnd1mr3['HALL']. ")" . "</td>";
	  }
	  ?>
	   
        
        <td class="style23"><div align="center" class="style53">BREAK</div></td>
		<?PHP
		$day = 'MONDAY';
	  $time = '2PM-4PM';
	  $Hnd1msql4 ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs4 = mysql_query($Hnd1msql4);
	  if(!$Hnd1msqlrs4){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd1mr4=mysql_fetch_array($Hnd1msqlrs4)){
	  
	  echo  "<td>" . $Hnd1mr4['CODE']. "(" .$Hnd1mr4['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
	  $day = 'MONDAY';
	  $time = '4PM-6PM';
	  $Hnd1msql5 ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs5 = mysql_query($Hnd1msql5);
	  if(!$Hnd1msqlrs5){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd1mr5=mysql_fetch_array($Hnd1msqlrs5)){
	  
	  echo  "<td>" . $Hnd1mr5['CODE']. "(" .$Hnd1mr5['HALL']. ")" . "</td>";
	  }
	  ?>
      </tr>
      <tr>
	  <?PHP
	  $day = 'MONDAY';
	  $time = '8am-10am';
	  $Hnd2msql ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs = mysql_query($Hnd2msql);
	  if(!$Hnd2msqlrs){
	  die('error: ' . mysql_error());
	  }
	   echo  "<td>" . "HNDII" . "</td>";
	 
	  while($Hnd2mr=mysql_fetch_array($Hnd2msqlrs)){
	 
	  
	  echo  "<td>" . $Hnd2mr['CODE']. "(" .$Hnd2mr['HALL']. ")" . "</td>";
	  }
	 
	  ?>
	  
        <?php
		$day = 'MONDAY';
	  $time = '10AM-12PM';
	  $Hnd2msql2 ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs2 = mysql_query($Hnd2msql2);
	  if(!$Hnd2msqlrs2){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd2mr2=mysql_fetch_array($Hnd2msqlrs2)){
	  
	  echo  "<td>" . $Hnd2mr2['CODE']. "(" .$Hnd2mr2['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
       $day = 'MONDAY';
	  $time = '12PM-1PM';
	  $Hnd2msql3 ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs3 = mysql_query($Hnd2msql3);
	  if(!$Hnd2msqlrs3){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd2mr3=mysql_fetch_array($Hnd2msqlrs3)){
	  
	  echo  "<td>" . $Hnd2mr3['CODE']. "(" .$Hnd2mr3['HALL']. ")" . "</td>";
	  }
	  ?>
	   
        
        <td class="style13"><div align="center" class="style53">BREAK</div></td>
		<?PHP
		$day = 'MONDAY';
	  $time = '2PM-4PM';
	  $Hnd2msql4 ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs4 = mysql_query($Hnd2msql4);
	  if(!$Hnd2msqlrs4){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd2mr4=mysql_fetch_array($Hnd2msqlrs4)){
	  
	  echo  "<td>" . $Hnd2mr4['CODE']. "(" .$Hnd2mr4['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
	  $day = 'MONDAY';
	  $time = '4PM-6PM';
	  $Hnd2msql5 ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs5 = mysql_query($Hnd2msql5);
	  if(!$Hnd2msqlrs5){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd2mr5=mysql_fetch_array($Hnd2msqlrs5)){
	  
	  echo  "<td>" . $Hnd2mr5['CODE']. "(" .$Hnd2mr5['HALL']. ")" . "</td>";
	  }
	  ?>
    </table></td>
  </tr>
  <tr>
    <td bgcolor="#00FFFF" class="style1">WEDNESDAY</td>
    <td><table width="262" height="123" border="1">
	<?php
	  $hostname = 'localhost';
	  $username = 'root';
	  $pword = '';
	  $dbname = 'timet';
	  $con = mysql_connect($hostname, $username, $pword);
	  if(!$con){
	  die('cannot connect to mysql ' . msql_error());
	  }
	  $db = mysql_select_db($dbname);
	  if(!$db){
	  die('cannot communicate with the specified database ' .mysql_error());
	  
	  }
	  $day = 'MONDAY';
	  $time = '8am-10am';
	  $nd1msql ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs = mysql_query($nd1msql);
	  if(!$nd1msqlrs){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr=mysql_fetch_array($nd1msqlrs)){
	  echo  "<td>" . "NDI" . "</td>";
	  echo  "<td>" . $nd1mr['CODE']. "(" .$nd1mr['HALL']. ")" . "</td>";
	  }
	  ?>
	  
        <?php
		$day = 'MONDAY';
	  $time = '10am-12Pm';
	  $nd1msql2 ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs2 = mysql_query($nd1msql2);
	  if(!$nd1msqlrs2){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr2=mysql_fetch_array($nd1msqlrs2)){
	  
	  echo  "<td>" . $nd1mr2['CODE']. "(" .$nd1mr2['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
       $day = 'MONDAY';
	  $time = '12PM-1PM';
	  $nd1msql3 ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs3 = mysql_query($nd1msql3);
	  if(!$nd1msqlrs3){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr3=mysql_fetch_array($nd1msqlrs3)){
	  
	  echo  "<td>" . $nd1mr3['CODE']. "(" .$nd1mr3['HALL']. ")" . "</td>";
	  }
	  ?>
	   
        
        <td width="252" class="style25"><div align="center" class="style53">BREAK</div></td>
		<?PHP
		$day = 'MONDAY';
	  $time = '2PM-4PM';
	  $nd1msql4 ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs4 = mysql_query($nd1msql4);
	  if(!$nd1msqlrs4){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr4=mysql_fetch_array($nd1msqlrs4)){
	  
	  echo  "<td>" . $nd1mr4['CODE']. "(" .$nd1mr4['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
	  $day = 'MONDAY';
	  $time = '4PM-6PM';
	  $nd1msql5 ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs5 = mysql_query($nd1msql5);
	  if(!$nd1msqlrs5){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr5=mysql_fetch_array($nd1msqlrs5)){
	  
	  echo  "<td>" . $nd1mr5['CODE']. "(" .$nd1mr5['HALL']. ")" . "</td>";
	  }
	  ?>
	  
 
  
      </tr>
      <tr>
	  <?PHP
	  $day = 'MONDAY';
	  $time = '8am-10am';
	  $nd2msql ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs = mysql_query($nd2msql);
	  if(!$nd2msqlrs){
	  die('error: ' . mysql_error());
	  }
	   echo  "<td>" . "NDII" . "</td>";
	  
	  while($nd2mr=mysql_fetch_array($nd2msqlrs)){
	 
	  
	  echo  "<td>" . $nd2mr['CODE']. "(" .$nd2mr['HALL']. ")" . "</td>";
	  }
	  
	  ?>
	  
        <?php
		$day = 'MONDAY';
	  $time = '10AM-12PM';
	  $nd2msql2 ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs2 = mysql_query($nd2msql2);
	  if(!$nd2msqlrs2){
	  die('error: ' . mysql_error());
	  }
	  while($nd2mr2=mysql_fetch_array($nd2msqlrs2)){
	  
	  echo  "<td>" . $nd2mr2['CODE']. "(" .$nd2mr2['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
       $day = 'MONDAY';
	  $time = '12PM-1PM';
	  $nd2msql3 ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs3 = mysql_query($nd2msql3);
	  if(!$nd2msqlrs3){
	  die('error: ' . mysql_error());
	  }
	  while($nd2mr3=mysql_fetch_array($nd2msqlrs3)){
	  
	  echo  "<td>" . $nd2mr3['CODE']. "(" .$nd2mr3['HALL']. ")" . "</td>";
	  }
	  ?>
	   
        
        <td class="style29"><div align="center" class="style53">BREAK</div></td>
		<?PHP
		$day = 'MONDAY';
	  $time = '2PM-4PM';
	  $nd2msql4 ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs4 = mysql_query($nd2msql4);
	  if(!$nd2msqlrs4){
	  die('error: ' . mysql_error());
	  }
	  while($nd2mr4=mysql_fetch_array($nd2msqlrs4)){
	  
	  echo  "<td>" . $nd2mr4['CODE']. "(" .$nd2mr4['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
	  $day = 'MONDAY';
	  $time = '4PM-6PM';
	  $nd2msql5 ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs5 = mysql_query($nd2msql5);
	  if(!$nd2msqlrs5){
	  die('error: ' . mysql_error());
	  }
	  while($nd2mr5=mysql_fetch_array($nd2msqlrs5)){
	  
	  echo  "<td>" . $nd2mr5['CODE']. "(" .$nd2mr5['HALL']. ")" . "</td>";
	  }
	  ?>
      </tr>
      <tr>
	   <?PHP
	  $day = 'MONDAY';
	  $time = '8am-10am';
	  $Hnd1msql ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs = mysql_query($Hnd1msql);
	  if(!$Hnd1msqlrs){
	  die('error: ' . mysql_error());
	  }
	   echo  "<td>" . "HNDI" . "</td>";
	 
	  
	  while($Hnd1mr=mysql_fetch_array($Hnd1msqlrs)){
	 
	  
	  echo  "<td>" . $Hnd1mr['CODE']. "(" .$Hnd1mr['HALL']. ")" . "</td>";
	  }
	  
	  ?>
	  
        <?php
		$day = 'MONDAY';
	  $time = '10AM-12PM';
	  $Hnd1msql2 ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs2 = mysql_query($Hnd1msql2);
	  if(!$Hnd1msqlrs2){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd1mr2=mysql_fetch_array($Hnd1msqlrs2)){
	  
	  echo  "<td>" . $Hnd1mr2['CODE']. "(" .$Hnd1mr2['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
       $day = 'MONDAY';
	  $time = '12PM-1PM';
	  $Hnd1msql3 ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs3 = mysql_query($Hnd1msql3);
	  if(!$Hnd1msqlrs3){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd1mr3=mysql_fetch_array($Hnd1msqlrs3)){
	  
	  echo  "<td>" . $Hnd1mr3['CODE']. "(" .$Hnd1mr3['HALL']. ")" . "</td>";
	  }
	  ?>
	   
        
        <td class="style31"><div align="center" class="style53">BREAK</div></td>
		<?PHP
		$day = 'MONDAY';
	  $time = '2PM-4PM';
	  $Hnd1msql4 ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs4 = mysql_query($Hnd1msql4);
	  if(!$Hnd1msqlrs4){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd1mr4=mysql_fetch_array($Hnd1msqlrs4)){
	  
	  echo  "<td>" . $Hnd1mr4['CODE']. "(" .$Hnd1mr4['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
	  $day = 'MONDAY';
	  $time = '4PM-6PM';
	  $Hnd1msql5 ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs5 = mysql_query($Hnd1msql5);
	  if(!$Hnd1msqlrs5){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd1mr5=mysql_fetch_array($Hnd1msqlrs5)){
	  
	  echo  "<td>" . $Hnd1mr5['CODE']. "(" .$Hnd1mr5['HALL']. ")" . "</td>";
	  }
	  ?>
      </tr>
      <tr>
	  <?PHP
	  $day = 'MONDAY';
	  $time = '8am-10am';
	  $Hnd2msql ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs = mysql_query($Hnd2msql);
	  if(!$Hnd2msqlrs){
	  die('error: ' . mysql_error());
	  }
	   echo  "<td>" . "HNDII" . "</td>";
	 
	  while($Hnd2mr=mysql_fetch_array($Hnd2msqlrs)){
	 
	  
	  echo  "<td>" . $Hnd2mr['CODE']. "(" .$Hnd2mr['HALL']. ")" . "</td>";
	  }
	 
	  ?>
	  
        <?php
		$day = 'MONDAY';
	  $time = '10AM-12PM';
	  $Hnd2msql2 ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs2 = mysql_query($Hnd2msql2);
	  if(!$Hnd2msqlrs2){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd2mr2=mysql_fetch_array($Hnd2msqlrs2)){
	  
	  echo  "<td>" . $Hnd2mr2['CODE']. "(" .$Hnd2mr2['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
       $day = 'MONDAY';
	  $time = '12PM-1PM';
	  $Hnd2msql3 ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs3 = mysql_query($Hnd2msql3);
	  if(!$Hnd2msqlrs3){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd2mr3=mysql_fetch_array($Hnd2msqlrs3)){
	  
	  echo  "<td>" . $Hnd2mr3['CODE']. "(" .$Hnd2mr3['HALL']. ")" . "</td>";
	  }
	  ?>
	   
        
        <td class="style33"><div align="center" class="style53">BREAK</div></td>
		<?PHP
		$day = 'MONDAY';
	  $time = '2PM-4PM';
	  $Hnd2msql4 ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs4 = mysql_query($Hnd2msql4);
	  if(!$Hnd2msqlrs4){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd2mr4=mysql_fetch_array($Hnd2msqlrs4)){
	  
	  echo  "<td>" . $Hnd2mr4['CODE']. "(" .$Hnd2mr4['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
	  $day = 'MONDAY';
	  $time = '4PM-6PM';
	  $Hnd2msql5 ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs5 = mysql_query($Hnd2msql5);
	  if(!$Hnd2msqlrs5){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd2mr5=mysql_fetch_array($Hnd2msqlrs5)){
	  
	  echo  "<td>" . $Hnd2mr5['CODE']. "(" .$Hnd2mr5['HALL']. ")" . "</td>";
	  }
	  ?>
    </table></td>
  </tr>
  <tr>
    <td bgcolor="#999999" class="style1">THURSDAY</td>
    <td><table width="263" height="123" border="1">
	<?php
	  $hostname = 'localhost';
	  $username = 'root';
	  $pword = '';
	  $dbname = 'timet';
	  $con = mysql_connect($hostname, $username, $pword);
	  if(!$con){
	  die('cannot connect to mysql ' . msql_error());
	  }
	  $db = mysql_select_db($dbname);
	  if(!$db){
	  die('cannot communicate with the specified database ' .mysql_error());
	  
	  }
	  $day = 'THURSDAY';
	  $time = '8am-10am';
	  $nd1msql ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs = mysql_query($nd1msql);
	  if(!$nd1msqlrs){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr=mysql_fetch_array($nd1msqlrs)){
	  echo  "<td>" . "NDI" . "</td>";
	  echo  "<td>" . $nd1mr['CODE']. "(" .$nd1mr['HALL']. ")" . "</td>";
	  }
	  ?>
	  
        <?php
		$day = 'THURSDAY';
	  $time = '10am-12Pm';
	  $nd1msql2 ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs2 = mysql_query($nd1msql2);
	  if(!$nd1msqlrs2){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr2=mysql_fetch_array($nd1msqlrs2)){
	  
	  echo  "<td>" . $nd1mr2['CODE']. "(" .$nd1mr2['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
       $day = 'THURSDAY';
	  $time = '12PM-1PM';
	  $nd1msql3 ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs3 = mysql_query($nd1msql3);
	  if(!$nd1msqlrs3){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr3=mysql_fetch_array($nd1msqlrs3)){
	  
	  echo  "<td>" . $nd1mr3['CODE']. "(" .$nd1mr3['HALL']. ")" . "</td>";
	  }
	  ?>
	   
        
        <td width="253" class="style33"><div align="center" class="style53">BREAK</div></td>
		<?PHP
		$day = 'THURSDAY';
	  $time = '2PM-4PM';
	  $nd1msql4 ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs4 = mysql_query($nd1msql4);
	  if(!$nd1msqlrs4){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr4=mysql_fetch_array($nd1msqlrs4)){
	  
	  echo  "<td>" . $nd1mr4['CODE']. "(" .$nd1mr4['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
	  $day = 'THURSDAY';
	  $time = '4PM-6PM';
	  $nd1msql5 ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs5 = mysql_query($nd1msql5);
	  if(!$nd1msqlrs5){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr5=mysql_fetch_array($nd1msqlrs5)){
	  
	  echo  "<td>" . $nd1mr5['CODE']. "(" .$nd1mr5['HALL']. ")" . "</td>";
	  }
	  ?>
	  
 
  
      </tr>
      <tr>
	  <?PHP
	  $day = 'THURSDAY';
	  $time = '8am-10am';
	  $nd2msql ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs = mysql_query($nd2msql);
	  if(!$nd2msqlrs){
	  die('error: ' . mysql_error());
	  }
	   echo  "<td>" . "NDII" . "</td>";
	  
	  while($nd2mr=mysql_fetch_array($nd2msqlrs)){
	 
	  
	  echo  "<td>" . $nd2mr['CODE']. "(" .$nd2mr['HALL']. ")" . "</td>";
	  }
	  
	  ?>
	  
        <?php
		$day = 'THURSDAY';
	  $time = '10AM-12PM';
	  $nd2msql2 ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs2 = mysql_query($nd2msql2);
	  if(!$nd2msqlrs2){
	  die('error: ' . mysql_error());
	  }
	  while($nd2mr2=mysql_fetch_array($nd2msqlrs2)){
	  
	  echo  "<td>" . $nd2mr2['CODE']. "(" .$nd2mr2['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
       $day = 'THURSDAY';
	  $time = '12PM-1PM';
	  $nd2msql3 ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs3 = mysql_query($nd2msql3);
	  if(!$nd2msqlrs3){
	  die('error: ' . mysql_error());
	  }
	  while($nd2mr3=mysql_fetch_array($nd2msqlrs3)){
	  
	  echo  "<td>" . $nd2mr3['CODE']. "(" .$nd2mr3['HALL']. ")" . "</td>";
	  }
	  ?>
	   
        
        <td class="style37"><div align="center" class="style53">BREAK</div></td>
		<?PHP
		$day = 'THURSDAY';
	  $time = '2PM-4PM';
	  $nd2msql4 ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs4 = mysql_query($nd2msql4);
	  if(!$nd2msqlrs4){
	  die('error: ' . mysql_error());
	  }
	  while($nd2mr4=mysql_fetch_array($nd2msqlrs4)){
	  
	  echo  "<td>" . $nd2mr4['CODE']. "(" .$nd2mr4['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
	  $day = 'THURSDAY';
	  $time = '4PM-6PM';
	  $nd2msql5 ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs5 = mysql_query($nd2msql5);
	  if(!$nd2msqlrs5){
	  die('error: ' . mysql_error());
	  }
	  while($nd2mr5=mysql_fetch_array($nd2msqlrs5)){
	  
	  echo  "<td>" . $nd2mr5['CODE']. "(" .$nd2mr5['HALL']. ")" . "</td>";
	  }
	  ?>
      </tr>
      <tr>
	   <?PHP
	  $day = 'THURSDAY';
	  $time = '8am-10am';
	  $Hnd1msql ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs = mysql_query($Hnd1msql);
	  if(!$Hnd1msqlrs){
	  die('error: ' . mysql_error());
	  }
	   echo  "<td>" . "HNDI" . "</td>";
	 
	  
	  while($Hnd1mr=mysql_fetch_array($Hnd1msqlrs)){
	 
	  
	  echo  "<td>" . $Hnd1mr['CODE']. "(" .$Hnd1mr['HALL']. ")" . "</td>";
	  }
	  
	  ?>
	  
        <?php
		$day = 'THURSDAY';
	  $time = '10AM-12PM';
	  $Hnd1msql2 ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs2 = mysql_query($Hnd1msql2);
	  if(!$Hnd1msqlrs2){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd1mr2=mysql_fetch_array($Hnd1msqlrs2)){
	  
	  echo  "<td>" . $Hnd1mr2['CODE']. "(" .$Hnd1mr2['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
       $day = 'THURSDAY';
	  $time = '12PM-1PM';
	  $Hnd1msql3 ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs3 = mysql_query($Hnd1msql3);
	  if(!$Hnd1msqlrs3){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd1mr3=mysql_fetch_array($Hnd1msqlrs3)){
	  
	  echo  "<td>" . $Hnd1mr3['CODE']. "(" .$Hnd1mr3['HALL']. ")" . "</td>";
	  }
	  ?>
	   
        
        <td class="style39"><div align="center" class="style53">BREAK</div></td>
		<?PHP
		$day = 'THURSDAY';
	  $time = '2PM-4PM';
	  $Hnd1msql4 ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs4 = mysql_query($Hnd1msql4);
	  if(!$Hnd1msqlrs4){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd1mr4=mysql_fetch_array($Hnd1msqlrs4)){
	  
	  echo  "<td>" . $Hnd1mr4['CODE']. "(" .$Hnd1mr4['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
	  $day = 'THURSDAY';
	  $time = '4PM-6PM';
	  $Hnd1msql5 ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs5 = mysql_query($Hnd1msql5);
	  if(!$Hnd1msqlrs5){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd1mr5=mysql_fetch_array($Hnd1msqlrs5)){
	  
	  echo  "<td>" . $Hnd1mr5['CODE']. "(" .$Hnd1mr5['HALL']. ")" . "</td>";
	  }
	  ?>
      </tr>
      <tr>
	  <?PHP
	  $day = 'THURSDAY';
	  $time = '8am-10am';
	  $Hnd2msql ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs = mysql_query($Hnd2msql);
	  if(!$Hnd2msqlrs){
	  die('error: ' . mysql_error());
	  }
	   echo  "<td>" . "HNDII" . "</td>";
	 
	  while($Hnd2mr=mysql_fetch_array($Hnd2msqlrs)){
	 
	  
	  echo  "<td>" . $Hnd2mr['CODE']. "(" .$Hnd2mr['HALL']. ")" . "</td>";
	  }
	 
	  ?>
	  
        <?php
		$day = 'THURSDAY';
	  $time = '10AM-12PM';
	  $Hnd2msql2 ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs2 = mysql_query($Hnd2msql2);
	  if(!$Hnd2msqlrs2){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd2mr2=mysql_fetch_array($Hnd2msqlrs2)){
	  
	  echo  "<td>" . $Hnd2mr2['CODE']. "(" .$Hnd2mr2['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
       $day = 'THURSDAY';
	  $time = '12PM-1PM';
	  $Hnd2msql3 ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs3 = mysql_query($Hnd2msql3);
	  if(!$Hnd2msqlrs3){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd2mr3=mysql_fetch_array($Hnd2msqlrs3)){
	  
	  echo  "<td>" . $Hnd2mr3['CODE']. "(" .$Hnd2mr3['HALL']. ")" . "</td>";
	  }
	  ?>
	   
        
        <td class="style41"><div align="center" class="style53">BREAK</div></td>
		<?PHP
		$day = 'THURSDAY';
	  $time = '2PM-4PM';
	  $Hnd2msql4 ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs4 = mysql_query($Hnd2msql4);
	  if(!$Hnd2msqlrs4){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd2mr4=mysql_fetch_array($Hnd2msqlrs4)){
	  
	  echo  "<td>" . $Hnd2mr4['CODE']. "(" .$Hnd2mr4['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
	  $day = 'THURSDAY';
	  $time = '4PM-6PM';
	  $Hnd2msql5 ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs5 = mysql_query($Hnd2msql5);
	  if(!$Hnd2msqlrs5){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd2mr5=mysql_fetch_array($Hnd2msqlrs5)){
	  
	  echo  "<td>" . $Hnd2mr5['CODE']. "(" .$Hnd2mr5['HALL']. ")" . "</td>";
	  }
	  ?>
	 </table></td>
  </tr>
  <tr>
    <td bgcolor="#006699" class="style1">FRIDAY</td>
    <td><table width="265" height="123" border="1">
	<?php
	  $hostname = 'localhost';
	  $username = 'root';
	  $pword = '';
	  $dbname = 'timet';
	  $con = mysql_connect($hostname, $username, $pword);
	  if(!$con){
	  die('cannot connect to mysql ' . msql_error());
	  }
	  $db = mysql_select_db($dbname);
	  if(!$db){
	  die('cannot communicate with the specified database ' .mysql_error());
	  
	  }
	  $day = 'FRIDAY';
	  $time = '8am-10am';
	  $nd1msql ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs = mysql_query($nd1msql);
	  if(!$nd1msqlrs){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr=mysql_fetch_array($nd1msqlrs)){
	  echo  "<td>" . "NDI" . "</td>";
	  echo  "<td>" . $nd1mr['CODE']. "(" .$nd1mr['HALL']. ")" . "</td>";
	  }
	  ?>
	  
        <?php
		$day = 'FRIDAY';
	  $time = '10am-12Pm';
	  $nd1msql2 ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs2 = mysql_query($nd1msql2);
	  if(!$nd1msqlrs2){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr2=mysql_fetch_array($nd1msqlrs2)){
	  
	  echo  "<td>" . $nd1mr2['CODE']. "(" .$nd1mr2['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
       $day = 'FRIDAY';
	  $time = '12PM-1PM';
	  $nd1msql3 ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs3 = mysql_query($nd1msql3);
	  if(!$nd1msqlrs3){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr3=mysql_fetch_array($nd1msqlrs3)){
	  
	  echo  "<td>" . $nd1mr3['CODE']. "(" .$nd1mr3['HALL']. ")" . "</td>";
	  }
	  ?>
	   
        
        <td width="255" class="style41"><div align="center" class="style53">BREAK</div></td>
		<?PHP
		$day = 'FRIDAY';
	  $time = '2PM-4PM';
	  $nd1msql4 ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs4 = mysql_query($nd1msql4);
	  if(!$nd1msqlrs4){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr4=mysql_fetch_array($nd1msqlrs4)){
	  
	  echo  "<td>" . $nd1mr4['CODE']. "(" .$nd1mr4['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
	  $day = 'FRIDAY';
	  $time = '4PM-6PM';
	  $nd1msql5 ="select * from NDi WHERE DAY = '$day' && time = '$time'";
	  $nd1msqlrs5 = mysql_query($nd1msql5);
	  if(!$nd1msqlrs5){
	  die('error: ' . mysql_error());
	  }
	  while($nd1mr5=mysql_fetch_array($nd1msqlrs5)){
	  
	  echo  "<td>" . $nd1mr5['CODE']. "(" .$nd1mr5['HALL']. ")" . "</td>";
	  }
	  ?>
	  
 
  
      </tr>
      <tr>
	  <?PHP
	  $day = 'FRIDAY';
	  $time = '8am-10am';
	  $nd2msql ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs = mysql_query($nd2msql);
	  if(!$nd2msqlrs){
	  die('error: ' . mysql_error());
	  }
	   echo  "<td>" . "NDII" . "</td>";
	  
	  while($nd2mr=mysql_fetch_array($nd2msqlrs)){
	 
	  
	  echo  "<td>" . $nd2mr['CODE']. "(" .$nd2mr['HALL']. ")" . "</td>";
	  }
	  
	  ?>
	  
        <?php
		$day = 'FRIDAY';
	  $time = '10AM-12PM';
	  $nd2msql2 ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs2 = mysql_query($nd2msql2);
	  if(!$nd2msqlrs2){
	  die('error: ' . mysql_error());
	  }
	  while($nd2mr2=mysql_fetch_array($nd2msqlrs2)){
	  
	  echo  "<td>" . $nd2mr2['CODE']. "(" .$nd2mr2['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
       $day = 'FRIDAY';
	  $time = '12PM-1PM';
	  $nd2msql3 ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs3 = mysql_query($nd2msql3);
	  if(!$nd2msqlrs3){
	  die('error: ' . mysql_error());
	  }
	  while($nd2mr3=mysql_fetch_array($nd2msqlrs3)){
	  
	  echo  "<td>" . $nd2mr3['CODE']. "(" .$nd2mr3['HALL']. ")" . "</td>";
	  }
	  ?>
	   
        
        <td class="style45"><div align="center" class="style53">BREAK</div></td>
		<?PHP
		$day = 'MONDAY';
	  $time = '2PM-4PM';
	  $nd2msql4 ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs4 = mysql_query($nd2msql4);
	  if(!$nd2msqlrs4){
	  die('error: ' . mysql_error());
	  }
	  while($nd2mr4=mysql_fetch_array($nd2msqlrs4)){
	  
	  echo  "<td>" . $nd2mr4['CODE']. "(" .$nd2mr4['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
	  $day = 'MONDAY';
	  $time = '4PM-6PM';
	  $nd2msql5 ="select * from NDii WHERE DAY = '$day' && time = '$time'";
	  $nd2msqlrs5 = mysql_query($nd2msql5);
	  if(!$nd2msqlrs5){
	  die('error: ' . mysql_error());
	  }
	  while($nd2mr5=mysql_fetch_array($nd2msqlrs5)){
	  
	  echo  "<td>" . $nd2mr5['CODE']. "(" .$nd2mr5['HALL']. ")" . "</td>";
	  }
	  ?>
      </tr>
      <tr>
	   <?PHP
	  $day = 'FRIDAY';
	  $time = '8am-10am';
	  $Hnd1msql ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs = mysql_query($Hnd1msql);
	  if(!$Hnd1msqlrs){
	  die('error: ' . mysql_error());
	  }
	   echo  "<td>" . "HNDI" . "</td>";
	 
	  
	  while($Hnd1mr=mysql_fetch_array($Hnd1msqlrs)){
	 
	  
	  echo  "<td>" . $Hnd1mr['CODE']. "(" .$Hnd1mr['HALL']. ")" . "</td>";
	  }
	  
	  ?>
	  
        <?php
		$day = 'FRIDAY';
	  $time = '10AM-12PM';
	  $Hnd1msql2 ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs2 = mysql_query($Hnd1msql2);
	  if(!$Hnd1msqlrs2){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd1mr2=mysql_fetch_array($Hnd1msqlrs2)){
	  
	  echo  "<td>" . $Hnd1mr2['CODE']. "(" .$Hnd1mr2['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
       $day = 'FRIDAY';
	  $time = '12PM-1PM';
	  $Hnd1msql3 ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs3 = mysql_query($Hnd1msql3);
	  if(!$Hnd1msqlrs3){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd1mr3=mysql_fetch_array($Hnd1msqlrs3)){
	  
	  echo  "<td>" . $Hnd1mr3['CODE']. "(" .$Hnd1mr3['HALL']. ")" . "</td>";
	  }
	  ?>
	   
        
        <td class="style47"><div align="center" class="style53">BREAK</div></td>
		<?PHP
		$day = 'FRIDAY';
	  $time = '2PM-4PM';
	  $Hnd1msql4 ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs4 = mysql_query($Hnd1msql4);
	  if(!$Hnd1msqlrs4){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd1mr4=mysql_fetch_array($Hnd1msqlrs4)){
	  
	  echo  "<td>" . $Hnd1mr4['CODE']. "(" .$Hnd1mr4['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
	  $day = 'FRIDAY';
	  $time = '4PM-6PM';
	  $Hnd1msql5 ="select * from HNDi WHERE DAY = '$day' && time = '$time'";
	  $Hnd1msqlrs5 = mysql_query($Hnd1msql5);
	  if(!$Hnd1msqlrs5){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd1mr5=mysql_fetch_array($Hnd1msqlrs5)){
	  
	  echo  "<td>" . $Hnd1mr5['CODE']. "(" .$Hnd1mr5['HALL']. ")" . "</td>";
	  }
	  ?>
      </tr>
      <tr>
	  <?PHP
	  $day = 'FRIDAY';
	  $time = '8am-10am';
	  $Hnd2msql ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs = mysql_query($Hnd2msql);
	  if(!$Hnd2msqlrs){
	  die('error: ' . mysql_error());
	  }
	   echo  "<td>" . "HNDII" . "</td>";
	 
	  while($Hnd2mr=mysql_fetch_array($Hnd2msqlrs)){
	 
	  
	  echo  "<td>" . $Hnd2mr['CODE']. "(" .$Hnd2mr['HALL']. ")" . "</td>";
	  }
	 
	  ?>
	  
        <?php
		$day = 'FRIDAY';
	  $time = '10AM-12PM';
	  $Hnd2msql2 ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs2 = mysql_query($Hnd2msql2);
	  if(!$Hnd2msqlrs2){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd2mr2=mysql_fetch_array($Hnd2msqlrs2)){
	  
	  echo  "<td>" . $Hnd2mr2['CODE']. "(" .$Hnd2mr2['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
       $day = 'FRIDAY';
	  $time = '12PM-1PM';
	  $Hnd2msql3 ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs3 = mysql_query($Hnd2msql3);
	  if(!$Hnd2msqlrs3){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd2mr3=mysql_fetch_array($Hnd2msqlrs3)){
	  
	  echo  "<td>" . $Hnd2mr3['CODE']. "(" .$Hnd2mr3['HALL']. ")" . "</td>";
	  }
	  ?>
	   
        
        <td class="style49"><div align="center" class="style53">BREAK</div></td>
		<?PHP
		$day = 'FRIDAY';
	  $time = '2PM-4PM';
	  $Hnd2msql4 ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs4 = mysql_query($Hnd2msql4);
	  if(!$Hnd2msqlrs4){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd2mr4=mysql_fetch_array($Hnd2msqlrs4)){
	  
	  echo  "<td>" . $Hnd2mr4['CODE']. "(" .$Hnd2mr4['HALL']. ")" . "</td>";
	  }
	  ?>
	  <?PHP
	  $day = 'FRIDAY';
	  $time = '4PM-6PM';
	  $Hnd2msql5 ="select * from HNDii WHERE DAY = '$day' && time = '$time'";
	  $Hnd2msqlrs5 = mysql_query($Hnd2msql5);
	  if(!$Hnd2msqlrs5){
	  die('error: ' . mysql_error());
	  }
	  while($Hnd2mr5=mysql_fetch_array($Hnd2msqlrs5)){
	  
	  echo  "<td>" . $Hnd2mr5['CODE']. "(" .$Hnd2mr5['HALL']. ")" . "</td>";
	  }
	  ?>
    </table></td>
  </tr>
</table>
 	
</div>

<div id="footer">
<div id="footer_content">
<div id="copyrights">
Timetable Solution.&copy; All Rights Reserved Group Four 2012/2013
</div>
	<div>
                    <ul class="footer_menu">
                        <li><a href="#" class="nav2">home </a></li>
                        <li><a href="#" class="nav2">Admin</a></li>
                        <li><a href="#" class="nav2">Timetable</a></li>
                        <li><a href="#" class="nav2">contact</a></li>
                    </ul>
    </div>
</div>
</div>


</body>
</html>