<?php
$host="localhost";//host name
$username="root";
$password="";
$db_name="timet";//Database name
$tbl_name="admintable";//Table name
//connect to server and select database
mysql_connect("$host", "$username", "$password") or 
die("cannot connect");
mysql_select_db("$db_name")or
die("cannot select DB");

//username and password sent from form

$myusername=$_POST['myusername'];
$mypassword=$_POST['mypassword'];
$myusername= stripslashes
($myusername);
$mypassword= stripslashes
($mypassword);
$myusername=mysql_real_escape_string($myusername);
$mypassword=mysql_real_escape_string($mypasswoord);
$sql="SELECT*FROM $tbl_name
WHERE
username='$myusername' and password='$password'";
$result=mysql_query($sql);

//Mysql_num_row is counting table row
$count=mysql_num_rows($result);
if($count==1){
session_register
("myusername");
session_register
("mypassword");
header
("location:login_success.php");
}
else{
echo "Wrong username or password";
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>::TIMETABLE GENERATION SYSTEM:</title>
<style type="text/css">
<!--
.style1 {
	color: #99CC00;
	font-family: Georgia, "Times New Roman", Times, serif;
}
.style6 {font-size: 18px}
.style10 {
	font-size: 24;
	font-family: "Comic Sans MS";
	color: #0000CC;
}
-->
</style>
</head>

<body bgcolor="#FFFFCC">
 </body>
</html>
