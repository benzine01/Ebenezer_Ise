 <?php
 session_start();
 if(!session_is_registered
 (myusername)){
 header
 ("location:form.php");
 }
 ?>
 <html>
<head>
 <title>::TIMETABLE GENERATION SYSTEM:</title>
<style type="text/css">
<!--
.style1 {
	color: #99CC00;
	font-family: Georgia, "Times New Roman", Times, serif;
}
.style6 {font-size: 18px}
.style10 {
	font-size: 24;
	font-family: "Comic Sans MS";
	color: #0000CC;
}
-->
</style>
</head>

<body bgcolor="#FFFFCC">
<div align="center"><img src="images/hdr_bg.jpg" alt="FPN"  width="900" height="150" border="1" longdesc="http://www.fepolynasonline.com" /></div>
Login Success!
</body> 

</html>
