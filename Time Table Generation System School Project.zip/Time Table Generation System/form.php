<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TIMETABLE GENERATION SYSTEM</title>
<link rel="stylesheet" type="text/css" href="style.css" />
<style type="text/css">
<!--
.style1 {
	font-size: 18px;
	font-weight: bold;
}
.style2 {
	font-family: "Comic Sans MS";
	font-size: 16px;
}
.style3 {font-size: 17px}
-->
</style>
</head>
<body>
<div id="top_menu">
                    <ul class="menu">
                        <li><a href="index.html" class="nav">HOME</a></li>
                        <li><a href="main_login.php" class="nav">ADMIN</a></li>
                        <li><a href="#" class="nav">TIMETABLE</a></li>
                        <li><a href="gallery.html" class="nav">ABOUT</a></li>
                        <li><a href="contact.html" class="nav">CONTACT</a></li>
                    </ul>
</div>
<div id="main_content">
	<div id="top_banner">
    <a href="index.html"></a>    </div>
    
    <div id="page_content_left">
    	<div class="title style1">
        ::<span class="style3">ADMIN CONTROL PANEL</span>::        </div>
        <div class="content_text">
        <table width="200" border="1"   align="center" bordercolor="#009999">
  <tr>
    <td>
	<form action="process.php" method="POST" name="regCourse">
  <p>
    HALL:
    <select name="hall">
      <option value = "sr1">SR1</option>
      <option value = "sr2">SR2</option>
      <option value = "sr3">SR3</option>
      <option value = "sr4">SR4</option>
    </select>
  </p>
  <p>
    LEVEL:
    <select name="level">
      <option value = "NDI">NDI</option>
      <option value = "NDII">NDII</option>
      <option value = "HNDI">HNDI</option>
      <option value = "HNDII">HNDII</option>
    </select>
  </p>
  
  <p>
    <label>CODE:</label>
    <select name="code">
      <option value = "COM112">COM112</option>
      <option value = "COM212">COM212</option>
      <option value = "COM231">COM231</option>
      <option value = "GNS414">GNS414</option>
	  <option value = "STA311">STA311</option>

    </select>
  </p>
  <p>
    <label>CODE:</label><select name="day">
      <option value = "MONDAY" selected="selected">MONDAY</option>
      <option value = "TUESDAY">TUESDAY</option>
      <option value = "WEDNESDAY">WEDNESDAY</option>
      <option value = "THURSDAY>THURSDAY"</option>
      <option value = "FRIDAY">FRIDAY</option>
    </select>
  </p>
  <p><label>TIME:</label>
          <select name="time">
      <option value = "8AM-10AM" selected="selected">8AM-10AM</option>
      <option value = "10AM-12PM">10AM-12PM</option>
      <option value = "12PM-1PM">12PM-1PM</option>
      <option value = "2PM-4PM">2PM-4PM</option>
      <option value = "4PM-6PM">4PM-6PM</option>
       </select>
  </p>
  
  <p><INPUT TYPE = "SUBMIT" VALUE "SEND" /> </p>
</form>

	</td>
  </tr>
</table></div><br />
  </div>
    <div id="page_content_right">
      <div class="more"><img src="images/timetable.png" alt="save time" width="300" height="300"  align="right"/></div>
    </div>
    
    
  <div id="page_bottom"></div>
		
</div>

<div id="footer">
<div id="footer_content">
<div id="copyrights">
Timetable Solution.&copy; All Rights Reserved Group Four 2012/2013
</div>
	<div>
                    <ul class="footer_menu">
                        <li><a href="#" class="nav2">home </a></li>
                        <li><a href="#" class="nav2">Admin</a></li>
                        <li><a href="#" class="nav2">Timetable</a></li>
                        <li><a href="#" class="nav2">contact</a></li>
                    </ul>
    </div>
</div>
</div>


</body>
</html>