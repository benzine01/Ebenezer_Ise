<?php
	include("db_connect.php");
	$sql="SELECT * FROM comment ORDER BY timestamp";
	$result=mysql_query($sql);
	if(!$result){
	
		echo "sl;kgjosijgosjgoisjgiosjrioguroigursutgprutg9wuartouwaut";
		
	}
	while($comment=mysql_fetch_array($result))
	{	
		$text = $comment['text'];
		$member_id = $comment['member_id'];
		echo "<BR>";
		echo $text."<BR>";
		echo "by <b>".$member_id."</b><br>";
	}
?>