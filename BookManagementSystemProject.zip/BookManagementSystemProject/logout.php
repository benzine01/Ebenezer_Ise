<?php
/******************************************************
* Book Subscription System							  *
* Author - Suhas Manjunath Kashyap					  *
* Logout Page - 'logout.php'				 		  *
* Purpose : This page will remove the cookie off and  *
* the user says bye-bye.							  *
******************************************************/
?>
<?php
	setcookie("id","",time()-10);
	header("Location: index.php");
?>