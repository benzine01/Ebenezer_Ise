<div id="nav2">
	<div class="menu">

<ul>
<li><a href="index.php">Home<!--[if IE 7]><!--></a></li>
<li><a href="#">Subscription<!--[if IE 7]><!--></a><!--<![endif]-->
<!--[if lte IE 6]><table><tr><td><![endif]-->
	<ul>

		<li><a href="add_subscription.php">Add Subscription</a></li>
		<li><a href="remove_subscription.php">Remove Subscription</a></li>
	
	</ul>
<!--[if lte IE 6]></td></tr></table></a><![endif]-->
</li>
<li><a href="#">Comments<!--[if IE 7]><!--></a><!--<![endif]-->

<!--[if lte IE 6]><table><tr><td><![endif]-->
	<ul>
		<li><a href="#">Read a Comment</a></li>
		<li><a href="write_comment.php">Write a Comment</a></li>	
	</ul>
<!--[if lte IE 6]></td></tr></table></a><![endif]-->
</li>
<li><a href="#">Ratings<!--[if IE 7]><!--></a><!--<![endif]-->

<!--[if lte IE 6]><table><tr><td><![endif]-->
	<ul>
		<li><a href="view_rate.php">View Ratings</a></li>
		<li><a href="rate_book.php">Rate Books</a></li>	
	</ul>
<!--[if lte IE 6]></td></tr></table></a><![endif]-->
</li>
</ul>
</div>
</div>