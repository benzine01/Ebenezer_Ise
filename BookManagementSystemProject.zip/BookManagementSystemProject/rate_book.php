<?php
/******************************************************
* Book Subscription System							  *
* Author - Suhas Manjunath Kashyap					  *
* Add Subscription Page - 'add_subscription.php'   	  *
* Purpose : This page will subscribe a book.          *
******************************************************/
if(!isset($_COOKIE['id'])){	
	header("Location: index.php");	
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title>Book Subscription System</title>
<meta name="Keywords" content="" />
<meta name="Description" content="" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="Content-Language" content="en-ie" />
<meta name="robots" content="all" />
<meta name="MSSmartTagsPreventParsing" content="true" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="copyright" content="Copyright (c) 2008 Suhas Manjunath Kashyap" />
<meta name="author" content="http://www.suhasmanjunath.co.nr/" />
<meta name="Rating" content="General" />
<link rel="shortcut icon" href="" type="image/x-icon" />
<link rel="stylesheet" type="text/css" media="all" href="css/glob_nav.css" />
<link rel="stylesheet" type="text/css" media="all" href="css/template.css" />
</head>
<body bgcolor="#f0f0f0">
<div id="header">
<?php
include('login_top.php');
?>
</div>
<?php
include('menu.php');
?>

<div id="body">
<div id="container">
<div id="sidebar1">
    <h3>Search</h3>
    <table border="0">
	<form name="login-form" method="POST" action="search.php">
	<tr>
		<td><input type="text" size="25" name="SEARCH_NAME"/></td>
		<td colspan="2" align="right"><input type="submit" id="button" value="Search" name="LOGIN_SUBMIT"/></td>
	</tr>
	<tr></tr>
	<tr>
		<td>Search Criteria</td>
		<td></td>
	</tr>
	<tr></tr>
	<tr>
		<td><input type="radio" value="title" checked name="R1">Title&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td><input type="radio" name="R1" value="author"> Author&nbsp;</td>
	</tr>
	<tr>
		<td><input type="radio" name="R1" value="keywords"> Keywords</td>
	</tr>
	</form>
	</table>
</div>
<?php include('login_side.php'); ?>
<span id="sep"></span>
<div id="mainContent">
<h1>Rate your Book</h1>
<p>Users can rate their favourite book here! Once the user enters this page, his login id, book title and the ratings which you can find on a select bar.</p>
<?php if(!isset($_REQUEST['SUCCESS'])&&!isset($_REQUEST['SUCCESS_FAIL'])){ ?>
<p>
<table border="0" align="center" id="text">
    <tr><td>&nbsp;</td></tr>
	<tr>
    <form action="rate_book_process.php" method="POST">
      <td align="center"><b>Member ID</b></td>
      <td align="left"><input type="text" value="<?php echo $_COOKIE['id']; ?>" readonly="yes" name="MEM_ID" size="20" /></td>
    </tr>   
	<tr><td>&nbsp;</td></tr>
	<tr>
      <td align="left"><b>Title</b></td>
      <td>
<select name="TITLE">
	<?php
	include ('db_connect.php');
	$sql="SELECT title FROM BOOK";
	$result=mysql_query($sql);
	while($mem=mysql_fetch_array($result))
	{
	?>
	<option value="<?php echo $mem['title'];?>"><?php echo $mem['title'];?></option>
	<?php
	}
	?>
</select>
</td>
	<tr><td>&nbsp;</td></tr>
    </tr>
    <tr>
    	<td align="left"><b>Your Rate</b></td>
        <td>
        <select name="RATE">
            <option>1</option>
            <option>2</option>
            <option>3</option>
            <option>4</option>
            <option>5</option>
        </select>
        </td>
       </tr>
       	<tr><td>&nbsp;</td></tr>
	    <tr>
      <td width="115" colspan=3 align="center" height="35">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <input type="submit" value="Subscribe" name="B1" id="button"></td>
      <td width="163" align="center" height="35">&nbsp;&nbsp;</td>
    </tr>
  </table>
  </form>
	<?php }
else if(isset($_REQUEST['SUCCESS_FAIL'])){ ?>
<p>
<table border="0" align="center" id="text" width="100%">
	<tr><td></td></tr>
    <tr>
      <td colspan="3">
	  <?php
		echo "<b> CANNOT DUPLICATE!!! </b><br> ISBN # : ".$_REQUEST['isbn']."<br> Member ID : ".$_COOKIE['id']."";
	  ?>
	  </td>
    </tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
  </table>
  </p>
<?php } 
else if(isset($_REQUEST['SUCCESS'])){ ?>
<p>
<table border="0" align="center" id="text" width="100%">
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>

    <tr>
      <td colspan="3">
	  <?php
		echo "<center><b>Subscription Added Successfully</b></center>";
	  ?>
	  </td>
    </tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
  </table>
  </p>
	<?php } ?>
 </div>
<br class="clearfloat" />
<div id="footer">
    <p>Copyright &copy; Suhas Manjunath Kashyap</p>
 </div>
</div>
</div>
</body>
</html>