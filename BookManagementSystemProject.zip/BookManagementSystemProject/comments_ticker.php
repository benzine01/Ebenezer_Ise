<table width="150px" height="150px">
<tr><td>
<marquee bgcolor="white" scrollamount=1 scrolldelay=1 direction=up 
onmouseover="this.stop()" onmouseout="this.start()">
<br>
	<?php include("latest_comments.php"); ?>
<br>
</marquee>
</td></tr>
</table>