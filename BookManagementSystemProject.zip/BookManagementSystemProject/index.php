<?php
/******************************************************
* Book Subscription System							  *
* Author - Suhas Manjunath Kashyap					  *
* Index Information Page - 'index.php'	        	  *
* Purpose : This page is an INDEX / START Page        *
******************************************************/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title>Book Subscription System</title>
<meta name="Keywords" content="" />
<meta name="Description" content="" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="Content-Language" content="en-ie" />
<meta name="robots" content="all" />
<meta name="MSSmartTagsPreventParsing" content="true" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="copyright" content="Copyright (c) 2008 Suhas Manjunath Kashyap" />
<meta name="author" content="http://www.suhasmanjunath.co.nr/" />
<meta name="Rating" content="General" />
<link rel="shortcut icon" href="" type="image/x-icon" />
<link rel="stylesheet" type="text/css" media="all" href="css/glob_nav.css" />
<link rel="stylesheet" type="text/css" media="all" href="css/template.css" />
</head>
<body bgcolor="#f0f0f0">
<div id="header">
<?php
include('login_top.php');
?>
</div>
<?php
include('menu.php');
?>

<div id="body">
<div id="container">
<div id="sidebar1">
    <h3>Search</h3>
    <table border="0">
	<form name="login-form" method="POST" action="search.php">
	<tr>
		<td><input type="text" size="25" name="SEARCH_NAME"/></td>
		<td colspan="2" align="right"><input type="submit" id="button" value="Search" name="LOGIN_SUBMIT"/></td>
	</tr>
	<tr></tr>
	<tr>
		<td>Search Criteria</td>
		<td></td>
	</tr>
	<tr></tr>
	<tr>
		<td><input type="radio" value="title" checked name="R1">Title&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td><input type="radio" name="R1" value="author"> Author&nbsp;</td>
	</tr>
	<tr>
		<td><input type="radio" name="R1" value="keywords"> Keywords</td>
	</tr>
	</form>
	</table>
</div>
<?php include('login_side.php'); ?>
<span id="sep"></span>
<div id="mainContent">
    <h1>Welcome</h1>
    <p>This Book Subscription System which allows users to enter information about their Book collection and then sort and search this information in a variety of different manners. The main use of this Book Subscription System is to catalog and manage your library or personal Book collection and it is suitable for collections of all sizes and types. It can also be used to keep track of Books that you wish to purchase in the future.</p>
    <h2>What's New</h2>
    <p>This Book Subscription System comprises of subscribing a Book and also allows user to post his comment for his favourite Book. An Extra Feature 'RATING BOOK feature' which enables user to rate the Book</p>
</div>
<br class="clearfloat" />
<div id="footer">
    <p>Copyright &copy; Suhas Manjunath Kashyap</p>
 </div>
</div>
</div>
</body>
</html>