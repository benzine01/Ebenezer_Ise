<?php
/******************************************************
* Book Subscription System							  *
* Author - Suhas Manjunath Kashyap					  *
* Login Process Page - 'login_process.php'			  *
* Purpose : This page will perform login validations  *
* in order to know whether the user has entered valid *
* details or not.									  *
******************************************************/
?>
<?php
include ("db_connect.php");
if($_POST['LOGIN_NAME'] == "" || $_POST['LOGIN_PASSWORD'] == ""){
		header("Location: index.php");
}
else{
	$sql="SELECT * FROM member where member_id='".$_POST['LOGIN_NAME']."'";
	$result=mysql_query($sql);
	if(!$result){
		//header("Location: index.php");
	}
	$mem=mysql_fetch_array($result);
	$mem_id=$mem["member_id"];
	$mem_pass=$mem["pass"];	
	$passs = base64_encode($_POST["LOGIN_PASSWORD"]);
	echo $mem_id."-".$mem_pass;
	if(($mem_id == $_POST["LOGIN_NAME"])&&($mem_pass == $passs)){
		setcookie("id",$_POST["LOGIN_NAME"]);
		header("Location: index.php");
	}
	else{
		header("Location: index.php");
	}
}
?>

	
	

