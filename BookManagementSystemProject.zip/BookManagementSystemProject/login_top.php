<?php
/******************************************************
* Book Subscription System							  *
* Author - Suhas Manjunath Kashyap					  *
* Login Top Information Page - 'login_top.php'		  *
* Purpose : This page is include in every top-right   *
* in order to know whether the user logged in or not. *
******************************************************/
?>
<?php
if(isset($_COOKIE['id'])){
	$USERNAME = $_COOKIE['id'];
}
else{
	$USERNAME="Guest";
}

?>
<table border="0">
<tr>
<td><p>Book Subscription System</p></td>
<td id="log_details">Welcome <b><?php echo $USERNAME; ?></b><?php if(isset($_COOKIE['id'])){?>&nbsp;<a href="logout.php" id="link">logout</a><?php } ?></td>
</tr>
</table>