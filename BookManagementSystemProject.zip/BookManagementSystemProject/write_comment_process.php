<?php
include('db_connect.php');
	if(empty($_POST[comment])){
		echo "<script language='javascript' type='text/javascript'> window.alert('Comment field is empty! Please fill it up.'); </script>";
		echo "<script language='javascript' type='text/javascript'> location.href='write_comment.php' </script>";
	}
	else{
		$result = mysql_query("INSERT INTO comment VALUES ('',now(),'$_POST[comment]','$_POST[isbn]','$_POST[MEM_ID]') ");
		if($result){
			echo "<script language='javascript' type='text/javascript'> window.alert('Your Comment added Successfully!'); </script>";
			echo "<script language='javascript' type='text/javascript'> location.href='index.php' </script>";
		}
		else{
			echo "<script language='javascript' type='text/javascript'> window.alert('Your Comment added Failed!'); </script>";
			echo "<script language='javascript' type='text/javascript'> location.href='write_comment.php' </script>";
		} 
	}
?>