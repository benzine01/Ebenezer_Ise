<?php
	include ("db_connect.php");
	if(!empty($_POST[MEM_ID]) and !empty($_POST[TITLE])){		
		$result=mysql_query("SELECT * FROM rate_book WHERE title = '$_POST[TITLE]' AND member_id = '$_POST[MEM_ID]'");
		while($book=mysql_fetch_array($result,MYSQL_ASSOC))
		{	
			$memid = $book['member_id'];
			$isbn = $book['isbn'];
		}
			if($_REQUEST[MEM_ID] == $memid){
				header("Location: rate_book.php?SUCCESS_FAIL=cd&isbn={$isbn}");		
			}
			else {
				$result1=mysql_query("SELECT * FROM book WHERE title ='$_POST[TITLE]'") or die("waste");
				while($book1 = mysql_fetch_array($result1,MYSQL_ASSOC))
				{	
					$isbn = $book1['isbn'];
				}
				$query = mysql_query("INSERT INTO subscription values('$_POST[MEM_ID]','$isbn')");
				if(!$query){
					echo "Inserted Unsuccessfully";
				}
				else{
					header("Location: add_subscription.php?SUCCESS=yes");
				}
			}	
		}
	
	else{
		header("Location: add_subscribe.php");
	}
?>