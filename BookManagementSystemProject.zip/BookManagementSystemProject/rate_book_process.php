<?php
	include ("db_connect.php");
	if(!empty($_POST[MEM_ID]) and !empty($_POST[TITLE])){	
		$result0=mysql_query("SELECT * FROM book WHERE title ='$_POST[TITLE]'");
		$book1 = mysql_fetch_array($result0,MYSQL_ASSOC);
		$result=mysql_query("SELECT * FROM rate_book WHERE isbn = '$book1[isbn]' AND member_id = '$_POST[MEM_ID]'");
		
		$book=mysql_fetch_array($result,MYSQL_ASSOC);
		$memid = $book['member_id'];
		$isbn = $book['isbn'];
		
		if($_REQUEST[MEM_ID] == $memid){
			header("Location: rate_book.php?SUCCESS_FAIL=cd&isbn={$isbn}");		
		}
		else {
			$query = mysql_query("INSERT INTO rate_book values('$book1[isbn]','$_POST[MEM_ID]','$_POST[RATE]')");
			if(!$query){
				header("Location: rate_book.php?SUCCESS_FAIL=cd&isbn={$isbn}");	
			}
			else{
				//echo "Inserted Successfully";
				header("Location: rate_book.php?SUCCESS=yes");
			}
		}	
	}	
	else{
		header("Location: rate_book.php");
	}
?>