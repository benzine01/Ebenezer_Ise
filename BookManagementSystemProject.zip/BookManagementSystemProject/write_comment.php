<?php
/**********************************************************************
* Book Subscription System						                  	  *
* Author - Suhas Manjunath Kashyap					 				  *
* Write Comment Page - 'write_comment.php'   						  *
* Purpose : This page will write a comment for the selected book.     *
**********************************************************************/
if(!isset($_COOKIE['id'])){	
	header("Location: index.php");	
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title>Book Subscription System</title>
<meta name="Keywords" content="" />
<meta name="Description" content="" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="Content-Language" content="en-ie" />
<meta name="robots" content="all" />
<meta name="MSSmartTagsPreventParsing" content="true" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="copyright" content="Copyright (c) 2008 Suhas Manjunath Kashyap" />
<meta name="author" content="http://www.suhasmanjunath.co.nr/" />
<meta name="Rating" content="General" />
<link rel="shortcut icon" href="" type="image/x-icon" />
<link rel="stylesheet" type="text/css" media="all" href="css/glob_nav.css" />
<link rel="stylesheet" type="text/css" media="all" href="css/template.css" />
</head>
<body bgcolor="#f0f0f0">
<div id="header">
<?php
include('login_top.php');
?>
</div>
<?php
include('menu.php');
?>

<div id="body">
<div id="container">
<div id="sidebar1">
    <h3>Search</h3>
    <table border="0">
	<form name="login-form" method="POST" action="search.php">
	<tr>
		<td><input type="text" size="25" name="SEARCH_NAME"/></td>
		<td colspan="2" align="right"><input type="submit" id="button" value="Search" name="LOGIN_SUBMIT"/></td>
	</tr>
	<tr></tr>
	<tr>
		<td>Search Criteria</td>
		<td></td>
	</tr>
	<tr></tr>
	<tr>
		<td><input type="radio" value="title" checked name="R1">Title&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td><input type="radio" name="R1" value="author"> Author&nbsp;</td>
	</tr>
	<tr>
		<td><input type="radio" name="R1" value="keywords"> Keywords</td>
	</tr>
	</form>
	</table>
</div>
<?php include('login_side.php'); ?>
<span id="sep"></span>
<div id="mainContent">
<h1>Write a Comment</h1>
<p>Users can Comment a book here. You can specify which privileges you wish to extend to your visitors. Basically, you can allow anyone to register/post, or you can require that someone must be registered before they can post a comment. In this example, let's not select either one, and let's see what happens when an unregistered visitor tries to post a comment. The visitor will click to read a post and then try to post a comment. You will see that since this is an unregistered user, the comment has been accepted into the database, but it will not be published until Admin moderation. When you login to your Admin area, you will now see that one comment requires moderation. At this point, you can email the visitor... or edit the comment... or view the comment... or delete this specific comment... or, if you have several comments to moderate, you can apply a bulk action to all comments. Let's take a look at the results. As you can see, the comment has been successfully added.</p>
<?php if(!isset($_REQUEST['SUCCESS'])&&!isset($_REQUEST['SUCCESS_FAIL'])){ ?>
 <form action="write_comment_process.php" method="POST">
<table border="0" align="center" style="background:#7B7978; color:#FFF; font-size:14px;">
    <tr>
      <td align="right"><b>Member ID</b></td>
      <td>&nbsp;</td>
      <td width="120" align="left"><input type="text" value="<?php echo $_COOKIE['id']; ?>" readonly="yes" name="MEM_ID" size="20"></td>
    </tr>    
	<tr>
      <td align="right"><b>ISBN</b></td>
      <td>&nbsp;</td>
      <td align="left">
      <select name="isbn" >
	<?php
	include ('db_connect.php');
	$sql="SELECT isbn FROM BOOK";
	$result=mysql_query($sql);
	while($mem=mysql_fetch_array($result))
	{
	?>
	<option value="<?php echo $mem['isbn'];?>"><?php echo $mem['isbn'];?></option>
	<?php
	}
	?>
</select>      </td>
    </tr>
    <tr>
      <td align="right"><b>Comment</b></td>
      <td>&nbsp;</td>
      <td align="left"><textarea name="comment" size="20"></textarea></td>
	</tr>
    <tr>
      <td colspan="3" align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <input type="submit" id="button" value="Comment" name="B1"></td>
      <td width="163" align="center" height="35">&nbsp;&nbsp;</td>
    </tr>
  </table>
	<?php }
else if(isset($_REQUEST['SUCCESS_FAIL'])){ ?>
<p>
<table border="0" align="center" id="text" width="100%">
	<tr><td></td></tr>
    <tr>
      <td colspan="3">
	  <?php
		echo "<b> CANNOT DUPLICATE!!! </b><br> ISBN # : ".$_REQUEST['isbn']."<br> Member ID : ".$_COOKIE['id']."";
	  ?>
	  </td>
    </tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
  </table>
  </p>
<?php } 
else if(isset($_REQUEST['SUCCESS'])){ ?>
<p>
<table border="0" align="center" id="text" width="100%">
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>

    <tr>
      <td colspan="3">
	  <?php
		echo "<center><b>Subscription Added Successfully</b></center>";
	  ?>
	  </td>
    </tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
  </table>
  </p>
	<?php } ?>
 </div>
<br class="clearfloat" />
<div id="footer">
    <p>Copyright &copy; Suhas Manjunath Kashyap</p>
 </div>
</div>
</div>
</body>
</html>