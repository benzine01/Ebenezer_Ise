<?php
/******************************************************
* Book Subscription System							  *
* Author - Suhas Manjunath Kashyap					  *
* Search Page - 'search.php'						  *
* Purpose : This page will perform search operations  *
* where the values are received from search box on    *
* every page left bar text-fields and radio buttons.  *
******************************************************/
if(!isset($_COOKIE['id'])){	
	header("Location: index.php");	
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title>Book Subscription System - Search</title>
<meta name="Keywords" content="" />
<meta name="Description" content="" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="Content-Language" content="en-ie" />
<meta name="robots" content="all" />
<meta name="MSSmartTagsPreventParsing" content="true" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="copyright" content="Copyright (c) 2008 Suhas Manjunath Kashyap" />
<meta name="author" content="http://www.suhasmanjunath.co.nr/" />
<meta name="Rating" content="General" />
<link rel="shortcut icon" href="" type="image/x-icon" />
<link rel="stylesheet" type="text/css" media="all" href="css/glob_nav.css" />
<link rel="stylesheet" type="text/css" media="all" href="css/template.css" />
</head>
<body bgcolor="#f0f0f0">
<div id="header">
<?php
include('login_top.php');
?>
</div>
<?php
include('menu.php');
?>

<div id="body">
<div id="container">
<div id="sidebar1">
    <h3>Search</h3>
    <table border="0">
	<form name="login-form" method="POST" action="search.php">
	<tr>
		<td><input type="text" size="25" name="SEARCH_NAME"/></td>
		<td colspan="2" align="right"><input type="submit" id="button" value="Search" name="LOGIN_SUBMIT"/></td>
	</tr>
	<tr></tr>
	<tr>
		<td>Search Criteria</td>
		<td></td>
	</tr>
	<tr></tr>
	<tr>
		<td><input type="radio" value="title" checked name="R1">Title&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td><input type="radio" name="R1" value="author"> Author&nbsp;</td>
	</tr>
	<tr>
		<td><input type="radio" name="R1" value="keywords"> Keywords</td>
	</tr>
	</form>
	</table>
</div>
<?php include('login_side.php'); ?>
<span id="sep"></span>
<div id="mainContent">
<h1>Search</h1>
<p>This Search Engine will provide the ultimate search to your database. This Engine will provide you with Three Options, Title (Title Search is the search where in the search word should match to the Title of the Book), Author (Author Search is the search where in the search word should match to the Author of the Book) and Keyword (Keyword Search is the search where in the search word should match to the Keyword of the Book.). Based on this criteria, the Search word is search and will let you know the results.</p>
<table border="0" width="100%" bgcolor="#7B7978" id="text">
<tr><td>
<?php

	include ('db_connect.php');
		
	if($_REQUEST['SEARCH_NAME'] != ""){
	if($_REQUEST['R1'] == "title"){
		$sql="SELECT * FROM book WHERE title LIKE '%".$_REQUEST['SEARCH_NAME']."%'";
		$result=mysql_query($sql);
		$book=mysql_fetch_array($result);
		$books = $book['title'];
		$isbn = $book['isbn'];
		
		if($_REQUEST['SEARCH_NAME'] == $books){
			echo "<B>Search Successful</B><BR><BR>";
			echo "<B>ISBN # : </B>".$isbn."<BR>";
			echo "<B>Title : </B>".$books;			
		}
		else {
			echo "<center><b>&quot;".$_REQUEST['SEARCH_NAME']."&quot;</b> is not found</center>";
		}
	}
	else if($_REQUEST['R1'] == "author"){
		$a = explode(' ',$_REQUEST['SEARCH_NAME']);
		$fname = $a[0];
		$sql="SELECT * FROM author WHERE first_name LIKE `%".$fname."%`";
		$result=mysql_query($sql);
		while($book=mysql_fetch_array($result))
		{	
			$aid = $book['author_id'];
			$name = $book['first_name']." ".$book['last_name'];
			$bio = $book['biosketch'];
		}
		if($_REQUEST['SEARCH_NAME'] == $name){
			echo "<B>Search Successful</B><BR><BR>";
			echo "<B>Author ID : </B>".$aid."<BR>";
			echo "<B>Author Name : </B>".$name."<BR>";
			echo "<B>Bio : </B>".$bio;			
		}
		else {
			echo "<center><b>&quot;".$_REQUEST['SEARCH_NAME']."&quot;</b> is not found</center>";
		}
		
	}
	else if($_REQUEST['R1'] == "keywords"){
		$sql="SELECT * FROM keyword where keyword LIKE CONCAT('%', '".$_REQUEST['SEARCH_NAME']."' ,'%');";
		$result=mysql_query($sql);
		while($book=mysql_fetch_array($result))
		{	
			$books = $book['keyword'];
			$isbn = $book['isbn'];
		}
		if($books != ''){
			echo "<B>Search Successful</B><BR><BR>";
			echo "<B>Data: </B>".$isbn."<BR>";
			echo "<B>Keyword : </B><span style='color:red;'>".$books."</span>";			
		}
		else {
			echo "<center><b>&quot;".$_REQUEST['SEARCH_NAME']."&quot;</b> is not found</center>";
		}		
	}
	}
	else{
		echo "<center><b>Search Keyword Not Found</b></center>";
	}

?>
	</td></tr>
	</table>
	</p>
</div>
<br class="clearfloat" />
<div id="footer">
    <p>Copyright &copy; Suhas Manjunath Kashyap</p>
 </div>
</div>
</div>
</body>
</html>