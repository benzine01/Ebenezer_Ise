<?php
	include ("db_connect.php");
	if(!empty($_POST[MEM_ID]) and !empty($_POST[ISBN])){		
		$result=mysql_query("SELECT * FROM subscription WHERE isbn ='$_POST[ISBN]' AND member_id = '$_POST[MEM_ID]'");
		 while($book = mysql_fetch_array($result,MYSQL_ASSOC))
		{	
			$memid = $book['member_id'];
			$isbn = $book['isbn'];
			$query = mysql_query("DELETE FROM SUBSCRIPTION WHERE isbn = '$_POST[ISBN]'");
			if(!$query){
				header("Location: add_subscription.php?SUCCESS_FAIL=cd&isbn={$isbn}");
			}
			else{
				header("Location: remove_subscription.php?SUCCESS=yes");
			}	
		}
	}
	else{
		header("Location: add_subscribe.php");
	}
?>