<?php
	if(empty($_POST['name']) or empty($_POST['email']) or empty($_POST['memid']) or empty($_POST['pass']) or empty($_POST['repass'])){
		echo "<script language='javascript' type='text/javascript'> window.alert('Some of the fields are empty! Please fill it up.'); </script>";
		echo "<script language='javascript' type='text/javascript'> location.href='register.php' </script>";
	}
	else{
		include('db_connect.php');
		$rs = mysql_query("INSERT INTO member VALUES ('$_POST[memid]','".base64_encode($_POST[pass])."','$_POST[name]','$_POST[email]')");
		if($rs){
		echo "<script language='javascript' type='text/javascript'> window.alert('Registration is Complete!'); </script>";
		echo "<script language='javascript' type='text/javascript'> location.href='index.php' </script>";
		}
		else{
		echo "<script language='javascript' type='text/javascript'> window.alert('Registeration is Incomplete!'); </script>";
		echo "<script language='javascript' type='text/javascript'> location.href='register.php' </script>";
		}
	}
?>