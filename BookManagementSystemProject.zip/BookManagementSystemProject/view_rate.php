<?php
/******************************************************
* Book Subscription System							  *
* Author - Suhas Manjunath Kashyap					  *
* Rate Viewer Page - 'view_rate.php'           	      *
* Purpose : This page will subscribe a book.          *
******************************************************/
if(!isset($_COOKIE['id'])){	
	header("Location: index.php");	
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title>Book Subscription System</title>
<meta name="Keywords" content="" />
<meta name="Description" content="" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="Content-Language" content="en-ie" />
<meta name="robots" content="all" />
<meta name="MSSmartTagsPreventParsing" content="true" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="copyright" content="Copyright (c) 2008 Suhas Manjunath Kashyap" />
<meta name="author" content="http://www.suhasmanjunath.co.nr/" />
<meta name="Rating" content="General" />
<link rel="shortcut icon" href="" type="image/x-icon" />
<link rel="stylesheet" type="text/css" media="all" href="css/glob_nav.css" />
<link rel="stylesheet" type="text/css" media="all" href="css/template.css" />
</head>
<body bgcolor="#f0f0f0">
<div id="header">
<?php
include('login_top.php');
?>
</div>
<?php
include('menu.php');
?>

<div id="body">
<div id="container">
<div id="sidebar1">
    <h3>Search</h3>
    <table border="0">
	<form name="login-form" method="POST" action="search.php">
	<tr>
		<td><input type="text" size="25" name="SEARCH_NAME"/></td>
		<td colspan="2" align="right"><input type="submit" id="button" value="Search" name="LOGIN_SUBMIT"/></td>
	</tr>
	<tr></tr>
	<tr>
		<td>Search Criteria</td>
		<td></td>
	</tr>
	<tr></tr>
	<tr>
		<td><input type="radio" value="title" checked name="R1">Title&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td><input type="radio" name="R1" value="author"> Author&nbsp;</td>
	</tr>
	<tr>
		<td><input type="radio" name="R1" value="keywords"> Keywords</td>
	</tr>
	</form>
	</table>
</div>
<?php include('login_side.php'); ?>
<span id="sep"></span>
<div id="mainContent">
<h1>View Rates</h1>
<p>
</p>
<p>
<table border="0" align="center" id="text">
  <tr><td>&nbsp;</td></tr>
    <form name="view" action="view_rate.php" method="POST">     
 	<tr><td colspan="2">&nbsp;</td></tr>
	<tr>
      <td align="left"><b>Title</b></td>
      <td>
<select name="TITLE">
	<?php
	include ('db_connect.php');
	$sql="SELECT * FROM BOOK";
	$result=mysql_query($sql);
	while($mem=mysql_fetch_array($result)){
	?>
	<option value="<?php echo $mem['isbn'];?>"><?php echo $mem['title']; ?></option>
	<?php } ?>
	
</td>
    </tr>
	    <tr>
      <td width="115" colspan="3" align="center" height="35">
      <input type="submit" value="Reveal" name="B1" id="button"></td>
    </tr>
  </table>

<p>
<table border="0" align="center" id="text" width="100%">
    <tr>
      <td>
	  <?php
	  if($_REQUEST[B1] != ''){
		include ('db_connect.php');
		$sql="SELECT * FROM rate_book WHERE isbn = '".$_REQUEST[TITLE]."'";
		$result=mysql_query($sql) or die("No");
		echo "<table border='1' style='border-style: #fff thick solid;'>";
		if(mysql_num_rows($result) == 0){
				echo "<tr><td>No Ratings Found</td></tr>";
		}
		else{
				echo "<tr><td width='25%'>ISBN</td>
						<td width='50%'>Member ID</td>
						<td width='25%'>Ratings</td></tr>";
		}
		while($res=mysql_fetch_array($result)){
				echo "<tr>
						<td width='25%'>{$res['isbn']}</td>
						<td width='50%'>{$res['member_id']}</td>
						<td width='25%'>{$res['rating']}</td>
					</tr>";
		}		
		echo "</table>";
	}
	?>
	 
	  </td>
    </tr>

  </table>
  </p>

 </div>
<br class="clearfloat" />
<div id="footer">
    <p>Copyright &copy; Suhas Manjunath Kashyap</p>
 </div>
</div>
</div>
</body>
</html>