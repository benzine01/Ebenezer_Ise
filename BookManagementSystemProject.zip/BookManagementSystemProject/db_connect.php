<?php
/******************************************************
* Book Subscription System							  *
* Author - Suhas Manjunath Kashyap					  *
* Database Connection Page - 'db_connect.php'		  *
* Purpose : In order to connect the database, just	  *
* include this file and all things will be done :)    *
******************************************************/

	$con = mysql_connect("localhost","root","");
	if(!$con){
		echo "Connection to the Database Console was Unsuccessful";
	}
	$select = mysql_select_db("book_subscription_system",$con);
	if(!$select){
		echo "Connection to the Database was Unsuccessful";
	}
?>