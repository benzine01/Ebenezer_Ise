-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 22, 2009 at 11:01 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `book_subscription_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `author`
--

CREATE TABLE `author` (
  `author_id` int(10) unsigned NOT NULL,
  `first_name` varchar(20) collate utf8_bin NOT NULL,
  `last_name` varchar(20) collate utf8_bin NOT NULL,
  `biosketch` varchar(1000) collate utf8_bin NOT NULL,
  PRIMARY KEY  (`author_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `author`
--

INSERT INTO `author` (`author_id`, `first_name`, `last_name`, `biosketch`) VALUES
(420, 'Barack', 'Obama', 'Senator turned President Elect of United States Of America'),
(421, 'Leo', 'Tolstoy', ' Russian Fiction writer, member of noblilty'),
(422, 'Rabindranath', 'Tagore', 'Famous Indian Literature Nobel Laureate '),
(423, 'Charles', 'Dickens', 'One of the most famous English Novelists'),
(424, 'Anne', 'Frank', 'Gained fame following the publication of her diary'),
(425, 'Jin', 'Yong', 'Popular Chinese novelist'),
(426, 'Mark', 'Twain', 'Famous american satirist'),
(427, 'Thomas', 'Hardy', 'English author of the naturalist movement'),
(428, 'LArry', 'Collins', 'American author of several historical books');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `isbn` varchar(13) collate utf8_bin NOT NULL,
  `title` varchar(100) character set utf8 NOT NULL,
  PRIMARY KEY  (`isbn`,`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`isbn`, `title`) VALUES
('123456', 'The Audacity of Hope'),
('123457', 'Dreams from my father'),
('123458', 'Great Expectations'),
('123459', 'A christmas Carol'),
('123460', 'Sword of the Yui Maiden'),
('123461', 'Gitanjali'),
('123462', 'Anne Frank: The whole story'),
('123463', 'War and Peace'),
('123464', 'Anna Karennina'),
('123465', 'Adventures of Tom Sawyer'),
('123466', 'Adventures of Huckelberry Finn'),
('123467', 'Far from the madding crowd'),
('123468', 'Is Paris burning?');

-- --------------------------------------------------------

--
-- Table structure for table `book_author`
--

CREATE TABLE `book_author` (
  `isbn` varchar(13) collate utf8_bin NOT NULL,
  `author_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`isbn`,`author_id`),
  KEY `author_id` (`author_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `book_author`
--


-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `comment_id` int(10) unsigned NOT NULL auto_increment,
  `timestamp` datetime NOT NULL,
  `text` varchar(1000) collate utf8_bin NOT NULL,
  `isbn` varchar(13) collate utf8_bin NOT NULL,
  `member_id` varchar(10) collate utf8_bin NOT NULL,
  PRIMARY KEY  (`comment_id`),
  KEY `isbn` (`isbn`),
  KEY `member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

--
-- Dumping data for table `comment`
--


-- --------------------------------------------------------

--
-- Table structure for table `keyword`
--

CREATE TABLE `keyword` (
  `isbn` varchar(13) collate utf8_bin NOT NULL,
  `keyword` varchar(20) collate utf8_bin NOT NULL,
  PRIMARY KEY  (`isbn`,`keyword`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `keyword`
--


-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `member_id` varchar(10) collate utf8_bin NOT NULL,
  `pass` varchar(32) collate utf8_bin NOT NULL,
  `name` varchar(50) collate utf8_bin NOT NULL,
  `email` varchar(100) collate utf8_bin NOT NULL,
  PRIMARY KEY  (`member_id`),
  UNIQUE KEY `name` (`name`,`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`member_id`, `pass`, `name`, `email`) VALUES
('suhastech', 'KnN1aGFzMTIz', 'Suhas Manjunath', 'suhas.amrita@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `rate_book`
--

CREATE TABLE `rate_book` (
  `isbn` varchar(13) collate utf8_bin NOT NULL,
  `member_id` varchar(10) collate utf8_bin NOT NULL,
  `rating` int(1) unsigned NOT NULL,
  PRIMARY KEY  (`isbn`,`member_id`),
  KEY `member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `rate_book`
--

INSERT INTO `rate_book` (`isbn`, `member_id`, `rating`) VALUES
('123456', 'suhastech', 5),
('123461', 'suhastech', 5);

-- --------------------------------------------------------

--
-- Table structure for table `subscription`
--

CREATE TABLE `subscription` (
  `member_id` varchar(10) collate utf8_bin NOT NULL,
  `isbn` varchar(100) collate utf8_bin NOT NULL,
  PRIMARY KEY  (`member_id`,`isbn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `subscription`
--


--
-- Constraints for dumped tables
--

--
-- Constraints for table `book_author`
--
ALTER TABLE `book_author`
  ADD CONSTRAINT `book_author_ibfk_1` FOREIGN KEY (`isbn`) REFERENCES `book` (`isbn`),
  ADD CONSTRAINT `book_author_ibfk_2` FOREIGN KEY (`author_id`) REFERENCES `author` (`author_id`);

--
-- Constraints for table `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `comment_ibfk_1` FOREIGN KEY (`isbn`) REFERENCES `book` (`isbn`),
  ADD CONSTRAINT `comment_ibfk_2` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`);

--
-- Constraints for table `keyword`
--
ALTER TABLE `keyword`
  ADD CONSTRAINT `keyword_ibfk_1` FOREIGN KEY (`isbn`) REFERENCES `book` (`isbn`);

--
-- Constraints for table `rate_book`
--
ALTER TABLE `rate_book`
  ADD CONSTRAINT `rate_book_ibfk_1` FOREIGN KEY (`isbn`) REFERENCES `book` (`isbn`),
  ADD CONSTRAINT `rate_book_ibfk_2` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`);

--
-- Constraints for table `subscription`
--
ALTER TABLE `subscription`
  ADD CONSTRAINT `subscription_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`) ON DELETE CASCADE ON UPDATE CASCADE;
