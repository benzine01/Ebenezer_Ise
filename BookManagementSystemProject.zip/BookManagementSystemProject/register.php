<?php
/******************************************************
* Book Subscription System							  *
* Author - Suhas Manjunath Kashyap					  *
* Index Information Page - 'index.php'	        	  *
* Purpose : This page is an INDEX / START Page        *
******************************************************/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title>Book Subscription System</title>
<meta name="Keywords" content="" />
<meta name="Description" content="" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="Content-Language" content="en-ie" />
<meta name="robots" content="all" />
<meta name="MSSmartTagsPreventParsing" content="true" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="copyright" content="Copyright (c) 2008 Suhas Manjunath Kashyap" />
<meta name="author" content="http://www.suhasmanjunath.co.nr/" />
<meta name="Rating" content="General" />
<link rel="shortcut icon" href="" type="image/x-icon" />
<link rel="stylesheet" type="text/css" media="all" href="css/glob_nav.css" />
<link rel="stylesheet" type="text/css" media="all" href="css/template.css" />
</head>
<body bgcolor="#f0f0f0">
<script type="text/javascript">
var emailfilter=/^\w+[\+\.\w-]*@([\w-]+\.)*\w+[\w-]*\.([a-z]{2,4}|\d+)$/i

function checkmail(e){
var returnval=emailfilter.test(e.value)
if (returnval==false){
alert("Please enter a valid email address.")
e.select()
}
return returnval
}

</script>

<div id="header">
<?php
include('login_top.php');
?>
</div>
<?php
include('menu.php');
?>

<div id="body">
<div id="container">
<div id="sidebar1">
    <h3>Search</h3>
    <table border="0">
	<form name="login-form" method="POST" action="search.php">
	<tr>
		<td><input type="text" size="25" name="SEARCH_NAME"/></td>
		<td colspan="2" align="right"><input type="submit" id="button" value="Search" name="LOGIN_SUBMIT"/></td>
	</tr>
	<tr></tr>
	<tr>
		<td>Search Criteria</td>
		<td></td>
	</tr>
	<tr></tr>
	<tr>
		<td><input type="radio" value="title" checked name="R1">Title&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td><input type="radio" name="R1" value="author"> Author&nbsp;</td>
	</tr>
	<tr>
		<td><input type="radio" name="R1" value="keywords"> Keywords</td>
	</tr>
	</form>
	</table>
</div>

<span id="sep"></span>
<div id="mainContent">
<div id="registration_form">
    <h1>Member Registration</h1>
    <form name="registration" action="registration_process.php" method="post">
    <table width="100%" border="0" align="center">
      <tr>
        <td width="49%" align="right">Name</td>
        <td width="3%">&nbsp;</td>
        <td width="48%"><input name="name" type="text" id="name" maxlength="50" /></td>
      </tr>
      <tr>
        <td align="right">e-mail address</td>
        <td>&nbsp;</td>
        <td><input name="email" type="text" id="email" maxlength="100" /></td>
      </tr>
      <tr>
        <td align="right">Member ID</td>
        <td>&nbsp;</td>
        <td><input name="memid" type="text" id="memid" maxlength="10" /></td>
      </tr>
      <tr>
        <td align="right">Password</td>
        <td>&nbsp;</td>
        <td><input name="pass" type="password" id="pass" maxlength="32" /></td>
      </tr>
      <tr>
        <td align="right">Re-type Password</td>
        <td>&nbsp;</td>
        <td><input name="repass" type="password" id="repass" maxlength="32" /></td>
      </tr>
      <tr>
        <td align="right">&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td align="right"><input name="submit" onClick="return checkmail(this.form.email)"type="submit" id="button" value="Submit" /></td>
        <td>&nbsp;</td>
        <td><input type="reset" name="Reset" id="button" value="Reset" /></td>
      </tr>
    </table>
    </form>
    <p>&nbsp;</p>
</div>
</div>
<br class="clearfloat" />
<div id="footer">
    <p>Copyright &copy; Suhas Manjunath Kashyap</p>
    
 </div>
</div>
</div>
</body>
</html>