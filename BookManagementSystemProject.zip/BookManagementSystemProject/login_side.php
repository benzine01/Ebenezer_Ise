<?php
/******************************************************
* Book Subscription System							  *
* Author - Suhas Manjunath Kashyap					  *
* Login Side Action Page - 'login_side.php'		      *
* Purpose : This page is include in every right       *
* sidebar to swap between login form as well as       *
* comments scroller.								  *
******************************************************/
if(!isset($_COOKIE['id'])){
?>
<div id="sidebar2">
  <h3>Login</h3>
    <table border="0">
	<form name="login-form" method="POST" action="login_process.php">
	<tr>
		<td>Username</td>
		<td><input type="text" size="25" name="LOGIN_NAME"/></td>
	</tr>
	<tr>
		<td>Password</td>
		<td><input type="password" size="25" name="LOGIN_PASSWORD"/></td>
	</tr>
	<tr>
		<td colspan="2" align="right"><input type="submit" id="button" value="Login" name="LOGIN_SUBMIT"/></td>
	</tr>
	<tr>
	  <td colspan="2">New User ? <a href="register.php" id="link">Click Here!</a></td>
	  </tr>
	</form>
	</table>
</div>
<?php } 
else {
?>
<div id="sidebar2">
<h3>Comments</h3>
<table border="0">
<tr><td>
<marquee scrollamount="1" scrolldelay="1" direction="up" 
onmouseover="this.stop()" onmouseout="this.start()">
<?php 	
	include("db_connect.php");
	$sql="SELECT * FROM comment ORDER BY timestamp";
	$result=mysql_query($sql);
	if(!$result){
	
		echo "The Result Set failed to access Database! Please Check the programatic error in file.";
		
	}
	while($comment=mysql_fetch_array($result))
	{	
		$text = $comment['text'];
		$member_id = $comment['member_id'];
		echo "<BR>";
		echo $text."<BR>";
		echo "by <b>".$member_id."</b><br>";
	}
	if(mysql_num_rows($result) == 0){
		echo "No Comments Yet!";
	}
?>
</marquee>
</td></tr>
</table>
</div>
<?php } ?>