Install database from Alumni.sql
Database name : alumni
user: root
password: ""
host : ""
