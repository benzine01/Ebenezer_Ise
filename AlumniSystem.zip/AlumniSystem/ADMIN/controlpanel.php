<?php
	header( "Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT" );
    header( "Cache-Control: no-cache, must-revalidate" );
    header( "Pragma: no-cache" );
	session_start();

		$strHTML="";
		if (!isset($_SESSION['LoggedIn'])){
         //not logged in
         $strHTML="<p><center><Form action=login.php method=post>";
         $strHTML=$strHTML."<br><B>User ID:</b>&nbsp;&nbsp;&nbsp;&nbsp;<input type=text name=uname>"; 
         $strHTML=$strHTML."<br><B>Password:</b>&nbsp;<input type=password name=pass>";
         $strHTML=$strHTML."<br><input type=Submit name=submit></form></center>";
        }
		else{
            if (!isset($_GET['action'])){
              $var_action="";
            }
            else{
              $var_action=$_GET['action'];
            }
            switch($var_action){
	          case "logout":
				  unset($_SESSION['LoggedIn']);
       			  header("Location:index.php");
				  exit();
		       break;
	          case "addnew":
				  $strHTML="";
       			  header("Location:addnew.php");
				  exit();
		       break;
	          case "search":
       			  header("Location:search.php");
				  exit();
		       break;
	          default:
            }
        }
?>
<html>
<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta name="author" content="Sudershan Thaiba, sudershanthaiba@gmail.com">
<title>Alumni Administration</title>
</head>

<body>
<table border="0" cellpadding="0" cellspacing="0" width="703" height="387">
  <tr>
    <td width="701" height="86" colspan="2" align="center">
      <blockquote>
        <blockquote>
      <p align="center"><img border="0" src="../banner.jpg" width="464" height="86">
        </blockquote>
      </blockquote>
    </td>
  </tr>
  <tr>
    <td width="152" height="33" align="center" valign="middle">
      <h1 align="center"><b><font color="#006600" face="Haettenschweiler" size="6">Control
      Panel</font></b></h1>
    </td>
    <td width="547" height="241" align="center" rowspan="2">
      <div style="position: absolute; top: 229; left: 167; width: 547; height: 19">
          <? echo $strHTML; ?>
      </div>
    </td>
  </tr>
  <tr>
    <td width="152" height="208" align="left" valign="top">
      <menu>
        <li><a href=<? $_SERVER['PHP_SELF']?>"?action=logout"><b><font color="#000080">Log out</font></b></a></li>
        <li><b><a href=addnew.php><font color="#000080">Add New
          Alumni</font></a></b></li>
        <li><b><a href="search.php"<font color="#000080">Search
          Alumni</font></a></b></li>
      </menu>
    </td>
  </tr>
  <tr>
    <td width="701" height="60" colspan="2" align="center">
      <blockquote>
        <blockquote>
          <p align="center"><font color="#666699">Copyright
      2006, Bluegene Consulting Services<br></font>
      
          <a href="mailto:sudershanthaiba@gmail.com"><font color="#888577">Contact
          Webmaster</font></a>
        </blockquote>
      </blockquote>
      
  </tr>
</table>

</body>

</html>
