﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data; 

namespace NAF.app
{
    public partial class invtmgt : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //UserSession.IsActive = true; UserSession.IDNo = "NAF001";
            //UserSession.FullName = "Grp. Capt. Imafidor"; UserSession.LevId = 1; Role.startFirstUserRole();
                      
            pageAccess();
            if (!IsPostBack)
            {
                hidModule.Value = Role.modInventory;        drpTrailAction.DataBind();

                DataTable locTBL = UserSession.RoleLocIDs; int nLocs = locTBL.Rows.Count; bool isAllLocations = false;
                if (nLocs == 1 && locTBL.Rows[0]["locId"].ToString() == "0" || UserSession.LevId == 1)
                {
                    locTBL = AppSet.getLocation(); nLocs = locTBL.Rows.Count; isAllLocations = true;
                }
                hidnLocIds.Value = nLocs.ToString();

                //chkUserLoc.DataSource = locTBL; chkUserLoc.DataBind(); 

                //drpViewUserLoc.Items.Clear();
                if (isAllLocations)
                {
                    drpPhoneLoc.Items.Add(new ListItem("==ALL LOCATIONS==", "0"));
                    drpViewPhoneLoc.Items.Add(new ListItem("==ALL LOCATIONS==", "0"));
                    drpRptLedgLoc.Items.Add(new ListItem("==ALL LOCATIONS==", "0"));
                }
                drpRptLedgLoc.DataSource = locTBL;   drpRptLedgLoc.DataBind();
                drpViewReqLoc.DataSource = locTBL;   drpViewReqLoc.DataBind();
                drpPhoneLoc.DataSource = locTBL;     drpPhoneLoc.DataBind();
                drpViewPhoneLoc.DataSource = locTBL; drpViewPhoneLoc.DataBind();
                drpSupLoc.DataSource = locTBL;       drpSupLoc.DataBind();
                drpIsuLoc.DataSource = locTBL;       drpIsuLoc.DataBind();
                drpSupIsuLoc.DataSource = locTBL;    drpSupIsuLoc.DataBind();
            }

        }

        protected void pageAccess()
        {

            if (UserSession.IsActive == false || Role.IsValid(Role.modInventory) == false)
            {
                UserSession.End(); Response.Redirect("~/authuser.aspx");
            }
        }

        protected void btnViewInvDept_Click(object sender, EventArgs e) {  GridInvDept.DataBind();   }


        //================ EXPORT ===================================
        public override void VerifyRenderingInServerForm(Control control) { }

        protected void imgExportLedger_Click(object sender, ImageClickEventArgs e)
        {

            if (Session["invGridData"] == null)
                ScriptManager.RegisterStartupScript(this, this.GetType(), "noExceldata",
                    "javascript:alert('No data to Export!!!');", true);
            DataTable tbl = new DataTable(); string fileName = "", gridName = "";
            /* Session["invGrid"] = "LedgerRptSumry"; Session["invGridData"] = tbl;
            Session["invGridFileName"] = "ledger_summaryrpt_date_" + DateTime.Now.ToString("MMM_dd_yyyy(hh_mm_tt)");
            GridLedgerSumry */
            try
            {
                tbl = (DataTable)Session["invGridData"]; fileName = Session["invGridFileName"].ToString();
                gridName = Session["invGrid"].ToString();
            }
            catch { } int[] hidCols = { };
            if (tbl.Rows.Count < 1)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "emptyExpLedgr",
                     "javascript:alert('No record to export...');", true);
                return;
            }
            try
            {
                if (gridName == "LedgerRpt") Export.EXCEL(GridLedger, tbl, hidCols, fileName);
                else Export.EXCEL(GridLedgerSumry, tbl, hidCols, fileName);
            }
            catch
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "unable2ExpLedgr",
                        "javascript:alert('Export not successfull');", true);
            }
        }

        protected void imgExportSrchLedgers_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["GridSrchLedgers"] == null)
                ScriptManager.RegisterStartupScript(this, this.GetType(), "noExcelLedgsdata",
                    "javascript:alert('No data to Export!!!');", true);
            DataTable tbl = new DataTable();
            try { tbl = (DataTable)Session["GridSrchLedgers"]; }
            catch { } int[] hidCols = { };
            if (tbl.Rows.Count < 1)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "emptyExpLedgrs",
                     "javascript:alert('No record to export...');", true); return;
            }
            try
            {
                Export.EXCEL(GridSrchLedgers, tbl, hidCols, "searchedPartsInAllLocations");
            }
            catch
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "unable2ExpLedgrs",
                        "javascript:alert('Export not successfull');", true);
            }
        }

        protected void exportExcel_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["invGridData"] == null)
                ScriptManager.RegisterStartupScript(this, this.GetType(), "noExceldata",
                    "javascript:alert('No data to Export!!!');", true);
            DataTable tbl = new DataTable(); string fileName = "", gridName = "";
            try
            {
                tbl = (DataTable)Session["invGridData"]; fileName = Session["invGridFileName"].ToString();
                gridName = Session["invGrid"].ToString();
            }
            catch { } int[] hidCols = { };

            if (tbl.Rows.Count < 1)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "emptyRptExp",
                     "javascript:alert('No record to export...');", true);
                return;
            }
            try
            {
                if (gridName == "SupplyRpt") Export.EXCEL(GridSupplyRpt, tbl, hidCols, fileName);
                else if (gridName == "IssueRpt") Export.EXCEL(GridIssueRpt, tbl, hidCols, fileName);
            }
            catch
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "unableRptExport",
                        "javascript:alert('Export not successfull');", true);
            }
            /*
             Session["invGrid"] = "GridInvRpt";         Session["invGridData"] = TBL;        
               Session["invGridFileName"] = "supply_hist_from" + fromDate.ToString("MMM_dd_yyyy") + "_to" + toDate.ToString("MMM_dd_yyyy");
             */
        }
         

        protected void ImgExportAuditTrail_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["GridTrailTBL"] == null)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "noExcelAuditData",
                    "javascript:alert('No data to Export!!!');", true); return;
            }
            DataTable tbl = new DataTable(); try { tbl = (DataTable)Session["GridTrailTBL"]; }
            catch { }
            int[] hidCols = { };
            try
            {
                if (tbl.Rows.Count < 1)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "emptyExcelAuditData",
                         "javascript:alert('No record to export...');", true); return;
                }
                Export.EXCEL(GridAuditTrail, tbl, hidCols, "auditTrail");
            }
            catch
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "unable2ExpAudit",
                        "javascript:alert('Export not successfull');", true);
            }
        }

         
    }
}