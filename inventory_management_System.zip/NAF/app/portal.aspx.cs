﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;

namespace NAF.app
{
	public partial class portal : System.Web.UI.Page
	{
		 
		protected void Page_Load(object sender, EventArgs e)
		{
			this.pageAccess();
		}

		protected void pageAccess()
		{
			if (!UserSession.IsActive) { UserSession.End(); Response.Redirect("~/authuser.aspx"); }

			 
			divInvInfo.InnerHtml = "";

			DataTable locTBL = UserSession.RoleLocIDs; int nLocs = locTBL.Rows.Count; 	
			 if (nLocs == 1 && locTBL.Rows[0]["locId"].ToString() == "0" || UserSession.LevId == 1) {
				 locTBL = AppSet.getLocation();				nLocs = locTBL.Rows.Count; 
			 }

			  
			
			 if (nLocs > 0)
			 {
				 int nExpiry = 0, nCrit = 0, nReorder = 0; 
				 foreach (DataRow dr in locTBL.Rows)
				 {
					 int _locId = 0; try { _locId = int.Parse(dr["locId"].ToString()); } catch { }
					 if (_locId > 0)
					 {
						 DataTable invTBL = Inventory.getLedgerDueReordeCritExpiryTBL(_locId);						  
						foreach (DataRow iR in invTBL.Rows)
						{
							int _exp = 0, _crit = 0, _reord = 0; 
							try { _exp = int.Parse(iR["nExpiry"].ToString()); } catch { }
							try { _crit = int.Parse(iR["nCritical"].ToString()); } catch { }
							try { _reord = int.Parse(iR["nReorder"].ToString()); } catch { }
							nExpiry += _exp; nCrit += _crit; nReorder += _reord;
						} 
					 }
				 }
				 string strExpCritOrd = "";
				 if (nExpiry > 0) strExpCritOrd += "<font color='red'>Expiry:<b>" + nExpiry.ToString() + "</b></font>&nbsp;&nbsp;";
				 if (nCrit > 0) strExpCritOrd += "<font color='red'>Critical:<b>" + nCrit.ToString() + "</b></font>&nbsp;&nbsp;";
				 if (nReorder > 0) strExpCritOrd += "<font color='red'>Re-Order:<b>" + nReorder.ToString() + "</b></font>";
				 divInvInfo.InnerHtml = strExpCritOrd;
			 }
		}

	}
}