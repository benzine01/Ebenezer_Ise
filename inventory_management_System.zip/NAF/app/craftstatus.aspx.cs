﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;

namespace NAF.app
{
    public partial class craftstatus : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //UserSession.IsActive = true; UserSession.IDNo = "NAF001";
            //UserSession.FullName = "Grp. Capt. Imafidor"; UserSession.LevId = 1; Role.startFirstUserRole();
            
            pageAccess();
            if (!IsPostBack)
            {
                hidModule.Value = Role.modAircraft;             drpTrailAction.DataBind();

                DataTable locTBL = UserSession.RoleLocIDs; int nLocs = locTBL.Rows.Count; bool isAllLocations = false;
                if (nLocs == 1 && locTBL.Rows[0]["locId"].ToString() == "0" || UserSession.LevId == 1)
                {
                    locTBL = AppSet.getLocation(); nLocs = locTBL.Rows.Count; isAllLocations = true;
                }
                hidnLocIds.Value = nLocs.ToString();

                //chkUserLoc.DataSource = locTBL; chkUserLoc.DataBind();  drpViewUserLoc.Items.Clear();
                if (isAllLocations)
                {
                    
                    //drpRptLedgLoc.Items.Add(new ListItem("==ALL LOCATIONS==", "0"));
                }
                drpViewCraftLoc.DataSource = locTBL; drpViewCraftLoc.DataBind();
                drpFlightLoc.DataSource = locTBL;   drpFlightLoc.DataBind();
                
                //craftTBL = obj.getAirCraftStatus(UserSession.LocationID);
                //drptkCraft.DataSource = craftTBL; drptkCraft.DataBind();
                
            }

        }

        protected void pageAccess()
        {

            if (UserSession.IsActive == false || Role.IsValid(Role.modAircraft) == false)
            {
                UserSession.End(); Response.Redirect("~/authuser.aspx");
            }
        }

        protected void drpFlightLoc_SelectedIndexChanged(object sender, EventArgs e)
        {
            drptkCraft.Items.Clear(); drptkCraft.DataBind();
            //drptkCraft.Items.Add(new ListItem("==CALL SIGN==", ""));
            ScriptManager.RegisterStartupScript(this, this.GetType(), "callCallSign",
                    "javascript:onChangeCraft();", true); return;
        }

        //================ EXPORT ===================================
        public override void VerifyRenderingInServerForm(Control control) { }

        protected void ImgExportAuditTrail_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["GridTrailTBL"] == null)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "noExcelAuditData",
                    "javascript:alert('No data to Export!!!');", true); return;
            }
            DataTable tbl = new DataTable(); try { tbl = (DataTable)Session["GridTrailTBL"]; }
            catch { }
            int[] hidCols = { };
            try
            {
                if (tbl.Rows.Count < 1)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "emptyExcelAuditData",
                         "javascript:alert('No record to export...');", true); return;
                }
                Export.EXCEL(GridAuditTrail, tbl, hidCols, "auditTrail");
            }
            catch
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "unable2ExpAudit",
                        "javascript:alert('Export not successfull');", true);
            }
        }

        


    }
}