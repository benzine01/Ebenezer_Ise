﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NAF.app
{
	public partial class barcode : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			this.pageAccess();
		}

		protected void pageAccess()
		{
			if (!UserSession.IsActive) { UserSession.End(); Response.Redirect("~/authuser.aspx"); }
		}
	}
}