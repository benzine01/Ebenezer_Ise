﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data; 

namespace NAF.app
{
    public partial class ecomgt : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            //UserSession.IsActive = true; UserSession.IDNo = "NAF001";
            //UserSession.FullName = "Grp. Capt. Imafidor"; UserSession.LevId = 1; Role.startFirstUserRole();
                       
            pageAccess(); 
            if (!IsPostBack)
            {
                hidModule.Value = Role.modECO;

                DataTable locTBL = UserSession.RoleLocIDs; int nLocs = locTBL.Rows.Count; bool isAllLocations = false;
                if (nLocs == 1 && locTBL.Rows[0]["locId"].ToString() == "0" || UserSession.LevId == 1)
                {
                    locTBL = AppSet.getLocation(); nLocs = locTBL.Rows.Count; isAllLocations = true;
                }
                hidnLocIds.Value = nLocs.ToString();

                //chkUserLoc.DataSource = locTBL; chkUserLoc.DataBind(); 
                if (isAllLocations)
                {
                    drpPhoneLoc.Items.Add(new ListItem("==ALL LOCATIONS==", "0"));
                    drpViewPhoneLoc.Items.Add(new ListItem("==ALL LOCATIONS==", "0"));
                    //drpViewReqLoc.Items.Add(new ListItem("==ALL LOCATIONS==", "0"));
                }
                drpPhoneLoc.DataSource = locTBL;        drpPhoneLoc.DataBind();
                drpViewPhoneLoc.DataSource = locTBL;    drpViewPhoneLoc.DataBind();
                drpReqLoc.DataSource = locTBL;          drpReqLoc.DataBind();
                drpViewReqLoc.DataSource = locTBL;      drpViewReqLoc.DataBind();
            }

        }

        protected void pageAccess()
        {

            if (UserSession.IsActive == false || Role.IsValid(Role.modECO) == false)
            {
                UserSession.End(); Response.Redirect("~/authuser.aspx");
            }
        }

        //================ EXPORT ===================================
        public override void VerifyRenderingInServerForm(Control control) { }

        protected void drpTrailModules_SelectedIndexChanged(object sender, EventArgs e)
        {
            drpTrailAction.Items.Clear();
            drpTrailAction.Items.Add(new ListItem("=== ALL ACTIONS ===", ""));
            drpTrailAction.DataBind();
        }

        protected void ImgExportAuditTrail_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["GridTrailTBL"] == null)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "noExcelAuditData",
                    "javascript:alert('No data to Export!!!');", true); return;
            }
            DataTable tbl = new DataTable(); try { tbl = (DataTable)Session["GridTrailTBL"]; }
            catch { }
            int[] hidCols = { };
            try
            {
                if (tbl.Rows.Count < 1)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "emptyExcelAuditData",
                         "javascript:alert('No record to export...');", true); return;
                }
                Export.EXCEL(GridAuditTrail, tbl, hidCols, "auditTrail");
            }
            catch
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "unable2ExpAudit",
                        "javascript:alert('Export not successfull');", true);
            }
        }

       
 

    }
}