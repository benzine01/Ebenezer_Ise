﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NAF.app
{
    public partial class takeoff_hist : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string callSign = "";
            try { if (Request.QueryString["cs"] != null) callSign = Request.QueryString["cs"].ToString().Trim(); }
            catch { }
            if (callSign.Length < 3)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "unknowCallSign",
                    "javascript: alert('Unknown CallSign'); ", true);
            }

            if (!UserSession.IsActive)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "userTimeOut",
                    "javascript:alert('Please Login'); location.href='../login.aspx';", true); return;
            }
            hidCallSign.Value = callSign; spanCallSign.InnerHtml = callSign;

        }
    }
}