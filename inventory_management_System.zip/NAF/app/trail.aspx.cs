﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;

namespace NAF.app
{
	public partial class trail : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			pageAccess();
		}
		protected void pageAccess()
		{

			if (UserSession.IsActive == false || (UserSession.LevId < 1 || UserSession.LevId > 2))
			{
				UserSession.End(); Response.Redirect("~/authuser.aspx");
			}
		}

		//================ EXPORT ===================================
		public override void VerifyRenderingInServerForm(Control control) { }


		 
		protected void drpTrailModules_SelectedIndexChanged(object sender, EventArgs e)
		{
			drpTrailAction.Items.Clear();
			drpTrailAction.Items.Add(new ListItem("=== ALL ACTIONS ===", ""));
			drpTrailAction.DataBind();
		}

		protected void ImgExportAuditTrail_Click(object sender, ImageClickEventArgs e)
		{
			if (Session["GridTrailTBL"] == null)
			{
				ScriptManager.RegisterStartupScript(this, this.GetType(), "noExcelAuditData",
					"javascript:alert('No data to Export!!!');", true); return;
			}
			DataTable tbl = new DataTable(); try { tbl = (DataTable)Session["GridTrailTBL"]; }
			catch { }
			int[] hidCols = { };
			try
			{
				if (tbl.Rows.Count < 1)
				{
					ScriptManager.RegisterStartupScript(this, this.GetType(), "emptyExcelAuditData",
						 "javascript:alert('No record to export...');", true); return;
				}
				Export.EXCEL(GridAuditTrail, tbl, hidCols, "auditTrail");
			}
			catch
			{
				ScriptManager.RegisterStartupScript(this, this.GetType(), "unable2ExpAudit",
						"javascript:alert('Export not successfull');", true);
			}
		}



	}
}