﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data; 

namespace NAF.app
{
    public partial class appset : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //UserSession.IsActive = true; UserSession.IDNo = "NAF001";
            //UserSession.FullName = "Grp. Capt. Imafidor"; UserSession.LevId = 1; Role.startFirstUserRole();
            
            pageAccess();

            if (!IsPostBack)
            {                
                DataTable locTBL = UserSession.RoleLocIDs; int nLocs = locTBL.Rows.Count; bool isAllLocations = false;
                if (nLocs == 1 && locTBL.Rows[0]["locId"].ToString() == "0"  || UserSession.LevId == 1)
                {
                    locTBL = AppSet.getLocation(); nLocs = locTBL.Rows.Count; isAllLocations = true;
                }
                chkUserLoc.DataSource = locTBL; chkUserLoc.DataBind(); hidnLocIds.Value = nLocs.ToString();

                drpViewUserLoc.Items.Clear();
                if (isAllLocations)
                {
                    drpViewUserLoc.Items.Add(new ListItem("==ALL LOCATIONS==", "0"));
                    drpCraftLoc.Items.Add(new ListItem("==ALL LOCATIONS==", "0"));
                }
                drpViewUserLoc.DataSource = locTBL; drpViewUserLoc.DataBind();

                drpAirLoc.DataSource = locTBL; drpAirLoc.DataBind();
                drpCraftLoc.DataSource = locTBL; drpCraftLoc.DataBind();
                drpOficLoc.DataSource = locTBL; drpOficLoc.DataBind();
            }

        }

        protected void pageAccess()
        {

            if (UserSession.IsActive == false || (UserSession.LevId < 1 || UserSession.LevId > 2))
            {
                UserSession.End(); Response.Redirect("~/authuser.aspx");
            }
        }

        //================ EXPORT ===================================
        public override void VerifyRenderingInServerForm(Control control) { }


        protected void ImgExportUsers_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["sesGridUserTBL"] == null)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "noExcelUsersData",
                    "javascript:alert('No data to Export!!!');", true); return;
            }
            DataTable tbl = new DataTable(); try { tbl = (DataTable)Session["sesGridUserTBL"]; }
            catch { } int[] hidCols = { };
            try
            {
                if (tbl.Rows.Count < 1)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "emptyExcelUsersData",
                         "javascript:alert('No record to export...');", true); return;
                } Export.EXCEL(GridUsers, tbl, hidCols, "users");
            }
            catch
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "unable2ExpUsers",
                  "javascript:alert('Export not successfull');", true);
            }
        }

        protected void drpTrailModules_SelectedIndexChanged(object sender, EventArgs e)
        {
            drpTrailAction.Items.Clear();
            drpTrailAction.Items.Add(new ListItem("=== ALL ACTIONS ===", ""));
            drpTrailAction.DataBind();
        }

        protected void ImgExportAuditTrail_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["GridTrailTBL"] == null)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "noExcelAuditData",
                    "javascript:alert('No data to Export!!!');", true); return;
            }
            DataTable tbl = new DataTable(); try { tbl = (DataTable)Session["GridTrailTBL"]; }
            catch { }
            int[] hidCols = { };
            try
            {
                if (tbl.Rows.Count < 1)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "emptyExcelAuditData",
                         "javascript:alert('No record to export...');", true); return;
                }
                Export.EXCEL(GridAuditTrail, tbl, hidCols, "auditTrail");
            }
            catch
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "unable2ExpAudit",
                        "javascript:alert('Export not successfull');", true);
            }
        }




        protected void btnLoadLoc_Click(object sender, ImageClickEventArgs e) {  GridLoc.DataBind();   }
        protected void btnViewAircraft_Click(object sender, EventArgs e)
        {            
            divAirFeedBck.InnerHtml = "";
            int locId = 0; try { locId = int.Parse(drpCraftLoc.SelectedValue.ToString()); }
            catch { divAirFeedBck.InnerHtml = "<font color='red'>Select the Location</font>"; return; }
            if (locId == 0) GridAircraft.DataSourceID = "SqlGridAirCraft0"; else GridAircraft.DataSourceID = "SqlGridAirCraft";

            GridAircraft.DataBind();
            GridAircraft.Caption = "<div class='tblHead' style='width:500px;'>LOCATION: " + ((locId == 0)? 
                "ALL LOCATIONS" : drpCraftLoc.SelectedItem.Text) + "</div>";
        }
        protected void drpCraftLoc_SelectedIndexChanged(object sender, EventArgs e) {  btnViewAircraft_Click(sender, e);  }

         
    }
}