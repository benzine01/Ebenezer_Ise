﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data.SqlClient;
using System.Configuration;
using System.Data; 

public class Inventory
{
    private SqlConnection _conn = new SqlConnection(Connect.CONN());
    private static SqlConnection conn = new SqlConnection(Connect.CONN());
    public static string error{ get; set; }

    public static bool setAlertNos(int locId, int typId, int deptId, string phone, string email, string RegIDNo)
    {
        string sql = "INSERT INTO invAlertNo(locId,typId,deptId,phone,email,RegIDNo,RegDate) " +
            " VALUES(@locId,@typId,@deptId,@phone,@email,@IDNo,@dt) ";
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@locId", locId);        cmd.Parameters.AddWithValue("@typId", typId);
        cmd.Parameters.AddWithValue("@deptId", deptId);      cmd.Parameters.AddWithValue("@phone", phone.Trim());
        cmd.Parameters.AddWithValue("@email", email.Trim());
        cmd.Parameters.AddWithValue("@IDNo", RegIDNo);       cmd.Parameters.AddWithValue("@dt", DateTime.Now);   int added = 0;
        try {  conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString());
        } catch (Exception ex) { error = ex.Message; } finally { conn.Close(); }
        string trailMsg = "added alert numbers, LOCATION: " + ((locId == 0)? "ALL LOCATIONS" : AppSet.getLocationName(locId)) +
            ", TYPE: " + ((typId == 0)? "ALL TYPES" : getTypeName(typId)) + 
            ", DEPT: " + ((deptId == 0)? "ALL DEPT" : getDeptName(deptId)) + ", PHONE: " + phone + ", EMAIL: " + email;
        Trail.setNew(Role.modInventory, "ADD", "", trailMsg, ((added > 0) ? true : false), error); return (added > 0) ? true : false;
    }

    public static DataTable getAlertNos(int locId, int typId)
    {
        string where = "";
        if (locId > 0) where = " OR (a.locId = @locId "; else where = " OR (a.locId >= @locId ";
        if (typId > 0) where += " AND a.typId = @typId) "; else where += " AND a.typId >= @typId) ";

        string sql = "SELECT a.*, (SELECT l.Name FROM location l WHERE l.Id = a.locId) AS Location, " +
            " (SELECT t.Name FROM invType t WHERE t.Id = a.typId) AS typeName, " +
            " (SELECT d.Name FROM invDept d WHERE d.Id = a.deptId) AS deptName FROM invAlertNo a WHERE a.locId = @zero " + where;
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);           dr.SelectCommand.Parameters.AddWithValue("@zero", 0);
        dr.SelectCommand.Parameters.AddWithValue("@locId", locId);   dr.SelectCommand.Parameters.AddWithValue("@typId", typId);
        DataTable TBL = new DataTable();    try { dr.Fill(TBL); conn.Close(); } catch { }    return TBL;
    }
    public static DataTable getAlertPhoneEmailNos(int locId, int typId, int deptId)
    {        
        string sql = "SELECT phone,email FROM invAlertNo WHERE (locId = @loc AND typId = @typ AND deptId = @dept) ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);         dr.SelectCommand.Parameters.AddWithValue("@loc", locId); 
        dr.SelectCommand.Parameters.AddWithValue("@typ", typId);   dr.SelectCommand.Parameters.AddWithValue("@dept", deptId);
        DataTable TBL = new DataTable(); try { dr.Fill(TBL); conn.Close(); } catch { } return TBL;
    }

    private static DataTable getAlertNos(int Id)
    {       
        string sql = "SELECT a.*, (SELECT l.Name FROM location l WHERE l.Id = a.locId) AS Location, " +
            " (SELECT t.Name FROM invType t WHERE t.Id = a.typId) AS typeName, " +
            " (SELECT d.Name FROM invDept d WHERE d.Id = a.deptId) AS deptName FROM invAlertNo a WHERE a.Id = @id ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn); dr.SelectCommand.Parameters.AddWithValue("@id", Id); 
        DataTable TBL = new DataTable(); try { dr.Fill(TBL); conn.Close(); } catch { } return TBL;
    }

    public static bool deleteAlertNos(int Id)
    {
        DataTable TBL = getAlertNos(Id);
        string sql = "DELETE FROM invAlertNo WHERE Id = @id ";
        SqlCommand cmd = new SqlCommand(sql, conn);  cmd.Parameters.AddWithValue("@id", Id);   int added = 0;
        try { conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString());
        }  catch (Exception ex) { error = ex.Message; } finally { conn.Close(); }
        if (added > 0 && TBL.Rows.Count > 0)
        {
            DataRow dr = TBL.Rows[0];
            string loc = dr["Location"].ToString().Trim();     string typ = dr["typeName"].ToString().Trim();
            string dept = dr["deptName"].ToString().Trim();
            string trailMsg = "deleted alert numbers, LOCATION: " + ((loc.Length < 2) ? "ALL LOCATIONS" : loc) +
                ", TYPE: " + ((typ.Length < 2) ? "ALL TYPES" : typ) +
                ", DEPT: " + ((dept.Length < 2) ? "ALL DEPT" : dept) + ", PHONE: " + dr["phone"].ToString() +
                ", EMAIL: " + dr["email"].ToString();
            Trail.setNew(Role.modInventory, "DELETE", "", trailMsg, ((added > 0) ? true : false), error);
        }
        return (added > 0) ? true : false;
    }

    //-------------- Type -------------------------
    public static bool setType(string name, bool isSales)
    {
        error = "<font color='red'>Type Name: " + name + ", already exist...</font>";  
		if (isTypeExist(name)) return false; error = "";
        string sql = "INSERT INTO invType(Name,IsSales) VALUES(@name,@sales) ";
        SqlCommand cmd = new SqlCommand(sql, conn); int added = 0;
        cmd.Parameters.AddWithValue("@name", name.Trim());      cmd.Parameters.AddWithValue("@sales", isSales);
        try { conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { error = ex.Message; } finally { conn.Close(); }
        Trail.setNew(Role.modInventory, "ADD", "", "TYPE: " + name + ", Sales: " + isSales.ToString(), ((added > 0) ? true : false),
            error);
        return (added > 0) ? true : false;
    }

    public static bool isTypeExist(string name) { return (getType(name).Rows.Count > 0) ? true : false; }
    public static DataTable getType() { return getType(""); }
    public static DataTable getType(string name)
    {
        string where = ""; if (name.Trim().Length > 1) where = " WHERE Name = @name ";
        string sql = "SELECT * FROM invType " + where + " ORDER BY Name ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn); DataTable TBL = new DataTable();
        if (name.Trim().Length > 1) dr.SelectCommand.Parameters.AddWithValue("@name", name.Trim());   
        try { dr.Fill(TBL); conn.Close(); }  catch { } return TBL;
    }
    public static DataTable getType(bool isSales)
    {
        string sql = "SELECT * FROM invType  WHERE IsSales = @valu ORDER BY Name ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn); DataTable TBL = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@valu", isSales); try { dr.Fill(TBL); conn.Close(); } catch { } return TBL;
    }
    public static DataTable getType(int Id)
    {         
        string sql = "SELECT * FROM invType WHERE Id = @id ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);     DataTable TBL = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@id", Id);   try { dr.Fill(TBL); conn.Close(); } catch { } return TBL;
    }
    public static string getTypeName(int Id) {  try { return getType(Id).Rows[0]["Name"].ToString(); } catch { return ""; }  }
    public static bool isTypeSales(int Id) { try { return bool.Parse(getType(Id).Rows[0]["IsSales"].ToString()); 
    } catch { return false; } }
  
    
    //-------------- Department -------------------
    public static bool setDept(int typId, string name)
    {
        error = "<font color='red'>Dept Name: " + name + ", already exist...</font>"; if (isDeptExist(typId, name)) return false; 
        error = "";
        string sql = "INSERT INTO invDept(typId,Name) VALUES(@typ,@name) ";
        SqlCommand cmd = new SqlCommand(sql, conn);         int added = 0;
        cmd.Parameters.AddWithValue("@typ", typId);         cmd.Parameters.AddWithValue("@name", name.Trim()); 
        try { conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { error = ex.Message; }  finally { conn.Close(); }        
        Trail.setNew(Role.modInventory, "ADD", "", "DEPARTMENT: " + name + " of TYPE: " + getTypeName(typId), ((added > 0) ? true : false),
            error);        return (added > 0) ? true : false;
    }

    public static bool isDeptExist(int typId, string name) { return (getDept(typId, name).Rows.Count > 0) ? true : false; }
    public static DataTable getDept(int typId) {   return getDept(typId, "");    }
    public static DataTable getDept(int typId, string name)
    {
        string where = ""; if (name.Trim().Length > 1) where = " AND Name = @name ";
        string sql = "SELECT * FROM invDept WHERE typId = @typ " + where + " ORDER BY Name ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);          DataTable TBL = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@typ", typId);
        if (name.Trim().Length > 1) dr.SelectCommand.Parameters.AddWithValue("@name", name.Trim());
        try { dr.Fill(TBL); conn.Close(); } catch { } return TBL;
    }
    public static DataTable getDeptById(int deptId)
    {        
        string sql = "SELECT Name FROM invDept WHERE Id = @id ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);         DataTable TBL = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@id", deptId);   try { dr.Fill(TBL); conn.Close(); } catch { } return TBL;
    }
    public static string getDeptName(int deptId) { try { return getDeptById(deptId).Rows[0]["Name"].ToString(); } catch { return ""; } }


    //------------- VENDOR -------------------
    public static bool setVendor(string refNo, string name, string contName, string phone, string email, string addr, string website,
        string rmk, string dealerOn, DateTime refRegDate, string regIDNo)
    {
        string sql = "INSERT INTO invVendor(RefNo,Name,ContactName,Phone,Email,Addr,Website,RMK,DealerOn,RegisterDt,RegIDNo,RegDate) " +
            " VALUES(@RefNo,@Name,@ContName,@Phone,@Email,@Addr,@Website,@RMK,@DealerOn,@refRegDt,@RegIDNo,@RegDate) ";
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@RefNo", refNo.Trim());        cmd.Parameters.AddWithValue("@Name", name.Trim());
        cmd.Parameters.AddWithValue("@ContName", contName.Trim());  cmd.Parameters.AddWithValue("@Phone", phone);
        cmd.Parameters.AddWithValue("@Email", email);               cmd.Parameters.AddWithValue("@Addr", addr);
        cmd.Parameters.AddWithValue("@Website", website);           cmd.Parameters.AddWithValue("@RMK", rmk);
        cmd.Parameters.AddWithValue("@DealerOn", dealerOn);         cmd.Parameters.AddWithValue("@refRegDt", refRegDate);
        cmd.Parameters.AddWithValue("@RegIDNo", regIDNo);       cmd.Parameters.AddWithValue("@RegDate", DateTime.Now);  int added = 0;
        try { conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { error = ex.Message; } finally { conn.Close(); }
        Trail.setNew(Role.modInventory, "ADD", "", "add VENDOR, REF. No.: " + refNo + " NAME: " + name, ((added > 0) ? true : false),
            error); return (added > 0) ? true : false;  
    }
    public static bool isVendorExist(string refNo) { return (getVendor(refNo).Rows.Count > 0) ? true : false; }
    public static DataTable getVendor() { return getVendor(""); }
    public static DataTable getVendor(string refNo)
    {
        string where = ""; if (refNo.Trim().Length > 0) where = " WHERE RefNo = @ref ";
        string sql = "SELECT * FROM invVendor " + where + " ORDER BY RefNo ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);          DataTable TBL = new DataTable();
        if(refNo.Trim().Length > 0) dr.SelectCommand.Parameters.AddWithValue("@ref", refNo);
        try { dr.Fill(TBL); conn.Close(); } catch { } return TBL;
    }
    public static DataTable getSearchVendor(string valu)
    {         
        string sql = "SELECT * FROM invVendor WHERE RefNo LIKE @valu OR Name LIKE @valu OR ContactName LIKE @valu " +
            " OR Phone LIKE @valu OR Email LIKE @valu OR Addr LIKE @valu OR Website LIKE @valu OR RMK LIKE @valu OR " +
            " DealerOn LIKE @valu OR YEAR(RegisterDt) = @valuYr OR RegIDNo LIKE @valu ORDER BY RefNo ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn); DataTable TBL = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@valu", ("%" + valu.Trim() + "%"));
        int year = 0; try { year = int.Parse(valu.Trim()); } catch { }
        dr.SelectCommand.Parameters.AddWithValue("@valuYr", year);   try { dr.Fill(TBL); conn.Close(); } catch { } return TBL;
    }

    //------------- SUPPLY HISTORY - LEDGER ----------------------- 
    public static bool setPart(int locId, int typId, int deptId, string rack, string card, string part, string serial,
        string name, int qty, string dOfQ, bool isMfg, bool isExp, DateTime mfgDt, DateTime expDt, decimal costPrice, bool isSalesPcent,
        decimal rate, decimal unitPrice, int reOrderQty, int critQty, string rmk, string vendor, string regIDNo)
    {

        bool isAdded = setSupplyHist(locId, typId, deptId, rack, card, part, serial, name, qty, dOfQ, isMfg, isExp, mfgDt, expDt,
            costPrice, isSalesPcent, rate, unitPrice, rmk, vendor, regIDNo);
        if (isAdded)
        {
            DataTable partTBL = getLedgerTBL(locId, typId, card);
            bool isNewPart = (partTBL.Rows.Count == 0) ? true : false;
            int stockQty = (isNewPart) ? 0 : int.Parse(partTBL.Rows[0]["Qty"].ToString());

            int currentQty = stockQty + qty;
            bool isPartAdded = setLedger(locId, typId, deptId, rack, card, part, serial, name, currentQty, dOfQ, isMfg, isExp,
                mfgDt, expDt, costPrice, isSalesPcent, rate, unitPrice, reOrderQty, critQty, vendor, isNewPart);
            return isPartAdded;
        }
        else return false; 
    }

    private static bool setLedger(int locId, int typId, int deptId, string rack, string card, string part, string serial,
        string name, int qty, string dOfQ, bool isMfg, bool isExp, DateTime mfgDt, DateTime expDt, decimal costPrice, bool isSalesPcent,
        decimal rate, decimal unitPrice, int reOrderQty, int critQty, string vendorID, bool isNew_Item)
    {
        string sql = "";
        if (isNew_Item)
            sql = "INSERT INTO invLedger(locId,typId,deptId,RackNo,CardNo,PartNo,SerialNo,Name,Qty,DofQ,IsMfg,IsExp," +
               " MfgDt,ExpDt,costPrice,IsSalesPcent,Rate,unitPrice,orderQty,critQty,vendorID) " +
               " VALUES(@loc,@typ,@dept,@rack,@card,@part,@serial,@name,@Qty,@DofQ,@IsMfg,@IsExp," +
               " @MfgDt,@ExpDt,@costPrice,@IsSalesPcent,@rate,@unitPrice,@ordQty,@critQty,@vendId) ";
        else
  sql = "UPDATE invLedger SET deptId = @dept, RackNo = @rack,PartNo = @part,SerialNo = @serial,Name = @name,Qty = @Qty,DofQ = @DofQ," +
            " IsMfg = @IsMfg,IsExp = @IsExp,MfgDt = @MfgDt,ExpDt = @ExpDt,costPrice = @costPrice,IsSalesPcent = @IsSalesPcent," +
            " Rate = @rate,unitPrice = @unitPrice, orderQty = @ordQty, critQty = @critQty, vendorID = @vendId " +
            " WHERE locId = @loc AND typId = @typ AND CardNo = @card ";
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@loc", locId);             cmd.Parameters.AddWithValue("@typ", typId);
        cmd.Parameters.AddWithValue("@dept", deptId);           cmd.Parameters.AddWithValue("@rack", rack.Trim());
        cmd.Parameters.AddWithValue("@card", card.Trim());      cmd.Parameters.AddWithValue("@part", part.Trim());
        cmd.Parameters.AddWithValue("@serial", serial.Trim());  cmd.Parameters.AddWithValue("@name", name.Trim());
        cmd.Parameters.AddWithValue("@Qty", qty);               cmd.Parameters.AddWithValue("@DofQ", dOfQ);
        cmd.Parameters.AddWithValue("@IsMfg", isMfg);           cmd.Parameters.AddWithValue("@IsExp", isExp);
        cmd.Parameters.AddWithValue("@MfgDt", mfgDt);           cmd.Parameters.AddWithValue("@ExpDt", expDt);
        cmd.Parameters.AddWithValue("@costPrice", costPrice);   cmd.Parameters.AddWithValue("@IsSalesPcent", isSalesPcent);
        cmd.Parameters.AddWithValue("@rate", rate);             cmd.Parameters.AddWithValue("@unitPrice", unitPrice);
        cmd.Parameters.AddWithValue("@ordQty", reOrderQty);     cmd.Parameters.AddWithValue("@critQty", critQty);
        cmd.Parameters.AddWithValue("@vendId", vendorID);       int added = 0;
        try { conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString()); } catch (Exception ex) { error = ex.Message; }
        finally { conn.Close(); } return (added > 0) ? true : false;
    }
    
    public static DataTable getLedgerTBL(int locId, int typId, string cardNo)
    {
        string sql = "SELECT i.*, (SELECT d.Name FROM invDept d WHERE d.Id = i.deptId) AS Dept " +
            " FROM invLedger i WHERE i.locId = @loc AND i.typId = @typ AND i.CardNo = @card ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);          DataTable tbl = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@loc", locId);    dr.SelectCommand.Parameters.AddWithValue("@typ", typId);
        dr.SelectCommand.Parameters.AddWithValue("@card", cardNo.Trim());  try { dr.Fill(tbl); conn.Close(); } catch { } return tbl;
    }
    public static DataTable getLedgerTBL(long Id)
    {
        string sql = "SELECT i.*, (SELECT d.Name FROM invDept d WHERE d.Id = i.deptId) AS Dept " +
            " FROM invLedger i WHERE i.Id = @id ORDER BY i.CardNo ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn); DataTable tbl = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@id", Id);   try { dr.Fill(tbl); conn.Close(); } catch { } return tbl;
    }
    public static DataTable getLedgerPartCardTBL(int locId, int typId, string cardNo)
    {
        string sql = "SELECT i.*, (SELECT d.Name FROM invDept d WHERE d.Id = i.deptId) AS Dept " +
            " FROM invLedger i WHERE (i.locId = @loc AND i.typId = @typ) AND (i.CardNo = @card OR i.PartNo = @card) ORDER BY i.CardNo ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);              DataTable tbl = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@loc", locId);        dr.SelectCommand.Parameters.AddWithValue("@typ", typId);
        dr.SelectCommand.Parameters.AddWithValue("@card", cardNo.Trim());  try { dr.Fill(tbl); conn.Close(); } catch { } return tbl;
    }

    public static DataTable getLedgerTBL(int locId, int typId)
    {
        string sql = "SELECT i.*, (SELECT d.Name FROM invDept d WHERE d.Id = i.deptId) AS Dept " +
            " FROM invLedger i WHERE i.locId = @loc AND i.typId = @typ ORDER BY i.CardNo ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);    DataTable TBL = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@loc", locId);    dr.SelectCommand.Parameters.AddWithValue("@typ", typId);
        try { dr.Fill(TBL); conn.Close(); } catch { } return TBL;
    }
    public static DataTable getLedgerCritReorderTBL(int locId, int typId, bool isCrit_Reorder)
    {
        string field = (isCrit_Reorder) ? " i.critQty >= i.Qty AND i.critQty > @zero " : " i.orderQty >= i.Qty AND i.orderQty > @zero ";
        string sql = "SELECT i.*, (SELECT d.Name FROM invDept d WHERE d.Id = i.deptId) AS Dept " +
            " FROM invLedger i WHERE i.locId = @loc AND i.typId = @typ AND " + field + " ORDER BY Dept, i.CardNo ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);          DataTable TBL = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@loc", locId);    dr.SelectCommand.Parameters.AddWithValue("@typ", typId);
        dr.SelectCommand.Parameters.AddWithValue("@zero", 0);       try { dr.Fill(TBL); conn.Close(); } catch { } return TBL;
    }
    public static DataTable getLedgerDueExpiryTBL(int locId, int typId)
    {
        DateTime dt = DateTime.Now.AddMonths(1);
        string sql = "SELECT i.*, (SELECT d.Name FROM invDept d WHERE d.Id = i.deptId) AS Dept  " +
            " FROM invLedger i WHERE i.locId = @loc AND i.typId = @typ AND " +
            " (i.ExpDt <= @dt AND i.IsExp = @isExp AND i.Qty > @zero) ORDER BY Dept, i.CardNo ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);               DataTable TBL = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@loc", locId);         dr.SelectCommand.Parameters.AddWithValue("@typ", typId);
        dr.SelectCommand.Parameters.AddWithValue("@dt", dt);             dr.SelectCommand.Parameters.AddWithValue("@isExp", true);
        dr.SelectCommand.Parameters.AddWithValue("@zero", 0);            try { dr.Fill(TBL); conn.Close(); }  catch { } return TBL;
    }
    public static DataTable getLedgerDueReordeCritExpiryTBL(int locId)
    {
        DateTime dt = DateTime.Now.AddMonths(1);
        string sql = "SELECT t.*, " +
            " (SELECT COUNT(Id) FROM invLedger WHERE ExpDt <= @dt AND IsExp = @exp AND Qty > @zero AND locId = @loc AND typId = t.Id) " +
            " AS nExpiry, " +
            " (SELECT COUNT(Id) FROM invLedger WHERE critQty >= Qty AND critQty > @zero AND locId = @loc AND typId = t.Id) AS nCritical, " +
            " (SELECT COUNT(Id) FROM invLedger WHERE orderQty >= Qty AND orderQty > @zero AND locId = @loc AND typId = t.Id) AS nReorder " +
            " FROM invType t ORDER BY t.IsSales, t.Name ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);          DataTable TBL = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@dt", dt);        dr.SelectCommand.Parameters.AddWithValue("@exp", true);
        dr.SelectCommand.Parameters.AddWithValue("@zero", 0);       dr.SelectCommand.Parameters.AddWithValue("@loc", locId);
        try {  dr.Fill(TBL); conn.Close(); } catch { }  return TBL; 
    }

    public static string PieChartValus, BarChartValus;
    public static void getLedgerChartValus(DataTable TBL)
    {
        PieChartValus = ""; BarChartValus = "";
        string pieValus = "", barValus = "";
        var deptRows = (from DataRow row in TBL.Rows
                        select new { deptName = row["Dept"] }).Distinct();
        foreach (var dRow in deptRows)
        {
            string dept = dRow.deptName.ToString(); int items = 0;
            items = TBL.AsEnumerable().Count(n => (n.Field<string>("Dept") == dept));
            pieValus += (dept + ":" + items.ToString() + ",");

            int reOrderQty = 0, critQty = 0, normalQty = 0, expiryQty = 0;
            int totalQty = TBL.AsEnumerable().Count();
            reOrderQty = TBL.AsEnumerable().Count(n => (n.Field<int>("orderQty") >= n.Field<int>("Qty")));
            critQty = TBL.AsEnumerable().Count(n => (n.Field<int>("critQty") >= n.Field<int>("Qty")));
            reOrderQty = reOrderQty - critQty;

            DateTime dt = DateTime.Now.AddMonths(1);
            expiryQty = TBL.AsEnumerable().Count(n => (n.Field<DateTime>("ExpDt") <= dt
                && n.Field<bool>("IsExp") == true && n.Field<int>("Qty") > 0));
            normalQty = totalQty - reOrderQty - critQty;
            //<input type="hidden" id="hidBarChatValus" value="catg,male,female;catg,male,female;" />
            barValus += (dept + "," + normalQty.ToString() + "," + reOrderQty.ToString() + "," + critQty.ToString() + "," +
                expiryQty.ToString() + ";");
        }
        PieChartValus = pieValus;      BarChartValus = barValus;
    }
    
    public static DataTable searchLedgerTBL(int typId, string searchValu) { return searchLedgerTBL(0, typId, 0, searchValu); }
    public static DataTable searchLedgerTBL(int locId, int typId, int deptId, string searchValu)
    {
        string locF = ""; if (locId > 0) locF = " i.locId = @loc AND ";
        string deptF = ""; if (deptId > 0) deptF = " AND i.deptId = @dept ";

        string sql = "SELECT i.*, (SELECT l.Name FROM location l WHERE l.Id = i.locId) AS Location, " +
            " (SELECT d.Name FROM invDept d WHERE d.Id = i.deptId) AS Dept " +
            " FROM invLedger i WHERE (" + locF + " i.typId = @typ " + deptF + ") AND " +
            " (i.PartNo LIKE @valu OR i.SerialNo LIKE @valu OR i.Name LIKE @valu) ORDER BY Location, Dept, i.Name ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);              DataTable TBL = new DataTable();
        if(locId > 0) dr.SelectCommand.Parameters.AddWithValue("@loc", locId);        
        dr.SelectCommand.Parameters.AddWithValue("@typ", typId);
        if(deptId > 0) dr.SelectCommand.Parameters.AddWithValue("@dept", deptId);
        dr.SelectCommand.Parameters.AddWithValue("@valu", ("%" + searchValu.Trim() + "%"));
        try { dr.Fill(TBL); conn.Close(); } catch { } return TBL;
    }

    //========================= SUPPLY HISTORY ========================= 
    private static bool setSupplyHist(int locId, int typId, int deptId, string rack, string card, string part, string serial,
        string name, int qty, string dOfQ, bool isMfg, bool isExp, DateTime mfgDt, DateTime expDt, decimal unitPrice,
        bool isSalesPcent, decimal rate, decimal salesPrice, string rmk, string vendorRefNo, string regIDNo)
    {
        string sql = "INSERT INTO invSupHist(locId,typId,deptId,RackNo,CardNo,PartNo,SerialNo,Name,Qty,DofQ,IsMfg,IsExp," +
          " MfgDt,ExpDt,unitPrice,IsSalesPcent,Rate,salesPrice,RMK,vendorID,RegIDNo,RegDate) " +
          " VALUES(@loc,@typ,@dept,@rack,@card,@part,@serial,@name,@Qty,@DofQ,@IsMfg,@IsExp," +
          " @MfgDt,@ExpDt,@unitPrice,@IsSalesPcent,@rate,@salesPrice,@RMK,@vendorID,@RegIDNo,@dt) ";
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@loc", locId);             cmd.Parameters.AddWithValue("@typ", typId);
        cmd.Parameters.AddWithValue("@dept", deptId);           cmd.Parameters.AddWithValue("@rack", rack.Trim());
        cmd.Parameters.AddWithValue("@card", card.Trim());      cmd.Parameters.AddWithValue("@part", part.Trim());
        cmd.Parameters.AddWithValue("@serial", serial.Trim());  cmd.Parameters.AddWithValue("@name", name.Trim());
        cmd.Parameters.AddWithValue("@Qty", qty);               cmd.Parameters.AddWithValue("@DofQ", dOfQ);
        cmd.Parameters.AddWithValue("@IsMfg", isMfg);           cmd.Parameters.AddWithValue("@IsExp", isExp);
        cmd.Parameters.AddWithValue("@MfgDt", mfgDt);           cmd.Parameters.AddWithValue("@ExpDt", expDt);
        cmd.Parameters.AddWithValue("@unitPrice", unitPrice);   cmd.Parameters.AddWithValue("@IsSalesPcent", isSalesPcent);
        cmd.Parameters.AddWithValue("@rate", rate);             cmd.Parameters.AddWithValue("@salesPrice", salesPrice);
        cmd.Parameters.AddWithValue("@RMK", rmk);               cmd.Parameters.AddWithValue("@vendorID", vendorRefNo.Trim());
        cmd.Parameters.AddWithValue("@RegIDNo", regIDNo);       cmd.Parameters.AddWithValue("@dt", DateTime.Now);     int added = 0;
        try { conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString()); } catch (Exception ex) { error = ex.Message; 
        } finally { conn.Close(); }
        string trailMsg = "added new supplied Part to LOCATION: " + AppSet.getLocationName(locId) + ", DEPT: " + getDeptName(deptId) + 
            ", PartName: " + part + ", QTY: " + qty.ToString() + dOfQ + ", Vendor RefNo: " + vendorRefNo;
        Trail.setNew(Role.modInventory, "ADD", "", trailMsg, ((added > 0) ? true : false), error); return (added > 0) ? true : false;  
    }
    
    public static DataTable getSupplyHistTBL(long supplyId)
    {
        string sql = "SELECT s.*,  (SELECT l.Name FROM location l WHERE l.Id = s.locId) AS Location, " +
            " (SELECT d.Name FROM invDept d WHERE d.Id = s.deptId) AS Dept, " +
            " (SELECT v.Name FROM invVendor v WHERE v.RefNo = s.vendorID) AS VendorName FROM invSupHist s WHERE s.Id = @id ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn); DataTable tbl = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@id", supplyId);  try { dr.Fill(tbl); conn.Close(); } catch { } return tbl;
    }
        
    public static DataTable getSupplyHistoryTBL(int locId, int typId, DateTime fromDt, DateTime toDt)
    {
        string where = ""; if (locId > 0) where = " s.locId = @locId AND ";      
        string sql = "SELECT s.*, " +
            " (SELECT l.Name FROM location l WHERE l.Id = s.locId) AS Location, " +
            " (SELECT d.Name FROM invDept d WHERE d.Id = s.deptId) AS Dept, " +
            " (SELECT v.Name FROM invVendor v WHERE v.RefNo = s.vendorID) AS VendorName " +            
            " FROM invSupHist s WHERE s.typId = @typ AND " + where +
            " cast(CONVERT(varchar(8), s.RegDate, 112) AS datetime) >= @fromDt AND " +
            " cast(CONVERT(varchar(8), s.RegDate, 112) AS datetime) <= @toDt ORDER BY s.deptId, s.CardNo ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);              DataTable tbl = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@typ", typId);
        if (locId > 0) dr.SelectCommand.Parameters.AddWithValue("@locId", locId); 
        dr.SelectCommand.Parameters.AddWithValue("@fromDt", fromDt);
        dr.SelectCommand.Parameters.AddWithValue("@toDt", toDt);   try { dr.Fill(tbl); conn.Close(); } catch { } return tbl;
    }

    //------------- SALES --------------------
    public static int getNewInvoice(int locId, int typId)
    {
        string sql = "SELECT MAX(InvNo) AS invNumb FROM invSales WHERE locId = @loc AND typId = @typ ";
        SqlCommand cmd = new SqlCommand(sql, conn);         SqlDataReader dr = null;
        cmd.Parameters.AddWithValue("@loc", locId);         cmd.Parameters.AddWithValue("@typ", typId);     int newInvNo = 0;
        try { conn.Open(); dr = cmd.ExecuteReader();
            while (dr.Read()) { try { newInvNo = int.Parse(dr["invNumb"].ToString()); } catch { } }
        } catch (Exception ex) { error = ex.Message; } finally { conn.Close(); }   newInvNo++; return newInvNo;
    }
    public static DataTable getSalesByInvoice(int locId, int typId, int invoiceNo)
    {
        string sql = "SELECT * FROM invSales WHERE locId = @loc AND typId = @typ AND InvNo = @invno ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn); DataTable TBL = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@loc", locId); dr.SelectCommand.Parameters.AddWithValue("@typ", typId);
        dr.SelectCommand.Parameters.AddWithValue("@invno", invoiceNo);
        try { dr.Fill(TBL); conn.Close(); } catch { } return TBL;
    }
   
    public static long setSales(long reqId, int locId, int typId, int invoiceNo, int nItems, decimal costAMT, decimal soldAMT,
        decimal VATrate, decimal VATamt, bool isDiscPcent, decimal discRate, decimal discAMT, decimal chargedAMT,
        decimal paidAMT, bool isPaid, string RMK, string receiverIDNo, string RegIDNo)
    {
        DateTime regDt = DateTime.Now;
        string sql = "INSERT INTO invSales(reqId,locId,typId,InvNo,nItems,costAMT,soldAMT,VATrate,VATamt,IsDiscPcent,discRate,discAMT," +
        " chargedAMT,paidAMT,IsPaid,RMK,ReceiverIDNo,RegIDNo,RegDate) VALUES(@reqId,@loc,@typ,@InvNo,@nItems, @costAMT,@soldAMT," +
        " @VATrate,@VATamt,@IsDiscPcent,@discRate,@discAMT,@chargedAMT,@paidAMT,@IsPaid,@RMK,@ReceiverIDNo,@RegIDNo,@dt) ";
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@reqId", reqId);       cmd.Parameters.AddWithValue("@loc", locId);
        cmd.Parameters.AddWithValue("@typ", typId);         cmd.Parameters.AddWithValue("@InvNo", invoiceNo);
        cmd.Parameters.AddWithValue("@nItems", nItems);     cmd.Parameters.AddWithValue("@costAMT", costAMT);
        cmd.Parameters.AddWithValue("@soldAMT", soldAMT);
        cmd.Parameters.AddWithValue("@VATrate", VATrate);   cmd.Parameters.AddWithValue("@VATamt", VATamt);
        cmd.Parameters.AddWithValue("@IsDiscPcent", isDiscPcent);   cmd.Parameters.AddWithValue("@discRate", discRate);
        cmd.Parameters.AddWithValue("@discAMT", discAMT);   cmd.Parameters.AddWithValue("@chargedAMT", chargedAMT);
        cmd.Parameters.AddWithValue("@paidAMT", paidAMT);
        cmd.Parameters.AddWithValue("@IsPaid", isPaid);     cmd.Parameters.AddWithValue("@RMK", RMK);
        cmd.Parameters.AddWithValue("@ReceiverIDNo", receiverIDNo.Trim());  cmd.Parameters.AddWithValue("@RegIDNo", RegIDNo.Trim());
        cmd.Parameters.AddWithValue("@dt", regDt);      int added = 0;
        try {  conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString());
        } catch (Exception ex) { error = ex.Message; } finally { conn.Close(); }

        long salesId = 0L;
        if (added > 0)
        {
            string sql2 = "SELECT Id FROM invSales WHERE reqId = @req AND locId = @loc AND typId = @typ AND InvNo = @invNo AND " +
                " nItems = @nItems AND RegDate = @dt ";
            SqlCommand cmd2 = new SqlCommand(sql2, conn);         cmd2.Parameters.AddWithValue("@req", reqId);
            cmd2.Parameters.AddWithValue("@loc", locId);          cmd2.Parameters.AddWithValue("@typ", typId);
            cmd2.Parameters.AddWithValue("@invNo", invoiceNo);    cmd2.Parameters.AddWithValue("@nItems", nItems);
            cmd2.Parameters.AddWithValue("@dt", regDt);           SqlDataReader dr2 = null;
            try {  conn.Open(); dr2 = cmd2.ExecuteReader();
                while (dr2.Read()) { long _id = 0L; try { _id = long.Parse(dr2["Id"].ToString()); } catch { }
                if (_id > 0L) salesId = _id;
                }
            } catch (Exception ex) { error = ex.Message; } finally { conn.Close(); }
        }
        string trailMsg = "add sales/issue parts to LOCATION: " + AppSet.getLocationName(locId) + ", TYPE: " + getTypeName(typId) + 
            ", INVOICE: " + invoiceNo.ToString() + ", ITEMS: " + nItems.ToString() + ", AMOUNT: " + soldAMT.ToString("N2") +
            "  RECEIVER: " + receiverIDNo;
        Trail.setNew(Role.modInventory, "ADD", "", trailMsg, ((added > 0) ? true : false), error);     return salesId;
    }

    /* Inventory.setSalesItem(salesId, i.Id, InvoiceNo, i.Qty, i.DofQ, i.CostPrice, i.UnitPrice,
                                     i.DeptId, i.RackNo, i.CardNo, i.PartNo, i.SerialNo, i.Name, i.IsMfg, i.IsExp, i.MfgDate, i.ExpDate); */
    public static bool setSalesItem(long salesId, long ledgerId, int invoiceNo, int qty, string dOfQ, decimal costPrice, 
        decimal unitPrice, int deptId, string rack, string card, string part, string serial, string name, bool isMfg, bool isExp,
        DateTime mfgDt, DateTime expDt)
    {
        bool updLedger = removeItemFromLedger(ledgerId, qty); if (!updLedger) return false;

        string sql = "INSERT INTO invSalesItem(salesId,InvNo,Qty,DofQ,costPrice,unitPrice,costAMT,soldAMT, " +
            " deptId,RackNo,CardNo,PartNo,SerialNo,Name,IsMfg,IsExp,MfgDt,ExpDt) " +
            " VALUES(@salesId,@invNo,@qty,@dofQ,@costPrice,@unitPrice,@costAMT,@soldAMT, " +
            " @dept,@rack,@card,@part,@serial,@name,@IsMfg,@IsExp,@MfgDt,@ExpDt) ";
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@salesId", salesId);       cmd.Parameters.AddWithValue("@invNo", invoiceNo);    
        cmd.Parameters.AddWithValue("@qty", qty);               cmd.Parameters.AddWithValue("@dofQ", dOfQ);
        cmd.Parameters.AddWithValue("@costPrice", costPrice);   cmd.Parameters.AddWithValue("@unitPrice", unitPrice);
        cmd.Parameters.AddWithValue("@costAMT", (qty * costPrice));       cmd.Parameters.AddWithValue("@soldAMT", (qty * unitPrice));
        cmd.Parameters.AddWithValue("@dept", deptId);           cmd.Parameters.AddWithValue("@rack", rack.Trim());
        cmd.Parameters.AddWithValue("@card", card.Trim());      cmd.Parameters.AddWithValue("@part", part.Trim());
        cmd.Parameters.AddWithValue("@serial", serial.Trim());  cmd.Parameters.AddWithValue("@name", name.Trim());
        cmd.Parameters.AddWithValue("@IsMfg", isMfg);           cmd.Parameters.AddWithValue("@IsExp", isExp);
        cmd.Parameters.AddWithValue("@MfgDt", mfgDt);           cmd.Parameters.AddWithValue("@ExpDt", expDt);    int added = 0;
        try { conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString());
        } catch (Exception ex) { error = ex.Message; } finally { conn.Close(); }    return (added > 0) ? true : false;        
    }
    private static bool removeItemFromLedger(long ledgerId, int qty)
    {
        string sql = "SELECT Qty FROM invLedger WHERE Id = @id ";       SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", ledgerId);                   int stockQty = 0;
        try { conn.Open(); stockQty = int.Parse(cmd.ExecuteScalar().ToString()); }
        catch (Exception ex) { error = ex.Message; } finally { conn.Close(); }
        
        int currentQty = stockQty - qty;
        if (currentQty < 0) {
            error = "<font color='red'>Stock QTY: " + stockQty + " </font> lesser than Issuing Qty: " + qty; return false;
        } else {
            string sql2 = "UPDATE invLedger SET Qty = @qty WHERE Id = @id ";   int updated = 0;
            SqlCommand cmd2 = new SqlCommand(sql2, conn);        cmd2.Parameters.AddWithValue("@qty", currentQty);
            cmd2.Parameters.AddWithValue("@id", ledgerId);
            try { conn.Open(); updated = int.Parse(cmd2.ExecuteNonQuery().ToString()); }
            catch (Exception ex) { error = ex.Message; } finally { conn.Close(); }        return (updated > 0) ? true : false;
        }
    }
    
    public static bool setSalesPayment(long salesId, decimal givenAMT, decimal paidAMT, string RegIDNo)
    {
        string sql = "INSERT INTO invSalesPaymt(salesId,givenAMT,paidAMT,RegIDNo,RegDate) " +
            " VALUES(@salesId,@givenAMT,@paidAMT,@regIDNo,@dt) ";
        SqlCommand cmd = new SqlCommand(sql, conn);                 int added = 0;
        cmd.Parameters.AddWithValue("@salesId", salesId);           cmd.Parameters.AddWithValue("@givenAMT", givenAMT);
        cmd.Parameters.AddWithValue("@paidAMT", paidAMT);
        cmd.Parameters.AddWithValue("@regIDNo", RegIDNo.Trim());    cmd.Parameters.AddWithValue("@dt", DateTime.Now);
        try { conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { error = ex.Message; } finally { conn.Close(); }    return (added > 0) ? true : false;
    }

    public static DataTable getIssueHistoryTBL(int locId, int typId, DateTime fromDt, DateTime toDt)
    {
        string sql = "SELECT s.* FROM invSales s WHERE s.locId = @loc AND s.typId = @typ AND " +  
            " cast(CONVERT(varchar(8), s.RegDate, 112) AS datetime) >= @fromDt AND " +
            " cast(CONVERT(varchar(8), s.RegDate, 112) AS datetime) <= @toDt ORDER BY s.InvNo ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);          DataTable tbl = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@typ", typId);    dr.SelectCommand.Parameters.AddWithValue("@loc", locId);
        dr.SelectCommand.Parameters.AddWithValue("@fromDt", fromDt);
        dr.SelectCommand.Parameters.AddWithValue("@toDt", toDt);    try { dr.Fill(tbl); conn.Close(); } catch { } return tbl;
    }
    public static DataTable getInvoiceItemTBL(long salesId)
    {
        string sql = "SELECT i.*, (SELECT d.Name FROM invDept d WHERE d.Id = i.deptId) AS Dept " +
            " FROM invSalesItem i WHERE i.salesId = @salesId ORDER BY Dept, i.Name ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);                DataTable tbl = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@salesId", salesId);    try { dr.Fill(tbl); conn.Close(); } catch { } return tbl;
    }
    
    //==================== INVENTORY REQUEST =======================
    //==================== INVENTORY REQUEST =======================
    public static long setRequest(int locId, int typId, string Rmk, string reqOutOfStock, string RegIDNo)
    {
        DateTime regDt = DateTime.Now;      long reqId = 0L;
        string sql = "INSERT INTO invRequest(locId,typId,ReqIDNo,ReqRMK,ReqOutStock,ReqDt,EcoIDNo,EcoRMK,EcoIsAprov,EcoRegDt, " +
            " InvNo,InvIsAprov,InvIDNo,InvRMK,InvRegDt) VALUES(@loc,@typ,@ReqIDNo,@RMK,@OutStock,@ReqDt,@valu,@valu,@false,@ReqDt, " +
            " @zero,@false,@valu,@valu,@ReqDt) ";
        SqlCommand cmd = new SqlCommand(sql, conn);     cmd.Parameters.AddWithValue("@loc", locId);
        cmd.Parameters.AddWithValue("@typ", typId);     cmd.Parameters.AddWithValue("@ReqIDNo", RegIDNo);
        cmd.Parameters.AddWithValue("@RMK", Rmk);       cmd.Parameters.AddWithValue("@OutStock", reqOutOfStock);
        cmd.Parameters.AddWithValue("@ReqDt", regDt);   cmd.Parameters.AddWithValue("@valu", "");
        cmd.Parameters.AddWithValue("@false", false);   cmd.Parameters.AddWithValue("@zero", 0); int added = 0;
        try {  conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString());
        } catch (Exception ex) { error = ex.Message; } finally { conn.Close(); }
                
        if (added > 0)
        {
            string sql2 = "SELECT Id FROM invRequest WHERE locId = @loc AND typId = @typ AND InvNo = @zero AND " +
                " ReqIDNo = @ReqIDNo AND ReqDt = @dt AND EcoIsAprov = @false AND InvIsAprov = @false ";
            SqlCommand cmd2 = new SqlCommand(sql2, conn); 
            cmd2.Parameters.AddWithValue("@loc", locId);        cmd2.Parameters.AddWithValue("@typ", typId);
            cmd2.Parameters.AddWithValue("@zero", 0);           cmd2.Parameters.AddWithValue("@ReqIDNo", RegIDNo);
            cmd2.Parameters.AddWithValue("@dt", regDt);         cmd2.Parameters.AddWithValue("@false", false);   
            SqlDataReader dr2 = null;
            try {  conn.Open(); dr2 = cmd2.ExecuteReader();
                while (dr2.Read()) { long _id = 0L; try { _id = long.Parse(dr2["Id"].ToString()); } catch { } if (_id > 0L) reqId = _id;
            } } catch (Exception ex) { error = ex.Message; } finally { conn.Close(); }
        }
        string trailMsg = "added Inventory Request to LOCATION: " + AppSet.getLocationName(locId) + ", TYPE: " + getTypeName(typId);
        Trail.setNew(Role.modECO, "ADD", "", trailMsg, ((added > 0) ? true : false), error);      return reqId;
    }
    public static bool setRequestItem(long requestId, long itemId, int qty, string dOfqty)
    {
        string sql = "INSERT INTO invReqItem(reqId,itemId,Qty,DofQ) VALUES(@reqId,@itemId,@qty,@dofQ) ";
        SqlCommand cmd = new SqlCommand(sql, conn);         int added = 0;
        cmd.Parameters.AddWithValue("@reqId", requestId);   cmd.Parameters.AddWithValue("@itemId", itemId);
        cmd.Parameters.AddWithValue("@qty", qty);           cmd.Parameters.AddWithValue("@dofQ", dOfqty);
        try { conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { error = ex.Message; } finally { conn.Close(); }       return (added > 0) ? true : false;
    }

    public static bool setRequestInvoice(long reqId, int invoiceNo, string RMK, string regIDNo)
    {
        string sql = "UPDATE invRequest SET InvNo = @inv, InvIsAprov = @isaprov, InvIDNo = @idno, InvRMK = @rmk, InvRegDt = @dt " +
            " WHERE Id = @id ";                           SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@inv", invoiceNo);   cmd.Parameters.AddWithValue("@isaprov", true);
        cmd.Parameters.AddWithValue("@idno", regIDNo);    cmd.Parameters.AddWithValue("@rmk", RMK);
        cmd.Parameters.AddWithValue("@dt", DateTime.Now); cmd.Parameters.AddWithValue("@id", reqId);     int updated = 0;
        try {   conn.Open(); updated = int.Parse(cmd.ExecuteNonQuery().ToString());
        } catch (Exception ex) { error = ex.Message; }  finally { conn.Close(); }     return (updated > 0) ? true : false;
    }

    public static DataTable getRequestPending(int locId, int invTypId, bool isECO_Inventory)
    {
        string where = ""; if (isECO_Inventory) where = " EcoIsAprov = @false ";
        else where = " EcoIsAprov = @true AND InvIsAprov = @false ";
        string sql = "SELECT * FROM invRequest WHERE locId = @loc AND typId = @typ AND " + where + " ORDER BY Id DESC ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);              DataTable TBL = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@loc", locId);        dr.SelectCommand.Parameters.AddWithValue("@typ", invTypId);
        dr.SelectCommand.Parameters.AddWithValue("@false", false);
        if (!isECO_Inventory) dr.SelectCommand.Parameters.AddWithValue("@true", true); 
        try { dr.Fill(TBL); conn.Close(); } catch { } return TBL;
    }
     
    public static DataTable getRequestApproved(int locId, int invTypId, bool isECO_Inventory, DateTime fromDt, DateTime toDt)
    {
        string where = (isECO_Inventory) ? " EcoIsAprov = @true " : " InvIsAprov = @true ";
        string dtF = (isECO_Inventory) ? " EcoRegDt " : " InvRegDt ";

        string sql = "SELECT * FROM invRequest WHERE locId = @loc AND typId = @typ AND " + where + 
            " AND cast(CONVERT(varchar(8), " + dtF + ", 112) AS datetime) >= @fromDt AND " +
            " cast(CONVERT(varchar(8), " + dtF + ", 112) AS datetime) <= @toDt  ORDER BY Id DESC ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);          DataTable TBL = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@loc", locId);    dr.SelectCommand.Parameters.AddWithValue("@typ", invTypId);
        dr.SelectCommand.Parameters.AddWithValue("@true", true);
        dr.SelectCommand.Parameters.AddWithValue("@fromDt", fromDt);
        dr.SelectCommand.Parameters.AddWithValue("@toDt", toDt);
        try { dr.Fill(TBL); conn.Close(); }
        catch (Exception ex) { error = ex.Message; } return TBL;
    }

    public static DataTable getRequestItems(long reqId)
    {
        string sql = "SELECT i.*, i.Qty AS iQty, i.DofQ AS iDofQ, g.* FROM invReqItem i, invLedger g " + 
            " WHERE i.reqId = @reqId AND g.Id = i.itemId ";    DataTable TBL = new DataTable();
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);     dr.SelectCommand.Parameters.AddWithValue("@reqId", reqId);
        try { dr.Fill(TBL); conn.Close(); } catch { } return TBL;
    }
    public static DataTable getRequest(long reqId)
    {
        string sql = "SELECT r.*, (SELECT Name FROM location WHERE Id = r.locId) AS Location, " +
            " (SELECT Name FROM invType WHERE Id = r.typId) AS InvTypeName FROM invRequest r WHERE r.Id = @reqId  "; 
        DataTable TBL = new DataTable();        SqlDataAdapter dr = new SqlDataAdapter(sql, conn); 
        dr.SelectCommand.Parameters.AddWithValue("@reqId", reqId);    try { dr.Fill(TBL); conn.Close(); } catch { } return TBL;
    }

    public static bool approveECOrequest(long reqId, string rmk, string RegIDNo)
    {
        string sql = "UPDATE invRequest SET EcoIDNo = @idno, EcoRMK = @rmk, EcoIsAprov = @aprov, EcoRegDt = @dt WHERE Id = @id ";
        SqlCommand cmd = new SqlCommand(sql, conn);         cmd.Parameters.AddWithValue("@idno", RegIDNo);
        cmd.Parameters.AddWithValue("@rmk", rmk);           cmd.Parameters.AddWithValue("@aprov", true);
        cmd.Parameters.AddWithValue("@dt", DateTime.Now);   cmd.Parameters.AddWithValue("@id", reqId);       int updated = 0;
        try { conn.Open(); updated = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { error = ex.Message; }  finally { conn.Close(); }    return (updated > 0) ? true : false;
    }

    public static bool deleteRequest(long reqId)
    {
        DataTable TBL = getRequest(reqId);

        string sql = "DELETE FROM invRequest WHERE Id = @id "; SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", reqId);          int deleted = 0;
        try { conn.Open(); deleted = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { error = ex.Message; } finally { conn.Close(); }
        //-----------------------------
        if (deleted > 0)
        {
            string sql2 = "DELETE FROM invReqItem WHERE reqId = @id"; SqlCommand cmd2 = new SqlCommand(sql2, conn);
            cmd2.Parameters.AddWithValue("@id", reqId);             int rows = 0;
            try { conn.Open(); rows = int.Parse(cmd2.ExecuteNonQuery().ToString()); }
            catch (Exception ex) { error = ex.Message; } finally { conn.Close(); }

            DataRow r = TBL.Rows[0];
            string trailMsg = "deleted Spare Part Request from LOCATION: " + AppSet.getLocationName(int.Parse(r["locId"].ToString())) +
                ", TYPE: " + getTypeName(int.Parse(r["typId"].ToString())) + ".  Snag Info: " + r["ReqRMK"].ToString();
            Trail.setNew(Role.modECO, "DELETE", r["ReqIDNo"].ToString(), trailMsg, true, error);  
        }
        return (deleted > 0) ? true : false;
    }

}   

