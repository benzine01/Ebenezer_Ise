﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;


using System.IO;
using System.Text;
using System.Data;
 
namespace NAF.codes
{
     
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    
    [System.Web.Script.Services.ScriptService]
    public class syncappset : System.Web.Services.WebService
    {

        private string timeoutMsg = "<font color='red'>session timeout, please login...</font>";

        [WebMethod(EnableSession = true)]
        public string setUser(string oficeLoc, string idno, string fullnm, string phone, string email, string lev, string acsLoc,
            string locs, string modCodes, string modValus)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;
            idno = idno.Trim();         phone = phone.Trim();

            int officerLocId = 0, levId = 0;
            try { officerLocId = int.Parse(oficeLoc.Trim()); } catch { }    try { levId = int.Parse(lev.Trim()); } catch { }
            if (officerLocId < 1) return "<font color='red'>Select Officer's Location... </font>";
            if (levId < 1) return "<font color='red'>Select Officer's Access Level... </font>";
            if(fullnm.Trim().Length < 5) return "<font color='red'>Enter the Full Name... </font>";
            if (phone.Length < 5) return "<font color='red'>Enter the Full Name... </font>";
            if (fullnm.Length < 5) return "<font color='red'>Enter the Full Name... </font>";
            if (fullnm.Length < 5) return "<font color='red'>Enter the Full Name... </font>";
                        
            acsLoc = acsLoc.Trim(); locs = locs.Trim(); modValus = modValus.Trim();
            // //accessloc  1-> all loc, 2->specific loc, 3->staff loc
            // 1,0,1,0,1; 1,0,1,0,1; 1,0,1,0,1; 1,0,1,0,1; 1,0,1,0,1           //(ADD,VIEW,EDIT,SETTINGS,APPROVE) 
            
            if (Users.getIDNo(idno.Trim()).Rows.Count > 0) return "<font color='red'>NAF NUMBER already exist... </font>";
            string[] RoleModules = modCodes.Split(','); string[] RoleModulesValus = modValus.Split(';');
                        
            string pwd = Users.generatePWD(6);          Users obj = new Users();
            bool isCreated = obj.setNew(officerLocId, idno, fullnm, pwd, levId, phone, email, UserSession.FullNameIDNo); 
            if (isCreated)
            {
                int locId = -1; string[] roles = modValus.Split(';');
                //string[] roleCodes = Role.ModulesCode; //{  "STAFF", "FREIGHT", "SALARY", "ACCOUNT", "INVENTORY", "ASSET" };
                if (acsLoc == "2")
                {
                    string[] locIds = locs.Split(',');
                    for (int j = 0; j < locIds.Length; j++)
                    {
                        int _locId = 0; try { _locId = int.Parse(locIds[j]); } catch { }
                        if (_locId > 0)
                        {
                            int kMod = -1;
                            foreach (string roleCode in RoleModules)
                            {
                                kMod++; string _roleCode = roleCode.Trim();
                                if (_roleCode.Length > 2)
                                {
                                    string[] valu = roles[kMod].Split(',');
                                    bool isAdd = (valu[0] == "1") ? true : false; bool isView = (valu[1] == "1") ? true : false;
                                    bool isEdit = (valu[2] == "1") ? true : false; bool isSet = (valu[3] == "1") ? true : false;
                                    bool isApprove = (valu[4] == "1") ? true : false;
                                    if (isAdd || isView || isEdit || isSet || isApprove)
                                        Role.setNew(_locId, idno, _roleCode.ToUpper(), isAdd, isView, isEdit, isSet, isApprove);
                                }
                            }
                        }
                    }
                }
                else if (acsLoc == "3" || acsLoc == "1")
                {
                    locId = (acsLoc == "1") ? 0 : officerLocId;              int kMod = -1;
                    foreach (string roleCode in RoleModules)
                    {
                        kMod++; string _roleCode = roleCode.Trim();
                        if (_roleCode.Length > 2)
                        {
                            string[] valu = roles[kMod].Split(',');
                            bool isAdd = (valu[0] == "1") ? true : false; bool isView = (valu[1] == "1") ? true : false;
                            bool isEdit = (valu[2] == "1") ? true : false; bool isSet = (valu[3] == "1") ? true : false;
                            bool isApprove = (valu[4] == "1") ? true : false;
                            if (isAdd || isView || isEdit || isSet || isApprove)
                                Role.setNew(locId, idno, _roleCode, isAdd, isView, isEdit, isSet, isApprove);
                        }
                    }
                }
                                
                string smsMsg = "NAF Login Details. Username: " + idno + ", Password: " + pwd +
                    " please login to change your username and password";
                string emailMsg = "<b>NAF Login Details.</b> <br /> Username: " + idno + " <br> Password: " + pwd +
                    " <br /> please login to change your username and password ";

                string return_msg = "<font color='green'>Successfully created user: " +
                    fullnm.ToUpper() + "(" + idno + ")... </font>";
                if (phone.Length > 9)
                {
                    Mailer.sendSMS("NAF.log", phone, smsMsg);
                    if (Mailer.IsSmsSent) return_msg += "<br /><font color='green'>User Login Credentials Sent (by SMS)...</font>";
                    else return_msg += "<br /><font color='red'>Unable to send Login Credentials (by SMS) </font>";
                }
                else return_msg += "<br /><font color='red'>no phone number to send login details  </font>";

                if (email.Length > 5)
                {
                    Mailer.sendEmail(email, "NAF LOGIN DETAILS", emailMsg);
                    if (Mailer.IsEmailSent) return_msg += "<br /><font color='green'>User Login Credentials Sent (by EMAIL)...</font>";
                    else return_msg += "<br /><font color='red'>Unable to send Login Credentials (by EMAIL) </font>";
                }
                else return_msg += "<br /><font color='red'>no e-mail address to send login details </font>";
                return return_msg;
            }
            else
            {
                return "<font color='red'>operation not successfull, caused by "  + obj._error + "... </font>";
            }

        }

        [WebMethod(EnableSession = true)]
        public string getUsers(string loc, string lev)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;
            
            int locId = 0, levId = 0;
            try { levId = int.Parse(lev); } catch { }    try { locId = int.Parse(loc); }  catch { }

            DataTable userTbl = Users.getUsers(locId, levId);

            StringBuilder tbl = new StringBuilder();
            tbl.Append("<div class='tblHead' style='width:600px;align:center;'> USERS: " + UserSession.getLevel(levId) + " </div>" +
                    "<table  style='font-size:11px; font-weight:100px;' cellpadding='0' cellspacing='0' border='0' " +
                    " class='display' id='jqUsersTBL'> <thead> <tr align='left'>  <th>LOCATION </th><th>LEVEL</th> <th>NAF_No.</th>" +
                    " <th>FULL NAME</th><th>PHONE</th> <th align='center'>STATUS</th><th>REGISTERED BY</th> <th>REG. DATE</th> " +
                    " <th>LAST LOGIN DATE</th> <th align='center'></th> </tr></thead><tfoot> " +
                    " <tr align='left'><th>LOCATION </th> <th>LEVEL</th><th>NAF No.</th><th>FULL NAME</th><th>PHONE</th> " +
                    " <th align='center'>STATUS</th><th>REGISTERED BY</th><th>REG. DATE</th> <th>LAST LOGIN DATE</th> " +
                    " <th align='center' style='width:90px;'></th></tr></tfoot> <tbody>");
            /* string sql = "SELECT u.*, s.locId, (s.SNm + ', ' + s.ONms) AS StaffName,s.Phone, s.Email, " +
            " (SELECT loc.Name FROM stfLocDeptLevStep loc WHERE loc.Id = s.locId) AS Location " +
            " FROM Users u, stfStaff s WHERE u.StfIDNo = s.IDNo " + field + " ORDER BY u.LevId ASC, u.IsActive DESC ";   */
            string imgDel = "<img src='../images/user_delete.gif' alt='delete' width='20' height='20' />";
            string imgRoles = "<img src='../images/user_info.gif' alt='roles' width='20' height='20' />";
            int curUserLevId = UserSession.LevId; int curUserId = UserSession.UserId;
            foreach (DataRow dr in userTbl.Rows)
            {
                int _Id = int.Parse(dr["Id"].ToString());
                int _levId = 0; try { _levId = int.Parse(dr["LevId"].ToString()); } catch { }
                bool _active = false; try { _active = bool.Parse(dr["IsActive"].ToString()); } catch { }
                string lock_open = (_active) ? "open" : "lock"; string activeId = (_active) ? "0" : "1";
                string lastLogDt = ""; string regDt = "";
                try { lastLogDt = DateTime.Parse(dr["LastLoginDt"].ToString()).ToString("MMM d,yyyy. h:m tt"); } catch { }
                try { regDt = DateTime.Parse(dr["RegDate"].ToString()).ToString("yyyy MMM d"); }
                catch { } //h:m tt
                string delImg = "", rolesImg = "", statusTitle = "Note: You can only Lock/Unlock a Sub-Ordinate User", jsStatus = "#";
                //if (curUserLevId < _levId || curUserId == _Id) {
                delImg = "<a href='javascript:deleteUser(" + _Id.ToString() + ");' title='Click to Delete User'>" + imgDel + "</a>";
                rolesImg = "<a href='javascript:viewRoles(" + _Id.ToString() + ");' title='Click to View/Edit Roles'>" + imgRoles + "</a>";
                statusTitle = "Click to " + ((_active) ? "LOCK" : "OPEN") + " User";
                jsStatus = "javascript:lockUnlockUser(" + activeId + "," + _Id.ToString() + ");";
                //}
                tbl.Append("<tr align='left'><td> " + dr["Location"].ToString() + " </td> <td>" + UserSession.getLevel(_levId) + 
                    " </td><td>" + dr["IDNo"].ToString() + "</td><td>" + dr["FullName"].ToString().ToUpper() + 
                    " </td> <td title='Email: " + dr["Email"].ToString() + "'> " + dr["Phone"].ToString() + "</td><td align='center'>" +
                    " <a href='" + jsStatus + "' title='" + statusTitle + "'>" +
                    " <img src='../images/user_" + lock_open + ".gif' alt='" + lock_open + "' width='20' height='20' /></a>" +
                    " </td><td>" + dr["RegName"].ToString() + " </td><td>" + regDt +
                    " </td><td>" + lastLogDt + " </td><td align='center'>" + delImg + " &nbsp;&nbsp; " + rolesImg + "</td> </tr>");
            }
            Context.Session["sesGridUserTBL"] = userTbl; tbl.Append("<tbody></table> "); return tbl.ToString();
            //deleteUser(" + _Id.ToString() + ");  viewRoles(" + _Id.ToString() + ")  
            //lockUnlockUser(" + activeId + "," + _Id.ToString() + ");
        }


        [WebMethod(EnableSession = true)]
        public string deleteUser(string id)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;
            int Id = 0; try { Id = int.Parse(id.Trim()); } catch { }
            if (Id < 1) return "<font color='red'>Unknown User... </font>";

            string userIDNo = Users.getUserById(Id).Rows[0]["IDNo"].ToString().Trim();
            bool isDeleted = Users.deleteUser(Id);
            if (isDeleted)
            {
                 Role.deleteRole(userIDNo);
                return "<font color='green'>Successfully deleted User: " + userIDNo + "..." + Role._error + " </font>";
            }
            else return "<font color='red'>Unable to delete User... </font>";
        }

        [WebMethod(EnableSession = true)]
        public string lockUnlockUser(string status, string id)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;
            int Id = 0; try { Id = int.Parse(id.Trim()); } catch { }
            bool isActive = (status == "1") ? true : false;
            bool isDone = Users.lockUnlockUser(Id, isActive); string task = ((isActive) ? "Open/Unlock" : "Lock");
            if (isDone) return "<font color='green'>Successfully " + task + "ed User... </font>";
            else return "<font color='red'>Unable to " + task + " User... </font>";
        }

        [WebMethod(EnableSession = true)]
        public string viewUserRoles(string id)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;
            int Id = 0; try { Id = int.Parse(id.Trim()); } catch { }

            DataTable UserTBL = Users.getUserById(Id);            
            if (UserTBL.Rows.Count < 1) return "<font color='red'>Unknown User... </font>";

            string IDNo = UserTBL.Rows[0]["IDNo"].ToString();           DataTable RoleTBL = Role.getRoles(IDNo);
            string staffName = UserTBL.Rows[0]["FullName"].ToString() + " " + IDNo;
            string level = UserSession.getLevel(int.Parse(UserTBL.Rows[0]["LevId"].ToString()));
            string officerLoc = UserTBL.Rows[0]["Location"].ToString();

            DataTable locTBL = Role.getLocIDs(IDNo); string locations = "<br><b>ACCESS LOCATION(s): </b> ";
            foreach (DataRow dr in locTBL.Rows)
            {
                int locId = int.Parse(dr["locId"].ToString()); string locNm = ""; try { locNm = dr["Name"].ToString(); } catch { }
                locations += ((locId == 0) ? "ALL LOCATIONS. " : (locNm + ". "));
            }
            StringBuilder tbl = new StringBuilder();
            string imgOn = "<img src='../images/active_on.gif' width='15' height='15' />";
            string imgOff = "";//<img src='../images/active_off.gif' width='15' height='15' />";
            tbl.Append("<div> <b>STAFF NAME: </b> " + staffName + " &nbsp;&nbsp;&nbsp; <b>LEVEL: </b> " + level +
                " <br> <b>OFFICER LOCATION: </b> " + officerLoc + " <br> " + locations + "</div>" +
                   "  <span style='float:left;'><a href=\"javascript:showHide('divStfRoleInfo');\" " +
                   " title='Click to Collapse/Open Staff Roles Information'> <img src='../images/showHide.png' /></a></span> " +
                   " <div id='divStfRoleInfo' style='display:block;'> " +
                   " <table border='1' class='table modTbl2'> <tr align='center'><th rowspan='2'><b>MODULES</b></th> " +
                   " <th colspan='5' align='center'><b>ACCESS RIGHTS</b></th></tr> <tr align='center'><th>ADD</th> " +
                   " <th>VIEW</th><th>EDIT</th><th>SETTINGS</th> <th>APPROVE</th></tr>");
            int k = 0;
            foreach (DataRow dr in RoleTBL.Rows)
            {
                k++;
                bool isAdd = bool.Parse(dr["IsAdd"].ToString()); bool isView = bool.Parse(dr["IsView"].ToString());
                bool isEdit = bool.Parse(dr["IsEdit"].ToString()); bool isSet = bool.Parse(dr["IsSet"].ToString());
                bool isApprove = bool.Parse(dr["IsApprove"].ToString());
                tbl.Append("<tr><th>" + dr["RoleCode"].ToString() + " </th> <td> " + ((isAdd) ? imgOn : imgOff) + " </td> " +
                           " <td> " + ((isView) ? imgOn : imgOff) + " </td><td> " + ((isEdit) ? imgOn : imgOff) + " </td> " +
                           "  <td> " + ((isSet) ? imgOn : imgOff) + " </td><td> " + ((isApprove) ? imgOn : imgOff) + " </td></tr>");
            }
            if (k == 0) tbl.Append("<tr><td colspan='6'><i>no Modules record...</i></font></td></tr>");
            tbl.Append("</table></div><div style='clear:both;'></div><br> " +
                " You can add/update User Module(s) by clicking on the <i>Edit Panel</i> below...<br>");

            /*<select id="selAccessLoc" style="width:155px;" onchange="if(this.value == 2) showDiv('spLoc'); else hideDiv('spLoc');">
               <%= ((UserSession.LevId <= 2) ? "<option value='3'>Staff Location</option>" : "")%>   
               <%= ((UserSession.LevId <= 2) ? "style='<option value='2'>Specific Location(s)</option>" : "")%>     
               <%= ((UserSession.LevId == 1) ? "<option value='1'>All Locations</option>" : "")%>   
                    </select> */
            DataTable locsTBL = Role.getLocIDs(UserSession.IDNo);
            int nlocs = locsTBL.Rows.Count;
            string selLocOpt = "<select id='selAccessLoc_' style='width:155px;' " +
                " onchange=\"if(this.value == 2) showDiv('spLoc_'); else hideDiv('spLoc_');\">   ";
            string chkOpts = ""; int hidnLocIds = 0; //accessloc  1-> all loc, 2->specific loc, 3->staff loc
            if (nlocs > 0)
            {
                selLocOpt += " <option value='3'>STAFF LOCATION</option> <option value='2'>SPECIFIC LOCATION </option> ";
                foreach (DataRow dr in locsTBL.Rows)
                {
                    int _locId = int.Parse(dr["locId"].ToString());
                    if (_locId == 0)
                    {
                        DataTable _locsTBL = AppSet.getLocation();
                        selLocOpt += " <option value='1'>ALL LOCATIONS </option> "; string _chkId = "";
                        foreach (DataRow _dr in _locsTBL.Rows)
                        {
                            hidnLocIds++;     _chkId = "chkUpdRoleLoc" + hidnLocIds.ToString();
                            chkOpts += "<input type='checkbox' value='" + _dr["Id"].ToString() +
                                "' id='" + _chkId + "' /><label for='" + _chkId + "'>" + _dr["Name"].ToString() + "</label><br>";
                        }
                    }
                    else
                    {
                        hidnLocIds++; string _chk = "chkUpdRoleLoc" + hidnLocIds.ToString();
                        chkOpts += "<input type='checkbox' value='" + _locId.ToString() +
                            "' id='" + _chk + "' /><label for='" + _chk + "'>" + dr["Name"].ToString() + "</label><br>";
                    }
                }
            }
            selLocOpt += "</option>";
            //hidChkUpdRolesNo,  selAccessLoc_,chkUpdRoleLoc(k)

            int curUserLevId = UserSession.LevId;
            tbl.Append("<div><a href=\"javascript:showHide('divRoleEditPanel');\" " +
                   " title='Click to Collapse/Open Role Edit Panel'> <img src='../images/showHide.png' />Edit Panel</a> </div>");

            tbl.Append("<span id='divEditRoleProgress'></span> <br> <div id='divRoleEditPanel' style='display:none;'> " +
            "<table border='0' class='table modTbl2'><tr><td>ACCESS LOCATION(s):</td><td> " + selLocOpt +
              " </td> <tr><td colspan='2' style='margin-left:20px;'> <span style='display:none;' id='spLoc_'> " + chkOpts +
              " </span> <input type='hidden' id='hidnLocIds_' value='" + hidnLocIds.ToString() + "' /> </td></tr>   " +
            " <tr><td colspan='2'> <table border='1' class='table gridView'> " +
         "<tr align='center'><th rowspan='2' style='width:130px;'> " +
            " <b><input type='checkbox' id='chkAllModules_' onclick='chkAllModules_();' /> " +
           "<label for='chkAllModules_'> MODULES</label></b></th><th colspan='5' align='center'><b>ACCESS RIGHTS</b></th></tr> " +
         "<tr align='center'><th>ADD</th><th>VIEW</th><th>EDIT</th><th>SETTINGS</th> " +
         " <th " + ((curUserLevId != 1) ? "style='display:none;'" : "") + "> APPROVE</th></tr> ");
            int _k = 0; string modules = "";
            foreach (string _role in Role.ModulesCode)
            {
                _k++;
                if (_k > 1)
                {
                    tbl.Append(this.getRoleCheckBoxsTR(_role, "_", curUserLevId)); modules += _role + "_,";
                }
            }

            //this.getRoleCheckBoxsTR(Role.modAccount, "_", curUserLevId) + this.getRoleCheckBoxsTR(Role.modAsset, "_", curUserLevId) +
            //this.getRoleCheckBoxsTR(Role.modFreight, "_", curUserLevId) + this.getRoleCheckBoxsTR(Role.modInventory, "_", curUserLevId) +
            //this.getRoleCheckBoxsTR(Role.modSalary, "_", curUserLevId) + this.getRoleCheckBoxsTR(Role.modStaff, "_", curUserLevId) +
            tbl.Append("</table></table>");
            /*string modules = Role.modStaff + "_," + Role.modFreight + "_," + Role.modSalary + "_," +
                Role.modAccount + "_," + Role.modInventory + "_," + Role.modAsset + "_";*/
            return tbl.ToString() + " <input type='hidden' id='hidRoleModules' value='" + modules + "' /> " +
                "&nbsp;&nbsp;<input type='button' value='Save' onclick='updateUserRoles(" + id.ToString() + ");' /> </div>";

        }

        [WebMethod(EnableSession = true)]
        public string getRoleCheckBoxsTR(string code, string postFix, int curUserLevId)
        {
            string cId = code + postFix;      //Staff_
            return "<tr " + ((Role.IsValid(code)) ? "" : "style='display:none;'") + "><th align='left'> " +
  "<input type='checkbox' id='chk" + cId + "' onclick=\"chkBoxs_('" + cId + "');\" /><label for='chk" + cId +
    "'>" + code + "</label></th> " +
  "<td> " + ((Role.IsAdd(code)) ? "<input type='checkbox' id='chk" + cId + "1' />" : " - ") + " </td> " +
  "<td> " + ((Role.IsView(code)) ? "<input type='checkbox' id='chk" + cId + "2' />" : " - ") + " </td> " +
  "<td> " + ((Role.IsEdit(code)) ? "<input type='checkbox' id='chk" + cId + "3' />" : " - ") + " </td> " +
  "<td> " + ((Role.IsSet(code)) ? "<input type='checkbox' id='chk" + cId + "4' />" : " - ") + " </td> " +
  "<td " + ((curUserLevId != 1) ? "style='display:none;'" : "") + ">" +
          ((Role.IsApprove(code)) ? "<input type='checkbox' id='chk" + cId + "5' />" : " - ") + "</td></tr> ";
        }


        [WebMethod(EnableSession = true)]
        public string updateUserRole(string id, string acsLoc, string locs, string modCodes, string modValus)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;
            int userId = int.Parse(id.ToString());

            DataTable userTBL = Users.getUserById(userId);
            string IDNo = userTBL.Rows[0]["IDNo"].ToString().Trim();
            int locId = int.Parse(userTBL.Rows[0]["locId"].ToString());
             
            string[] RoleModules = modCodes.Replace('_', ' ').Split(',');
            string[] roles = modValus.Split(';');
                        
            Role.deleteRole(IDNo);
            if (acsLoc == "2")
            {
                string[] locIds = locs.Split(',');
                foreach (string loc_Id in locIds)
                {
                    int _locId = 0; try { _locId = int.Parse(loc_Id); } catch { }
                    if (_locId > 0)
                    {
                        int kMod = -1;
                        foreach (string roleCode in RoleModules)
                        {
                            kMod++; string _roleCode = roleCode.Trim();
                            if (_roleCode.Length > 2)
                            {
                                string[] valu = roles[kMod].Split(',');
                                bool isAdd = (valu[0] == "1") ? true : false; bool isView = (valu[1] == "1") ? true : false;
                                bool isEdit = (valu[2] == "1") ? true : false; bool isSet = (valu[3] == "1") ? true : false;
                                bool isApprove = (valu[4] == "1") ? true : false;
                                if (isAdd || isView || isEdit || isSet || isApprove)
                                    Role.setNew(_locId, IDNo, _roleCode.ToUpper(), isAdd, isView, isEdit, isSet, isApprove);
                            }
                        }
                    }
                }

            }
            else if (acsLoc == "3" || acsLoc == "1")
            {
                //locId = (acsLoc == "1") ? 0 : int.Parse(dr["locId"].ToString());
                if (acsLoc == "1") locId = 0;
                int kMod = -1;
                foreach (string roleCode in RoleModules)
                {
                    kMod++; string _roleCode = roleCode.Trim();
                    if (_roleCode.Length > 2)
                    {
                        string[] valu = roles[kMod].Split(',');
                        bool isAdd = (valu[0] == "1") ? true : false; bool isView = (valu[1] == "1") ? true : false;
                        bool isEdit = (valu[2] == "1") ? true : false; bool isSet = (valu[3] == "1") ? true : false;
                        bool isApprove = (valu[4] == "1") ? true : false;
                        if (isAdd || isView || isEdit || isSet || isApprove)
                            Role.setNew(locId, IDNo, _roleCode.ToUpper(), isAdd, isView, isEdit, isSet, isApprove);
                    }
                }
            }

            return this.viewUserRoles(userId.ToString());

        }

        //====================================================        
        [WebMethod(EnableSession = true)]
        public string setLocation(string name)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;
            if (name.Length < 3) return "<font color='red'><i>Please Enter the Location...</i></font>"; 
            bool isAdded = AppSet.setLocation(name);
            if (isAdded) return "<font color='green'>Successfully Added Location: " + name + " </font>";  else return AppSet._error;
        }
                
        [WebMethod(EnableSession = true)]
        public string setAircraft(string loc, string callSign, string name)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;
            int locId = 0; try { locId = int.Parse(loc.Trim()); } catch { }
            callSign = callSign.Trim(); name = name.Trim();            
            if (callSign.Length < 3) return "<font color='red'><i>Please Enter the Aircraft CallSign...</i></font>";
            if (name.Length < 3) return "<font color='red'><i>Please Enter the Aircraft Name...</i></font>";

            bool isAdded = Aircraft.setAircraft(locId, callSign, name);
            if (isAdded) return "<font color='green'>Successfully added Aircraft: " + name + " (" + callSign + ") </font>";
            else return Aircraft.error;
        }




        //====================================================================
        //====================================================================
        [WebMethod(EnableSession = true)]
        public string setLogInOutTimer(string inAct, string inTime, string outAct, string outTime, string idleMins)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;
            bool isInAct = (inAct.Trim() == "1") ? true : false; bool isOutAct = (outAct.Trim() == "1") ? true : false;
            int hr = 0, mins = 0, am = 0;
            string[] inTimes = inTime.Trim().Split(','); string[] outTimes = outTime.Trim().Split(',');
            hr = int.Parse(inTimes[0]); mins = int.Parse(inTimes[1]); am = int.Parse(inTimes[2]); hr += am;
            DateTime toDay = DateTime.Now;
            DateTime logInTime = new DateTime(toDay.Year, toDay.Month, toDay.Day, hr, mins, 0);
            hr = 0; mins = 0; am = 0;
            hr = int.Parse(outTimes[0]); mins = int.Parse(outTimes[1]); am = int.Parse(outTimes[2]); hr += am;
            DateTime logOutTime = new DateTime(toDay.Year, toDay.Month, toDay.Day, hr, mins, 0);
            bool isSet = AppSet.setLogin(isInAct, logInTime, true);
            string msg = "";
            if (isSet) msg = "<font color='green'>Successfully " + ((isInAct) ? "Activated" : "De-Activated") +
                " Login Time " + ((isInAct) ? logInTime.ToString("hh:mm tt") : "") + " </font><br>";
            else msg = "<font color='red'>unable to " + ((isInAct) ? "Activate" : "De-Activate") +
                " Login Time, error: " + AppSet._error + "  </font><br>";

            isSet = AppSet.setLogin(isOutAct, logOutTime, false);
            if (isSet) msg += "<font color='green'>Successfully " + ((isOutAct) ? "Activated" : "De-Activated") +
                " LogOut Time " + ((isOutAct) ? logOutTime.ToString("hh:mm tt") : "") + " </font><br>";
            else msg += "<font color='red'>unable to " + ((isOutAct) ? "Activate" : "De-Activatee") +
                " LogOut Time, error: " + AppSet._error + "  </font><br>";

            int _idleMins = 0; try { _idleMins = int.Parse(idleMins.Trim()); }
            catch { }
            isSet = AppSet.setIdleMins(_idleMins);
            if (isSet) msg += "<font color='green'>Successfully " + ((isOutAct) ? "Activated" : "De-Activated") + " Idle Minutes: " +
                 ((_idleMins < 1) ? "<font color='red'>Unlimited</font>" : _idleMins.ToString() + " mins") + " </font>";
            else msg += "<font color='red'>unable to " + ((isOutAct) ? "Activate" : "De-Activate") +
                " Idle Minutes, error: " + AppSet._error + "  </font>";
            return msg;
        }

        [WebMethod(EnableSession = true)]
        public string getLogInOutTimer()
        {
            if (!UserSession.IsActive) return this.timeoutMsg; AppSet.getValus();
            string tbl = "<table border='0' class='gridView tbls'> " +
                " <tr><th> LOGIN TIMER: </th><td> " + ((AppSet.isLoginActive) ? "<font color='green'>ACTIVE" :
                 "<font color='red'>DE-ACTIVATED") + "</font></td></tr>" +
     ((AppSet.isLoginActive) ? ("<tr><th> LOGIN TIME: </th><td> " + AppSet.logoutTime.ToString("hh:mm tt") + " </td></tr>") : "") +
                " <tr><th> LOGOUT TIMER: </th><td> " + ((AppSet.isLogoutActive) ? "<font color='green'>ACTIVE" :
                 "<font color='red'>DE-ACTIVATED") + "</font> </td></tr>" +
    ((AppSet.isLogoutActive) ? ("<tr><th> LOGOUT TIME: </th><td> " + AppSet.logoutTime.ToString("hh:mm tt") + " </td></tr>") : "") +
    "<tr><td>IDLE MINUTES TIMEOUT:</td><td>" + ((AppSet.idleMins < 1) ? "<i>Unlimited</i>" : AppSet.idleMins.ToString() + " mins") +
    "</td></tr>"; return tbl;
        }

        [WebMethod(EnableSession = true)]
        public string setMaxAppUsers(string adminU, string superU, string user)
        {
            if (!UserSession.IsActive) return this.timeoutMsg; AppSet.getValus();
            int nAdminUsers = 0, nSuperUsers = 0, nUsers = 0;
            try { nAdminUsers = int.Parse(adminU.Trim()); }
            catch { }
            try { nSuperUsers = int.Parse(superU.Trim()); }
            catch { }
            try { nUsers = int.Parse(user.Trim()); }
            catch { }
            bool isSet = AppSet.setMaxUsers(nAdminUsers, nSuperUsers, nUsers);
            if (isSet) return "<font color='green'>Successfully set Maximum App. Users. </font>";
            else return "<font color='red'>Unable to set Maximum App. Users. " + AppSet._error + " </font>";
        }

        [WebMethod(EnableSession = true)]
        public string getMaxAppUsersInfo()
        {
            if (!UserSession.IsActive) return this.timeoutMsg; AppSet.getValus();
            string tbl = "<table border='0' class='gridView tbls'> <tr><th> ADMINISTRATOR: </th><td> " +
                    ((AppSet.maxAdmin > 0) ? ("<font color='green'>" + AppSet.maxAdmin.ToString()) :
                 "<font color='red'>Unlimited") + " </font></td></tr>" +
                 " <tr><th> SUPER USERS: </th><td> " + ((AppSet.maxSuper > 0) ? ("<font color='green'>" + AppSet.maxSuper.ToString()) :
                 "<font color='red'>Unlimited") + "</font> </td></tr>" +
                 " <tr><th> USERS: </th><td> " + ((AppSet.maxUser > 0) ? ("<font color='green'>" + AppSet.maxUser.ToString()) :
                 "<font color='red'>Unlimited") + "</font> </td></tr></table>";
            return tbl;
        }

        [WebMethod(EnableSession = true)]
        public string setSms(string tit, string sesID)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;
            bool isSmsValid = Mailer.isSmsValid(sesID); bool isAdded = false;
            if (isSmsValid) isAdded = AppSet.setSMS(tit.Trim(), sesID.Trim());
            else return "<font color='red'>Invalid SMS Gateway ID</font>";
            if (isAdded) return "<font color='green'>Successfully Set SMS Gateway</font>";
            else return "<font color='red'>Couldnot Set Gateway, " + AppSet._error + "</font>";
        }

        [WebMethod(EnableSession = true)]
        public string getSmsInfo()
        {
            if (!UserSession.IsActive) return this.timeoutMsg; AppSet.getValus();
            string tbl = "<table border='0' class='gridView tbls'>  <tr><th> SMS DEFAULT TITLE: </th><td> " +
        ((AppSet.smsTitle.Length > 0) ? ("<font color='green'>" + AppSet.smsTitle) : "<font color='red'>None") + " </font></td></tr>" +
        " <tr><th> SMS GATEWAY ID: </th><td> " + ((AppSet.smsID.Length > 2) ? ("<font color='green'>" + AppSet.smsID) :
        "<font color='red'>None") + " </font></td></tr> </table>"; return tbl;
        }


        [WebMethod(EnableSession = true)]
        public string setEmail(string serva, string port, string email, string pwd, string dispName)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;
            int _port = 0; try { _port = int.Parse(port); }
            catch { }
            bool isAdded = false;
            bool isEmailValid = Mailer.isEmailValid(serva, _port, email, pwd, dispName);
            if (isEmailValid) isAdded = AppSet.setEmail(serva, _port, email, pwd, dispName);
            else return "<font color='red'>Invalid Email SMTP OUT-GOING Settings ...</font>";

            if (isAdded) return "<font color='green'>Successfully Set Email SMTP OUT-GOING Settings </font>";
            else return "<font color='red'>Couldnot add Email SMTP OUT-GOING Settings, " + AppSet._error + "</font>";
        }

        [WebMethod(EnableSession = true)]
        public string getEmailInfo()
        {
            if (!UserSession.IsActive) return this.timeoutMsg;
            AppSet.getValus();
            string _tbl = "<table border='0' class='gridView tbls'> " +
        " <tr><th>SMTP Server:</th><td>" + ((AppSet.smtpServer.Length > 0) ? ("<font color='green'>" + AppSet.smtpServer) :
        "<font color='red'>None") + " </font></td> </tr> " +
        " <tr><th>SMTP Port:</th><td>" +
((AppSet.smtpPort > 0) ? ("<font color='green'>" + AppSet.smtpPort.ToString() + "</font>") : "") + "</td></tr> " +
        " <tr><th>Email:</th><td>" +
        ((AppSet.smtpEmail.Length > 0) ? ("<font color='green'>" + AppSet.smtpEmail) : "<font color='red'>None") + "</font></td></tr>  " +
        " <tr><th>Display Name:</th><td>" +
        ((AppSet.smtpDisplay.Length > 0) ? ("<font color='green'>" + AppSet.smtpDisplay) :
            "<font color='red'>None") + "</font></td></tr> </table>"; return _tbl;
        }

          

        [WebMethod(EnableSession = true)]
        public string getTrail(string modul, string action, string frmDt, string toDt)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;

            DateTime fromDate = DateTime.Now; DateTime toDate = DateTime.Now;
            try { fromDate = DateTime.Parse(frmDt); }
            catch { return "<font color='red'>Please select a valid from date...</font>"; }
            try { toDate = DateTime.Parse(toDt); }
            catch { return "<font color='red'>Please select a valid to date...</font>"; }

            DataTable TBL = new DataTable();
            try { TBL = Trail.getTrail(modul, action, fromDate, toDate); }
            catch (Exception ex) { return "Error: " + ex.Message; }

            StringBuilder tbl = new StringBuilder();   string msg = "";
            string activeImgOn = "<img src='../images/active_on.gif' alt='active' width='18' height='18' />";
            string activeImgOff = "<img src='../images/active_off.gif' alt='not-active' width='18' height='18' />";
            tbl.Append("<div class='tblHead' style='width:400px;align:center;'> </div>" +
                    "<table  style='font-size:11px; font-weight:100px;' cellpadding='0' cellspacing='0' border='0' " +
                    " class='display' id='jqAuditTBL'> <thead> <tr align='left'>" +
                    " <th>MODULE </th> <th>ACTION</th> <th>ACTION MESSAGE</th><th></th><th>ERROR MESSAGE</th>  " +
                    " <th>BROWSER INFO.</th>  <th>AFFECTED STAFF</th> <th>REG. BY</th> <th>REG. DATE</th> </tr></thead><tfoot> " +
                    " <tr align='left'> <th>MODULE </th> <th>ACTION</th> <th>ACTION MESSAGE</th><th></th><th>ERROR MESSAGE</th>  " +
                    " <th>BROWSER INFO.</th>  <th>AFFECTED STAFF</th> <th>REG. BY</th> <th>REG. DATE</th> </tr></tfoot> <tbody>");
            //return "what is Rows: " + TBL.Rows.Count.ToString();
            /* sql = "SELECT a.*,  " +
            " (SELECT (f.SNm + ', ' + f.ONms) FROM stfStaff f WHERE f.IDNo = a.AffStfID) AS AfectedStaffName, " +
            " (SELECT (r.SNm + ', ' + r.ONms) FROM stfStaff r WHERE r.IDNo = a.RegStfID) AS RegByName " +
            " FROM AuditTrail a WHERE " + moduleF + actionF +  
            " cast(CONVERT(varchar(8), a.RegDate, 112) AS datetime) >= @fromDt AND " +
            " cast(CONVERT(varchar(8), a.RegDate, 112) AS datetime) <= @toDt ORDER BY a.RegDate DESC "; */
            foreach (DataRow dr in TBL.Rows)
            {
                try
                {
                    string regDt = "";
                    try { regDt = DateTime.Parse(dr["RegDate"].ToString()).ToString("yyyy MMM dd, hh:mm tt"); }
                    catch { }
                    string img = (bool.Parse(dr["IsSuccess"].ToString())) ? activeImgOn : activeImgOff;
                    string stf = "";
                    try { stf = dr["STAFF"].ToString(); }
                    catch (Exception ex) { msg += "Error Staf: " + ex.Message; }
                    //dr["AfectedStaffName"].ToString() + " - " + dr["AffStfID"].ToString()
                    tbl.Append("<tr align='left'> <td>" + dr["Module"].ToString() + "</td><td>" + dr["Action"].ToString() +
                        " </td><td> " + dr["ActionMSG"].ToString() + "</td><td align='center'>" + img + " </td> <td> " +
                        dr["ErrMSG"].ToString() + "</td> <td>" + dr["MachInfo"].ToString() + " </td><td>" +
                        stf + "</td><td>" + dr["RegName"].ToString() + " </td><td>" + regDt + "</td></tr>");
                }
                catch (Exception ex) { msg += "Error: " + ex.Message; }
            }

            Context.Session["GridTrailTBL"] = TBL; tbl.Append("</tbody></table> " + msg); return tbl.ToString();

        }
        

    }
}
