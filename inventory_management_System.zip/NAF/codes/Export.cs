﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.IO;

 
public class Export
{ 
    public static void EXCEL(GridView grdView, DataTable GridData, int[] hideColumns, string file_name)
    {
        if (GridData == null) { HttpContext.Current.Response.Write("No Data to Export"); return; }
        try { for (int i = 0; i < grdView.Columns.Count; i++) grdView.Columns[i].Visible = true; } catch { }
        for (int i = 0; i < hideColumns.Count(); i++) grdView.Columns[hideColumns[i]].Visible = false;

        HttpContext.Current.Response.ClearContent(); HttpContext.Current.Response.Buffer = true;
        HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}.xls", file_name));
        HttpContext.Current.Response.ContentType = "application/ms-excel";
        StringWriter sw = new StringWriter(); HtmlTextWriter htw = new HtmlTextWriter(sw);
        grdView.AllowPaging = false; grdView.ShowFooter = true;  grdView.DataSource = GridData; grdView.DataBind();

        grdView.HeaderRow.Style.Add("background-color", "#FFFFFF");//Change the Header Row back to white color
        //Applying stlye to gridview header cells
        for (int i = 0; i < grdView.HeaderRow.Cells.Count; i++)
            grdView.HeaderRow.Cells[i].Style.Add("background-color", "#FFFFFF");
        int j = 1;
        //This loop is used to apply stlye to cells based on particular row
        foreach (GridViewRow gvrow in grdView.Rows)
        {      //gvrow.BackColor = Color.White;
            if (j <= grdView.Rows.Count)
            {
                if (j % 2 != 0)
                {
                    for (int k = 0; k < gvrow.Cells.Count; k++) { gvrow.Cells[k].Style.Add("background-color", "#FFFFFF"); }
                }
            } j++;
        }
        grdView.RenderControl(htw); HttpContext.Current.Response.Write(sw.ToString()); HttpContext.Current.Response.End();
    }
    public static void EXCEL(GridView grdView, string hideColumns, string file_name)
    {
        if (grdView == null) { HttpContext.Current.Response.Write("No Data to Export"); return; }
        try { for (int i = 0; i < grdView.Columns.Count; i++) grdView.Columns[i].Visible = true; }catch { }
               
        if (hideColumns.Contains(','))
        {
            string[] hideCols = hideColumns.Split(',');
            foreach (string cols in hideCols)
            {
                int col = -1; try { col = int.Parse(cols); } catch { }
                if (col > -1) { grdView.Columns[col].Visible = false; }
            }
        }
        else if (hideColumns.Length > 0)
        {
            int col = -1; try { col = int.Parse(hideColumns); }  catch { }    if (col > -1) { grdView.Columns[col].Visible = false; }
        }
        grdView.AllowPaging = false; grdView.DataBind();
        HttpContext.Current.Response.ClearContent(); HttpContext.Current.Response.Buffer = true;
        HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}.xls", file_name));
        HttpContext.Current.Response.ContentType = "application/ms-excel";
        StringWriter sw = new StringWriter(); HtmlTextWriter htw = new HtmlTextWriter(sw);
        
        grdView.HeaderRow.Style.Add("background-color", "#FFFFFF");//Change the Header Row back to white color
        //Applying stlye to gridview header cells
        for (int i = 0; i < grdView.HeaderRow.Cells.Count; i++) grdView.HeaderRow.Cells[i].Style.Add("background-color", "#FFFFFF");
        int j = 1;
        //This loop is used to apply stlye to cells based on particular row
        foreach (GridViewRow gvrow in grdView.Rows)
        {            //gvrow.BackColor = Color.White;
            if (j <= grdView.Rows.Count)
            {
                if (j % 2 != 0)
                {
                    for (int k = 0; k < gvrow.Cells.Count; k++) { gvrow.Cells[k].Style.Add("background-color", "#FFFFFF"); }
                }
            } j++;
        }
        grdView.RenderControl(htw); HttpContext.Current.Response.Write(sw.ToString()); HttpContext.Current.Response.End();
    }

    public static void WORD(GridView grdView, DataTable GridData, int[] hideColumns, string file_name, string HeaderText)
    {
        if (GridData == null) { HttpContext.Current.Response.Write("No Data to Export"); return; }
        try { for (int i = 0; i < grdView.Columns.Count; i++) grdView.Columns[i].Visible = true; } catch { }        
        for (int i = 0; i < hideColumns.Count(); i++) grdView.Columns[hideColumns[i]].Visible = false;
        grdView.AllowPaging = false; grdView.ShowFooter = false; grdView.DataSource = GridData; grdView.DataBind();

        HttpContext.Current.Response.ClearContent();
        HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}.doc", file_name));
        HttpContext.Current.Response.Charset = ""; HttpContext.Current.Response.ContentType = "application/ms-word";
        StringWriter sw = new StringWriter(); HtmlTextWriter htw = new HtmlTextWriter(sw);
        grdView.RenderControl(htw); HttpContext.Current.Response.Write(HeaderText + sw.ToString());
        HttpContext.Current.Response.End();
    }
    public static void WORD(GridView grdView, string hideColumns, string file_name, string HeaderText)
    {
        if (grdView == null) { HttpContext.Current.Response.Write("No Data to Export"); return; }
        try { for (int i = 0; i < grdView.Columns.Count; i++) grdView.Columns[i].Visible = true; }
        catch { }
        
        if (hideColumns.Contains(','))
        {
            string[] hideCols = hideColumns.Split(',');
            foreach (string cols in hideCols)
            {
                int col = -1; try { col = int.Parse(cols); }
                catch { } if (col > -1) { grdView.Columns[col].Visible = false; }
            }
        }
        else if (hideColumns.Length > 0)
        {
            int col = -1; try { col = int.Parse(hideColumns); }
            catch { } if (col > -1) { grdView.Columns[col].Visible = false; }
        }
        grdView.AllowPaging = false; grdView.ShowFooter = true; grdView.DataBind();
        HttpContext.Current.Response.ClearContent();
        HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}.doc", file_name));
        HttpContext.Current.Response.Charset = ""; HttpContext.Current.Response.ContentType = "application/ms-word";
        StringWriter sw = new StringWriter(); HtmlTextWriter htw = new HtmlTextWriter(sw);
        grdView.RenderControl(htw); HttpContext.Current.Response.Write(HeaderText + sw.ToString());
        HttpContext.Current.Response.End();
    }

}

public class Import
{
    public static string _error = "";

    public static DataTable getImport(string fileName)
    {
        DataTable dt = new DataTable();                 _error = "";
        string pathFileName = HttpContext.Current.Server.MapPath(@"~/fTemp/" + fileName);
        if (!File.Exists(pathFileName)) { _error = "couldnot get uploaded file..."; return dt; }

        string ext = Path.GetExtension(fileName);
        if (ext.ToLower().Trim() == ".csv") return getCSV(pathFileName); else return getEXCEL(pathFileName);

    }

    private static DataTable getCSV(string fileName)
    {
        DataTable dt = new DataTable(); DataRow dr; 
        System.IO.StreamReader strWer = new System.IO.StreamReader(fileName);
        string strLine = ""; try { strWer = File.OpenText(fileName); } catch { } int nCols = 0;
        while (strWer.EndOfStream)
        {
            strLine = strWer.ReadLine();
            if (strLine.Trim() != "")
            {
                nCols += 1;       string[] rowTDs = strLine.Split(',');
                if (nCols == 1) {
                    int _nCol = 0;  foreach (string td in rowTDs) {  _nCol++;    dt.Columns.Add("col" + _nCol.ToString());   }
                }
                dr = dt.NewRow(); int k = 0;   foreach (string valu in rowTDs) {  k++;  dr["col" + k.ToString()] = valu;   }
                dt.Rows.Add(dr);               
            }
        }
        strWer.Close(); return dt;
    }

    private static DataTable getEXCEL(string fileName)
    {
        string conn = "";
        if (Path.GetExtension(fileName).ToLower().Trim() == ".xls")
            conn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties='Excel 8.0;HDR=YES;'";//Excel 97 - 2003        
        else
            conn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Excel 12.0 Xml;HDR=YES;'";// Excel 2007
        DataTable tbl = new DataTable();
        try {
            conn = String.Format(conn, fileName);      string sql = String.Format("SELECT * FROM [{0}$]", "Sheet1");
            System.Data.OleDb.OleDbConnection myConn = new System.Data.OleDb.OleDbConnection(conn);
            System.Data.OleDb.OleDbDataAdapter cmd = new System.Data.OleDb.OleDbDataAdapter(sql, myConn);
            try { cmd.Fill(tbl); } catch { }   myConn.Close();            
            for (int k = 1; k < tbl.Rows.Count - 1; k++) { try { DataRow r = tbl.Rows[k]; } catch { }  }
        } catch (Exception ex) { _error = ex.Message; }  return tbl;
    }

}





