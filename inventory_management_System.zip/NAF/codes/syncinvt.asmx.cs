﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;


using System.IO;
using System.Text;
using System.Data;
 

namespace NAF.codes
{
    /// <summary>
    /// Summary description for syncinvt
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    
    [System.Web.Script.Services.ScriptService]
    public class syncinvt : System.Web.Services.WebService
    {

        private string timeoutMsg = "<font color='red'>session timeout, please login...</font>";


        //[WebMethod(EnableSession = true)]
        //public string GetDueInfo()
        //{
        //    InventoryReport obj = new InventoryReport();
        //    try
        //    {
        //        return obj.getLedgerDue(UserSession.LocationID);
        //    }
        //    catch (Exception ex) { return ex.Message; }
        //    //getLedgerDueReordeCritExpiryTBL()
        //}


        [WebMethod(EnableSession = true)]
        public string setType(string name, string sales)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;
            bool isSales = (sales.Trim() == "1") ? true : false;        name = name.Trim();
            if (name.Length < 3) return "<font color='red'><i>Enter the Inventory Type Name</i></font>";

            bool isAdded = Inventory.setType(name, isSales);
            if (isAdded) return "<font color='green'>Successfully Added Type: " + name.Trim() + " </font>";
            else return  "<font color='red'>Couldnot add Inventory Type, <small> Error:<i> " + Inventory.error + "</i></small></font>";
        }

        [WebMethod(EnableSession = true)]
        public string setDept(string typ, string name)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;      name = name.Trim();
            int typId = 0;       try { typId = int.Parse(typ.Trim()); } catch { }
            if (typId < 1) return "<font color='red'>Select the Inventory Type...</font>";
            if (name.Length < 3) return "<font color='red'>Enter the Department name...</font>";

            bool isAdded = Inventory.setDept(typId, name); 
            if (isAdded) return "<font color='green'>Successfully Added Department </font>";
            else return "<font color='red'>Couldnot add Department, <small> Error:<i> " + Inventory.error + "</i></small></font>";
        }

         
        [WebMethod(EnableSession = true)]
        public string getSelDept(string typ, string sel)
        {
           int typId = 0; try { typId = int.Parse(typ.Trim()); } catch { }
           if (typId < 1) return "<font color='red'>Select the Inventory Type...</font>";
           DataTable tbl = Inventory.getDept(typId); 
            string opt = "<select id='" + sel.Trim() + "' style='width:190px;'><option value='0'>==ALL DEPT==</option>";
           foreach (DataRow dr in tbl.Rows) {
               opt += "<option value='" + dr["Id"].ToString() + "'> " + dr["Name"].ToString() + " </option>";
           }
           opt += "</select>"; return opt;
        }
         
        [WebMethod(EnableSession = true)]
        public string getDeptControl(string typ, string sel)
        {
            int typId = 0; try { typId = int.Parse(typ.Trim()); } catch { }
            if (typId < 1) return "<font color='red'>Select the Inventory Type...</font>";
            DataTable tbl = Inventory.getDept(typId);
            bool isSales = false;
            try { isSales = bool.Parse(Inventory.getType(typId).Rows[0]["IsSales"].ToString()); } catch { }
            string opt = "<select id='" + sel.Trim() + "' style='width:180px;'>";
            foreach (DataRow dr in tbl.Rows)
            {
                opt += "<option value='" + dr["Id"].ToString() + "'> " + dr["Name"].ToString() + " </option>";
            }
            opt += "</select><input type='hidden' id='hid" + sel + "' value='" + ((isSales)? "1" : "0") + "' />"; return opt;
        }

        [WebMethod(EnableSession = true)]
        public string setAlertNos(string loc, string typ, string dept, string phone, string email)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;
             
            int locId = 0, typId = 0, deptId = 0; 
            try { locId = int.Parse(loc.Trim()); } catch { }
            try { typId = int.Parse(typ.Trim()); } catch { }
            try { deptId = int.Parse(dept.Trim()); } catch { }
            if (phone.Length  < 11) return "<font color='red'>Enter the Phone Number(s)...</font>"; 

            bool isAdded = Inventory.setAlertNos(locId, typId, deptId, phone, email, UserSession.FullNameIDNo);
            if (isAdded) return "<font color='green'>Successfully Added Alert Phone(s)/Email(s) </font>";
            else return "<font color='red'>Couldnot add Phone(s)/Email(s), <small> Error:<i> " + Inventory.error + "</i></small></font>";
        }

        
        [WebMethod(EnableSession = true)]
        public string getAlertNos(string loc, string typ)
        {
            int locId = 0, typId = 0; 
            try { locId = int.Parse(loc.Trim()); } catch { }     try { typId = int.Parse(typ.Trim()); } catch { }

            DataTable TBL = Inventory.getAlertNos(locId, typId);  /* "SELECT a.*, Location, typeName, deptName */

            StringBuilder tbl = new StringBuilder(); 
            tbl.Append("<div class='tblHead' style='width:400px;align:center;'> </div>" +
                    "<table  style='font-size:11px; font-weight:100px;' cellpadding='0' cellspacing='0' border='0' " +
                    " class='display' id='jqPhoneEmailsTBL'> <thead> <tr align='left'>" +
                    " <th>LOCATION </th> <th>TYPE</th> <th>DEPARTMENT</th> <th>PHONE NUMBER(S)</th>  " +
                    " <th>EMAIL ADDRESS(ES)</th> <th>REG. BY/DATE</th> <th> </th> </tr></thead><tfoot> " +
                    " <tr align='left'> <th>LOCATION </th> <th>TYPE</th> <th>DEPARTMENT</th> <th>PHONE NUMBER(S)</th>  " +
                    " <th>EMAIL ADDRESS(ES)</th> <th>REG. BY/DATE</th> <th> </th> </tr></tfoot> <tbody>");
            foreach (DataRow dr in TBL.Rows)
            {
                string regDt = "";
                try { regDt = DateTime.Parse(dr["RegDate"].ToString()).ToString("yyyy MMM dd, hh:mm tt"); } catch { }
                string locNm = dr["Location"].ToString(), typeNm = dr["typeName"].ToString(), deptNm = dr["deptName"].ToString();
                if (locNm.Length < 3) locNm = "ALL LOCATIONS"; if (typeNm.Length < 3) typeNm = "ALL TYPES";
                if (deptNm.Length < 3) deptNm = "ALL DEPTS";

                tbl.Append("<tr align='left'> <td>" + locNm + "</td><td>" + typeNm + "</td><td> " + deptNm + "</td><td>" +
                   dr["phone"].ToString() + " </td><td> " + dr["email"].ToString() + "</td> <td title='DATE: " + regDt + "'>" + 
                   dr["RegIDNo"].ToString() + " </td><td><a href='javascript:deleteAlertNo(" + dr["Id"].ToString() +
                   ");'><img src='../images/delete.gif' alt='delete' /></a><span id='" + dr["Id"].ToString() + "'></span></td></tr>");
            }

            Context.Session["GridAlertPhoneTBL"] = TBL; 
            tbl.Append("</tbody></table><input type='hidden' id='hidPhonelocTypIds' value='" + loc + "," + typ + "' /> "); 
            return tbl.ToString();
        }
                
        [WebMethod(EnableSession = true)]
        public string deleteAlertNo(string id, string locTyp)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;
            string loc = "", typ = "";
            try { loc = locTyp.Split(',')[0].Trim(); } catch { }   try { typ = locTyp.Split(',')[1].Trim(); } catch { }
            int tblId = 0; try { tblId = int.Parse(id.Trim()); } catch { }
            Inventory.deleteAlertNos(tblId);      return getAlertNos(loc, typ);
        }
               
        [WebMethod(EnableSession = true)]
        public string setVendor(string refNo, string refDt, string compNm, string contPerson, string phone, string email, string web,
             string rmk, string dealer, string addr)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;
            DateTime referDate = DateTime.Now;    try { referDate = DateTime.Parse(refDt.Trim());  } catch {
                return "<font color='red'>Please Enter a valid Date...</font>";
            }
            if (Inventory.getVendor(refNo).Rows.Count > 0)
                return "<font color='red'>Ref. No. already exist...</font>";

            bool isAdd = Inventory.setVendor(refNo, compNm, contPerson, phone, email, addr, web, rmk, dealer, referDate,
                UserSession.FullNameIDNo);
            if (isAdd)   return "<font color='green'>Successfully added Vendor: " + compNm + ", REF. No: " +  refNo + " </font>";
            else  return "<font color='red'>Unable to add Vendor..." + Inventory.error + " </font>";            
        }

         
        [WebMethod(EnableSession = true)]
        public string getVendors(string valu)
        {         
            if (!UserSession.IsActive) return this.timeoutMsg;
            DataTable TBL = new DataTable();
            if (valu.Length > 2) TBL = Inventory.getSearchVendor(valu);    else TBL = Inventory.getVendor();

            StringBuilder tbl = new StringBuilder();
            tbl.Append("<div class='tblHead' style='width:400px;align:center;'> " + 
                ((valu.Length > 2)? ("SEARCH: " + valu) : "ALL VENDORS") + " </div>" +
                    "<table  style='font-size:11px; font-weight:100px;' cellpadding='0' cellspacing='0' border='0' " +
                    " class='display' id='jqVendorTBL'> <thead> <tr align='left'>" +
                    " <th>REF. No. </th><th> REF. DATE</th> <th>COMPANY NAME</th><th>CONTACT NAME</th><th>PHONE NUMBER</th>" +
                    " <th>EMAIL ADDRESS</th> <th>WEBSITE</th> <th>PRODUCT/SERVICES </th><th> REMARKS</th> " +
                    " <th>REGISTERED BY </th></tr></thead><tfoot>  <tr align='left'> " +
                    "<th>REF. No. </th><th> REF. DATE</th> <th>COMPANY NAME</th><th>CONTACT NAME</th><th>PHONE NUMBER</th>" +
                    " <th>EMAIL ADDRESS</th> <th>WEBSITE</th> <th>PRODUCT/SERVICES </th><th> REMARKS</th> " +
                    " <th>REGISTERED BY </th></tr></tfoot> <tbody>");
            foreach (DataRow dr in TBL.Rows)
            {
                string regDt = "";
                try { regDt = DateTime.Parse(dr["RegDate"].ToString()).ToString("yyyy MMM dd, hh:mm tt"); } catch { }
               
                tbl.Append("<tr align='left'> <td>" + dr["RefNo"].ToString() + "</td><td>" + 
                    DateTime.Parse(dr["RegisterDt"].ToString()).ToString("yyyy-MMM-dd") +
                    "</td><td> " + dr["Name"].ToString() + "</td><td>" + dr["ContactName"].ToString() +
                   " </td><td> " + dr["Phone"].ToString() + "</td><td> " + dr["Email"].ToString() +
                   "</td> <td>" + dr["Website"].ToString() + " </td><td>" + dr["DealerOn"].ToString() +
                   "</td><td>" + dr["RMK"].ToString() + "</td><td title='Reg. Date: " + regDt + "'>" +
                   dr["RegIDNo"].ToString() + "</td></tr>");
            }

            Context.Session["GridVendorTBL"] = TBL;    tbl.Append("</tbody></table>");    return tbl.ToString();

        }


        //=======================================================================
        //======================================================================= 
        [WebMethod(EnableSession = true)]
        public object setPart(string loc, string typ, string dept, string rack, string card, string part, string serial, string name,
            string qty, string dOfQ, string isMfg, string mfgDt, string isExp, string expDt, string isSales, string unitPrice,
            string isPcent, string rate, string rmk, string vendor, string allowAlert, string rQty, string critQty)
        {
            if (!UserSession.IsActive) { var _obj = new { Id = 0, Msg = this.timeoutMsg }; return _obj; }

            int _loc = 0, _invTyp = 0, _dept = 0, _qty = 0, reorderQty = 0, criticalQty = 0;
            _loc = int.Parse(loc.Trim()); _invTyp = int.Parse(typ.Trim()); _dept = int.Parse(dept.Trim()); _qty = int.Parse(qty.Trim());
            card = card.Trim(); part = part.Trim();            
            DateTime mfgDate = DateTime.Now, expiryDate = DateTime.Now;
            bool isExpiry = (isExp.Trim() == "1") ? true : false;      bool isManufact = (isMfg.Trim() == "1") ? true : false;
            if (isManufact)
            {
                try { mfgDate = DateTime.Parse(mfgDt.Trim()); }
                catch { var er = new { Id = 0, Msg = "<font color='red'>Enter a valid Manufacturing Date...</font>" }; return er; }
            }
            if (isExpiry)
            {
                try { expiryDate = DateTime.Parse(expDt.Trim()); }
                catch { var er = new { Id = 0, Msg = "<font color='red'>Enter a valid Expiry Date...</font>" }; return er; }
            }
            if (allowAlert.Trim() == "1") {
                try { reorderQty = int.Parse(rQty.Trim()); } catch { } try { criticalQty = int.Parse(critQty.Trim()); } catch { }
            }
            bool _isSales = (isSales.Trim() == "1") ? true : false;        decimal _unitPrice = 0.0M, _rate = 0.0M, _salesAMT = 0.0M;
            bool _isPcent = (isPcent.Trim() == "1") ? true : false;
            if (_isSales)
            {
               try { _unitPrice = decimal.Parse(unitPrice.Trim()); } catch { }   try { _rate = decimal.Parse(rate.Trim()); } catch { }
               if (_isPcent) _salesAMT = ((_rate / 100.0M) * _unitPrice) + _unitPrice; else _salesAMT = _rate + _unitPrice;
          if (_unitPrice < 0.01M) { var er = new { Id = 0, Msg = "<font color='red'>Enter the Cost Price/per unit...</font>" }; return er;
          } else if (_rate < 0.01M) { var er = new { Id = 0, Msg = "<font color='red'>Enter the Profit rate...</font>" }; return er; }
            }

            bool isAdded = Inventory.setPart(_loc, _invTyp, _dept, rack, card, part, serial, name, _qty, dOfQ, isManufact, isExpiry,
                mfgDate, expiryDate, _unitPrice, _isPcent, _rate, _salesAMT, reorderQty, criticalQty, rmk, vendor, 
                UserSession.FullNameIDNo);
            if (isAdded) {    var ad = new { Id = 1, Msg = "<font color='green'>Successfully added Part...</font>" }; return ad;
            } else {
                var ad = new { Id = 0, Msg = "<font color='red'>Unable to added Part..." + Inventory.error + "</font>" }; return ad;
            } 
        }
         
        [WebMethod(EnableSession = true)]
        public object getAddPartsCardNoTBL(string loc, string typ, string partCardNo)
        {
            if (!UserSession.IsActive) { var _obj = new { No = 0, Msg = this.timeoutMsg }; return _obj; }
            int locId = 0, typId = 0;   try { locId = int.Parse(loc.Trim()); typId = int.Parse(typ.Trim()); } catch { }
            DataTable TBL = Inventory.getLedgerPartCardTBL(locId, typId, partCardNo.Trim());
            
            string msg = ""; int nRows = TBL.Rows.Count;
            if (nRows < 1)
            {
                msg = "<font color='red'>No Part/Card Number has <b>" + partCardNo + "</b> </font>";
                var return_obj = new { No = 0, Msg = msg }; return return_obj;
            }
            else if (nRows == 1)
            {
                DataRow dr = TBL.Rows[0];
                int _isSalesPcent = (bool.Parse(dr["IsSalesPcent"].ToString())) ? 1 : 2;
                var valu = new
                {
                    No = 1, Msg = "", deptId = dr["deptId"], Rack = dr["RackNo"], Card = dr["CardNo"], Part = dr["PartNo"],
                    Serial = dr["SerialNo"],  Name = dr["Name"],  Qty = dr["Qty"].ToString(), DofQ = dr["DofQ"],
                    IsMfg = bool.Parse(dr["IsMfg"].ToString()), IsExp = bool.Parse(dr["IsExp"].ToString()),
                    MfgDt = DateTime.Parse(dr["MfgDt"].ToString()).ToString("yyyy-MM-dd"),
                    ExpDt = DateTime.Parse(dr["ExpDt"].ToString()).ToString("yyyy-MM-dd"),
                    CostPrice = dr["costPrice"], IsSalesPcent = _isSalesPcent, Rate = dr["Rate"], UnitPrice = dr["unitPrice"],
                    ReQty = dr["orderQty"], CrQty = dr["critQty"], vendor = dr["vendorID"]
                };               
                return valu;
            }
            else
            {
                StringBuilder tbl = new StringBuilder();
                tbl.Append("<table cellspacing='1' cellpadding='1' border='0' class='tbls'> " +
                   "<tr><th>CARD No.</th><th>PART No.</th><th>NAME</th><th>QTY</th><th>DEPARTMENT</th><th></th></tr>");
                string img = "<img src='../images/arrow_right_16.png' alt='add' />";
                
                foreach (DataRow dr in TBL.Rows)
                {
                    string color = "black";                                   int qty = 0, critQty = 0, reorderQty = 0;                    
                    bool isExp = bool.Parse(dr["IsExp"].ToString());          DateTime expDt = DateTime.Now;
                    try { if (isExp) expDt = DateTime.Parse(dr["ExpDt"].ToString()); } catch { } //.ToString("yyyy-MM-dd")
                    try {
                        qty = int.Parse(dr["Qty"].ToString());    reorderQty = int.Parse(dr["orderQty"].ToString());
                        critQty = int.Parse(dr["critQty"].ToString());                        
                    } catch { }

                    if (reorderQty >= qty && reorderQty > 0) color = "orange";      if (critQty >= qty && critQty > 0) color = "amber";
                    if (isExp && expDt < DateTime.Now.AddMonths(1)) color = "red";

                    try {
                        tbl.Append("<tr><td>" + dr["CardNo"].ToString() + "</td><td>" + dr["PartNo"].ToString() +
                            "</td><td>" + dr["Name"].ToString() + "</td><td><font color='" + color + "'> " + qty + " " +
                            dr["DofQ"].ToString() + "</font> </td><td>" + dr["Dept"].ToString() + "</td> " +
                            " <td><a href='javascript:setPartValuesToAdd(\"" + dr["Id"].ToString() + "\")'> " + img +
                            " </a></td></tr>");
                    } catch { }
                }
                msg = tbl.ToString() + "</table>";   var return_obj = new { No = 0, Msg = msg }; return return_obj;
            }
        }

        [WebMethod(EnableSession = true)]
        public object getPartValus(string partID)
        {
            if (!UserSession.IsActive) { var _obj = new { No = 0, Msg = this.timeoutMsg }; return _obj; }
            long part_Id = 0L; try { part_Id = long.Parse(partID.Trim()); } catch { }
            DataTable TBL = Inventory.getLedgerTBL(part_Id);
            if (TBL.Rows.Count < 1)
            {
                var _obj = new { No = 0, Msg = "<font color='red'>No Record...</font>" }; return _obj;
            }
            DataRow dr = TBL.Rows[0];
            int _isSalesPcent = (bool.Parse(dr["IsSalesPcent"].ToString())) ? 1 : 0;
            var valu = new
            {
                No = 1, Msg = "", deptId = dr["deptId"], Rack = dr["RackNo"], Card = dr["CardNo"],
                Part = dr["PartNo"], Serial = dr["SerialNo"], Name = dr["Name"], Qty = dr["Qty"].ToString(),
                DofQ = dr["DofQ"], IsMfg = bool.Parse(dr["IsMfg"].ToString()),
                IsExp = bool.Parse(dr["IsExp"].ToString()),
                MfgDt = DateTime.Parse(dr["MfgDt"].ToString()).ToString("yyyy-MM-dd"),
                ExpDt = DateTime.Parse(dr["ExpDt"].ToString()).ToString("yyyy-MM-dd"),
                CostPrice = dr["costPrice"],IsSalesPcent = _isSalesPcent, Rate = dr["Rate"],
                UnitPrice = dr["unitPrice"], ReQty = dr["orderQty"], CrQty = dr["critQty"], vendor = dr["vendorID"]
            };
            return valu;
        }


        //============== ISSUING PARTS TO CART AND SALES OF PARTS ==================
               
        [WebMethod(EnableSession = true)]
        public object addPartToCart(string loc, string typ, string isSales, string cardNo, string qty)
        {
            if (!UserSession.IsActive) { 
                var _obj = new { Id = 0, Msg = this.timeoutMsg, Cart = "0", CartAMT = "0.0", CartAMT2 = "0.0" }; return _obj; 
            }
            bool _isSales = (isSales.Trim() == "1") ? true : false;

            ArrayList lst = new ArrayList();
            if (Session["sesCartLst"] != null) try { lst = (ArrayList)Session["sesCartLst"]; } catch { }
            string cartMsg = this.getCartParts(lst, _isSales);
            decimal grandCartCost = InvParts.grandCostAMT;

            int locId = 0, typId = 0, nQty = 0; cardNo = cardNo.Trim();
            try { locId = int.Parse(loc); }catch{}  try { typId = int.Parse(typ); } catch{} try { nQty = int.Parse(qty); }catch {}
            if (locId < 1) {
                var _obj = new { Id = 0, Msg = "<font color='red'><i>Please Select the Location...</i></font>",
                                 Cart = cartMsg, CartAMT = grandCartCost, CartAMT2 = grandCartCost.ToString("N2") }; return _obj;
            }
            if (typId < 1) {
                var _obj = new { Id = 0, Msg = "<font color='red'><i>Please Select the Inventory Type...</i></font>",
                                 Cart = cartMsg, CartAMT = grandCartCost, CartAMT2 = grandCartCost.ToString("N2") }; return _obj;
            }
            if (nQty < 1) {
                var _obj = new {  Id = 0, Msg = "<font color='red'><i>Please Enter the Quantity...</i></font>",
                    Cart = cartMsg, CartAMT = grandCartCost, CartAMT2 = grandCartCost.ToString("N2") }; return _obj;
            }

            DataTable TBL = Inventory.getLedgerTBL(locId, typId, cardNo);
            int nRows = TBL.Rows.Count;      int stockQty = 0;  DataRow dr;
            if (nRows > 0) {  dr = TBL.Rows[0]; try { stockQty = int.Parse(TBL.Rows[0]["Qty"].ToString()); } catch { }
            } else {
                var _obj = new { Id = 0, Msg = "<font color='red'>CARD IDNo: " + cardNo + " does not exist...</font>",
                                 Cart = cartMsg, CartAMT = grandCartCost, CartAMT2 = grandCartCost.ToString("N2") }; return _obj;
            }            
            
            if (nQty > stockQty)
            {     
                var _obj = new { Id = 0, Msg = "<font color='red'>CARD IDNo: " + cardNo + " out of Stock(" + stockQty.ToString() +
                    ")...</font>", Cart = cartMsg, CartAMT = grandCartCost, CartAMT2 = grandCartCost.ToString("N2") }; return _obj;
            }
            else
            {
                long Id = 0L;        try { Id = long.Parse(dr["Id"].ToString()); } catch { }
                if (Session["sesCartLst"] != null) lst = this.removeExistingPart(Id);
                              
                bool isMfg = bool.Parse(dr["IsMfg"].ToString());    bool isExp = bool.Parse(dr["IsExp"].ToString());
                DateTime mfgDt = new DateTime(1900, 1, 1);          if (isMfg) mfgDt = DateTime.Parse(dr["MfgDt"].ToString());
                DateTime expDt = new DateTime(1900, 1, 1);          if (isExp) expDt = DateTime.Parse(dr["ExpDt"].ToString());
                decimal unitPrice = 0.0M, costPrice = 0.0M;    try { unitPrice = decimal.Parse(dr["unitPrice"].ToString()); } catch { }
                try { costPrice = decimal.Parse(dr["costPrice"].ToString()); } catch { }
                int deptId = int.Parse(dr["deptId"].ToString());

                InvParts pObj = new InvParts(Id, deptId, dr["Dept"].ToString(), dr["CardNo"].ToString(), dr["PartNo"].ToString(),
                    dr["Name"].ToString(), dr["SerialNo"].ToString(), dr["RackNo"].ToString(), costPrice, unitPrice,
                    nQty, dr["DofQ"].ToString(), isMfg, mfgDt, isExp, expDt);

                lst.Add(pObj);   Session["sesCartLst"] = lst;     string _cartMsg = this.getCartParts(lst, _isSales);
                grandCartCost = InvParts.grandCostAMT;
                var _obj = new { Id = 1, Msg = "<font color='green'>Added Card Number: " + cardNo + " </font>",
                                Cart = _cartMsg, CartAMT = grandCartCost, CartAMT2 = grandCartCost.ToString("N2")
                }; return _obj;
            }  
        } 

        [WebMethod(EnableSession = true)]
        private ArrayList removeExistingPart(long Id)
        {
            ArrayList lst = new ArrayList();
            if (Session["sesCartLst"] != null)  try { lst = (ArrayList)Session["sesCartLst"]; } catch { }
            var pObj = from InvParts obj in lst //.Cast<Parts>()
                           where obj.Id != Id
                           select obj;
            ArrayList l2 = new ArrayList(); foreach (InvParts pt in pObj) l2.Add(pt); Session["sesCartLst"] = l2; return l2;
        }
                        
        [WebMethod(EnableSession = true)]
        private string getCartParts(ArrayList lst, bool isSales)
        {
            StringBuilder tbl = new StringBuilder();
            if(isSales)
            tbl.Append("<table cellspacing='1' cellpadding='1' border='0' class='tbls' style='font-size:11px'> " +
                  "<tr><th>S/N</th><th>CARD No.</th><th>PART No.</th><th>NAME</th><th>QTY</th><th>UNIT PRICE</th> " +
                  " <th>AMOUNT</th><th>EXP. DATE</th> <th></th></tr>");
            else
                tbl.Append("<table cellspacing='1' cellpadding='1' border='0' class='tbls'> " +
                  "<tr><th>S/N</th><th>CARD No.</th><th>PART No.</th><th>NAME</th><th>QTY</th> <th>EXP. DATE</th> <th></th></tr>");
            int nParts = 0, partsQty = 0; decimal grandAMT = 0.0M;
            foreach (object item in lst)
            {
                InvParts obj = (InvParts)item;   nParts++; partsQty += obj.Qty;                
                string expDt = "";      if (obj.IsExp) expDt = obj.ExpDate.ToString("MMM dd, yyyy");
                string mfgdate = "";    if (obj.IsMfg) mfgdate = "Manuf. Date: " + obj.MfgDate.ToString("MMM dd, yyyy");
                decimal costAMT = obj.Qty * obj.UnitPrice;               grandAMT += costAMT;
                if (isSales)
                    tbl.Append("<tr title='DEPARTMENT: " + obj.Dept + ", RACK No.: " + obj.RackNo + "'><td>" + nParts.ToString() + 
                        " </td><td>" + obj.CardNo + "</td><td>" + obj.PartNo + " </td><td>" + obj.Name + " </td><td>" + 
                        obj.Qty.ToString() + " " + obj.DofQ + "</td><td>" + obj.UnitPrice.ToString("N2") + " </td><td> " + 
                        costAMT.ToString("N2") + "</td> <td title='" + mfgdate + "'>" + expDt + " </td><td align='center'>" +
               "<a href='javascript:removePart(\"" + obj.Id.ToString() + "\");' title='Click to Remove Part from Cart List'>" +
                         "<img src='../images/delete.gif' alt='remove' width='15px' height='15px' /></a> </td></tr>"); 
                    // <img src='../images/basket_remove.png' alt='remove' width='19px' height='18px' />
                else
                    tbl.Append("<tr title='DEPARTMENT: " + obj.Dept + ", RACK No.: " + obj.RackNo + "'><td>" + nParts.ToString() + 
                        " </td><td>" + obj.CardNo + " </td><td>" + obj.PartNo + "</td><td>" + obj.Name + " </td><td>" + 
                        obj.Qty.ToString() + " " + obj.DofQ + "</td><td title='" + mfgdate + "'>" + expDt + " </td><td align='center'>" +
              "<a href='javascript:removePart(\"" + obj.Id.ToString() + "\");' title='Click to Remove Part from Cart List'> " +
                        "<img src='../images/delete.gif' alt='remove' width='15px' height='15px' /></a> </td></tr>"); 
                //<img src='../images/basket_remove.png' alt='remove' />
            }
            if (isSales)
                tbl.Append("<tr><th colspan='4' align='right'>TOTAL:</th><th colspan='2' align='left'>" + partsQty.ToString() + "</th> " +
                      " <th colspan='3' align='left'> " + grandAMT.ToString("N2") + " </th> </tr>");
            else
       tbl.Append("<tr><th colspan='4' align='right'>TOTAL:</th><th colspan='3' align='left'>" + partsQty.ToString() + "</th> </tr>");

            string hidParts = "<input type='hidden' id='hidIsuPartNos' value='" + nParts + "' />";

            InvParts.grandCostAMT = grandAMT;     return (nParts > 0) ? (tbl.ToString() + hidParts) : hidParts;
        }

        
        [WebMethod(EnableSession = true)]
        public object removePart(string ID, string isSales) 
        {
            long Id = 0L;           try { Id = long.Parse(ID.Trim()); } catch { }
            bool _isSales = (isSales.Trim() == "1") ? true : false;            ArrayList lst = new ArrayList();
            if (Session["sesCartLst"] != null) try { lst = (ArrayList)Session["sesCartLst"]; } catch { }
            var partsObj = from InvParts obj in lst //.Cast<Parts>()
                           where obj.Id != Id
                           select obj;
            ArrayList lst2 = new ArrayList(); foreach (InvParts pt in partsObj) lst2.Add(pt);    Session["sesCartLst"] = lst2; 
            string _cartMsg = this.getCartParts(lst2, _isSales);          decimal grandCartCost = InvParts.grandCostAMT;
            var _obj = new { Id = 1, Msg = "", Cart = _cartMsg, CartAMT = grandCartCost, CartAMT2 = grandCartCost.ToString("N2")
            }; return _obj;
        }

        [WebMethod(EnableSession = true)]
        public string clearCart() { Session["sesCartLst"] = null; return ""; }

      
        [WebMethod(EnableSession = true)]
        public object submitIssueCart(string req, string loc, string typ, string recName, string rmk, string sales, 
            string isvat, string vatrate, string isdisc, string isdiscPcent, string discrate, string givenamt)
        {
            if (!UserSession.IsActive) {  var _obj = new { Id = 0, Msg = this.timeoutMsg }; return _obj;  }
            
            long requestId = 0L;   try { requestId = long.Parse(req.Trim()); } catch { }
            bool isRequest = (requestId > 0L) ? true : false;

            int locId = 0, invTypId = 0; 
            try { locId = int.Parse(loc.Trim()); } catch { }   try { invTypId = int.Parse(typ.Trim()); } catch { }
            if (locId < 1) {
                var _obj = new { Id = 0, Msg = "<font color='red'><i>Please Select the Location...</i></font>" }; return _obj;
            }
            if (invTypId < 1) {
                var _obj = new { Id = 0, Msg = "<font color='red'><i>Please Select the Inventory Type...</i></font>" }; return _obj;
            }
            
            ArrayList lst = new ArrayList(); if (Session["sesCartLst"] != null) try { lst = (ArrayList)Session["sesCartLst"]; }catch{ }
                        
            int nItems = lst.Count;
            if (lst.Count < 1) {  var _obj = new { Id = 0, Msg = "<font color='red'>No Item in Cart...</font>" }; return _obj;
            }
            else
            {
                bool isSales = (sales.Trim() == "1") ? true : false;
                bool isVAT = (isvat.Trim() == "1") ? true : false;
                bool isDiscount = (isdisc.Trim() == "1") ? true : false;
                bool isDiscountPcent = (isdiscPcent.Trim() == "1") ? true : false;
                decimal VATrate = 0.0M;  try { VATrate = decimal.Parse(vatrate.Trim()); } catch { }
                decimal discRate = 0.0M; try { discRate = decimal.Parse(discrate.Trim()); } catch { }
                decimal givenAMT = 0.0M; try { givenAMT = decimal.Parse(givenamt.Trim()); } catch { }

                decimal costAMT = 0.0M, soldAMT = 0.0M, discountAMT = 0.0M, VATamt = 0.0M, chargedAMT = 0.0M, paidAMT = 0.0M; 
                bool isPaid = true;       decimal balanceDebtAMT = 0.0M;
                
                if (isSales)
                {
                    isPaid = false; 
                    foreach (InvParts co in lst) { soldAMT += (co.Qty * co.UnitPrice); costAMT += (co.Qty + co.CostPrice); }
                    if (isVAT) VATamt = (VATrate / 100.0M) * soldAMT;
                    if (isDiscount) {
                        if (isDiscountPcent) discountAMT = (discRate / 100.0M) * soldAMT;  else discountAMT = discRate;
                    }
                    chargedAMT = soldAMT + VATamt - discountAMT;
                    if (givenAMT >= chargedAMT) { paidAMT = chargedAMT; isPaid = true;
                    } else {  isPaid = false; paidAMT = givenAMT;  }
                    balanceDebtAMT = givenAMT - chargedAMT;
                }
                string RegIDNo = UserSession.FullNameIDNo, errorMsg = "";
                 
               
                try
                {
                    int InvoiceNo = Inventory.getNewInvoice(locId, invTypId);
                    errorMsg += Inventory.error; Inventory.error = "";

                    if (InvoiceNo > 0)
                    {
                        long salesId = Inventory.setSales(requestId, locId, invTypId, InvoiceNo, nItems, costAMT, soldAMT, VATrate,
                            VATamt, isDiscountPcent, discRate, discountAMT, chargedAMT, paidAMT, isPaid, rmk, recName, RegIDNo);
                        errorMsg += Inventory.error; Inventory.error = "";

                        if (isSales && givenAMT > 0.0M) Inventory.setSalesPayment(salesId, givenAMT, paidAMT, RegIDNo);
                        errorMsg += Inventory.error; Inventory.error = "";


                        string locationName = "", emailStr = "";
                        if (isRequest)
                        {
                           bool isSend = Inventory.setRequestInvoice(requestId, InvoiceNo, rmk, RegIDNo);
                           if (!isSend) isRequest = false;
                            locationName = AppSet.getLocationName(locId);
                            emailStr = "<b>INVENTORY ECO REQUEST APPROVED FROM LOCATION: " + locationName + " </b><br>" +
                                "<b>INVENTORY TYPE: </b>" + Inventory.getTypeName(invTypId) + 
                                "<br>ECO please note item issued as requested<br>" +
                                "<b>INVOICE NUMBER: " + InvoiceNo + "</b><table border='0' cellpadding='2' cellspacing='2'>" +
                                "<tr><th>S/N</th> <th>PART NUMBER</th> <th>PART NAME</th> <th>QUANTITY</th> </tr>";
                        }
                        int k = 0;

                        foreach (InvParts i in lst)
                        {
                          bool isAdded =  Inventory.setSalesItem(salesId, i.Id, InvoiceNo, i.Qty, i.DofQ, i.CostPrice, i.UnitPrice,
                                     i.DeptId, i.RackNo, i.CardNo, i.PartNo, i.SerialNo, i.Name, i.IsMfg, i.IsExp, i.MfgDate, i.ExpDate);
                            errorMsg += Inventory.error; Inventory.error = "";
                            
                            if (isRequest)
                            {
                                k++; emailStr += "<tr><td>" + k.ToString() + ".</td><td>" + i.PartNo + "</td><td>" + i.Name +
                          "</td><td>" + i.Qty.ToString() + " " + i.DofQ + " </td></tr>";
                            }
                        }
                        Session["sesCartLst"] = null;
                        //==================================
                        string returnMsg = "";
                        if (isRequest)
                        {
                            emailStr += "<tr><td colspan='4'><hr /></td></tr> ";
                            DataTable reqTBL = Inventory.getRequest(requestId);                DataRow dr = reqTBL.Rows[0];
                            emailStr += "<tr><td colspan='4'><b>REQUESTED BY:</b> " + dr["EcoIDNo"].ToString()  + " </td></tr> " +
                            " <tr><td colspan='4'><b>REQUESTED DATE: " +
                            DateTime.Parse(dr["EcoRegDt"].ToString()).ToString("MMM dd, yyyy hh:mm tt") + "</td></tr></table>";
                            //------------- GETTING EMAILS & PHONE NUMBERS TO SEND ALERT -------------------------
                            DataTable phoneEmailTBL = Role.getApprovalPhoneEmails(locId, Role.modECO);
                            if (phoneEmailTBL.Rows.Count < 1) phoneEmailTBL = Role.getApprovalPhoneEmails(0, Role.modECO);

                            string emailNos = "", phoneNos = "", emailPhoneStr = "";
                            foreach (DataRow _dr in phoneEmailTBL.Rows)
                            {
                                string email = "", phone = "";
                                try { email = _dr["Email"].ToString().Trim(); } catch { }
                                try { phone = _dr["Phone"].ToString().Trim(); } catch { }
                                if (email.Length > 4) emailNos += email + ","; if (phone.Length > 7) phoneNos += phone + ",";
                            }
                            if (emailNos.Length > 4)
                            {
                                Mailer.sendEmail(emailNos, "INVENTORY ECO REQUEST ISSUED", emailStr);
                                if (Mailer.IsEmailSent) 
                                    emailPhoneStr = "<font color='green'>Successfully Sent Notification by Email</font>";
                                else emailPhoneStr = "<font color='red'>Unable to Send Notification by Email</font>";
                            }
                            else
                                emailPhoneStr = "<font color='red'>No Email, Unable to Send Notification by Email</font>";
                            if (phoneNos.Length > 7)
                            {
                                Mailer.sendSMS("NAF.REQ.APROV", phoneNos, ("ECO please note item issued as requested. location: " + 
                                    locationName + ", Invoice No: " + InvoiceNo));
                                if (Mailer.IsSmsSent) 
                                    emailPhoneStr += "<br><font color='green'>Successfully Sent Notification by SMS</font>";
                                else emailPhoneStr += "<br><font color='red'>Unable to Send Notification by SMS</font>";
                            }
                            else  emailPhoneStr += "<br><font color='red'>No Phone Number, Unable to Send Notification by SMS</font>";
                            returnMsg = "<div><font color='green'>Successfully Approved Request...</font></div>" + emailPhoneStr + errorMsg;
                        }
                        //======================================================
                        returnMsg += "<div style='padding-left:90px;'><table class='modTbl2'><tr><th>INVOICE No:</th><td>" +
                            InvoiceNo.ToString() + "</td></tr> <tr><th>ITEMS:</th> <td>" + nItems.ToString() + "</td></tr>";
            //  "<tr><th>ITEMS AMOUNT:</th> <td> =N=" + soldAMT.ToString("N2") + "</td></tr>";
            //  if (VATamt > 0.0M)
            //      returnMsg += "<tr><th>VAT(" + VATrate.ToString() + "):</th> <td> =N=" + VATamt.ToString("N2") + "</td></tr>";
            //  if (discountAMT > 0.0M && isDiscountPcent)
            //      returnMsg += "<tr><th>DISCOUNT(" + discRate.ToString() + "%):</th> <td> =N=" + discountAMT.ToString("N2") +
            //          "</td></tr>";
            //  if (discountAMT > 0.0M && !isDiscountPcent)
            //      returnMsg += "<tr><th>DISCOUNT:</th> <td> =N=" + discountAMT.ToString("N2") + "</td></tr>";

            //  returnMsg += "<tr><td colspan='2'> </td></tr>" +
            //      "<tr><th>CHARGED AMOUNT:</th> <td> =N=" + chargedAMT.ToString("N2") + "</td></tr>" +
            //      "<tr><th>GIVEN AMOUNT:</th> <td> =N=" + givenAMT.ToString("N2") + "</td></tr>";
            //if (balanceDebtAMT >= 0.0M)
            // returnMsg += "<tr><th><font color='green'>BALANCE:</font></th> <td> =N=" + balanceDebtAMT.ToString("N2") + "</td></tr>";
            //else returnMsg += "<tr><th><font color='red'>DEBT:</font></th> <td> =N=" + balanceDebtAMT.ToString("N2") + "</td></tr>";
                        returnMsg += "</table></div>" + errorMsg;         var v = new { Id = 1, Msg = returnMsg };   return v;
                    }
                    else errorMsg += " couldnot issue parts ";
                    var er = new { Id = 0, Msg = "<font color='red'> " + errorMsg + " ...</font>" };   return er;
                }
                catch (Exception ex)
                {
                    var er = new { Id = 0, Msg = "<font color='red'>Couldnot Issue Parts: " + ex.Message + errorMsg + " ...</font>" };
                    return er;
                }
            }           
        }

        //============================== REQUEST FOR PARTS =====================================
        [WebMethod(EnableSession = true)]
        public string searchPartsInv(string loc, string typ, string dept, string part)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;
            int locId = 0, typId = 0, deptId = 0;               try { locId = int.Parse(loc.Trim()); } catch { }
            try { typId = int.Parse(typ.Trim()); } catch { }    try { deptId = int.Parse(dept.Trim()); } catch { }
            DataTable TBL = Inventory.searchLedgerTBL(locId, typId, deptId, part);
             
            StringBuilder tbl = new StringBuilder();
            tbl.Append("<table border='0' class='tbls'><tr><th>PART No.</th><th>PART NAME</th><th> </th></tr>");
            int k = 0;
            foreach (DataRow dr in TBL.Rows)
            {
                k++;                bool isExp = bool.Parse(dr["IsExp"].ToString());
                DateTime expDt = new DateTime(1900, 1, 1);          if (isExp) expDt = DateTime.Parse(dr["ExpDt"].ToString());
                string expDate = "";        if (isExp) expDate = "    Expiry Date: " + expDt.ToString("MMM dd, yyyy"); 
                
                string tit = "title='SERIAL No: " + dr["SerialNo"].ToString() + ",   STOCK QTY: " + dr["Qty"].ToString() +
                    " " + dr["DofQ"].ToString() + expDate + ".'";
                 
                tbl.Append("<tr " + tit + "><td>" + dr["PartNo"].ToString() + "</td> <td>" + dr["Name"].ToString() + 
                    "</td> <td><a href='javascript:addSrchCardNoToCartBox(\"" + dr["CardNo"].ToString() + "\",\"" +
                    dr["PartNo"].ToString() + "\")'>add</a></td>  </tr>");
            }
            if (k == 0) tbl.Append("<tr><td colspan='3'><font color='red'><i>No Record...</i></font></td></tr>");
            tbl.Append("</table>"); return tbl.ToString();
        }
                
        [WebMethod(EnableSession = true)]
        public object submitReqCart(string loc, string typ, string rmk, string outOfStock)
        {           
            if (!UserSession.IsActive) { var _obj = new { Id = 0, Msg = this.timeoutMsg }; return _obj; }

            int locId = 0, invTypId = 0;
            try { locId = int.Parse(loc.Trim()); } catch { }     try { invTypId = int.Parse(typ.Trim()); } catch { }
            if (locId < 1) {
                var _obj = new { Id = 0, Msg = "<font color='red'><i>Please Select the Location...</i></font>" }; return _obj;
            }
            if (invTypId < 1) {
                var _obj = new { Id = 0, Msg = "<font color='red'><i>Please Select the Inventory Type...</i></font>" }; return _obj;
            }
            ArrayList lst = new ArrayList(); if (Session["sesCartLst"] != null) 
                try { lst = (ArrayList)Session["sesCartLst"]; } catch { }

            int nItems = lst.Count;
            if (lst.Count < 1) {
                var _obj = new { Id = 0, Msg = "<font color='red'>No Item in Cart...</font>" }; return _obj;
            }
            else
            {
                string RegIDNo = UserSession.FullNameIDNo, errorMsg = "";
                  
                /* 	Couldnot Send Request: The parameter 'addresses' cannot be an empty string. Parameter name: addresses  :*/
                long requestId = Inventory.setRequest(locId, invTypId, rmk, outOfStock, RegIDNo);                    
                    
                string locationName = AppSet.getLocationName(locId), invTypeName = Inventory.getTypeName(invTypId);
                string emailStr = "<b>INVENTORY REQUEST, LOCATION: " + locationName + ", INVENTORY TYPE: " + invTypeName + "</b><br>" +
                        "Request for spare part approval pending<br> <table border='0' cellpadding='2' cellspacing='2'>" +
                        "<tr><th colspan='4'>CO/ECO COMMENTS: </th></tr><tr><td colspan='4'>" + rmk + "</td></tr> " +
                        " <tr><th>S/N </th><th>PART NAME </th><th>PART NUMBER </th><th>QTY/UNITS </th> </tr>";
                int k = 0;
                if (requestId > 0L)
                {                        
                    foreach (InvParts i in lst)
                    {                            
                        bool isAdded = Inventory.setRequestItem(requestId, i.Id, i.Qty, i.DofQ);
                        if (isAdded)
                        {
                            k++;
                            emailStr += "<tr><td>" + k.ToString() + ".</td><td>" + i.Name + "</td><td>" + i.PartNo +
                                "</td><td>" + i.Qty.ToString() + " " + i.DofQ + " </td></tr>";
                        }
                        //errorMsg += "<br>setRequestITem Error: " + Inventory.error; Inventory.error = "";
                    }
                    emailStr += "<tr><td colspan='4'><hr /></td></tr> ";
                    if (outOfStock.Length > 0)
                        emailStr += "<tr><th colspan='4'>OUT OF STOCK PARTS: </th></tr><tr><td colspan='4'>" + outOfStock + "</td></tr>";

                    emailStr += " </table>";     Context.Session["sesCartLst"] = null;

                    //------------- GETTING EMAILS & PHONE NUMBERS TO SEND ALERT -------------------------
                    DataTable phoneEmailTBL = new DataTable();
                    phoneEmailTBL = Role.getApprovalPhoneEmails(locId, Role.modECO);
                    if (phoneEmailTBL.Rows.Count < 1) phoneEmailTBL = Role.getApprovalPhoneEmails(0, Role.modECO);

                     
                    string emailNos = "", phoneNos = "", emailPhoneStr = "";
                    if (phoneEmailTBL.Rows.Count > 0)
                    {
                        foreach (DataRow dr in phoneEmailTBL.Rows)
                        {
                            string email = "", phone = "";
                            try { email = dr["Email"].ToString().Trim(); } catch { }
                            try { phone = dr["Phone"].ToString().Trim(); } catch { }
                            if (email.Length > 4) emailNos += email + ","; if (phone.Length > 7) phoneNos += phone + ",";
                        }
                        if (emailNos.Length > 4)
                        {
                            try { Mailer.sendEmail(emailNos, "INVENTORY REQUEST", emailStr); }
                            catch { }
                            if (Mailer.IsEmailSent) 
                                emailPhoneStr = "<font color='green'>Successfully Sent Notification by Email</font>";
                            else emailPhoneStr = "<font color='red'>Unable to Send Notification by Email</font>";
                        }
                        else
                            emailPhoneStr = "<font color='red'>No Email, Unable to Send Notification by Email</font>";
                        if (phoneNos.Length > 7)
                        {
                            try
                            {
                                Mailer.sendSMS("NAF.REQUEST", phoneNos, ("Request for spare part approval pending. location: " + 
                                    locationName));
                            }
                            catch { }
                            if (Mailer.IsSmsSent) 
                                emailPhoneStr += "<br><font color='green'>Successfully Sent Notification by SMS</font>";
                            else emailPhoneStr += "<br><font color='red'>Unable to Send Notification by SMS</font>";
                        }
                        else
                            emailPhoneStr += "<br><font color='red'>No Phone Number, Unable to Send Notification by SMS</font>";
                    }

                    string returnMsg = "<div><font color='green'>Successfully Sent Request...</font></div>" + emailPhoneStr + errorMsg;
                    var v = new { Id = 1, Msg = returnMsg }; return v;
                }
                else errorMsg += " couldnot issue parts ";
                var er = new { Id = 0, Msg = "<font color='red'> " + errorMsg + " ...</font>" }; return er;
            }
        }
               
        [WebMethod(EnableSession = true)]
        public string getViewRequest(string loc, string typ, string stat, string frmdt, string todt)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;
            int locId = 0, typId = 0, statusId = 0; 
            try { locId = int.Parse(loc.Trim()); } catch { }           try { typId = int.Parse(typ.Trim()); } catch { } 
            try { statusId = int.Parse(stat.Trim()); } catch { }
            if (locId < 1) return "<font color='red'>Select the Location...</font>";
            if (typId < 1) return "<font color='red'>Select the Inventory Type...</font>";
            if (statusId < 1) return "<font color='red'>Select the Status...</font>";
            
            DateTime fromDt = DateTime.Now, toDt = DateTime.Now;
            if (statusId == 2 || statusId == 4)
            {
                try { fromDt = DateTime.Parse(frmdt.Trim()); }
                catch { return "<font color='red'>Select a Valid FROM Date...</font>"; }
                try { toDt = DateTime.Parse(todt.Trim()); }
                catch { return "<font color='red'>Select a Valid TO Date...</font>"; }
            }
            DataTable TBL = new DataTable(); bool isECO = true, isNotECO = false;

            string headerTxt = "LOCATION: " + AppSet.getLocationName(locId) + " &nbsp; &nbsp;INVENTORY: " +
                Inventory.getTypeName(typId) + " &nbsp; &nbsp;STATUS: ";
            if (statusId == 1) //Pending ECO Approval
            {
                //getRequestPending(int locId, int invTypId, bool isECO_Inventory)
                TBL = Inventory.getRequestPending(locId, typId, isECO);
                headerTxt += " PENDING ECO APPROVAL ";
            }
            else if (statusId == 2) //Approved by ECO
            {
                TBL = Inventory.getRequestApproved(locId, typId, isECO, fromDt, toDt);
                headerTxt += " ECO APPROVED.<br>  FROM: " + fromDt.ToString("MMM dd, yyyy.") + " &nbsp; TO: " + toDt.ToString("MMM dd, yyyy"); 
            }
            else if (statusId == 3) //Pending Inventory Control Approval
            {
                TBL = Inventory.getRequestPending(locId, typId, isNotECO);
                headerTxt += " PENDING INVENTORY CONTROL APPROVAL "; 
            }
            else if (statusId == 4) //Approved By  Inventory Control
            {
                TBL = Inventory.getRequestApproved(locId, typId, isNotECO, fromDt, toDt);
                headerTxt += " INVENTORY CONTROL APPROVED. <br>FROM: " + fromDt.ToString("MMM dd, yyyy.") +
                    " &nbsp; TO: " + toDt.ToString("MMM dd, yyyy");
            }


            else if (statusId == 5)//Pending Inventory Control Approval
            {
                TBL = Inventory.getRequestPending(locId, typId, isNotECO);
                headerTxt += " PENDING INVENTORY CONTROL APPROVAL "; 

            }
            else if (statusId == 6)//Approved By  Inventory Control
            {
                TBL = Inventory.getRequestApproved(locId, typId, isNotECO, fromDt, toDt);
                headerTxt += " INVENTORY CONTROL APPROVED. <br>  FROM: " + fromDt.ToString("MMM dd, yyyy.") +
                    " &nbsp; TO: " + toDt.ToString("MMM dd, yyyy");
            }
             
            StringBuilder tbl = new StringBuilder();
            tbl.Append("<div class='tblHead' style='width:800px;align:center;'>" + headerTxt + "  </div>" +
                    "<table  style='font-size:12px; font-weight:100px;' cellpadding='0' cellspacing='0' border='0' " +
                    " class='display' id='jqReqTBL'> <thead> <tr align='left'>");
            string tblTH = "";
            if(statusId <= 3) //pending ECO approval
                tblTH  = "<th>SNAG INFO </th> <th>TCI/OUT OF STOCK</th><th>REGISTERED BY</th> <th>REG. DATE</th><th> VIEW DETAILS</th> ";
            if(statusId == 2 || statusId == 3) //Approved By ECO 
                tblTH += "<th>CO/ECO COMMENT</th><th>CO/ECO PERSONNEL</th><th>CO/ECO APPROVED DATE</th>";
            if(statusId == 4) //Approved Inventory Control Approval 
                tblTH += "<th>INVOICE</th> <th>CO/ECO COMMENT</th> <th>CO/ECO PERSONNEL</th> <th>ISSUE REMARKS</th> " +
                    " <th>ISSUED BY</th><th>ISSUED DATE</th> ";

            if (statusId == 5)
                tblTH += "<th>SNAG INFO </th> <th>TCI/OUT OF STOCK</th><th>REQUESTED BY</th><th>REQ. DATE</th> <th> ITEMS</th>";

            tblTH += " </tr>";     tblTH += "</thead><tfoot><tr align='left'>" + tblTH + "</tr></tfoot><tbody>";   tbl.Append(tblTH);
            foreach (DataRow dr in TBL.Rows)
            {                 
                string _tbl = "";
                string outOfStock =  dr["ReqOutStock"].ToString().Trim();
                if (statusId <= 3) //pending ECO approval
                    _tbl = "<td>" + dr["ReqRMK"].ToString() + "</td><td>" + outOfStock + "</td><td>" + dr["ReqIDNo"].ToString() +
                        "</td> <td>" + DateTime.Parse(dr["ReqDt"].ToString()).ToString("yyyy MMM dd, hh:mm tt") + 
                        " </td><td><a href='javascript:viewReqItems(\"" + dr["Id"].ToString() + "\");'>details</a></td> ";
                if (statusId == 2 || statusId == 3) //Approved By ECO 
                    _tbl += "<td>" + dr["EcoRMK"].ToString() + "</td><td>" + dr["EcoIDNo"].ToString() +
                        "</td><td> " + DateTime.Parse(dr["EcoRegDt"].ToString()).ToString("yyyy MMM dd, hh:mm tt") + " </td>";
                if (statusId == 4) //Approved Inventory Control Approval 
                    _tbl += "<td><a href='javascript:viewReqItemsInvoice(\"" + dr["Id"].ToString() + "\")'>" + dr["InvNo"].ToString() +
                        "</a></td> <td>" + dr["EcoRMK"].ToString() + "</td> <td>" +
                        dr["EcoIDNo"].ToString() + "</td> <td>" + dr["InvRMK"].ToString() + "</td> " +
                        " <td>" + dr["InvIDNo"].ToString() + "</td><td>" +
                        DateTime.Parse(dr["InvRegDt"].ToString()).ToString("yyyy MMM dd, hh:mm tt") + "</td> ";
                if (statusId == 5)
                    tblTH += "<td>" + dr["EcoRMK"].ToString() + "</td><td>" + outOfStock + "</td><td>" + dr["EcoIDNo"].ToString() +
                        "</td><td> " + DateTime.Parse(dr["EcoRegDt"].ToString()).ToString("yyyy MMM dd, hh:mm tt") + " </td> " +
                        " <td><a href='javascript:viewReqItems(\"" + dr["Id"].ToString() + "\");'>details</a></td>";

                _tbl += " </tr>";
                tbl.Append(_tbl);
            }

            tbl.Append("</tbody></table>"); return tbl.ToString();

            /* <td><select id="Select1" style="width:220px;" 
onchange=" $('#txtReqFrmDt').val(''); $('#txtReqToDt').val(''); if(this.value == 2 || this.value == 4){ showDiv('spReqDt1'); showDiv('spReqDt2'); }else{ hideDiv('spReqDt1'); hideDiv('spReqDt2'); }">
<option value="0"> === STATUS === </option>    <option value="1">Pending ECO Approval</option>
<option value="2">Approved By ECO</option>     <option value="3">Pending Inventory Control Approval</option>
<option value="4">Approved By Inventory Control</option></select></td> */

        }
               
        [WebMethod(EnableSession = true)]
        public string getReqItems(string id)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;
            long reqId = 0L;         try { reqId = long.Parse(id.Trim()); } catch { }
            if (reqId <= 0L) return "<font color='red'>Unknown Request Parts</font>";

            /*getRequestItems(long reqId)  string sql = "SELECT i.*, i.Qty AS iQty, i.DofQ AS iDofQ, g.* FROM invReqItem i, invLedger g " + 
                public static DataTable getRequest(long reqId) AS Location,  InvTypeName   } */
            DataTable reqTBL = Inventory.getRequest(reqId);  string tbl = "";
            if (reqTBL.Rows.Count > 0)
            {
                DataRow rw = reqTBL.Rows[0];
                tbl = "<div><b>LOCATION:</b> " + rw["Location"].ToString() + " &nbsp; &nbsp;<b>INVENTORY:</b> " + 
                    rw["InvTypeName"].ToString() + " </div> <b>SNAG INFO: </b><br> " +  rw["ReqRMK"].ToString() + 
                    "<table class='tbls'><tr><th>S/N</th><th>PART No.</th><th>PART NAME</th><th>QTY</th></tr>";
                DataTable itemTBL = Inventory.getRequestItems(reqId); int k = 0;
                foreach (DataRow dr in itemTBL.Rows)
                {
                    k++;
                    tbl += "<tr><td>" + k.ToString() + ". </td> <td>" + dr["PartNo"].ToString() + "</td><td>" + dr["Name"].ToString() +
                        "</td><td>" + dr["iQty"].ToString() + "  " + dr["iDofQ"].ToString() + " </td></tr>";
                }
                if (rw["ReqOutStock"].ToString().Trim().Length > 2)
                    tbl += "<tr><td colspan='4'> <b>TCI/OUT OF STOCK INFO:</b> <hr />" + rw["ReqOutStock"].ToString() + "</td></tr>";
                tbl += "</table><b>REGISTERED BY: </b> " + rw["ReqIDNo"].ToString() + "<br> <b>REG. DATE: </b>" +
                    DateTime.Parse(rw["ReqDt"].ToString()).ToString("MMM dd, yyyy. hh:mm tt");
                if(!bool.Parse(rw["EcoIsAprov"].ToString()))
                    tbl += "<table border='0' cellpadding='3' cellspacing='2'><tr><td>CO/ECO COMMENT: </td><td> " +
                        " <textarea id='txtECOrmk' rows='3' style='width:300px;'></textarea></td></tr>" +
                        "<tr><td colspan='2' align='center'><input type='button' id='btnApprovReq' onclick='approveReq();' " +
                        " value='Approve' />&nbsp;&nbsp;<input type='button' value='Delete' onclick='deleteReq();' /></td></tr></table>";
            }
            return tbl;
        }

        [WebMethod(EnableSession = true)]
        public string approveECOreq(string id, string rmk)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;
            long reqId = 0L; try { reqId = long.Parse(id.Trim()); } catch { }
            if (reqId <= 0L) return "<font color='red'>Unknown Request Parts</font>";
            bool isUpd = Inventory.approveECOrequest(reqId, rmk, UserSession.FullNameIDNo);
            if (isUpd)
            {
                int locId = 0, typId = 0;
                DataRow dr = Inventory.getRequest(reqId).Rows[0];
                locId = int.Parse(dr["locId"].ToString());            typId = int.Parse(dr["typId"].ToString());
                string locationName = AppSet.getLocationName(locId), invTypeName = Inventory.getTypeName(typId);
                string emailStr = "<b>INVENTORY REQUEST, LOCATION: " + locationName +
                    ", INVENTORY TYPE: " + invTypeName + "</b><br>Request of issuance of spare part pending " +
                    " <table border='0' cellpadding='2' cellspacing='2'>" +
                    "<tr><th colspan='5'>REQUEST REMARKS: </th></tr><tr><td colspan='5'>" + rmk + "</td></tr> " +
                    " <tr><th>S/N </th><th>CARD NUMBER </th><th>PART NUMBER </th><th>PART NAME </th><th>QTY/UNITS </th> </tr>";
                int k = 0;
                DataTable partsTBL = Inventory.getRequestItems(reqId); string errorMsg = "";
                foreach (DataRow ir in partsTBL.Rows)
                {
                    k++;/*string sql = "SELECT i.*, i.Qty AS iQty, i.DofQ AS iDofQ, g.* FROM invReqItem i, invLedger g " + 
            " WHERE i.reqId = @reqId AND g.Id = i.itemId "; */
                    emailStr += "<tr><td>" + k.ToString() + ".</td><td>" + ir["CardNo"].ToString() + "</td><td>"
                        + ir["PartNo"].ToString() + "</td><td>" + ir["Name"].ToString() + "</td> <td>"
                        + ir["iQty"].ToString() + " " + ir["iDofQ"].ToString() + " </td></tr>";
                    errorMsg += Inventory.error; Inventory.error = "";
                }
                    emailStr += "<tr><td colspan='5'><hr /></td></tr> ";
                    if (dr["ReqOutStock"].ToString().Length > 0)
                        emailStr += "<tr><th colspan='5'>OUT OF STOCK PARTS: </th></tr><tr><td colspan='5'>" +
                            dr["ReqOutStock"].ToString() + "</td></tr>"; 
                    emailStr += " </table>";
                    emailStr += "<b>REQUEST BY: </b>" + dr["EcoIDNo"].ToString() + "<br />" +
                                "<b>REQUEST DATE: </b>" + DateTime.Parse(dr["EcoRegDt"].ToString()).ToString("MMM dd, yyyy hh:mm tt");

                    //------------- GETTING EMAILS & PHONE NUMBERS TO SEND ALERT -------------------------
                    DataTable phoneEmailTBL = Role.getApprovalPhoneEmails(locId, Role.modInventory);
                    if (phoneEmailTBL.Rows.Count < 1) phoneEmailTBL = Role.getApprovalPhoneEmails(0, Role.modInventory);

                    string emailNos = "", phoneNos = "", emailPhoneStr = "";
                    foreach (DataRow _dr in phoneEmailTBL.Rows)
                    {
                        string email = "", phone = "";
                        try { email = _dr["Email"].ToString().Trim(); } catch { } 
                        try { phone = _dr["Phone"].ToString().Trim(); } catch { }
                        if (email.Length > 4) emailNos += email + ",";      if (phone.Length > 7) phoneNos += phone + ",";
                    }
                    if (emailNos.Length > 4)
                    {
                        try { Mailer.sendEmail(emailNos, "INVENTORY ISSUANCE REQUEST", emailStr); } catch { }
                        if (Mailer.IsEmailSent) emailPhoneStr = "<font color='green'>Successfully Sent Notification by Email</font>";
                        else emailPhoneStr = "<font color='red'>Unable to Send Notification by Email</font>";
                    }
                    else
                        emailPhoneStr = "<font color='red'>No Email, Unable to Send Notification by Email</font>";
                    if (phoneNos.Length > 7)
                    {
                        try { Mailer.sendSMS("NAF.ISU.REQ", phoneNos, "Request of issuance of spare part pending. location: " + 
                            locationName); }
                        catch { }
                        if (Mailer.IsSmsSent) emailPhoneStr += "<br><font color='green'>Successfully Sent Notification by SMS</font>";
                        else emailPhoneStr += "<br><font color='red'>Unable to Send Notification by SMS</font>";
                    }
                    else
                        emailPhoneStr += "<br><font color='red'>No Phone Number, Unable to Send Notification by SMS</font>";


                    return "<div><font color='green'>Successfully Approved, Sent Request to Inventory Control...</font></div>" +
                        emailPhoneStr + errorMsg;
            }
            else return "<font color='red'>Unable to Approve Request</font>";
        }
                
        [WebMethod(EnableSession = true)]
        public string deleteECOreq(string id)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;
            long reqId = 0L; try { reqId = long.Parse(id.Trim()); } catch { }
            if (reqId <= 0L) return "<font color='red'>Unknown Request Parts</font>";
            bool isUpd = Inventory.deleteRequest(reqId);
            if (isUpd) return "<font color='green'>Successfully Deleted Request</font>";
            else return "<font color='red'>Unable to Delete Request</font>";
        }

        //--------------- INVENTORY REQUIRED ITEMS ----------        
        [WebMethod(EnableSession = true)]
        public string getInvReqItems(string id)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;         long reqId = 0L; try { reqId = long.Parse(id.Trim()); } catch { }
            if (reqId <= 0L) return "<font color='red'>Unknown Request Parts</font>";

            /*getRequestItems(long reqId)  string sql = "SELECT i.*, i.Qty AS iQty, i.DofQ AS iDofQ, g.* FROM invReqItem i, invLedger g " + 
                public static DataTable getRequest(long reqId) AS Location,  InvTypeName   } */
            DataTable reqTBL = Inventory.getRequest(reqId); string tbl = "";
            if (reqTBL.Rows.Count > 0)
            {
                DataRow rw = reqTBL.Rows[0];
                tbl = "<div style='padding:10px; padding-top:0px;' class='widget'> " +
                    "&nbsp;<span class='wp-caption'>&nbsp;<b>REQUEST INFO.: </b>&nbsp;</span><br />  " +
                    " <b>LOCATION:</b> " + rw["Location"].ToString() + "<br><b>INVENTORY:</b> " +
                    rw["InvTypeName"].ToString() + " <br> <b>REQUEST REMARKS: </b><br> " + rw["EcoRMK"].ToString() +
                    "<table class='tbls' style='font-size:11px;'><tr><th></th><th>CARD No.</th><th>PART NAME</th><th>QTY</th></tr>";
                DataTable itemTBL = Inventory.getRequestItems(reqId); int k = 0;
                foreach (DataRow dr in itemTBL.Rows)
                {
                    k++;
                    tbl += "<tr><td>" + k.ToString() + ". </td> <td><a href='javascript:setCardNoInTxtBox(\"" + dr["CardNo"].ToString() +
                        "\",\"" + dr["iQty"].ToString() + "\");'>" + dr["CardNo"].ToString() + "</td><td>" + dr["Name"].ToString() +
                        "</td><td title=\"Units: " + dr["iDofQ"].ToString() + "\">" + dr["iQty"].ToString() + " </td></tr>";
                }
                if (rw["ReqOutStock"].ToString().Trim().Length > 2)
                    tbl += "<tr><td colspan='4'> <b>TCI/OUT OF STOCK INFO:</b> <hr />" + rw["ReqOutStock"].ToString() + "</td></tr>";
                tbl += "</table><b>REQUEST BY: </b> " + rw["EcoIDNo"].ToString() + "<br> <b>REQ. DATE: </b>" +
                    DateTime.Parse(rw["EcoRegDt"].ToString()).ToString("MMM dd, yyyy. hh:mm tt") +
                    " <input type='hidden' id='hidReqECO' value=\"" + rw["EcoIDNo"].ToString() + "\" /> </div>";                
            }
            return tbl;
        }

        //======================= INVENTORY REPORT ===========================
        //====================================================================
                
        [WebMethod(EnableSession = true)]
        public string getLedgerSumry()
        {

            string tbl = "<div class='tblHead' style='width:800px;align:center;'> LEDGER SUMMARY OF ALL LOCATIONS </div>" +
                   "<table  style='font-size:12px; font-weight:100px;' cellpadding='0' cellspacing='0' border='0' class='display' " +
                   " id='ledgerTBL'> <thead> <tr align='center'> <th>LOCATION</th><th>INVENTORY TYPE</th><th>EXPIRY ITEMS</th> " +
                   "  <th>RE-ORDER ITEMS</th> <th>CRITICAL ITEMS</th> </tr></thead>  <tfoot> <tr align='center'> <th>LOCATION</th> " +
                   " <th>INVENTORY TYPE</th><th>EXPIRY ITEMS</th> <th>RE-ORDER ITEMS</th> <th>CRITICAL ITEMS</th> </tr></tfoot> <tbody>";

            DataTable locTBL = AppSet.getLocation(); 
            foreach (DataRow lrw in locTBL.Rows)
            {
                int locId = 0; try { locId = int.Parse(lrw["Id"].ToString()); } catch { }
                if (locId > 0)
                {
                    string locName = AppSet.getLocationName(locId);
                    DataTable invTBL = Inventory.getLedgerDueReordeCritExpiryTBL(locId);  
                    foreach (DataRow dr in invTBL.Rows)
                    {
            string nExp = (dr["nExpiry"].ToString() == "0" || dr["nExpiry"].ToString() == "") ? "" : dr["nExpiry"].ToString();
            string nReorder = (dr["nReorder"].ToString() == "0" || dr["nReorder"].ToString() == "") ? "" : dr["nReorder"].ToString();
            string nCritical = (dr["nCritical"].ToString() == "0" || dr["nCritical"].ToString() == "") ? "" : dr["nCritical"].ToString();
                        if (nExp.Length > 0 || nReorder.Length > 0 || nCritical.Length > 0)
                            tbl += "<tr align='center'><td align='left'>" + locName + "</td><td align='left'>" + dr["Name"].ToString() +
                                " </td><td><b>" + nExp + "</b></td><td><b>" + nReorder + "</b></td><td><b>" + nCritical + "</b></td> </tr>";
                    }
                }                 
            } 
            tbl += "</tbody></table>";   Session["invGrid"] = "LedgerRptSumry"; Session["invGridData"] = tbl;  return tbl;
        }
        
        [WebMethod(EnableSession = true)]
        public string getLedger(string loc, string typ, string stat)
        {
            if (!UserSession.IsActive) return timeoutMsg;            
            /* <option value="1">Ledger Parts</option><option value="2">Critical Parts</option>
    <option value="3">Re-order Parts</option> <option value="4">Expiration</option> <option value="5">Search</option>  */
            DataTable TBL = new DataTable();            int locId = 0; try { locId = int.Parse(loc.Trim()); } catch { }
            string locName = "", invTypeName = ""; 
            if (locId > 0) locName = AppSet.getLocationName(locId);
            int typId = 0, statId = 0; 
            try { typId = int.Parse(typ.Trim()); }catch { } try { statId = int.Parse(stat.Trim()); } catch { }
            invTypeName = Inventory.getTypeName(typId);
            string headTxt = "";
            if (statId == 1) //current ledger parts
            {
                headTxt = "CURRENT LEDGER PARTS OF LOCATION: " + locName + ", INVENTORY TYPE: " + invTypeName;
                TBL = Inventory.getLedgerTBL(locId, typId);
            }
            else if (statId == 2) //critical parts
            {
                headTxt = "CRITICAL LEDGER PARTS OF LOCATION: " + locName + ", INVENTORY TYPE: " + invTypeName;                
                TBL = Inventory.getLedgerCritReorderTBL(locId, typId, true); 
            }
            else if (statId == 3) //Re-order Parts
            {
                headTxt = "RE-ORDER LEDGER PARTS OF LOCATION: " + locName + ", INVENTORY TYPE: " + invTypeName;
                TBL = Inventory.getLedgerCritReorderTBL(locId, typId, false); 
            }
            else if (statId == 4) //Expiration parts
            {
                headTxt = "EXPIR(ED/ING) LEDGER PARTS OF LOCATION: " + locName + ", INVENTORY TYPE: " + invTypeName;
                TBL = Inventory.getLedgerDueExpiryTBL(locId, typId);
            }
            
            Inventory.getLedgerChartValus(TBL);
            Session["sesBarValus"] = Inventory.BarChartValus;            Session["sesPieValus"] = Inventory.PieChartValus;

            Session["invGrid"] = "LedgerRpt"; Session["invGridData"] = TBL;
            Session["invGridFileName"] = "ledger_report_" + DateTime.Now.ToString("MMM_dd_yyyy(hh_mm_tt)");
            return bindPartsTBL(headTxt, TBL);
        }
        private string bindPartsTBL(string headerTxt, DataTable TBL)
        {
            StringBuilder tbl = new StringBuilder();
            tbl.Append("<div class='tblHead' style='width:800px;align:center;'> " + headerTxt + " </div>" +
                    "<table  style='font-size:11px; font-weight:100px;' cellpadding='0' cellspacing='0' border='0' " +
                    " class='display' id='ledgerTBL'> <thead> <th>DEPT</th><th>RACK</th> " +
                    " <th>CARD No.</th> <th>PART No.</th>  <th>PART NAME</th> <th>SERIAL</th> " +
                    " <th>QTY</th> <th>DofQ</th><th>MFG. DATE</th> <th>EXP. DATE</th> </tr></thead> " +
                    " <tfoot>	<tr> <th>DEPT</th><th>RACK</th><th>CARD No.</th> <th>PART No.</th>  " +
         " <th>PART NAME</th> <th>SERIAL</th> <th>QTY</th> <th>UNITS</th><th>MFG. DATE</th> <th>EXP. DATE</th> " +
                     "   </tr></tfoot> <tbody>");

            //string active_on = "<img src='../images/active_on.gif' alt='Lock' width='20px' height='20px' />";
            //string active_off = "<img src='../images/active_off.gif' alt='Lock' width='20px' height='20px' />";
            int qty = 0, critQty = 0, reorderQty = 0;
            foreach (DataRow dr in TBL.Rows)
            {
                bool isMfg = false; try { isMfg = bool.Parse(dr["IsMfg"].ToString()); } catch { }
                bool isExp = false; try { isExp = bool.Parse(dr["IsExp"].ToString()); } catch { }
                string MfgDt = "", ExpDt = ""; DateTime expDt = DateTime.Now;
                if (isMfg)  try { MfgDt = DateTime.Parse(dr["MfgDt"].ToString()).ToString("MMM dd, yyyy"); }catch { }
                if (isExp)  try { ExpDt = DateTime.Parse(dr["ExpDt"].ToString()).ToString("MMM dd, yyyy");
                                    expDt = DateTime.Parse(dr["ExpDt"].ToString());   } catch { }
                string color = "black";
                try
                {
                    qty = int.Parse(dr["Qty"].ToString()); reorderQty = int.Parse(dr["orderQty"].ToString());
                    critQty = int.Parse(dr["critQty"].ToString());
                    //if (reorderQty >= qty) color = "orange"; if (critQty >= qty) color = "red";
                    if (qty <= critQty && critQty > 0) color = "amber"; 
                    else if (qty <= reorderQty && reorderQty > 0) color = "orange"; else color = "green";
                    if (isExp && expDt < DateTime.Now.AddMonths(1)) color = "red";
                }
                catch { }

                
                tbl.Append("<tr><td>" + dr["Dept"].ToString() + " </td><td>" +
                    dr["RackNo"].ToString() + " </td><td>" + dr["CardNo"].ToString() + " </td><td>" + dr["PartNo"].ToString() +
                    " </td><td>" + dr["Name"].ToString() + " </td><td>" + dr["SerialNo"].ToString() +
                    " </td><td align='center'><b><font color='" + color + "'>" + qty + "</font></b> </td><td><font color='" +
                    color + "'>" + dr["DofQ"].ToString() + "</font></td><td>" + MfgDt + " </td><td>" + ExpDt + "</td> </tr>");
                /* <td><a href='javascript:alert(\"Under Construction\");' title='Click to View Details'> " +
                    " <img src='../images/arrow_right_16.png' alt='details' /> </a> </td> */
            }
            tbl.Append("<tbody></table><a target='_blank' href='chart.aspx'>chart </a> ");
            return tbl.ToString();
        }
                
        [WebMethod(EnableSession = true)]
        public string searchLegders(string typ, string valu)
        {
            if (!UserSession.IsActive) return timeoutMsg;
            int typId = 0; try { typId = int.Parse(typ.Trim()); }  catch { }
            if (typId < 1) return "<font color='red'>Please Select the Inventory Type... </font>";
            
            DataTable TBL = Inventory.searchLedgerTBL(typId, valu);             Session["GridSrchLedgers"] = TBL;

            string invName = Inventory.getTypeName(typId);

            StringBuilder tbl = new StringBuilder();
            tbl.Append("<div class='tblHead' style='width:800px;align:center;'>INVENTORY: " + invName + ". &nbsp;&nbsp;&nbsp; SEARCH: " + 
                valu + " </div>" +
                    "<table  style='font-size:11px; font-weight:100px;' cellpadding='0' cellspacing='0' border='0' " +
                    " class='display' id='ledgersTBL'> <thead> <th>LOCATION</th> <th>DEPT</th><th>RACK</th> " +
                    " <th>CARD No.</th> <th>PART No.</th>  <th>PART NAME</th> <th>SERIAL</th> " +
                    " <th>QTY/DofQ</th><th>MFG. DATE</th> <th>EXP. DATE</th> </tr></thead> " +
                    " <tfoot>	<tr> <th>DEPT</th><th>RACK</th><th>CARD No.</th> <th>PART No.</th>  " +
                    " <th>PART NAME</th> <th>SERIAL</th> <th>QTY/DofQ</th><th>MFG. DATE</th> <th>EXP. DATE</th> </tr></tfoot> <tbody>");
            int qty = 0, critQty = 0, reorderQty = 0;
            foreach (DataRow dr in TBL.Rows)
            {
                bool isMfg = false; try { isMfg = bool.Parse(dr["IsMfg"].ToString()); } catch { }
                bool isExp = false; try { isExp = bool.Parse(dr["IsExp"].ToString()); } catch { }
                string MfgDt = "", ExpDt = ""; DateTime expDt = DateTime.Now;
                if (isMfg) try { MfgDt = DateTime.Parse(dr["MfgDt"].ToString()).ToString("MMM dd, yyyy"); } catch { }
                if (isExp) try { ExpDt = DateTime.Parse(dr["ExpDt"].ToString()).ToString("MMM dd, yyyy"); 
                                    expDt = DateTime.Parse(dr["ExpDt"].ToString());   } catch { }
                string color = "black";
                try
                {
                    qty = int.Parse(dr["Qty"].ToString()); reorderQty = int.Parse(dr["orderQty"].ToString());
                    critQty = int.Parse(dr["critQty"].ToString());
                    //if (reorderQty >= qty) color = "orange"; if (critQty >= qty) color = "red";
                    if (qty <= critQty && critQty > 0) color = "amber"; 
                    else if (qty <= reorderQty && reorderQty > 0) color = "orange"; else color = "green";
                    if(isExp && expDt < DateTime.Now.AddMonths(1)) color = "red";
                }
                catch { }
                
                tbl.Append("<tr><td>" + dr["Location"].ToString() + " </td><td>" + dr["Dept"].ToString() + " </td><td>" +
                    dr["RackNo"].ToString() + " </td><td>" + dr["CardNo"].ToString() + " </td><td>" + dr["PartNo"].ToString() +
                    " </td><td>" + dr["Name"].ToString() + " </td><td>" + dr["SerialNo"].ToString() +
                    " </td><td align='center'><b><font color='" + color + "'>" + qty + "</font></b> <font color='" +
                    color + "'>" + dr["DofQ"].ToString() + "</font></td><td>" + MfgDt + " </td><td>" + ExpDt + "</td> </tr>");
            }
            tbl.Append("<tbody></table>"); return tbl.ToString();
        }
              
        [WebMethod(EnableSession = true)]
        public string getSupplyIssueHist(string loc, string typ, string stat, string fDt, string tDt)
        {
            if (!UserSession.IsActive) return timeoutMsg;

            int locId = 0, typId = 0, statId = 0;            DateTime fromDate = DateTime.Now; DateTime toDate = DateTime.Now;
            try { locId = int.Parse(loc.Trim()); typId = int.Parse(typ.Trim()); statId = int.Parse(stat.Trim()); } catch { }
            try { fromDate = DateTime.Parse(fDt.Trim()); } catch { }     try { toDate = DateTime.Parse(tDt.Trim()); } catch { }
            string locTypeName = "LOCATION: " + AppSet.getLocationName(locId) + " &nbsp;&nbsp;&nbsp;INVENTORY TYPE: " +
                Inventory.getTypeName(typId);
            //1-Suply  2-Receive/Issue
            DataTable TBL = new DataTable();        string headTxt = "", returnTBL = "";
            if (statId == 1)
            {
                headTxt = " SUPPLY HISTORY FROM: " + fromDate.ToString("MMM dd, yyyy.") +
                    "&nbsp;&nbsp;TO: " + toDate.ToString("MMM dd, yyyy.") + "<br>" + locTypeName;                
                TBL = Inventory.getSupplyHistoryTBL(locId, typId, fromDate, toDate); 
                returnTBL = this.bindSupplyHistTBL(headTxt, TBL);   Session["invGrid"] = "SupplyRpt";   Session["invGridData"] = TBL;
                Session["invGridFileName"] = "supply_hist_from" + fromDate.ToString("MMM_dd_yyyy") + "_to" + toDate.ToString("MMM_dd_yyyy");
            }
            else if (statId == 2)
            {
                headTxt = " ISSUE HISTORY FROM: " + fromDate.ToString("MMM dd, yyyy.") +
                    "&nbsp;&nbsp;TO: " + toDate.ToString("MMM dd, yyyy.") + "<br>" + locTypeName;                 
                TBL = Inventory.getIssueHistoryTBL(locId, typId, fromDate, toDate);
                returnTBL = this.bindIssueHistTBL(headTxt, TBL);
                Session["invGrid"] = "IssueRpt"; Session["invGridData"] = TBL;
                Session["invGridFileName"] = "issue_hist_from" + fromDate.ToString("MMM_dd_yyyy") + "_to" + toDate.ToString("MMM_dd_yyyy");
            }
            return returnTBL;
        }

        [WebMethod(EnableSession = true)]
        private string bindSupplyHistTBL(string headerTxt, DataTable TBL)
        {            
            StringBuilder tbl = new StringBuilder();
            tbl.Append("<div class='tblHead' style='width:800px;align:center;'> " + headerTxt + " </div>" +
                    "<table  style='font-size:11px; font-weight:100px;' cellpadding='0' cellspacing='0' border='0' " +
                    " class='display' id='invRptTBL'> <thead> <tr align='left'> <th>DEPARTMENT</th><th>RACK</th> " +
                    " <th>CARD No.</th> <th>PART No.</th>  <th>PART NAME</th> <th align='center'>QTY/DofQ</th>  " +
                    "  <th>EXP. DATE</th>  <th>SUPPLIER</th>  <th> </th></tr></thead>" +
                    " <tfoot>	<tr align='left'> <th>DEPARTMENT</th><th>RACK</th> <th>CARD No.</th> <th>PART No.</th> " +
                    " <th>PART NAME</th> <th align='center'>QTY/DofQ</th> <th>EXP. DATE</th>  <th>SUPPLIER</th> " +
                    " <th> </th>   </tr></tfoot> <tbody>");
            string del_img = "<img src='../images/delete.gif' alt='delete' title='Click to delete Supply from Ledger' />";
            /* sql = "SELECT s.*, " +
            " (SELECT l.Name FROM location l WHERE l.Id = s.locId) AS Location, " +
            " (SELECT d.Name FROM invDept d WHERE d.Id = s.deptId) AS Dept, " +
            " (SELECT v.Name FROM invVendor v WHERE v.RefNo = s.vendorID) AS VendorName " +            
            " FROM invSupHist s WHERE s.typId = @typ AND " + where +
            " cast(CONVERT(varchar(8), s.RegDate, 112) AS datetime) >= @fromDt AND " +
            " cast(CONVERT(varchar(8), s.RegDate, 112) AS datetime) <= @toDt ORDER BY s.deptId, s.CardNo ";*/
            foreach (DataRow dr in TBL.Rows)
            {
                bool isMfg = false; try { isMfg = bool.Parse(dr["IsMfg"].ToString()); } catch { }
                bool isExp = false; try { isExp = bool.Parse(dr["IsExp"].ToString()); } catch { }
                string MfgDt = "", ExpDt = "";
                if (isMfg) try { MfgDt = "Manuf. Date: " + DateTime.Parse(dr["MfgDt"].ToString()).ToString("MMM dd,yyyy"); } catch { }
                if (isExp) try { ExpDt = DateTime.Parse(dr["ExpDt"].ToString()).ToString("MMM dd,yyyy"); } catch { }               
                tbl.Append("<tr><td>" + dr["Dept"].ToString() + ". </td><td>" + dr["RackNo"].ToString() +
                    " </td> <td>" + dr["CardNo"].ToString() + " </td><td title=\"SERIAL No.: " + dr["SerialNo"].ToString() + "\">" +
                    dr["PartNo"].ToString() + " </td><td> " + dr["Name"].ToString() + "</td><td align='center'>" + dr["Qty"].ToString() +
                    " " + dr["DofQ"].ToString() + " </td> <td title=\"" + MfgDt + "\">" + ExpDt + " </td> <td> " +
                    dr["VendorName"].ToString() + " - " + dr["vendorID"].ToString() + " </td> " +
                    " <td style='width:40px;'> <a href='javascript: showSupplyInfo(\"" + dr["Id"].ToString() +
                    "\");' title='Click to View Details'> <img src='../images/arrow_right_16.png' alt='details' /></a> " +
                    " <a href='javascript: alert(\"Under Construction\");'>" + del_img + "</a> </td> </tr>");
            }
            tbl.Append("<tbody></table> ");     return tbl.ToString();
        }

        [WebMethod(EnableSession = true)]
        private string bindIssueHistTBL(string headerTxt, DataTable TBL)
        {
            if (!UserSession.IsActive) return timeoutMsg;

            StringBuilder tbl = new StringBuilder();
            tbl.Append("<div class='tblHead' style='width:800px;align:center;'> " + headerTxt + " </div>" +
                    "<table  style='font-size:11px; font-weight:100px;' cellpadding='0' cellspacing='0' border='0' " +
                    " class='display' id='invRptTBL'> <thead> <tr align='left'> <th>REQUEST </th> <th>INVOICE No.</th> " +
                    "  <th align='center'>ITEMS</th> <th> RECEIVER </th> <th> REMARKS </th> <th>REGISTERED BY</th> " +
                    " <th>REG. DATE</th> <th> </th>   </tr></thead><tfoot> " +
                    " <tr align='left'> <th>REQUEST </th> <th>INVOICE No.</th> " +
                    "  <th align='center'>ITEMS</th> <th> RECEIVER </th> <th> REMARKS </th> <th>REGISTERED BY</th> " +
                    " <th>REG. DATE</th>  <th style='width:30px;'> </th>   </tr></tfoot> <tbody>");
            
            foreach (DataRow dr in TBL.Rows)
            {               
                string req = dr["reqId"].ToString().Trim();       if (req == "0" || req == "") req = "YES"; else req = "NO";

                tbl.Append("<tr><td>" + req + "</td><td>" + dr["InvNo"].ToString() +
                    " </td><td>" + dr["nItems"].ToString() + " </td><td>" + dr["ReceiverIDNo"].ToString() + " </td><td>" +
                    dr["RMK"].ToString() + " </td> <td> " + dr["RegIDNo"].ToString() + " </td><td>" +
                    DateTime.Parse(dr["RegDate"].ToString()).ToString("MMMdd,yyyy hh:mm tt") + "</td>" +
                    " <td> <a href='javascript:showInvoiceInfo(\"" + dr["Id"].ToString() + "\");' title='Click to View Invoice Details'> " +
                " <img src='../images/arrow_right_16.png' alt='details' /></a>  </td> </tr>");
            }
            tbl.Append("<tbody></table> "); return tbl.ToString();
        }

        [WebMethod(EnableSession = true)]
        public string getSupplyHistInfo(string Id)
        {
            if (!UserSession.IsActive) return timeoutMsg;
            long supplyId = 0L; try { supplyId = long.Parse(Id); } catch { }
            DataTable TBL = Inventory.getSupplyHistTBL(supplyId);
            
            if (TBL.Rows.Count > 0)
            {
                DataRow dr = TBL.Rows[0];
                bool isMfg = false; try { isMfg = bool.Parse(dr["IsMfg"].ToString()); } catch { }
                bool isExp = false; try { isExp = bool.Parse(dr["IsExp"].ToString()); } catch { }
                string MfgDt = "", ExpDt = "";
                if (isMfg) try { MfgDt = DateTime.Parse(dr["MfgDt"].ToString()).ToString("MMM dd, yyyy"); } catch { }
                if (isExp) try { ExpDt = DateTime.Parse(dr["ExpDt"].ToString()).ToString("MMM dd, yyyy"); } catch { }

                string tbl = " <div style='padding:10px; padding-top:0px;width:400px;' class='widget'> " +
                    "&nbsp;<span class='wp-caption'>&nbsp;<b>PART INFO: " + dr["Name"].ToString() + "</b>&nbsp;</span><br><br> " +
                    "&nbsp;&nbsp; <input type='button' value='clear' onclick=\"$('#divSupplyInfo').html('');\" /><br>" +
                   " <table border='0' cellpadding='2' cellspacing='2' style='width:390px;' class='tbls'> " +
                    "<tr><th style='width:150px;'>LOCATION: </th> <td>" + dr["Location"].ToString() + " </td> </tr>" +
                    "<tr><th>DEPARTMENT:</th> <td>" + dr["Dept"].ToString() + " </td> </tr>" +
                    "<tr><th>RACK No.</th> <td>" + dr["RackNo"].ToString() + " </td> </tr>" +
                    "<tr><th>CARD No.</th> <td> " + dr["CardNo"].ToString() + "  </td> </tr>" +
                    "<tr><th>PART No.</th> <td> " + dr["PartNo"].ToString() + " </td> </tr>" +
                    "<tr><th>SERIAL No.</th> <td> " + dr["SerialNo"].ToString() + " </td> </tr>" +
                    "<tr><th>PART NAME:</th> <td> " + dr["Name"].ToString() + "  </td> </tr>" +
                    "<tr><th>QTY/DofQ</th> <td> " + dr["Qty"].ToString() + " " + dr["DofQ"].ToString() + " </td> </tr>" +
                    "<tr><th>MFG. DATE:</th> <td>" + MfgDt + " </td> </tr>" +
                    "<tr><th>EXP. DATE:</th> <td>" + ExpDt + " </td> </tr>" +
                    "<tr><th>SUPPLIER: </th> <td>" + dr["VendorName"].ToString() + " - " + dr["vendorID"].ToString() + "</td> </tr>" +
                    "<tr valign='top'><th>OTHER Info: </th> <td>" + dr["RMK"].ToString() + " </td> </tr>" +
                    "<tr><th>REG. BY: </th> <td>" + dr["RegIDNo"].ToString() + " </td> </tr>" +
                    "<tr><th>REG. DATE: </th> <td>" + DateTime.Parse(dr["RegDate"].ToString()).ToString("MMM dd, yyyy hh:mm tt") +
                    " </td> </tr>  </table> </div>";
                return tbl;
            }
            else
            {
                return "<font color='red'>Unknown Record...</font>";
            }
        }

        [WebMethod(EnableSession = true)]
        public string getInvReceipt(string id)
        {
            // jd = '{ "id":"' + id + '" }'; sync2('getInvReceipt', jd, 'divSupplyInfo', jsPg); 
            if (!UserSession.IsActive) return timeoutMsg;
            long salesId = 0L; try { salesId = int.Parse(id.Trim()); } catch { }
            DataTable TBL = Inventory.getInvoiceItemTBL(salesId);

            if (TBL.Rows.Count < 1) return "<font color='red'>no record....</font>";
            
            string _tbl = " <div style='padding:10px; padding-top:0px;' class='widget'> " +
                    "&nbsp;<span class='wp-caption'>&nbsp;<b>INVOICE: " + TBL.Rows[0]["InvNo"].ToString() + "</b>&nbsp;</span><br><br> " +
                    "&nbsp;&nbsp; <input type='button' value='clear' onclick=\"$('#divSupplyInfo').html('');\" /><br>" + 
                    "<br>  <table border='0' cellpadding='2' cellspacing='2' class='tbls'> " +
                "<tr><th>S/N</th><th>DEPARTMENT</th><th>RACK</th><th>CARD No.</th><th> PART No.</th><th>PART NAME </th>  " +
                " <th>SERIAL</th><th> QTY/DofQ</th><th> MFG. DATE </th><th> EXP. DATE </th> </tr>"; int n = 0;
            foreach (DataRow dr in TBL.Rows)
            {
                n++;
                bool isMfg = false; try { isMfg = bool.Parse(dr["IsMfg"].ToString()); } catch { }
                bool isExp = false; try { isExp = bool.Parse(dr["IsExp"].ToString()); } catch { }
                string MfgDt = "", ExpDt = "";
                if (isMfg) try { MfgDt = DateTime.Parse(dr["MfgDt"].ToString()).ToString("MMM dd, yyyy"); } catch { }
                if (isExp) try { ExpDt = DateTime.Parse(dr["ExpDt"].ToString()).ToString("MMM dd, yyyy"); } catch { }

                _tbl += "<tr><td>" + n.ToString() + ". </td><td>" + dr["Dept"].ToString() + "</td><td>" + dr["RackNo"].ToString() +
                    " </td><td>" + dr["CardNo"].ToString() + "</td><td> " + dr["PartNo"].ToString() + " </td> " +
                    " <td> " + dr["Name"].ToString() + " </td> <td> " + dr["SerialNo"].ToString() + " </td> " +
                    " <td> " + dr["Qty"].ToString() + " " + dr["DofQ"].ToString() + "</td> " +
                    " <td> " + MfgDt + " </td><td> " + ExpDt + "</td> </tr>";
            }
            _tbl += "</table>"; return _tbl;
        }


    }


    class InvParts
    {
        public long Id { get; set; }
        public string Dept { get; set; }       public string CardNo { get; set; }
        public string PartNo { get; set; }     public string Name { get; set; }      public string RackNo { get; set; }

        public decimal CostPrice { get; set; } public decimal UnitPrice { get; set; }
        
        public int Qty { get; set; }          public string DofQ { get; set; }
        public bool IsMfg { get; set; }        public DateTime MfgDate { get; set; }
        public bool IsExp { get; set; }        public DateTime ExpDate { get; set; }

        public int DeptId { get; set; }        public string SerialNo { get; set; }


        public InvParts(long id, int deptId, string dept, string card, string part, string name, string serial, string rack,
            decimal costPrice, decimal unitPrice, int qty, string dOfQ, bool isMfg, DateTime mfgDt, bool isExp, DateTime expDt)
        {
            Id = id;        Dept = dept;        CardNo = card;      PartNo = part;      Name = name;
            RackNo = rack;  Qty = qty;          DofQ = dOfQ;
            CostPrice = costPrice;              UnitPrice = unitPrice;
            IsMfg = isMfg;  MfgDate = mfgDt;    IsExp = isExp;      ExpDate = expDt;
            DeptId = deptId;                    SerialNo = serial;
        }

        public static decimal grandCostAMT { get; set; }

    } 

}
