﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web; 

using System.IO;
using System.Net;
using System.Text;
using System.Net.Mail; 
using System.Data;

public class Mailer
{
    
    private static string _SmsURL = "http://www.smslive247.com/http/index.aspx";

    private string _error, _smtpServer, _smtpEmail, _smtpPWD, _smtpEmailDisplay, _smsTitle, _smsSesID;
    private int _smtpPort;
    private bool getEmailSMSsettings()
    {
        _error = ""; _smtpServer = ""; _smtpEmail = ""; _smtpPWD = "";
        _smtpEmailDisplay = ""; _smsTitle = ""; _smsSesID = "";

        Users obj = new Users(); DataTable tbl = new DataTable(); tbl = obj.getEmailSmsTBL();
        if (tbl.Rows.Count < 1) { _error = "<font color='red'>please configure your Email/SMS settings</font>"; return false; }

        DataRow dr = tbl.Rows[0];
        try { _smsTitle = dr["SmsTitle"].ToString().Trim(); _smsSesID = dr["SmsSesID"].ToString().Trim(); } catch { }

        try {    _smtpServer = dr["SmtpServer"].ToString().Trim();
                 _smtpEmail = dr["SmtpEmail"].ToString().Trim();
                 _smtpPWD = dr["SmtpPWD"].ToString().Trim();
                 _smtpEmailDisplay = dr["SmtpDisplay"].ToString().Trim();
        } catch { }
        try { _smtpPort = int.Parse(dr["SmtpPort"].ToString()); } catch { }     return true;
    }

    public static bool isSmsValid(string sesID)
    {
        string phone = "+2347030378600";
        string msg = "NAF+Aircraft+Management+Solution+Testing";
        string sender = "NAF.ALERT";
        System.Net.ServicePointManager.Expect100Continue = false;      string url = _SmsURL;
        HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
        string proxy = null;
        string sendSMSparams = String.Format("cmd={0}&sessionid={1}&message={2}&sender={3}&sendto={4}&msgtype={5}",
            "sendmsg", sesID, msg, sender, phone, 0); //"c0578c91-09bb-46d0-921e-520f34b0207d"
        sendSMSparams = sendSMSparams.Replace(' ', '+');
        try
        {
            byte[] buffer = Encoding.UTF8.GetBytes(sendSMSparams); req.Method = "POST";
            req.ContentType = "application/x-www-form-urlencoded"; req.ContentLength = buffer.Length;
            req.Proxy = new WebProxy(proxy, true);       // ignore for local addresses
            req.CookieContainer = new CookieContainer(); // enable cookies
            Stream reqst = req.GetRequestStream();          /* add form data to request stream */
            reqst.Write(buffer, 0, buffer.Length); reqst.Flush(); reqst.Close();
            HttpWebResponse res = (HttpWebResponse)req.GetResponse(); Stream resst = res.GetResponseStream();
            StreamReader sr = new StreamReader(resst); 
            string response = sr.ReadToEnd();  //    return response;
            return true;
        }
        catch { return false; }
    }

    public static bool IsSmsSent;
    public static string sendSMS(string _sender, string phones, string msg)
    {
        IsSmsSent = false;
         Mailer obj = new Mailer(); bool isValid = obj.getEmailSMSsettings();
         if (!isValid) return obj._error;
         string sender = obj._smsTitle; if (_sender.Length >= 3) sender = _sender;
        
        /* htp://www.smslive247.com/http/index.aspx?cmd=login&owneremail=keltangs@gmail.com&subacct=SCHOOLMGT&subacctpwd=SCHOOLMGT
         * OK: c0578c91-09bb-46d0-921e-520f34b0207d         */
        //SEND MSG: htp://www.smslive247.com/http/index.aspx?cmd=sendmsg&sessionid=xxx&message=xxx&sender=xxx&sendto=xxx&msgtype=0
        //htp://sms.bbnplace.com/bulksms/bulksms.php?username=$username&password=$password&sender=$sender&message=$text&mobile=$mobiles
        //string phones = "0802938494,+23370293839290,0802938494,070293839290,0802938494,070293839290,0802938494,070293839290";

        phones = phones.Trim(); phones = phones.Replace(" ", ""); phones = phones.Replace(",0", ",+234");
        string iszero = phones.Substring(0, 1);
        if (iszero == "0") phones = "+234" + phones.Substring(1, phones.Length - 1).Trim();

        System.Net.ServicePointManager.Expect100Continue = false;       string url = _SmsURL;
        HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
        string proxy = null; 
        string sendSMSparams = String.Format("cmd={0}&sessionid={1}&message={2}&sender={3}&sendto={4}&msgtype={5}",
            "sendmsg", obj._smsSesID, msg, sender, phones, 0); //"c0578c91-09bb-46d0-921e-520f34b0207d"
        sendSMSparams = sendSMSparams.Replace(' ', '+');
        try
        {
            byte[] buffer = Encoding.UTF8.GetBytes(sendSMSparams); req.Method = "POST";
            req.ContentType = "application/x-www-form-urlencoded"; req.ContentLength = buffer.Length;
            req.Proxy = new WebProxy(proxy, true);       // ignore for local addresses
            req.CookieContainer = new CookieContainer(); // enable cookies
            Stream reqst = req.GetRequestStream();          /* add form data to request stream */
            reqst.Write(buffer, 0, buffer.Length); reqst.Flush(); reqst.Close();
            HttpWebResponse res = (HttpWebResponse)req.GetResponse(); Stream resst = res.GetResponseStream();
            StreamReader sr = new StreamReader(resst); string response = sr.ReadToEnd();
            IsSmsSent = true;     return response;
        }
        catch { return "<font color='red'>SMS Not Successfully Sent...</font>"; }
    }

    public static string getSmsBalance()
    {
        Mailer obj = new Mailer(); bool isValid = obj.getEmailSMSsettings();
        if (!isValid) return obj._error;

        //ACCT BALANCE: htp://www.smslive247.com/http/index.aspx?cmd=querybalance&sessionid=xxx
        System.Net.ServicePointManager.Expect100Continue = false;    string url = _SmsURL;
        HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url); string proxy = null;
        try
        {
            string sendSMSparams = String.Format("cmd={0}&sessionid={1}", "querybalance", obj._smsSesID);
            byte[] buffer = Encoding.UTF8.GetBytes(sendSMSparams);
            req.Method = "POST"; req.ContentType = "application/x-www-form-urlencoded"; req.ContentLength = buffer.Length;
            req.Proxy = new WebProxy(proxy, true);       // ignore for local addresses
            req.CookieContainer = new CookieContainer(); // enable cookies
            Stream reqst = req.GetRequestStream(); // add form data to request stream
            reqst.Write(buffer, 0, buffer.Length); reqst.Flush(); reqst.Close();
            HttpWebResponse res = (HttpWebResponse)req.GetResponse();
            Stream resst = res.GetResponseStream(); StreamReader sr = new StreamReader(resst);
            string response = sr.ReadToEnd(); return response;
        }
        catch { return "<font color='red'>couldnot get balance...</font>"; }
    }

    //======================= EMAIL =================================
    //======================= EMAIL =================================
    //======================= EMAIL =================================
    public static bool IsEmailSent;
    public static string sendEmail(string emails, string subject, string body_html)
    {
        IsEmailSent = false;
        Mailer obj = new Mailer(); bool isValid = obj.getEmailSMSsettings();
        MailMessage mail = new MailMessage();
        if (emails.Contains(',')) {         foreach (string _email in emails.Split(','))  mail.To.Add(_email); 
        } else if (emails.Contains(';')) {  foreach (string _email in emails.Split(';'))  mail.To.Add(_email); 
        } else  mail.To.Add(emails);
        mail.Subject = subject;      mail.From = new MailAddress(obj._smtpEmail, obj._smtpEmailDisplay);
        mail.IsBodyHtml = true;      mail.Body = body_html;
        SmtpClient smtp;
        if (obj._smtpPort < 1) smtp = new SmtpClient(obj._smtpServer);
        else smtp = new SmtpClient(obj._smtpServer, obj._smtpPort);

        bool isSuccess = false; string error = "";
        try
        {
            smtp.UseDefaultCredentials = false; smtp.EnableSsl = true;
            smtp.Credentials = new NetworkCredential(obj._smtpEmail, obj._smtpPWD); smtp.Send(mail); isSuccess = true;
        }
        catch (Exception ex)
        {
            error = ex.Message;
            try
            {
                smtp.UseDefaultCredentials = false; smtp.EnableSsl = false;
                smtp.Credentials = new NetworkCredential(obj._smtpEmail, obj._smtpPWD); smtp.Send(mail); isSuccess = true;
            }
            catch (Exception ex1)
            {
                error = ex1.Message;
                try
                {
                    smtp.UseDefaultCredentials = true; smtp.EnableSsl = true;
                    smtp.Credentials = new NetworkCredential(obj._smtpEmail, obj._smtpPWD); smtp.Send(mail); isSuccess = true;
                }
                catch (Exception ex2)
                {
                    error = ex2.Message;
                    try
                    {
                        smtp.UseDefaultCredentials = true; smtp.EnableSsl = false;
                        smtp.Credentials = new NetworkCredential(obj._smtpEmail, obj._smtpPWD); smtp.Send(mail); isSuccess = true;
                    }
                    catch (Exception ex3)
                    {
                        error = ex3.Message;
                    }
                }
            }
        }
        IsEmailSent = (isSuccess) ? true : false;
        return (isSuccess)? "<font color='green'>Successfully Sent Email</font>" :
            "<font color='red'>Unable to send Email, caused by: " + error + " </font>";

    }

    public static string mailError = "";
    public static bool isEmailValid(string smtpServer, int smtpPort, string smtpEmail, string smtpPWD, string smtpDisplay){

         MailMessage mail = new MailMessage();       mail.To.Add(smtpEmail);
         mail.Subject = "NAF.ALERT"; mail.From = new MailAddress(smtpEmail, smtpDisplay);
        mail.IsBodyHtml = true;      mail.Body = "NAF Alert System, testing the email configuration...";
        SmtpClient smtp;       if (smtpPort < 1) smtp = new SmtpClient(smtpServer);
        else smtp = new SmtpClient(smtpServer, smtpPort);

        bool isSuccess = false; string error = "";
        try
        {
            smtp.UseDefaultCredentials = false; smtp.EnableSsl = true;
            smtp.Credentials = new NetworkCredential(smtpEmail, smtpPWD); smtp.Send(mail); isSuccess = true;
        }
        catch (Exception ex)
        {
            error = ex.Message;
            try
            {
                smtp.UseDefaultCredentials = false; smtp.EnableSsl = false;
                smtp.Credentials = new NetworkCredential(smtpEmail, smtpPWD); smtp.Send(mail); isSuccess = true;
            }
            catch (Exception ex1)
            {
                error = ex1.Message;
                try
                {
                    smtp.UseDefaultCredentials = true; smtp.EnableSsl = true;
                    smtp.Credentials = new NetworkCredential(smtpEmail, smtpPWD); smtp.Send(mail); isSuccess = true;
                }
                catch (Exception ex2)
                {
                    error = ex2.Message;
                    try
                    {
                        smtp.UseDefaultCredentials = true; smtp.EnableSsl = false;
                        smtp.Credentials = new NetworkCredential(smtpEmail, smtpPWD); smtp.Send(mail); isSuccess = true;
                    }
                    catch (Exception ex3)
                    {
                        error = ex3.Message;
                    }

                }

            }

        }
        mailError = error;    return isSuccess;

    }


   
}
