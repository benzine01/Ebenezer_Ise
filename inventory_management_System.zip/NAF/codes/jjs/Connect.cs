﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Configuration;
/// <summary>
/// Summary description for Connect
/// </summary>
public static class Connect
{ 
        
    public static string CONN()
    {
        string conn = ConfigurationManager.ConnectionStrings["DB_CONN"].ConnectionString; return conn;
    }

}