﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

 
using System.IO;
using System.Net;
using System.Text;
using System.Net.Mail;
using System.Configuration;

using System.Data.SqlClient;

public class SMS
{
    public static string SendSMS(string optional_Sender, string phones, string msg)
    {
        /* htp://www.smslive247.com/http/index.aspx?cmd=login&owneremail=keltangs@gmail.com&subacct=SCHOOLMGT&subacctpwd=SCHOOLMGT
         * OK: c0578c91-09bb-46d0-921e-520f34b0207d         */
        //SEND MSG: htp://www.smslive247.com/http/index.aspx?cmd=sendmsg&sessionid=xxx&message=xxx&sender=xxx&sendto=xxx&msgtype=0
        //htp://sms.bbnplace.com/bulksms/bulksms.php?username=$username&password=$password&sender=$sender&message=$text&mobile=$mobiles
        //string phones = "0802938494,+23370293839290,0802938494,070293839290,0802938494,070293839290,0802938494,070293839290";

        phones = phones.Trim(); phones = phones.Replace(" ", ""); phones = phones.Replace(",0", ",+234");
        string iszero = phones.Substring(0, 1);
        if (iszero == "0") phones = "+234" + phones.Substring(1, phones.Length - 1).Trim();

        System.Net.ServicePointManager.Expect100Continue = false;
        string url = "http://www.smslive247.com/http/index.aspx";
        HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
        string proxy = null;
        string sendSMSparams = String.Format("cmd={0}&sessionid={1}&message={2}&sender={3}&sendto={4}&msgtype={5}",
            "sendmsg", "c0578c91-09bb-46d0-921e-520f34b0207d", msg, optional_Sender, phones, 0);
        sendSMSparams = sendSMSparams.Replace(' ', '+');
        try
        {
            byte[] buffer = Encoding.UTF8.GetBytes(sendSMSparams); req.Method = "POST";
            req.ContentType = "application/x-www-form-urlencoded"; req.ContentLength = buffer.Length;
            req.Proxy = new WebProxy(proxy, true);       // ignore for local addresses
            req.CookieContainer = new CookieContainer(); // enable cookies
            Stream reqst = req.GetRequestStream();          /* add form data to request stream */
            reqst.Write(buffer, 0, buffer.Length); reqst.Flush(); reqst.Close();
            HttpWebResponse res = (HttpWebResponse)req.GetResponse(); Stream resst = res.GetResponseStream();
            StreamReader sr = new StreamReader(resst); string response = sr.ReadToEnd();
            return response;
        }
        catch { return "<font color='red'>SMS Not Successfully Sent...</font>"; }
    }

    public static string GetSmsBalance()
    {
        //ACCT BALANCE: htp://www.smslive247.com/http/index.aspx?cmd=querybalance&sessionid=xxx

        System.Net.ServicePointManager.Expect100Continue = false;
        string url = "http://www.smslive247.com/http/index.aspx";
        HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url); string proxy = null;
        try
        {
            string sendSMSparams = String.Format("cmd={0}&sessionid={1}", "querybalance", "c0578c91-09bb-46d0-921e-520f34b0207d");
            byte[] buffer = Encoding.UTF8.GetBytes(sendSMSparams);
            req.Method = "POST"; req.ContentType = "application/x-www-form-urlencoded"; req.ContentLength = buffer.Length;
            req.Proxy = new WebProxy(proxy, true);       // ignore for local addresses
            req.CookieContainer = new CookieContainer(); // enable cookies
            Stream reqst = req.GetRequestStream(); // add form data to request stream
            reqst.Write(buffer, 0, buffer.Length); reqst.Flush(); reqst.Close();
            HttpWebResponse res = (HttpWebResponse)req.GetResponse();
            Stream resst = res.GetResponseStream(); StreamReader sr = new StreamReader(resst);
            string response = sr.ReadToEnd(); return response;
        }
        catch { return "<font color='red'>error occured...</font>"; }
    }


}