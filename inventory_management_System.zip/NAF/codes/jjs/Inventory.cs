﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data.SqlClient;
using System.Configuration;
using System.Data; 

public class Inventory
{
    private SqlConnection _conn = new SqlConnection(Connect.CONN());
    public string _error;

    //-------------------- Location --------------------
    public bool setLocation(string name, string details)
    {
        string sql = "INSERT INTO invLocation(Name,Details) VALUES(@name,@details) ";
        SqlCommand cmd = new SqlCommand(sql, this._conn);
        cmd.Parameters.AddWithValue("@name", name);       cmd.Parameters.AddWithValue("@details", details);
        int added = 0;
        try { this._conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { this._error = ex.Message; }  finally { this._conn.Close(); }
        return (added > 0) ? true : false;
    }

    public DataTable getLocationTBL()
    {
        string sql = "SELECT * FROM invLocation ";      SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn);        
        DataTable tbl = new DataTable(); dr.Fill(tbl); this._conn.Close(); return tbl;
    }
    public DataTable getLocationTBL(int locId)
    {
        string sql = "SELECT * FROM invLocation WHERE ID = @id ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn);
        dr.SelectCommand.Parameters.AddWithValue("@id", locId);
        DataTable tbl = new DataTable(); dr.Fill(tbl); this._conn.Close(); return tbl;
    }
    
    public DataTable getLocationTBL(string name)
    {
        string sql = "SELECT * FROM invLocation WHERE Name = @name ";        
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn);
        dr.SelectCommand.Parameters.AddWithValue("@name", name);
        DataTable tbl = new DataTable(); dr.Fill(tbl); this._conn.Close(); return tbl;
    }

    //-------------------- Department/Category ----------------------
    public bool setDept(string name, string otherInfo)
    {
        string sql = "INSERT INTO invDept(Name, OtherInfo) VALUES(@name, @otherInfo) ";
        SqlCommand cmd = new SqlCommand(sql, this._conn);
        cmd.Parameters.AddWithValue("@name", name); cmd.Parameters.AddWithValue("@otherInfo", otherInfo);   int added = 0;
        try { this._conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { this._error = ex.Message; }  finally { this._conn.Close(); } return (added > 0) ? true : false;
    }

    public DataTable getDeptTBL(int deptID)  {   return this.getDeptTBL(deptID, "");   }
    public DataTable getDeptTBL(string name) {   return this.getDeptTBL(0, name);   }

    private DataTable getDeptTBL(int deptID, string name)
    {
        string sql = "SELECT * FROM invDept WHERE "; sql += (deptID > 0) ? " ID = @id " : " Name = @name ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn);
        if (deptID > 0) dr.SelectCommand.Parameters.AddWithValue("@id", deptID);
        else dr.SelectCommand.Parameters.AddWithValue("@name", name);
        DataSet dtSet = new DataSet(); dr.Fill(dtSet, "TBL"); return dtSet.Tables["TBL"];
    }
    public DataTable getDeptTBL()
    {
        string sql = "SELECT * FROM invDept ORDER BY Name ";     SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn);
        DataTable tbl = new DataTable(); try { dr.Fill(tbl); this._conn.Close(); }  catch { } return tbl;
    }

    //---------------- Items/Ledger & Supply History ---------------------------------------
    public bool setItem(int locID, int deptID, string RackNo, string CardNo, string PartNo, string SerialNo, 
        string Name, int qty, string qtyUnits, bool IsMfg, DateTime MfgDate, bool IsExp, DateTime ExpDate,
        string UsedOnAircraft, string Supplier, string otherInfo, bool AllowAlert, int reOrderQty, int critQty,
        string RegByIDNo, string RegBy)
    {
        
        bool isItemHistAdded = this.setItemHistory(locID, deptID, RackNo, CardNo, PartNo, SerialNo, Name, qty, 
            qtyUnits, IsMfg, MfgDate, IsExp, ExpDate, UsedOnAircraft, Supplier, otherInfo,RegByIDNo, RegBy);
        if (isItemHistAdded)
        {
            DataTable itemTBL = new DataTable(); itemTBL = this.getLedgerTBL( locID, CardNo);
            bool isNewItem = (itemTBL.Rows.Count > 0) ? false : true;
            int stockItemQty = (isNewItem) ? 0 : (int.Parse(itemTBL.Rows[0]["Qty"].ToString()));

            int currentQty = stockItemQty + qty;
            bool isItemAdded = this.setLedger(locID, deptID, RackNo, CardNo, PartNo, SerialNo, Name, currentQty,
                qtyUnits, IsMfg, MfgDate, IsExp, ExpDate, UsedOnAircraft, otherInfo, AllowAlert, reOrderQty,
                critQty, isNewItem);
            return isItemAdded;
        }
        else return false;
        
    }
   
    public bool removeItem(int locId, string cardNo, int qty)
    {
        DataTable itemTBL = new DataTable(); itemTBL = this.getLedgerTBL(locId, cardNo);
        int stockQty = int.Parse(itemTBL.Rows[0]["Qty"].ToString());        int currentQty = stockQty - qty;
        if (currentQty < 0)
        {
            this._error = "<font color='red'>Stock QTY: " + stockQty + " </font> lesser than Issuing Qty: " + qty;
            return false;
        }
        else
        {
            string sql = "UPDATE invLedger SET Qty = @qty WHERE LocationID = @locID AND CardNo = @cardNo ";
            SqlCommand cmd = new SqlCommand(sql, this._conn);   int updated = 0;
            cmd.Parameters.AddWithValue("@qty", currentQty);
            cmd.Parameters.AddWithValue("@locID", locId);  cmd.Parameters.AddWithValue("@cardNo", cardNo);            
            try { this._conn.Open(); updated = int.Parse(cmd.ExecuteNonQuery().ToString()); }
            catch (Exception ex) { this._error = ex.Message; } finally { this._conn.Close(); }
            return (updated > 0) ? true : false;
        } 
    }

    private DateTime RegDateTime;
    private bool setItemHistory(int locID, int deptID, string RackNo, string CardNo, string PartNo, string SerialNo,
        string Name, int qty, string qtyUnits, bool IsMfg, DateTime MfgDate, bool IsExp, DateTime ExpDate,
        string UsedOnAircraft, string Supplier, string otherInfo, string RegByIDNo, string RegBy)
    {
        string sql = "INSERT INTO invSupplyHistory(LocationID,DeptID,RackNo,CardNo,PartNo,SerialNo,Name,Qty,QtyUnits, " +
                 " IsMfg,IsExpiry,MfgDate,ExpDate, UsedOnAircraft,Supplier,OtherInfo,RegByIDNo,RegBy,RegDate) " +
            " VALUES(@LocID,@DeptID,@RackNo,@CardNo,@PartNo,@SerialNo,@Name,@qty,@qtyUnits, " +
                 " @IsMfg,@IsExp,@MfgDate,@ExpDate,@Craft,@Supplier,@OtherInfo,@IDNo,@RegBy,@RegDate) ";
        SqlCommand cmd = new SqlCommand(sql, this._conn);
        this.RegDateTime = DateTime.Now;
        cmd.Parameters.AddWithValue("@LocID", locID);
        cmd.Parameters.AddWithValue("@DeptID", deptID);         cmd.Parameters.AddWithValue("@RackNo", RackNo); 
        cmd.Parameters.AddWithValue("@CardNo", CardNo);         cmd.Parameters.AddWithValue("@PartNo", PartNo);
        cmd.Parameters.AddWithValue("@SerialNo", SerialNo);     cmd.Parameters.AddWithValue("@Name", Name);         
        cmd.Parameters.AddWithValue("@qty", qty);               cmd.Parameters.AddWithValue("@qtyUnits", qtyUnits); 
        cmd.Parameters.AddWithValue("@IsMfg", IsMfg);           cmd.Parameters.AddWithValue("@IsExp", IsExp); 
        cmd.Parameters.AddWithValue("@MfgDate", MfgDate);       cmd.Parameters.AddWithValue("@ExpDate", ExpDate);         
        cmd.Parameters.AddWithValue("@Craft", UsedOnAircraft);         
        cmd.Parameters.AddWithValue("@Supplier", Supplier);
        cmd.Parameters.AddWithValue("@OtherInfo", otherInfo);
        cmd.Parameters.AddWithValue("@IDNo", RegByIDNo);
        cmd.Parameters.AddWithValue("@RegBy", RegBy);  cmd.Parameters.AddWithValue("@RegDate", this.RegDateTime); 
        
        int added = 0;
        try { this._conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { this._error = ex.Message; }
        finally { this._conn.Close(); } return (added > 0) ? true : false;
    }

    private bool deleteItemHistory(string cardNo, DateTime regdt)
    {
        string sql = "DELETE FROM invSupplyHistory WHERE CardNo = @cardNo AND RegDate = @dt ";
        SqlCommand cmd = new SqlCommand(sql, this._conn);   int deleted = 0;
        cmd.Parameters.AddWithValue("@cardNo", cardNo);     cmd.Parameters.AddWithValue("@dt", regdt);
        try { this._conn.Open(); deleted = int.Parse(cmd.ExecuteNonQuery().ToString()); 
        } catch (Exception ex) { this._error = ex.Message; } finally { this._conn.Close(); }
        return (deleted > 0) ? true : false;            
    }

    private bool setLedger(int locID, int deptID, string RackNo, string CardNo, string PartNo, string SerialNo,
        string Name, int qty, string qtyUnits, bool IsMfg, DateTime MfgDate, bool IsExp, DateTime ExpDate,
        string UsedOnAircraft, string otherInfo, bool AllowAlert, int reOrderQty, int critQty, bool isNewItem)
    {
        string sql = "";
        if (isNewItem)
            sql = "INSERT INTO invLedger(LocationID,DeptID,RackNo,CardNo,PartNo,SerialNo,Name,Qty,QtyUnits, " +
                   " IsMfg,IsExpiry,MfgDate,ExpDate, UsedOnAircraft,OtherInfo, AllowAlert, ReorderQty, CriticalQty) " +
              " VALUES(@LocID,@DeptID,@RackNo,@CardNo,@PartNo,@SerialNo,@Name,@qty,@qtyUnits, " +
                   " @IsMfg,@IsExp,@MfgDate,@ExpDate,@Craft,@OtherInfo, @AllowAlert, @ReordQty, @CritQty) ";
        else
            sql = "UPDATE invLedger SET LocationID = @LocID, DeptID = @DeptID, RackNo = @RackNo, PartNo = @PartNo, " +
                " SerialNo = @SerialNo, Name = @Name, Qty = @qty, QtyUnits = @qtyUnits, IsMfg = @IsMfg, IsExpiry = @IsExp, " +
                " MfgDate = @MfgDate, ExpDate = @ExpDate, UsedOnAircraft = @Craft, OtherInfo = @OtherInfo, " +
                " AllowAlert = @AllowAlert, ReorderQty = @ReordQty, CriticalQty = @CritQty WHERE CardNo = @CardNo ";
        SqlCommand cmd = new SqlCommand(sql, this._conn);
        cmd.Parameters.AddWithValue("@LocID", locID);
        cmd.Parameters.AddWithValue("@DeptID", deptID); cmd.Parameters.AddWithValue("@RackNo", RackNo);
        cmd.Parameters.AddWithValue("@CardNo", CardNo); cmd.Parameters.AddWithValue("@PartNo", PartNo);
        cmd.Parameters.AddWithValue("@SerialNo", SerialNo); cmd.Parameters.AddWithValue("@Name", Name);
        cmd.Parameters.AddWithValue("@qty", qty); cmd.Parameters.AddWithValue("@qtyUnits", qtyUnits);
        cmd.Parameters.AddWithValue("@IsMfg", IsMfg); cmd.Parameters.AddWithValue("@IsExp", IsExp);
        cmd.Parameters.AddWithValue("@MfgDate", MfgDate); cmd.Parameters.AddWithValue("@ExpDate", ExpDate);
        cmd.Parameters.AddWithValue("@Craft", UsedOnAircraft);        
        cmd.Parameters.AddWithValue("@OtherInfo", otherInfo);      cmd.Parameters.AddWithValue("@AllowAlert", AllowAlert);
        cmd.Parameters.AddWithValue("@ReordQty", reOrderQty);      cmd.Parameters.AddWithValue("@CritQty", critQty);
        int added = 0;
        try { this._conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { this._error = ex.Message; }
        finally { this._conn.Close(); } return (added > 0) ? true : false;
    }


    public DataTable getLedgerTBL(int locId, string cardNo)
    {
        string sql = "SELECT * FROM invLedger WHERE LocationID = @locID AND CardNo = @CardNo ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn);      DataSet dtSet = new DataSet();
        dr.SelectCommand.Parameters.AddWithValue("@locID", locId);
        dr.SelectCommand.Parameters.AddWithValue("@CardNo", cardNo);
        dr.Fill(dtSet, "TBL"); this._conn.Close(); return dtSet.Tables["TBL"];
    }
    
    //------------------ Issue ---------------------------
    private int getNewInvoice(int locID)
    {
        string sql = "SELECT MAX(InvoiceNo) AS MaxInvoice FROM invReceivinTech " +
            " WHERE LocationID = @locID AND InvoiceNo > @zero ";
        SqlCommand cmd = new SqlCommand(sql, this._conn);
        cmd.Parameters.AddWithValue("@locID", locID);     cmd.Parameters.AddWithValue("@zero", 0);
        int invoiceNo = 0; SqlDataReader dr = null;
        try
        {
            this._conn.Open(); dr = cmd.ExecuteReader();
            while(dr.Read()){ invoiceNo = int.Parse(dr["MaxInvoice"].ToString());  }            
        } catch (Exception ex) { this._error = ex.Message; }finally { this._conn.Close(); }
        invoiceNo += 1;     return invoiceNo;
    }

    public int setIssue(int locID, string stfName, string stfIDNo, int nItems, string airCraft, string details, 
       string EOCAuth, string regIDNo, string regStfName)
    {
        int invoiceNo = this.getNewInvoice(locID);
        string sql = "INSERT INTO invReceivinTech(LocationID,InvoiceNo,StaffName,StaffIDNo,nItems, " + 
            " UsedOnAircraft, Details, EOCAuth, RegByIDNo,RegStaffName,RegDate) " +
            " VALUES(@LocID,@InvNo, @StfName,@StfIDNo,@nItems,@Craft,@details, @EOCAuth, " +
            " @RegByIDNo,@RegStfName,@RegDate) ";
        SqlCommand cmd = new SqlCommand(sql, this._conn);       DateTime regDateTime = DateTime.Now;
        cmd.Parameters.AddWithValue("@LocID", locID);        cmd.Parameters.AddWithValue("@InvNo", invoiceNo);
        cmd.Parameters.AddWithValue("@StfName", stfName);
        cmd.Parameters.AddWithValue("@StfIDNo", stfIDNo);    cmd.Parameters.AddWithValue("@nItems", nItems);
        cmd.Parameters.AddWithValue("@Craft", airCraft);     cmd.Parameters.AddWithValue("@details", details);
        cmd.Parameters.AddWithValue("@EOCAuth", EOCAuth);    cmd.Parameters.AddWithValue("@RegByIDNo", regIDNo); 
        cmd.Parameters.AddWithValue("@RegStfName", regStfName);
        cmd.Parameters.AddWithValue("@RegDate", regDateTime);    int added = 0;
        try {   this._conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString());
        } catch (Exception ex) { this._error = ex.Message; } finally { this._conn.Close(); }
        return invoiceNo;
    }
     

    public bool setIssueItem(int locId, int InvoiceNo, int deptID, string cardNo, string partNo, string partName, 
        string serialNo, string rackNo, int qty, string qtyUnit, bool isMfg, DateTime mfgDate, 
        bool isExp, DateTime expDate)
    {        
        bool updLedger = this.removeItem(locId, cardNo, qty);    if (!updLedger) return false;
        string sql = "INSERT INTO invIssuedParts(LocationID,InvoiceNo,DeptID,CardNo,PartNo,PartName, SerialNo, " +
            " RackNo,Qty,QtyUnit,IsMfg,MfgDate, IsExp,ExpDate) " +
            " VALUES(@LocID,@InvNo,@DeptID,@CardNo,@PartNo,@name,@SerialNo, @RackNo,@Qty, @QtyUnit,@IsMfg, " +
            " @MfgDate,@IsExp,@ExpDate) ";
        SqlCommand cmd = new SqlCommand(sql, this._conn);
        cmd.Parameters.AddWithValue("@LocID", locId);            cmd.Parameters.AddWithValue("@InvNo", InvoiceNo);
        cmd.Parameters.AddWithValue("@DeptID", deptID);          cmd.Parameters.AddWithValue("@CardNo", cardNo);          
        cmd.Parameters.AddWithValue("@PartNo", partNo);          cmd.Parameters.AddWithValue("@name", partName);
        cmd.Parameters.AddWithValue("@SerialNo", serialNo);      cmd.Parameters.AddWithValue("@RackNo", rackNo);
        cmd.Parameters.AddWithValue("@Qty", qty);                cmd.Parameters.AddWithValue("@QtyUnit", qtyUnit);
        cmd.Parameters.AddWithValue("@IsMfg", isMfg);            cmd.Parameters.AddWithValue("@MfgDate", mfgDate);
        cmd.Parameters.AddWithValue("@IsExp", isExp);            cmd.Parameters.AddWithValue("@ExpDate", expDate);
        int added = 0;
        try { this._conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString());
        } catch (Exception ex) { this._error = ex.Message; }  finally { this._conn.Close(); }
        return (added > 0) ? true : false;
    }

    public DataTable getInvoiceItems(int locId, int invoiceNo)
    {
        string sql = "SELECT i.*, d.Name AS DEPT, l.Name AS Location FROM invIssuedParts i, invDept d, invLocation l " +
            " WHERE i.LocationID = @locId AND i.InvoiceNo = @invNo AND d.ID = i.DeptID AND l.ID = i.LocationID  ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn);
        dr.SelectCommand.Parameters.AddWithValue("@locId", locId);
        dr.SelectCommand.Parameters.AddWithValue("@invNo", invoiceNo);
        DataTable tbl = new DataTable(); try { dr.Fill(tbl); this._conn.Close(); } catch { }  return tbl;
    }
    //---------------------
     
}