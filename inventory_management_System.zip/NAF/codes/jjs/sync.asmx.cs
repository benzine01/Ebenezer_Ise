﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

using System.Text;
using System.Data;

namespace AirInventory.codes
{
    /// <summary>
    /// Summary description for sync
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    
    [System.Web.Script.Services.ScriptService]
    public class sync : System.Web.Services.WebService
    {

        private string timeoutMsg = "<font color='red'>session timeout, please login...</font>";
         
        
 

        //[WebMethod]
        //public string setCalendarInspMth(string mth)
        //{
        //    int mthId = 0; try { mthId = int.Parse(mth.Trim()); } catch { }  Users obj = new Users();
        //    bool isAdded = obj.setCalendarInspMth(mthId);
        //    if (isAdded) return "<font color='green'>Successfully added Calendar Months</font>";
        //    else return "<font color='red'>unable to add Calendar Months, <i> " + obj._error + " </i></font>";
        //}


        //[WebMethod]
        //public string setAircraft(string loc, string sign, string name)
        //{
        //    int locId = 0;    try { locId = int.Parse(loc); } catch { }
        //    AircraftStatus obj = new AircraftStatus(); bool isAdded = obj.setAircraft(locId, sign.Trim(), name.Trim());
        //    if (isAdded) return "<font color='green'>Successfully added Aircraft</font>";
        //    else return "<font color='red'>unable to add Aircraft, <i> " + obj._error + " </i></font>";
        //}

        //[WebMethod]
        //public string setServLev(string lev, string info)
        //{
        //    AircraftStatus obj = new AircraftStatus();     int level = 0; try { level = int.Parse(lev); } catch { }
        //    bool isAdded = obj.setServLev(level, info);
        //    if (isAdded) return "<font color='green'>Successfully added Aircraft Service Level</font>";
        //    else return "<font color='red'>unable to add Aircraft Service Level, <i> " + obj._error + " </i></font>";
        //}


         
        //[WebMethod(EnableSession=true)]
        //public string setTakeOff(string sign, string task, string name, string tLocNm, 
        //    string tHr, string tMins, string lLocNm, string lHr, string lMins, string spHr, string spMins, string isSnag, string rmk)
        //{
        //    DateTime today = new DateTime(); today = DateTime.Now;
        //    int _tHr = 0, _tMins = 0;     try { _tHr = int.Parse(tHr); _tMins = int.Parse(tMins); } catch { }
        //    int _lHr = 0, _lMins = 0;     try { _lHr = int.Parse(lHr); _lMins = int.Parse(lMins); } catch { }

        //    int _spHr = 0, _spMins = 0, _IsSnag = 0;            
        //    DateTime takeOffTime = new DateTime(today.Year, today.Month, today.Day, _tHr, _tMins, 0);
        //    DateTime landTime = new DateTime(today.Year, today.Month, today.Day, _lHr, _lMins, 0);
        //    try { _spHr = int.Parse(spHr); _spMins = int.Parse(spMins); _IsSnag = int.Parse(isSnag); } catch { }

        //    int _taskId = 0; try { _taskId = int.Parse(task); } catch { }
        //    AircraftStatus obj = new AircraftStatus();
        //    //setTakeOff(string callSign, string takeOffLoc, DateTime takeOffTime, string landLoc, DateTime landTime,
        ////int hr, int mins, int taskId, string taskName, int isSnag, string details, string RegIDNo, string RegName)
        //    bool isAdded = obj.setTakeOff(sign, tLocNm, takeOffTime, lLocNm, landTime, _spHr, _spMins, _taskId, name, _IsSnag,
        //        rmk, UserSession.IDNo, UserSession.Name);
        //    if (isAdded) return "<font color='green'>Successfully added...</font>";
        //    else return "<font color='red'>unable to add record..., <i> " + obj._error + " </i></font>";
        //}

        //[WebMethod]
        //public string getCraftStatus(string calSign)
        //{
        //    AircraftStatus obj = new AircraftStatus();
        //    DataTable tbl = new DataTable();
        //    try { tbl = obj.getAirCraftStatus(calSign); }
        //    catch (Exception ex) { return ex.Message; }
        //    if (tbl.Rows.Count < 1) return "<font color='red'>no record...</font>";
        //    DataRow dr = tbl.Rows[0];
        //    int isSnag = 2; try { isSnag = int.Parse(dr["IsSnag"].ToString()); } catch { } 
        //    bool isService = false; try { isService = bool.Parse(dr["IsService"].ToString()); } catch { }
        //    string snag = "";
        //    if (isSnag == 0) snag = "<font color='green'><b>No</b></font>";
        //    else if (isSnag == 1) snag = "<font color='orange'><b>Delay Discripancy</b></font> ";
        //    else if (isSnag == 2) snag = "<font color='red'><b>YES</b></font> ";
        //    string service = (isService && isSnag < 2) ? "<font color='green'><b>S</b></font> " :
        //        "<font color='red'><b>US</b></font> ";            
        //    if (isSnag == 1) service = "<font color='orange'><b>S</b></font> ";

        //    string _tbl = "<table border='0' cellpadding='2' cellspacing='4'> " +
        //    "<tr align='left'><th>LOCATION: </th> <td> " + dr["Location"].ToString()  + " </td></tr>" +
        //    "<tr align='left'><th>AIRCRAFT: </th> <td> " + dr["callSign"].ToString() + "</td></tr>" +
        //    "<tr align='left'><th>CURRENT HOURS: </th> <td> " + dr["curHR"].ToString() + " hrs, " +
        //                   dr["curMins"].ToString() + " mins </td></tr>" +
        //    "<tr align='left'><th>REMAINING HOURS: </th> <td> " + dr["HRsLeft"].ToString() + " hrs, " + 
        //                   dr["MinsLeft"].ToString() + " mins </td></tr>" +
        //    "<tr align='left'><th>LAST INSPECTION: </th> <td> " + dr["curLev"].ToString() + "</td></tr>" +
        //    "<tr align='left'><th>NEXT INSPECTION: </th> <td> " + dr["nextLev"].ToString() + "</td></tr>" +
        //    "<tr align='left'><th>SNAG: </th> <td> " + snag + "</td></tr>" +
        //    "<tr align='left'><th>STATUS: </th> <td> " + service + "</td></tr>" +
        //    "<tr align='left' valign='top'><th>REMARK </th> <td> " + dr["details"].ToString() + "</td></tr></table>";
        //    return _tbl;
        //}

        //[WebMethod]
        //public string getCraftLastFlight(string calSign)
        //{
        //    AircraftStatus obj = new AircraftStatus(); DataTable tbl = obj.getAircraftLastFlight(calSign);
        //    if (tbl.Rows.Count < 1) return "<font color='red'>no record...</font>";
        //    DataRow dr = tbl.Rows[0];
        //    int isSnag = 2; try { isSnag = int.Parse(dr["IsSnag"].ToString()); }catch { }             
        //    string snag = "";
        //    if (isSnag == 0) snag = "<font color='green'><b>No</b></font>";
        //    else if (isSnag == 1) snag = "<font color='orange'><b>Delay Discripancy</b></font> ";
        //    else if (isSnag == 2) snag = "<font color='red'><b>YES</b></font> ";
        //    int taskId = 0; try { taskId = int.Parse(dr["taskId"].ToString()); } catch { }
        //    string[] tasks = { "","Mission", "FCF", "Hovering", "Ground Running" };
            
        //    // <option value="1">Mission</option>   <option value="2">Hovering</option> <option value="3">Grounding</option>

        //    string _tbl = "<table border='0' cellpadding='2' cellspacing='4'> " +
        //    "<tr><th align='left'>CALL SIGN: </th> <td> " + dr["callSign"].ToString() +
        //             " </td></tr> <tr><th align='left'>TASK TYPE: </th> <td> " + tasks[taskId] + "</td></tr>" +
        //    "<tr><th align='left'>TASK NAME: </th> <td> " + dr["taskName"].ToString() + "</td></tr>" +
        //    "<tr><th align='left'>TAKE-OFF LOCATION: </th> <td> " + dr["takeOffLoc"].ToString() + "</td></tr>" +
        //    "<tr><th align='left'>TAKE-OFF TIME: </th> <td> " +
        //        DateTime.Parse(dr["takeOffTime"].ToString()).ToString("dd MMM yyyy. hh:mm tt") + " </td></tr>" +
        //    "<tr><th align='left'>LAND LOCATION: </th> <td> " + dr["landLoc"].ToString() + "</td></tr>" +
        //    "<tr><th align='left'>LAND TIME: </th> <td> " + 
        //         DateTime.Parse(dr["landTime"].ToString()).ToString("dd MMM yyyy. hh:mm tt") + " </td></tr>" +
        //    "<tr><th align='left'>FLIGHT TIME: </th> <td> " + dr["HR"].ToString() + " hrs, " + 
        //         dr["Mins"].ToString() + " mins</td></tr>" +
        //    "<tr><th align='left'>SNAG: </th> <td> " + snag + "</td></tr>" +
        //    "<tr valign='top'><th align='left'>REMARK: </th> <td> " + dr["details"].ToString() + "</td></tr>" +
        //    "<tr><th align='left'>REG. BY: </th> <td> " + dr["RegName"].ToString() + " (" + dr["RegIDNo"].ToString() + ") </td></tr>" +
        //    "<tr><th align='left'>REG. DATE: </th> <td> " + 
        //          DateTime.Parse(dr["landTime"].ToString()).ToString("dd MMM yyyy. hh:mm tt") + " </td></tr></table>";
        //    return _tbl;
        //}


        //[WebMethod]
        //public string getAircraftStatus(string loc){
        //    AircraftStatus obj = new AircraftStatus();
        //    int locId = 0;    try { locId = int.Parse(loc); } catch { }
        //    DataTable airTBL = new DataTable();      airTBL = obj.getAirCraftStatus(locId);
        //    if (airTBL.Rows.Count < 1)
        //        return "<font color='red'>no record</font>";
        //    StringBuilder tbl = new StringBuilder();
        //    tbl.Append("<div class='tblHead' style='width:800px;align:center;'> LOCATION: " + airTBL.Rows[0]["Location"].ToString() +
        //        "  </div>" +
        //               "<table  style='font-size:12px; font-weight:100px;' cellpadding='0' cellspacing='0' border='0' " +
        //               " class='display' id='craftStatusTBL'> <thead> <th>CALL SIGN</th> " +
        //               " <th>CUR. HRs</th> <th>LAST INSP.</th>  <th>NEXT INSP.</th> <th>HRs. To NEXT INSP.</th> " +
        //               " <th>SNAG</th><th>STATUS</th> <th>REMARK</th><th> </th> </tr></thead> " +
        //               " <tfoot> <tr>  <th>CALL SIGN</th> " +
        //               " <th>CUR. HRs</th> <th>LAST INSP.</th>  <th>NEXT INSP.</th> <th>HRs. To NEXT INSP.</th> " +
        //               " <th>SNAG</th> <th>STATUS</th> <th>REMARK</th> <th> </th> </tr></tfoot> <tbody>");
        //    string img = "<img src='../images/arrow_right_16.png' alt='add' />";
        //    foreach (DataRow dr in airTBL.Rows)
        //    {
        //        /* CallSignName,  Location LastInsp */
        //        /*<tr> <th>AIRCRAFT TYPE</th><th>CALL SIGN</th> " +
        //              " <th>CUR. HRs</th> <th>LAST INSP.</th>  <th>NEXT INSP.</th> <th>HRs. To NEXT INSP.</th> " +
        //              " <th>STATUS</th> <th>REMARK</th> */
        //        int isSnag = 0; string snag = "", service = "";    try { isSnag = int.Parse(dr["IsSnag"].ToString()); } catch { }
        //        if (isSnag == 0)
        //        {
        //            snag = "<font color='green'><b>NO</b></font>";   service = "<font color='green'><b>S</b></font>";
        //        }
        //        else if (isSnag == 1)
        //        {
        //            service = "<font color='orange'><b>S</b></font>";
        //            snag = "<font color='orange'><b>Delay Discripancy</b></font>";
        //        }
        //        else if (isSnag == 2) { service = "<font color='red'><b>US</b></font>";
        //            snag = "<font color='red'><b>YES</b></font>";
        //        }
        //        string callSign = dr["callSign"].ToString().Trim();
        //        tbl.Append("<tr align='center'> <td>" + callSign + " </td> " +
        //             " <td> " + dr["curHR"].ToString() + " Hrs, " + dr["curMins"].ToString() + " Mins</td> " +
        //             " <td> " + dr["LastInsp"].ToString() + " </td><td> " + dr["nextLev"].ToString() +
        //             " </td><td>" + dr["HRsLeft"].ToString() + " Hrs, " + dr["MinsLeft"].ToString() +
        //            " Mins </td><td>" + snag + " </td><td>" + service + " </td><td align='left'> " + dr["details"].ToString() +
        //             " </td><td><a href='takeoff_hist.aspx?cs=" + callSign + "' target='_blank'> " + img + " </a> </td> </tr>");
        //    }
        //    tbl.Append("</tbody></table>");          return tbl.ToString();
        //}


        //[WebMethod]
        //public object getDateDiff(string dt1, string  dt2)
        //{
        //    //var date1 = tYr + ',' + tMth + ',' + tDay + ',' + tHr + ',' + tMin;
        //    //var date2 = lYr + ',' + lMth + ',' + lDay + ',' + lHr + ',' + lMin;
        //    int _tDay = 0, _tMth = 0, _tYr = 0, _tHr = 0, _tMins = 0;
        //    int _lDay = 0, _lMth = 0, _lYr = 0, _lHr = 0, _lMins = 0;
        //    string[] t1 = dt1.Split(','); string[] t2 = dt2.Split(',');
        //    _tYr = int.Parse(t1[0]); _tMth = int.Parse(t1[1]); _tDay = int.Parse(t1[2]);
        //    _tHr = int.Parse(t1[3]); _tMins = int.Parse(t1[4]);

        //    _lYr = int.Parse(t2[0]); _lMth = int.Parse(t2[1]); _lDay = int.Parse(t2[2]);
        //    _lHr = int.Parse(t2[3]); _lMins = int.Parse(t2[4]);

        //    DateTime _dt1 = new DateTime(_tYr, _tMth, _tDay, _tHr, _tMins, 0);
        //    DateTime _dt2 = new DateTime(_lYr, _lMth, _lDay, _lHr, _lMins, 0);

        //    TimeSpan t = _dt2 - _dt1;
        //    double noOfDays = t.TotalDays;        double noOfHours = t.TotalHours;      double noOfMins = t.TotalMinutes;
            
        //    string str = "Days: " + noOfDays.ToString() + ", Hours: " + noOfHours.ToString() + ", Mins: " + noOfMins.ToString();
        //    //string msg = str + "<br>Date1: " + _dt1.ToString("MMM dd, yyyy hh:mm tt") + ",, " + dt1 + " <br>Date2: " +
        //    //    _dt2.ToString("MMM dd, yyyy hh:mm tt") + ",, " + dt2;
        //    var obj = new { HR = Convert.ToInt32(noOfMins / 60), Mins = noOfMins % 60 };  return obj;
        //}


        //[WebMethod(EnableSession=true)]
        //public string getTakeOffHist(string callSign)
        //{
        //    DataTable TBL = new DataTable(); AircraftStatus obj = new AircraftStatus();
        //    TBL = obj.getTakeOffHist(callSign);
        //    if (TBL.Rows.Count < 1) return "<font color='red'>no record in " + callSign + "...</font>";
        //    DataTable airTBL = obj.getAirCraftStatus(callSign);

        //    StringBuilder tbl = new StringBuilder();
        //    tbl.Append("<div class='tblHead' style='width:800px;align:center;'> LOCATION: " + airTBL.Rows[0]["Location"].ToString() +
        //        "  </div>" +
        //               "<table  style='font-size:12px; font-weight:100px;' cellpadding='0' cellspacing='0' border='0' " +
        //               " class='display tbls' id='takeOffHistTBL'> <thead> <th>S/N</th> <th>CALL SIGN</th> <th>TASK</th>" +
        //               " <th>TAKE-OFF LOC.</th> <th>LAND LOC.</th> <th>FLIGHT DATE</th> <th>TAKE-OFF TIME</th> " +
        //               " <th>LAND TIME</th> <th>FLIGHT TIME</th> <th>IS SNAG</th><th>REMARK</th><th>REGISTERED BY</th> </tr></thead> " +
        //               " <!--<tfoot> <tr> <th>S/N </th> <th>CALL SIGN</th> <th>TASK</th> <th>TAKE-OFF LOCATION</th>" +
        //               "  <th>LAND LOCATION</th> <th>FLIGHT DATE</th><th>TAKE-OFF TIME</th> <th>LAND TIME</th> " +
        //               " <th>FLIGHT TIME</th> <th>IS SNAG</th><th>REMARK</th><th>REGISTERED BY</th> </tr></tfoot>//--> <tbody>");
        //    //string del_img = "<img src='../images/delete.gif' alt='delete' title='Click to delete Item' />";
        //    int n = 0;
        //    foreach (DataRow dr in TBL.Rows)
        //    {
        //        n++;
        //        int isSnag = 2; try { isSnag = int.Parse(dr["IsSnag"].ToString()); }  catch { }
        //        string snag = "";
        //        if (isSnag == 0) snag = "<font color='green'><b>NO</b></font>";
        //        else if (isSnag == 1) snag = "<font color='orange'><b>Delay Discripancy</b></font> ";
        //        else if (isSnag == 2) snag = "<font color='red'><b>YES</b></font> ";
        //        int taskId = 0; try { taskId = int.Parse(dr["taskId"].ToString()); } catch { }
        //        string[] tasks = { "", "Mission", "FCF", "Hovering", "Ground Running" };
        //        string task = tasks[taskId] + " - " + dr["taskName"].ToString();
        //        tbl.Append("<tr><td> " + n.ToString() + ". </td><td> " + dr["callSign"].ToString() + " </td><td>" + task
        //            + " </td><td> " + dr["takeOffLoc"].ToString() + "</td><td> " + dr["landLoc"].ToString() + " </td> <td>" + 
        //            DateTime.Parse(dr["RegDate"].ToString()).ToString("MMM dd, yyyy") + " </td><td> " + 
        //            DateTime.Parse(dr["takeOffTime"].ToString()).ToString("HH:mm") + " </td><td>" + 
        //            DateTime.Parse(dr["landTime"].ToString()).ToString("HH:mm") + " </td> " +
        //        " <td> " + dr["HR"].ToString() + ":" + dr["Mins"].ToString() + " </td><td> " + snag + " </td><td> " + 
        //        dr["details"].ToString() + " </td><td> " + dr["RegName"].ToString() + " </td> </tr>");
        //    }
        //    tbl.Append("</tbody></table>"); return tbl.ToString();
        //}
               
        
        
        
        //================== INVENTORY ====================================
        //================== INVENTORY ====================================

        
        [WebMethod(EnableSession = true)]
        public string GetDueInfo()
        {
            InventoryReport obj = new InventoryReport();
            try
            {
                return obj.getLedgerDue(UserSession.LocationID);
            }
            catch (Exception ex) { return ex.Message; }
            //getLedgerDueReordeCritExpiryTBL()
        }

          //===============
        //[WebMethod(EnableSession = true)]
        //public object GetAddPartsCardNoTBL(string PartCardNo)
        //{
        //    //getLedgerPartCardTBL(int locID, string PartCardNo)
        //    PartCardNo = PartCardNo.Trim();
        //    InventoryReport obj = new InventoryReport();          DataTable TBL = new DataTable();
        //    TBL = obj.getLedgerPartCardTBL(UserSession.LocationID, PartCardNo);
        //    string msg = ""; int nRows = TBL.Rows.Count;
        //    if (nRows < 1)
        //    {
        //        msg = "<font color='red'>No Part/Card Number has <b>" + PartCardNo + "</b> </font>";
        //        var return_obj = new {  No = 0, MsgTBL = msg }; return return_obj;
        //    }
        //    else if (nRows == 1)
        //    {
        //        string cardNo = ""; try { cardNo = TBL.Rows[0]["CardNo"].ToString(); } catch { }
        //        return this.GetPartValus(cardNo);
        //    }
        //    else
        //    {
        //        StringBuilder tbl = new StringBuilder();
        //        tbl.Append("<table cellspacing='1' cellpadding='1' border='0' class='tbls'> " +
        //           "<tr><th>PART No.</th><th>CARD No.</th><th>NAME</th><th>QTY</th><th>DEPARTMENT</th><th></th></tr>");
        //        string img = "<img src='../images/arrow_right_16.png' alt='add' />";
        //        int qty = 0, critQty = 0, reorderQty = 0; 
        //        foreach (DataRow dr in TBL.Rows)
        //        {
        //            string color = "black";
        //            try { qty = int.Parse(dr["Qty"].ToString());
        //                  reorderQty = int.Parse(dr["ReorderQty"].ToString());
        //                  critQty = int.Parse(dr["CriticalQty"].ToString());
        //                  if (reorderQty >= qty) color = "orange";  if (critQty >= qty) color = "red";
        //            } catch { }
        //            try
        //            {
                                                
        //                tbl.Append("<tr><td>" + dr["PartNo"].ToString() + "</td><td>" + dr["CardNo"].ToString() +
        //                    "</td><td>" + dr["Name"].ToString() + "</td><td><font color='" + color + "'> " + qty + " " +
        //                    dr["QtyUnits"].ToString() + "</font> </td><td>" + dr["Dept"].ToString() + "</td> " +
        //                    " <td><a href='javascript:setPartValuesToAdd(\"" + dr["CardNo"].ToString() + "\")'> " + img +
        //                    " </a></td></tr>");
        //            }
        //            catch { }
        //        }
        //        msg = tbl.ToString() + "</table>";
        //        var return_obj = new { No = 0,  MsgTBL = msg }; return return_obj;
        //    }            
        //}

        //[WebMethod(EnableSession = true)]
        //public object GetPartValus(string CardNo)
        //{
        //    //'{"CardNo":"' + cardNo + '"}';  sync('GetPartValus', jDt, div);
        //    InventoryReport obj = new InventoryReport(); DataTable tbl = new DataTable();
        //    tbl = obj.getLedgerTBL(UserSession.LocationID, CardNo);           DataRow dr = tbl.Rows[0];            
        //    var valu = new {No = 1, DeptID = dr["DeptID"].ToString(), Rack = dr["RackNo"], Card = dr["CardNo"], Part = dr["PartNo"], 
        //        Serial = dr["SerialNo"], Name = dr["Name"], Qty = dr["Qty"].ToString(), QUnits = dr["QtyUnits"],
        //        IsMfg = dr["IsMfg"], IsExp = dr["IsExpiry"], AirCraft = dr["UsedOnAircraft"], OInfo = dr["OtherInfo"],
        //        IsAlert = dr["AllowAlert"], RQty = dr["ReorderQty"].ToString(), CQty = dr["CriticalQty"].ToString()
        //    };
        //    return valu;
        //}

        /*
         *  '{"CardNo":"' + cardNo + '", "Qty":"' + qty + '" }';
               get_sync('AddIssuePart', jDt, 'divIssueFeedbck', returnIssuePart);
         */
        //[WebMethod(EnableSession = true)]
        //public string AddIssuePart(string CardNo, string Qty)
        //{
        //    if (!UserSession.IsAllowIssue)
        //        return "<font color='red'>session terminated, please login to issue parts... </font>";

        //    InventoryReport rptObj = new InventoryReport(); DataTable tbl = new DataTable();
        //    tbl = rptObj.getLedgerTBL(UserSession.LocationID, CardNo);
        //    int nRows = tbl.Rows.Count; int stockQty = 0; DataRow dr;
        //    if (nRows > 0)
        //    {
        //        dr = tbl.Rows[0]; try { stockQty = int.Parse(dr["Qty"].ToString()); }  catch { }
        //    }
        //    int nQty = 0; try { nQty = int.Parse(Qty.Trim()); } catch { }   
        //    string msg = ""; ArrayList lst = new ArrayList();
            

        //    if (nRows < 1)
        //    {
        //        //CardNo does not exist
        //        msg = "<font color='red'>CARD IDNo: " + CardNo + " does not exist...</font>";
        //    }
        //    else if (nQty > stockQty)
        //    {
        //        //out of stock
        //        msg = "<font color='red'>CARD IDNo: " + CardNo + " out of stock...</font>";
        //    }
        //    else
        //    {
        //        if (Session["sesCartLst"] != null)
        //        {
        //            //try { lst = (ArrayList)Session["sesCartLst"]; }  catch { }
        //            lst = this.RemoveExistingPart(CardNo);
        //        }
        //        /*Parts(string dept, string card, string part, string name, int qty, string qtyUnits, bool isMfg, 
        //    string mfgDt, bool isExp, string expDt) */
        //        dr = tbl.Rows[0]; int maxID = 0;
        //        var partIDs = from Parts prt in lst
        //                      select prt.ID;
        //        foreach (int numb in partIDs) { maxID = (numb > maxID) ? numb : maxID; }           maxID++;
        //        bool isMfg = bool.Parse(dr["IsMfg"].ToString()); bool isExp = bool.Parse(dr["IsExpiry"].ToString());
        //        DateTime  mfgDt = new DateTime(1901,1,1);    if (isMfg) mfgDt = DateTime.Parse(dr["MfgDate"].ToString());
        //        DateTime expDt = new DateTime(1901, 1, 1); if (isExp) expDt = DateTime.Parse(dr["ExpDate"].ToString());
        //        int deptId = int.Parse(dr["DeptID"].ToString());
        //        Parts pObj = new Parts(maxID, deptId, dr["Dept"].ToString(), dr["CardNo"].ToString(), dr["PartNo"].ToString(),
        //            dr["Name"].ToString(), dr["SerialNo"].ToString(), dr["RackNo"].ToString(), nQty, dr["QtyUnits"].ToString(), 
        //            isMfg, mfgDt, isExp, expDt);
        //        lst.Add(pObj); Session["sesCartLst"] = lst;
        //        /* Parts(int id, int deptID, string dept, string card, string part, string name, string serial, string rack,
        //    int qty, string qtyUnits, bool isMfg, DateTime  mfgDt, bool isExp, DateTime  expDt) */
        //    }
        //    //SessionCart SessionCartLst CartTBL                        
        //    return msg + "<br>" + this.CartItems(lst);
        //}
       
        //[WebMethod(EnableSession = true)]
        //public string RemovePart(string ID)
        //{
        //    int partID = 0; try { partID = int.Parse(ID.Trim()); }  catch { }      ArrayList lst = new ArrayList();
        //    if (Session["sesCartLst"] != null)  try { lst = (ArrayList)Session["sesCartLst"]; } catch { }            
        //    var partsObj = from Parts obj in lst //.Cast<Parts>()
        //              where obj.ID != partID
        //              select obj;
        //    ArrayList lst2 = new ArrayList();  foreach (Parts pt in partsObj) lst2.Add(pt);
        //    Session["sesCartLst"] = lst2;         return this.CartItems(lst2);
        //}

        //[WebMethod(EnableSession = true)]
        //private ArrayList RemoveExistingPart(string CardNo)
        //{
        //    ArrayList lst = new ArrayList();
        //    if (Session["sesCartLst"] != null) 
        //        try { lst = (ArrayList)Session["sesCartLst"]; } catch { }
        //    var partsObj = from Parts obj in lst //.Cast<Parts>()
        //                   where obj.CardNo != CardNo
        //                   select obj;
        //    ArrayList lst2 = new ArrayList(); foreach (Parts pt in partsObj) lst2.Add(pt);
        //    Session["sesCartLst"] = lst2; return lst2;
           
        //}

        /*
            list.Add(new Person { FirstName = "Bugs", LastName = "Bunny" });
            list.Add(new Person { FirstName = "Peter", LastName = "Pan" }); 
            var q = from Person p in list
                    orderby p .FirstName
                    orderby p.LastName
                    select p; 
            string br = "<br/>";  foreach (Person p in q) {  L1.Text += p.ToString() + br;   }   
             *                           
      myAL.RemoveAt( 5 );// Removes the element at index 5.
      myAL.Remove( "lazy" );// Removes the element containing "lazy".
             * 
             * ArrayList objs = new ArrayList();
        objs.Add(new Foo(){ Name="sumit"});    objs.Add(new Foo() { Name = "rahul" }); objs.Add(new Foo() { Name = "ashish" });
        foreach(Foo  item  in objs)   {   if (item.Name.Equals("sumit"))  {   objs.Remove(item);    break;     }     }            
            
             * 
             * 
             var cc = from Cars car in carList
                 where car.CarMake == "BMW"
                 select car;
 
        var cc1 = from car in carList.Cast<Cars>()
              where car.CarMake == "BMW"
              select car;
 
        var cc2 = from car in carList.OfType<Cars>()
              where car.CarMake == "BMW"
              select car;
 
 
        foreach (Cars c in cc1)
            Console.WriteLine(c.CarMake + "-" + c.CarModel);
 
             */      
        

        //[WebMethod(EnableSession = true)]
        //private string CartItems(ArrayList lst)
        //{
        //    StringBuilder tbl = new StringBuilder();
        //    tbl.Append("<table cellspacing='1' cellpadding='1' border='0' class='tbls'> " +
        //          "<tr><th>S/N</th><th>CARD No.</th><th>PART No.</th><th>NAME</th><th>QTY</th><th>DEPARTMENT</th> " +
        //          "<th>MFG. DATE</th><th>EXP. DATE</th> <th></th></tr>");
        //    int nParts = 0, partsQty = 0;
        //    foreach (object item in lst)
        //    {
        //        Parts obj = (Parts)item;    string id = obj.ID.ToString();      nParts++;    partsQty += obj.Qty;
        //        string mfgDt = "";    if (obj.IsMfg) mfgDt = obj.MfgDate.ToString("MMM dd, yyyy");
        //        string expDt = "";    if (obj.IsExp) expDt = obj.ExpDate.ToString("MMM dd, yyyy"); 
        //        tbl.Append("<tr><td>" + nParts.ToString() + ".</td><td>" + obj.CardNo + "</td><td>" + obj.PartNo +
        //            "</td><td>" + obj.Name + " </td><td>" + obj.Qty.ToString() + "  " + obj.QtyUnits +
        //            "</td><td>" + obj.Dept + "</td> <td>" + mfgDt + "</td><td>" + expDt + " </td> " +
        //           " <td align='center'><a href='javascript:removePart(\"" + id + "\");' title='Click to Remove Part from Cart List'> " +
        //             " <img src='../images/basket_remove.png' alt='remove' width='19px' /></a> </td></tr>");
        //    }
        //    tbl.Append("</table><span><b>PARTS: " + nParts.ToString() +
        //         ", &nbsp;&nbsp;&nbsp; PARTS QTY: " + partsQty.ToString() + "</b>  </span>");
        //    return (nParts > 0)? tbl.ToString() : "";
        //}

        //[WebMethod(EnableSession = true)]
        //public object setIssueParts(string IDNo, string Name, string EOCAuth, string Aircraft, string OtherInfo)
        //{
        //    /* '{"IDNo":"", "Name":"", "Aircraft":"", "Otherinfo":"" }';
        //       sync('setIssueParts',*/
        //    ArrayList lst = new ArrayList();
        //    if (Session["sesCartLst"] != null) try { lst = (ArrayList)Session["sesCartLst"]; }  catch { }
        //    int InvoiceNo = 0; int nItems = lst.Count;
        //    if (lst.Count < 1)
        //    {
        //        var msg = new { No = 0, Msg = "<font color='red'>Please enter the Parts to Issue...</font>" };
        //        return msg;
        //    }
        //    else
        //    {
        //        /*var partsObj = from Parts obj in lst 
        //                      select obj;
        //        foreach (Parts pt in partsObj) nItems += pt.Qty;*/
                
        //        //string parts_msg = "";
        //        Inventory obj = new Inventory();
        //        try
        //        {
        //            int locId = UserSession.LocationID;
        //            InvoiceNo = obj.setIssue(locId, Name, IDNo, nItems, Aircraft, OtherInfo, EOCAuth,
        //                UserSession.IDNo, UserSession.Name_IDNo);
        //            if (InvoiceNo > 0)
        //            {
        //                foreach (Parts pt in lst)
        //                {
        //                    obj.setIssueItem(locId, InvoiceNo, pt.deptId, pt.CardNo, pt.PartNo,pt.Name, pt.Serial, 
        //                        pt.Rack, pt.Qty, pt.QtyUnits, pt.IsMfg, pt.MfgDate, pt.IsExp, pt.ExpDate);
        //                }
        //                Session["sesCartLst"] = null;
        //            }
        //            else
        //            {
        //                var msg_err = new { No = 0, Msg = "<font color='red'>Couldnot Issue Parts Receiving Technician : " + obj._error + "...</font>" };
        //                return msg_err;
        //            }
        //        }
        //        catch(Exception ex) {
        //            var msgs = new { No = 0, Msg = "<font color='red'>Couldnot Issue Parts: " + ex.Message + " ...</font>" };
        //            return msgs;
        //        }

        //        var msg = new
        //        {
        //            No = 1,
        //            Msg = "<font color='green'>Successfully Issued Parts to <b>" + Name + " (" + IDNo 
        //            + ")</b> </font>" };
        //        return msg;
        //    }
        //    /* setIssue(int locID, string stfName, string stfIDNo, int nItems, string airCraft, string details, 
        //string regIDNo, string regStfName) 
             
        //     setIssueItem(long issueID, int deptID, string cardNo, string partNo, string serialNo, string rackNo,
        //int qty, string qtyUnit, bool isMfg, DateTime mfgDate, bool isExp, DateTime expDate)
        //     */ 
        //}

        //[WebMethod(EnableSession = true)]
        //public string ClearCart() { Session["sesCartLst"] = null; return " "; } 

      
        //===========================================
        //===========================================

        //[WebMethod(EnableSession = true)]
        //public string getLedgerSummary()
        //{
        //    InventoryReport obj = new InventoryReport(); DataTable tbl = new DataTable();
        //    tbl = obj.getLedgerDueReordeCritExpiryTBL();
        //    /*  string sql = "SELECT l.ID, l.Name," +
        //    " (SELECT COUNT(ID) FROM invLedger WHERE (ExpDate <= @dt AND IsExpiry = @isExp AND Qty > @zero) AND LocationID = l.ID) " +
        //    "  AS nExpiry, " +
        //    " (SELECT COUNT(ID) FROM invLedger WHERE CriticalQty >= Qty AND LocationID = l.ID) AS nCritical, " +
        //    " (SELECT COUNT(ID) FROM invLedger WHERE ReorderQty >= Qty AND LocationID = l.ID) AS nReorder FROM invLocation l " +
        //    " ORDER BY l.Name "; */
        //    StringBuilder str = new StringBuilder();
        //    str.Append("<div class='tblHead' style='width:800px;align:center;'> LEDGER SUMMARY OF ALL LOCATIONS </div>" +
        //           "<table  style='font-size:12px; font-weight:100px;' cellpadding='0' cellspacing='0' border='0' " +
        //           " class='display' id='partDataTBL'> <thead> <tr align='center'> <th>LOCATION</th><th>EXPIRY ITEMS</th> " +
        //           "  <th>RE-ORDER ITEMS</th> <th>CRITICAL ITEMS</th> </tr></thead>  <tfoot> <tr align='center'> <th>LOCATION</th> " +
        //           " <th>EXPIRY ITEMS</th> <th>RE-ORDER ITEMS</th> <th>CRITICAL ITEMS</th> </tr></tfoot> <tbody>");

        //    foreach (DataRow dr in tbl.Rows)
        //    {
        //        string nExp = (dr["nExpiry"].ToString() == "0") ? "" : dr["nExpiry"].ToString();
        //        string nReorder = (dr["nReorder"].ToString() == "0") ? "" : dr["nReorder"].ToString();
        //        string nCritical = (dr["nCritical"].ToString() == "0") ? "" : dr["nCritical"].ToString();

        //        str.Append("<tr align='center'><td align='left'>" + dr["Name"].ToString() + "</td><td><b>" + nExp +
        //            "</b></td><td><b>" + nReorder + "</b></td><td><b>" + nCritical + "</b></td> </tr>");
        //    }
        //    str.Append("</tbody></table>");
        //    Session["invGrid"] = "LedgerRptSumry"; Session["invGridData"] = tbl;
        //    Session["invGridFileName"] = "ledger_summaryrpt_date_" + DateTime.Now.ToString("MMM_dd_yyyy(hh_mm_tt)");
                       
        //    return str.ToString();
        //}

    
    //    [WebMethod(EnableSession=true)]
    //    public string GetLedger(string loc, string rptTyp, string LocName)
    //    {
    //        if (!UserSession.IsActive) return "<font color='red'>timeout, please login...</font>";
    //        InventoryReport obj = new InventoryReport(); DataTable tbl = new DataTable();
    //        /* <option value="1">Ledger Parts</option><option value="2">Critical Parts</option>
    //<option value="3">Re-order Parts</option> <option value="4">Expiration</option> <option value="5">Search</option>  */
    //        int rptId = 0; try { rptId = int.Parse(rptTyp.Trim()); } catch { }
    //        int locID = 0; try { locID = int.Parse(loc.Trim()); } catch { }
    //        string headTxt = "";
    //        if (rptId == 1) //current ledger parts
    //        {
    //            headTxt = "CURRENT LEDGER PARTS OF LOCATION: " + LocName;
    //            tbl = obj.getLedgerTBL(locID);
    //        }
    //        else if (rptId == 2) //critical parts
    //        {
    //            headTxt = "CRITICAL LEDGER PARTS OF LOCATION: " + LocName;                
    //            tbl = obj.getLedgerCriticalTBL(locID);
    //        }
    //        else if (rptId == 3) //Re-order Parts
    //        {
    //            headTxt = "RE-ORDER LEDGER PARTS OF LOCATION: " + LocName;
    //            tbl = obj.getLedgerReorderTBL(locID); 
    //        }
    //        else if (rptId == 4) //Expiration parts
    //        {
    //            headTxt = "EXPIR(ED/ING) LEDGER PARTS OF LOCATION: " + LocName;
    //            tbl = obj.getLedgerDueExpiryTBL(locID); 
    //        } 
    //        string err = "";
    //        try { obj.getLedgerChartValus(tbl); } catch (Exception ex) { err = ex.Message; }
    //        Session["sesBarValus"] = obj.BarChartValus;
    //        Session["sesPieValus"] = obj.PieChartValus;

    //        Session["invGrid"] = "LedgerRpt"; Session["invGridData"] = tbl;
    //        Session["invGridFileName"] = "ledger_report_date_" + DateTime.Now.ToString("MMM_dd_yyyy(hh_mm_tt)");
    //        return bindPartsTBL(headTxt, tbl);
    //    }
    //    private string bindPartsTBL(string headerTxt, DataTable TBL)
    //    {           
    //        StringBuilder tbl = new StringBuilder();
    //        tbl.Append( "<div class='tblHead' style='width:800px;align:center;'> " + headerTxt + " </div>" +
    //                "<table  style='font-size:12px; font-weight:100px;' cellpadding='0' cellspacing='0' border='0' " +
    //                " class='display' id='partDataTBL'> <thead> <th>DEPT</th><th>RACK</th> " +
    //                " <th>CARD No.</th> <th>PART No.</th>  <th>PART NAME</th> <th>SERIAL</th> " +
    //                " <th>QTY</th> <th>DofQ</th><th>MFG. DATE</th> <th>EXP. DATE</th> </tr></thead> " +
    //                " <tfoot>	<tr> <th>DEPT</th><th>RACK</th><th>CARD No.</th> <th>PART No.</th>  " +
    //     " <th>PART NAME</th> <th>SERIAL</th> <th>QTY</th> <th>UNITS</th><th>MFG. DATE</th> <th>EXP. DATE</th> " +
    //                 "   </tr></tfoot> <tbody>");

    //        //string active_on = "<img src='../images/active_on.gif' alt='Lock' width='20px' height='20px' />";
    //        //string active_off = "<img src='../images/active_off.gif' alt='Lock' width='20px' height='20px' />";
    //        int qty = 0, critQty = 0, reorderQty = 0;
    //        foreach (DataRow dr in TBL.Rows)
    //        {
    //            bool isMfg = false; try { isMfg = bool.Parse(dr["IsMfg"].ToString()); }  catch { }
    //            bool isExp = false; try { isExp = bool.Parse(dr["IsExpiry"].ToString()); } catch { }
    //            string MfgDt = "", ExpDt = "";
    //            if (isMfg) 
    //                try { MfgDt = DateTime.Parse(dr["MfgDate"].ToString()).ToString("MMM dd, yyyy"); } catch { }
    //            if (isExp) 
    //                try { ExpDt = DateTime.Parse(dr["ExpDate"].ToString()).ToString("MMM dd, yyyy"); } catch { }

    //            string color = "black";
    //            try
    //            {
    //                qty = int.Parse(dr["Qty"].ToString()); reorderQty = int.Parse(dr["ReorderQty"].ToString());
    //                critQty = int.Parse(dr["CriticalQty"].ToString());
    //                if (reorderQty >= qty) color = "orange"; if (critQty >= qty) color = "red";
    //                if (qty <= critQty) color = "red"; else if (qty <= reorderQty) color = "orange"; else color = "green";
    //            }
    //            catch { }

    //            tbl.Append("<tr><td>" + dr["Dept"].ToString() + " </td><td>" +
    //                dr["RackNo"].ToString() + " </td><td>" + dr["CardNo"].ToString() + " </td><td>" + dr["PartNo"].ToString() +
    //                " </td><td>" + dr["Name"].ToString() + " </td><td>" + dr["SerialNo"].ToString() +
    //                " </td><td align='center'><b><font color='" + color + "'>" + qty + "</font></b> </td><td><font color='" +
    //                color + "'>" + dr["QtyUnits"].ToString() + "</font></td><td>" + MfgDt + " </td><td>" + ExpDt +
    //                "</td> </tr>");
    //            /* <td><a href='javascript:alert(\"Under Construction\");' title='Click to View Details'> " +
    //                " <img src='../images/arrow_right_16.png' alt='details' /> </a> </td> */
    //        }
    //        tbl.Append("<tbody></table><a target='_blank' href='chart.aspx'>chart </a> ");              
    //        return tbl.ToString();
    //    }
              
         //$('#divSearchLedgers').html(msg.d); reloadTable('ledgersTBL');
        // var jd = '{"valu":"' + valu + '"}';  get_sync('searchLegders', jd, div, fxnSearchLedgers); 
     
        //[WebMethod(EnableSession = true)]
        //public string searchLegders(string valu)
        //{
        //    if (!UserSession.IsActive) return "<font color='red'>timeout, please login...</font>";
        //    InventoryReport obj = new InventoryReport(); DataTable TBL = new DataTable();
        //    TBL = obj.searchLedgersTBL(valu);         Session["GridSrchLedgers"] = TBL;

        //    StringBuilder tbl = new StringBuilder();
        //    tbl.Append("<div class='tblHead' style='width:800px;align:center;'> SEARCH: " + valu + " </div>" +
        //            "<table  style='font-size:12px; font-weight:100px;' cellpadding='0' cellspacing='0' border='0' " +
        //            " class='display' id='ledgersTBL'> <thead> <th>LOCATION</th> <th>DEPT</th><th>RACK</th> " +
        //            " <th>CARD No.</th> <th>PART No.</th>  <th>PART NAME</th> <th>SERIAL</th> " +
        //            " <th>QTY/DofQ</th><th>MFG. DATE</th> <th>EXP. DATE</th> </tr></thead> " +
        //            " <tfoot>	<tr> <th>DEPT</th><th>RACK</th><th>CARD No.</th> <th>PART No.</th>  " +
        // " <th>PART NAME</th> <th>SERIAL</th> <th>QTY/DofQ</th><th>MFG. DATE</th> <th>EXP. DATE</th> " +
        //             "   </tr></tfoot> <tbody>");
        //    //string active_on = "<img src='../images/active_on.gif' alt='Lock' width='20px' height='20px' />";
        //    //string active_off = "<img src='../images/active_off.gif' alt='Lock' width='20px' height='20px' />";
        //    int qty = 0, critQty = 0, reorderQty = 0;
        //    foreach (DataRow dr in TBL.Rows)
        //    {
        //        bool isMfg = false; try { isMfg = bool.Parse(dr["IsMfg"].ToString()); }    catch { }
        //        bool isExp = false; try { isExp = bool.Parse(dr["IsExpiry"].ToString()); } catch { }
        //        string MfgDt = "", ExpDt = "";
        //        if (isMfg) try { MfgDt = DateTime.Parse(dr["MfgDate"].ToString()).ToString("MMM dd, yyyy"); } catch { }
        //        if (isExp) try { ExpDt = DateTime.Parse(dr["ExpDate"].ToString()).ToString("MMM dd, yyyy"); } catch { }
        //        string color = "black";
        //        try {
        //            qty = int.Parse(dr["Qty"].ToString()); reorderQty = int.Parse(dr["ReorderQty"].ToString());
        //            critQty = int.Parse(dr["CriticalQty"].ToString());
        //            if (reorderQty >= qty) color = "orange"; if (critQty >= qty) color = "red";
        //            if (qty <= critQty) color = "red"; else if (qty <= reorderQty) color = "orange"; else color = "green";
        //        } catch { }
        //        tbl.Append("<tr><td>" + dr["Location"].ToString() + " </td><td>" + dr["Dept"].ToString() + " </td><td>" +
        //            dr["RackNo"].ToString() + " </td><td>" + dr["CardNo"].ToString() + " </td><td>" + dr["PartNo"].ToString() +
        //            " </td><td>" + dr["Name"].ToString() + " </td><td>" + dr["SerialNo"].ToString() +
        //            " </td><td align='center'><b><font color='" + color + "'>" + qty + "</font></b> <font color='" +
        //            color + "'>" + dr["QtyUnits"].ToString() + "</font></td><td>" + MfgDt + " </td><td>" + ExpDt + "</td> </tr>"); 
        //    }
        //    tbl.Append("<tbody></table>");        return tbl.ToString(); 
        //}




        //[WebMethod(EnableSession=true)]
        //public string getInvRpt(string loc, string typ, string dept, string fDt, string tDt)
        //{
        //    if (!UserSession.IsActive) return "<font color='red'>timeout, please login...</font>";
        //    int locId = 0, typId = 0, deptId = 0;         int yr = 0, mth = 0, day = 0;  
        //    string[] fromDt = fDt.Trim().Split('-');      string[] toDt = tDt.Trim().Split('-'); //yyyy-mm-dd
        //    DateTime fromDate = DateTime.Now;             DateTime toDate = DateTime.Now;
        //    try { locId = int.Parse(loc.Trim()); typId = int.Parse(typ.Trim()); deptId = int.Parse(dept.Trim()); } catch { }
        //    try { yr = int.Parse(fromDt[0].Trim());   mth = int.Parse(fromDt[1].Trim());  day = int.Parse(fromDt[2].Trim());
        //    } catch { }    try { DateTime _dt = new DateTime(yr, mth, day); fromDate = _dt; } catch { }

        //    try { yr = int.Parse(toDt[0].Trim()); mth = int.Parse(toDt[1].Trim()); day = int.Parse(toDt[2].Trim());
        //    } catch { }  try { DateTime _dt = new DateTime(yr, mth, day); toDate = _dt; } catch { }
        //    //1-Suply  2-Receive/Issue
            
        //    DataTable TBL = new DataTable(); InventoryReport obj = new InventoryReport();
        //    string headTxt = "", returnTBL = "";
        //    if (typId == 1)
        //    {
        //        headTxt = " SUPPLY HISTORY FROM: " + fromDate.ToString("MMM dd, yyyy.") +
        //            "&nbsp;&nbsp;TO: " + toDate.ToString("MMM dd, yyyy.");
        //        TBL = obj.getSupplyHistTBL(locId, deptId, fromDate, toDate); 
        //        returnTBL = this.bindSupplyHistTBL(headTxt, TBL);
        //        Session["invGrid"] = "SupplyRpt"; Session["invGridData"] = TBL;        
        //        Session["invGridFileName"] = "supply_hist_from" + fromDate.ToString("MMM_dd_yyyy") + "_to" + toDate.ToString("MMM_dd_yyyy");
        //    }
        //    else if (typId == 2)
        //    {
        //        headTxt = " ISSUE HISTORY FROM: " + fromDate.ToString("MMM dd, yyyy.") +
        //            "&nbsp;&nbsp;TO: " + toDate.ToString("MMM dd, yyyy.");
        //        TBL = obj.getReceivTBL(locId, fromDate, toDate);      returnTBL = this.bindIssueHistTBL(headTxt, TBL);
        //        Session["invGrid"] = "IssueRpt";  Session["invGridData"] = TBL;
        //        Session["invGridFileName"] = "issue_hist_from" + fromDate.ToString("MMM_dd_yyyy") + "_to" + toDate.ToString("MMM_dd_yyyy");
        //    }
        //    return returnTBL;
        //}

        //[WebMethod(EnableSession = true)]
        //private string bindSupplyHistTBL(string headerTxt, DataTable TBL)
        //{
        //    if (!UserSession.IsActive) return "<font color='red'>timeout, please login...</font>";
        //    StringBuilder tbl = new StringBuilder();
        //    tbl.Append("<div class='tblHead' style='width:800px;align:center;'> " + headerTxt + " </div>" +
        //            "<table  style='font-size:12px; font-weight:100px;' cellpadding='0' cellspacing='0' border='0' " +
        //            " class='display' id='invRptTBL'> <thead> <tr align='left'> <th>LOCATION </th> <th>DEPT</th><th>RACK</th> " +
        //            " <th>CARD No.</th> <th>PART No.</th>  <th>PART NAME</th> <th align='center'>QTY/DofQ</th>  " +
        //            "  <th>EXP. DATE</th>  <th>SUPPLIER</th>  <th> </th></tr></thead>" +
        //            " <tfoot>	<tr align='left'> <th>LOCATION </th> <th>DEPT</th><th>RACK</th> <th>CARD No.</th> <th>PART No.</th> " +
        //            " <th>PART NAME</th> <th align='center'>QTY/DofQ</th> <th>EXP. DATE</th>  <th>SUPPLIER</th> " +
        //            " <th> </th>   </tr></tfoot> <tbody>");
        //    string del_img = "<img src='../images/delete.gif' alt='delete' title='Click to delete Supply from Ledger' />";
        //    //if (UserSession.LevID != 1) del_img = "";
        //    foreach (DataRow dr in TBL.Rows)
        //    {
        //        bool isMfg = false; try { isMfg = bool.Parse(dr["IsMfg"].ToString()); } catch { }
        //        bool isExp = false; try { isExp = bool.Parse(dr["IsExpiry"].ToString()); } catch { }
        //        string MfgDt = "", ExpDt = "";
        //        if (isMfg) try { MfgDt = DateTime.Parse(dr["MfgDate"].ToString()).ToString("MMM dd,yyyy"); }
        //            catch { }
        //        if (isExp) try { ExpDt = DateTime.Parse(dr["ExpDate"].ToString()).ToString("MMM dd,yyyy"); }
        //            catch { }
        //        string _loc = dr["Location"].ToString(); if (_loc.Length > 9) _loc = _loc.Substring(0, 9);
        //        string _dept = dr["Dept"].ToString(); if (_dept.Length > 9) _dept = _dept.Substring(0, 8); 
        //        tbl.Append("<tr title=\"REG. DATE: " + DateTime.Parse(dr["RegDate"].ToString()).ToString("MMM dd, yyyy hh:mm tt") +
        //            ".   " + dr["RegBy"].ToString() + "\"><td title=\"" + dr["Location"].ToString() + "\">" +
        //            _loc + ". </td><td title=\"" + dr["Dept"].ToString() + "\">" + _dept + " </td><td>" + 
        //            dr["RackNo"].ToString() + " </td><td>" + dr["CardNo"].ToString() +
        //            " </td><td title=\"SERIAL No.: " + dr["SerialNo"].ToString() + "\">" + dr["PartNo"].ToString() +
        //            " </td><td> " + dr["Name"].ToString() + " </td> <td align='center'> " + dr["Qty"].ToString() + " " +
        //            dr["QtyUnits"].ToString() + " </td> <td title=\"Manuf. Date: " + MfgDt + "\">" + ExpDt + " </td> <td> " +
        //            dr["Supplier"].ToString() + " </td> <td style='width:40px;'> <a href='javascript: showSupplyInfo(\"" +
        //  dr["ID"].ToString() + "\");' title='Click to View Details'> <img src='../images/arrow_right_16.png' alt='details' /></a> " +
        //            "   <a href='javascript: alert(\"Under Construction\");'>" + del_img + "</a> </td> </tr>");
        //    }
        //    tbl.Append("<tbody></table> ");
        //    return tbl.ToString();
        //}

        //[WebMethod(EnableSession = true)]
        //private string bindIssueHistTBL(string headerTxt, DataTable TBL)
        //{
        //    if (!UserSession.IsActive) return "<font color='red'>timeout, please login...</font>";
            
        //    StringBuilder tbl = new StringBuilder();
        //    tbl.Append("<div class='tblHead' style='width:800px;align:center;'> " + headerTxt + " </div>" +
        //            "<table  style='font-size:12px; font-weight:100px;' cellpadding='0' cellspacing='0' border='0' " +
        //            " class='display' id='invRptTBL'> <thead> <tr align='left'> <th>LOCATION </th> <th>INVOICE No.</th> " +
        //            "  <th align='center'>ITEMS</th> <th> RECEIVER </th> <th> EOC. AUTH. </th> <th>USED ON </th> " +
        //            " <th>OTHER INFO.</th> <th>REGISTERED BY</th> <th>REG. DATE</th> <th> </th>   </tr></thead><tfoot> " +
        //            " <tr align='left'> <th>LOCATION </th> <th>INVOICE</th>  <th align='center'>ITEMS</th>" +
        //            " <th> RECEIVER </th> <th> EOC. AUTH. </th> <th>USED ON </th> <th>OTHER INFO.</th>" +
        //            "  <th>REGISTERED BY</th> <th>REG. DATE</th> <th style='width:30px;'> </th>   </tr></tfoot> <tbody>"); 
        //    //if (UserSession.LevID != 1) del_img = "";
        //    foreach (DataRow dr in TBL.Rows)
        //    {
        //        string _loc = dr["Location"].ToString(); if (_loc.Length > 9) _loc = _loc.Substring(0, 9);
        //        string _reg = dr["RegStaffName"].ToString(); if (_reg.Length > 14) _reg = _reg.Substring(0, 14);
        //        tbl.Append("<tr><td title=\"" + dr["Location"].ToString() + "\">" + _loc + "</td><td>" + dr["InvoiceNo"].ToString() +
        //            " </td><td>" + dr["nItems"].ToString() + " </td><td>" + dr["StaffName"].ToString() + " (" +
        //            dr["StaffIDNo"].ToString() + ") </td><td>" + dr["EOCAuth"].ToString() + " </td><td>" + 
        //            dr["UsedOnAircraft"].ToString() + " </td><td> " + dr["Details"].ToString() + " </td> " +
        //            " <td title=\"REG. BY: " + dr["RegStaffName"].ToString() + "\"> " + _reg + "</td> <td title=\"REG. DATE: " + 
        //            DateTime.Parse(dr["RegDate"].ToString()).ToString("MMMdd,yyyy hh:mm tt") + "\"> " +
        //            DateTime.Parse(dr["RegDate"].ToString()).ToString("MMM dd, yyyy") + " </td>" +
        //            " <td> <a href='javascript: showInvoiceInfo(\"" +
        //  dr["LocationID"].ToString() + "\",\"" + dr["InvoiceNo"].ToString() + "\");' title='Click to View Invoice Details'> " +
        //        " <img src='../images/arrow_right_16.png' alt='details' /></a>  </td> </tr>");
        //    }
        //    tbl.Append("<tbody></table> ");      return tbl.ToString();
        //}

        //[WebMethod(EnableSession = true)]
        //public string getSupplyHistInfo(string Id)
        //{
        //    if (!UserSession.IsActive) return "<font color='red'>timeout, please login...</font>";
        //    Int64 ID = 0L; try { ID = Int64.Parse(Id); } catch { }        InventoryReport obj = new InventoryReport();
        //    DataTable TBL = obj.getSupplyHistTBL(ID);
        //    if (TBL.Rows.Count > 0)
        //    {
        //        DataRow dr = TBL.Rows[0];
        //        bool isMfg = false; try { isMfg = bool.Parse(dr["IsMfg"].ToString()); }  catch { }
        //        bool isExp = false; try { isExp = bool.Parse(dr["IsExpiry"].ToString()); } catch { }
        //        string MfgDt = "", ExpDt = "";
        //        if (isMfg) try { MfgDt = DateTime.Parse(dr["MfgDate"].ToString()).ToString("MMM dd, yyyy"); } catch { }
        //        if (isExp) try { ExpDt = DateTime.Parse(dr["ExpDate"].ToString()).ToString("MMM dd, yyyy"); } catch { }

        //        string tbl = " <div style='padding:10px; padding-top:0px;width:400px;' class='widget'> " +
        //            "&nbsp;<span class='wp-caption'>&nbsp;<b>PART INFO: " + dr["Name"].ToString() + "</b>&nbsp;</span><br><br> " +
        //            "&nbsp;&nbsp; <input type='button' value='clear' onclick=\"$('#divSupplyInfo').html('');\" /><br>" +
        //           " <table border='0' cellpadding='2' cellspacing='2' style='width:390px;' class='tbls'> " +
        //            "<tr><th style='width:150px;'>LOCATION: </th> <td>" + dr["Location"].ToString() + " </td> </tr>" +
        //            "<tr><th>DEPARTMENT:</th> <td>" + dr["Dept"].ToString() + " </td> </tr>" +
        //            "<tr><th>RACK No.</th> <td>" + dr["RackNo"].ToString() + " </td> </tr>" +
        //            "<tr><th>CARD No.</th> <td> " + dr["CardNo"].ToString() + "  </td> </tr>" +
        //            "<tr><th>PART No.</th> <td> " + dr["PartNo"].ToString() + " </td> </tr>" +
        //            "<tr><th>SERIAL No.</th> <td> " + dr["SerialNo"].ToString() + " </td> </tr>" +
        //            "<tr><th>PART NAME:</th> <td> " + dr["Name"].ToString() + "  </td> </tr>" +
        //            "<tr><th>QTY/DofQ</th> <td> " + dr["Qty"].ToString() + " " + dr["QtyUnits"].ToString() + " </td> </tr>" +
        //            "<tr><th>MFG. DATE:</th> <td>" + MfgDt + " </td> </tr>" +
        //            "<tr><th>EXP. DATE:</th> <td>" + ExpDt + " </td> </tr>" +
        //            "<tr valign='top'><th><span style='font-size:12px;'>Can be Used On Aircraft:</span></th> <td> " + 
        //              dr["UsedOnAircraft"].ToString() + "</td> </tr>" +
        //            "<tr><th>SUPPLIER: </th> <td>" + dr["Supplier"].ToString() + " </td> </tr>" +
        //            "<tr valign='top'><th>OTHER Info: </th> <td>" + dr["OtherInfo"].ToString() + " </td> </tr>" +
        //            "<tr><th>REG. BY: </th> <td>" + dr["RegBy"].ToString() + " </td> </tr>" +
        //            "<tr><th>REG. DATE: </th> <td>" + DateTime.Parse(dr["RegDate"].ToString()).ToString("MMM dd, yyyy hh:mm tt") +
        //            " </td> </tr>  </table> </div>";
        //        return tbl;
        //    }
        //    else
        //    {
        //        return "<font color='red'>Unknown Record...</font>";
        //    }
        //}

        //[WebMethod(EnableSession = true)]
        //public string getInvReceipt(string loc, string invNo)
        //{
        //    if (!UserSession.IsActive) return "<font color='red'>timeout, please login...</font>";
        //    int locId = 0, invId = 0;          try { locId = int.Parse(loc.Trim()); invId = int.Parse(invNo.Trim()); } catch { }
        //    Inventory obj = new Inventory();       DataTable tbl = new DataTable();
        //    tbl = obj.getInvoiceItems(locId, invId);
        //    if (tbl.Rows.Count < 1) return "<font color='red'>no record....</font>";
        //    DataRow dr1 = tbl.Rows[0];       string locName = dr1["Location"].ToString();

        //    string _tbl = " <div style='padding:10px; padding-top:0px;' class='widget'> " +
        //            "&nbsp;<span class='wp-caption'>&nbsp;<b>INVOICE: " + invNo + "</b>&nbsp;</span><br><br> " +
        //            "&nbsp;&nbsp; <input type='button' value='clear' onclick=\"$('#divSupplyInfo').html('');\" /><br>" +
        //            "<b>LOCATION:</b> " + locName + 
        //            "<br>  <table border='0' cellpadding='2' cellspacing='2' class='tbls'> " + 
        //        "<tr><th>S/N</th><th>DEPARTMENT</th><th>RACK</th><th>CARD No.</th><th> PART No.</th><th>PART NAME </th>  " +
        //        " <th>SERIAL</th><th> QTY/DofQ</th><th> MFG. DATE </th><th> EXP. DATE </th> </tr>"; int n = 0;
        //    foreach (DataRow dr in tbl.Rows)
        //    {
        //        n++;
        //        bool isMfg = false; try { isMfg = bool.Parse(dr["IsMfg"].ToString()); }catch { }
        //        bool isExp = false; try { isExp = bool.Parse(dr["IsExpiry"].ToString()); } catch { }
        //        string MfgDt = "", ExpDt = "";
        //        if (isMfg) try { MfgDt = DateTime.Parse(dr["MfgDate"].ToString()).ToString("MMM dd, yyyy"); } catch { }
        //        if (isExp) try { ExpDt = DateTime.Parse(dr["ExpDate"].ToString()).ToString("MMM dd, yyyy"); } catch { }

        //        _tbl += "<tr><td>" + n.ToString() + ". </td><td>" + dr["DEPT"].ToString() + "</td><td>" + dr["RackNo"].ToString() +
        //            " </td><td>" + dr["CardNo"].ToString() + "</td><td> " + dr["PartNo"].ToString() + " </td> " +
        //            " <td> " + dr["PartName"].ToString() + " </td> <td> " + dr["SerialNo"].ToString() + " </td> " +
        //            " <td> " + dr["Qty"].ToString() + " " + dr["QtyUnit"].ToString() + "<td> " +
        //            " <td> " + MfgDt + " </td><td> " + ExpDt + "</td> </tr>";
        //    }
        //    _tbl += "</table>";      return _tbl;
        //}
    }
   



    class Parts{
        public int ID { get; set; }
        public string Dept { get; set; }     public int deptId { get; set; }
        public string CardNo { get; set; }
        public string PartNo { get; set; }    public string Name { get; set; }
        public string Serial { get; set; }    public string Rack { get; set; }
        public int Qty { get; set; }          public string QtyUnits { get; set; }
        public bool  IsMfg { get; set; }      public DateTime MfgDate { get; set; }        
        public bool IsExp { get; set; }       public DateTime ExpDate { get; set; }

        public Parts(int id, int deptID, string dept, string card, string part, string name, string serial, 
            string rack,
            int qty, string qtyUnits, bool isMfg, DateTime  mfgDt, bool isExp, DateTime  expDt)
        {
            ID = id; deptId = deptID;       Dept = dept; CardNo = card; PartNo = part; Name = name;
            Serial = serial; Rack = rack;   Qty = qty; QtyUnits = qtyUnits;
            IsMfg = isMfg; MfgDate = mfgDt; IsExp = isExp; ExpDate = expDt;
        }

    } 

}
