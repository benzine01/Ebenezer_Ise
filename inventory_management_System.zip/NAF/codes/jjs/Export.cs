﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.IO;

using iTextSharp.text;
using iTextSharp.text.html;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;


/// <summary>
/// Summary description for Export
/// </summary>
public static class Export
{

    public static void PDF(GridView grdView, DataTable GridData, int[] hideColumns, string file_name)
    {
        //HttpContext.Current.HttpContext.Current.Response.Write();

        if (GridData == null) { HttpContext.Current.Response.Write("No Data to Export"); return; }
        try { for (int i = 0; i < grdView.Columns.Count; i++) grdView.Columns[i].Visible = true; }
        catch { }
        HttpContext.Current.Response.ContentType = "application/pdf";
        HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}.pdf", file_name));
        HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
        StringWriter sw = new StringWriter(); HtmlTextWriter hw = new HtmlTextWriter(sw);
        grdView.AllowPaging = false; grdView.DataSource = GridData; grdView.DataBind();
        for (int i = 0; i < hideColumns.Count(); i++) grdView.Columns[hideColumns[i]].Visible = false;

        grdView.RenderControl(hw); grdView.HeaderRow.Style.Add("width", "15%");
        grdView.HeaderRow.Style.Add("font-size", "12px"); grdView.Style.Add("text-decoration", "none");
        grdView.Style.Add("font-family", "Arial, Helvetica, sans-serif;");
        grdView.Style.Add("font-size", "8px");
        StringReader sr = new StringReader(sw.ToString()); Document pdfDoc = new Document(PageSize.A2.Rotate(), 10f, 10f, 10f, 5f);
        //var pdfDoc = new Document(PageSize.A4, 50, 50, 25, 25);
        HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
        var writer = PdfWriter.GetInstance(pdfDoc, HttpContext.Current.Response.OutputStream); pdfDoc.Open();

        //---------------------------------------------------------------
        Color color = new Color(2, 2, 5, 1); //color.B = 12; 
        var titleFont = FontFactory.GetFont("Arial", 18, Font.BOLD, color);
        var subTitleFont = FontFactory.GetFont("Arial", 14, Font.BOLD);
        var boldTableFont = FontFactory.GetFont("Arial", 12, Font.BOLD);
        var endingMessageFont = FontFactory.GetFont("Arial", 10, Font.ITALIC);
        var bodyFont = FontFactory.GetFont("Arial", 12, Font.NORMAL);       // Add the "Northwind Traders Receipt" title
        pdfDoc.Add(new Paragraph("Northwind Traders Receipt", titleFont));
        // Now add the "Thank you for shopping at Northwind Traders. Your order details are below." message
        pdfDoc.Add(new Paragraph("Thank you for shopping at Northwind Traders. Your order details are below.", bodyFont));
        pdfDoc.Add(Chunk.NEWLINE);
        pdfDoc.Add(new Paragraph("Order Information", subTitleFont));
        pdfDoc.Add(Chunk.NEWLINE);
        var endingMessage = new Paragraph("Thank you for your business! Iontact us at 800-555-NORTH.", endingMessageFont);
        endingMessage.SetAlignment("Center"); pdfDoc.Add(endingMessage);
        // Finally, add an image in the upper right corner
        // var logo = iTextSharp.text.Image.GetInstance(HttpContext.Current.Server.MapPath("~/images/1.jpg"));
        // logo.SetAbsolutePosition(440, 800); pdfDoc.Add(logo); //logo.SetAbsolutePosition(440, 800);    
        //-------------------------------------------------------------------------------------------------------
        //var pdfDoc = new Document(PageSize.A4, 50, 50, 25, 25); var output = new MemoryStream();
        //var writer = PdfWriter.GetInstance(pdfDoc, output); pdfDoc.Open();
        string file_html = "<table><tr><td>Testing HTML</td><td>Second Cell</td></table><hr /> James Lugard";
        // Read in the contents of the Receipt.htm HTML template file
        //string contents = File.ReadAllText(Server.MapPath("~/HTMLTemplate/Receipt.htm"));
        var parsedHtmlElements = HTMLWorker.ParseToList(new StringReader(file_html), null);
        foreach (var htmlElement in parsedHtmlElements) pdfDoc.Add(htmlElement as IElement);
        //------------------------------------------------------------------------------------------------------
        htmlparser.Parse(sr); pdfDoc.Close(); HttpContext.Current.Response.Write(pdfDoc); HttpContext.Current.Response.End();
    }

    public static void PDF(GridView grdView, DataTable GridData, int[] hideColumns, string file_name, string headerText, string footerText)
    {
        //HttpContext.Current.HttpContext.Current.Response.Write();

        if (GridData == null) { HttpContext.Current.Response.Write("No Data to Export"); return; }
        try { for (int i = 0; i < grdView.Columns.Count; i++) grdView.Columns[i].Visible = true; }
        catch { }
        HttpContext.Current.Response.ContentType = "application/pdf";
        HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}.pdf", file_name));
        HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
        StringWriter sw = new StringWriter(); HtmlTextWriter hw = new HtmlTextWriter(sw);
        grdView.AllowPaging = false; grdView.DataSource = GridData; grdView.DataBind();
        for (int i = 0; i < hideColumns.Count(); i++) grdView.Columns[hideColumns[i]].Visible = false;

        grdView.RenderControl(hw); grdView.HeaderRow.Style.Add("width", "15%");
        grdView.HeaderRow.Style.Add("font-size", "12px"); grdView.Style.Add("text-decoration", "none");
        grdView.Style.Add("font-family", "Arial, Helvetica, sans-serif;");
        grdView.Style.Add("font-size", "8px");
        StringReader sr = new StringReader(sw.ToString());
        Document pdfDoc = new Document(PageSize.A4, 50, 50, 25, 25);
        //var pdfDoc = new Document(PageSize.A2.Rotate(), 10f, 10f, 10f, 5f);
        HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
        var writer = PdfWriter.GetInstance(pdfDoc, HttpContext.Current.Response.OutputStream); pdfDoc.Open();

        //---------------------------------------------------------------
        Color color = new Color(2, 2, 5, 1); //color.B = 12; 
        var titleFont = FontFactory.GetFont("Arial", 18, Font.BOLD, color);
        var subTitleFont = FontFactory.GetFont("Arial", 14, Font.BOLD);
        var boldTableFont = FontFactory.GetFont("Arial", 12, Font.BOLD);
        var endingMessageFont = FontFactory.GetFont("Arial", 10, Font.ITALIC);
        var bodyFont = FontFactory.GetFont("Arial", 12, Font.NORMAL);       // Add the "Northwind Traders Receipt" title
        pdfDoc.Add(new Paragraph(headerText, titleFont));
        // Now add the "Thank you for shopping at Northwind Traders. Your order details are below." message
        pdfDoc.Add(new Paragraph("Thank you for shopping at Northwind Traders. Your order details are below.", bodyFont));
        pdfDoc.Add(Chunk.NEWLINE);
        pdfDoc.Add(new Paragraph("Order Information", subTitleFont));
        pdfDoc.Add(Chunk.NEWLINE);
        var endingMessage = new Paragraph("Thank you for your business! Iontact us at 800-555-NORTH.", endingMessageFont);
        endingMessage.SetAlignment("Center"); pdfDoc.Add(endingMessage);
        // Finally, add an image in the upper right corner
        // var logo = iTextSharp.text.Image.GetInstance(HttpContext.Current.Server.MapPath("~/images/1.jpg"));
        // logo.SetAbsolutePosition(440, 800); pdfDoc.Add(logo); //logo.SetAbsolutePosition(440, 800);    
        //-------------------------------------------------------------------------------------------------------
        //var pdfDoc = new Document(PageSize.A4, 50, 50, 25, 25); var output = new MemoryStream();
        //var writer = PdfWriter.GetInstance(pdfDoc, output); pdfDoc.Open();
        string file_html = footerText; // "<table><tr><td>Testing HTML</td><td>Second Cell</td></table><hr /> James Lugard";
        // Read in the contents of the Receipt.htm HTML template file
        //string contents = File.ReadAllText(Server.MapPath("~/HTMLTemplate/Receipt.htm"));
        var parsedHtmlElements = HTMLWorker.ParseToList(new StringReader(file_html), null);
        foreach (var htmlElement in parsedHtmlElements) pdfDoc.Add(htmlElement as IElement);
        //------------------------------------------------------------------------------------------------------
        htmlparser.Parse(sr); pdfDoc.Close(); HttpContext.Current.Response.Write(pdfDoc); HttpContext.Current.Response.End();
    }


    public static void EXCEL(GridView grdView, DataTable GridData, int[] hideColumns, string file_name)
    {
        if (GridData == null) { HttpContext.Current.Response.Write("No Data to Export"); return; }
        try { for (int i = 0; i < grdView.Columns.Count; i++) grdView.Columns[i].Visible = true; }
        catch { }

        HttpContext.Current.Response.ClearContent(); HttpContext.Current.Response.Buffer = true;
        HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}.xls", file_name));
        HttpContext.Current.Response.ContentType = "application/ms-excel";
        StringWriter sw = new StringWriter(); HtmlTextWriter htw = new HtmlTextWriter(sw);
        grdView.AllowPaging = false; grdView.ShowFooter = false; grdView.DataSource = GridData; grdView.DataBind();
        for (int i = 0; i < hideColumns.Count(); i++) grdView.Columns[hideColumns[i]].Visible = false;


        grdView.HeaderRow.Style.Add("background-color", "#FFFFFF");//Change the Header Row back to white color
        //Applying stlye to gridview header cells
        for (int i = 0; i < grdView.HeaderRow.Cells.Count; i++)
            grdView.HeaderRow.Cells[i].Style.Add("background-color", "#CFFFFF");
        int j = 1;
        //This loop is used to apply stlye to cells based on particular row
        foreach (GridViewRow gvrow in grdView.Rows)
        {      //gvrow.BackColor = Color.White;
            if (j <= grdView.Rows.Count)
            {
                if (j % 2 != 0)
                {
                    for (int k = 0; k < gvrow.Cells.Count; k++) { gvrow.Cells[k].Style.Add("background-color", "#AFF3FF"); }
                }
            } j++;
        }
        grdView.RenderControl(htw); HttpContext.Current.Response.Write(sw.ToString()); HttpContext.Current.Response.End();
    }
    public static void EXCEL(GridView grdView, string hideColumns, string file_name)
    {
        if (grdView == null) { HttpContext.Current.Response.Write("No Data to Export"); return; }
        try { for (int i = 0; i < grdView.Columns.Count; i++) grdView.Columns[i].Visible = true; }
        catch { }

        grdView.AllowPaging = false; grdView.DataBind();
        if (hideColumns.Contains(','))
        {
            string[] hideCols = hideColumns.Split(',');
            foreach (string cols in hideCols)
            {
                int col = -1; try { col = int.Parse(cols); }
                catch { }
                if (col > -1) { grdView.Columns[col].Visible = false; }
            }
        }
        else if (hideColumns.Length > 0)
        {
            int col = -1; try { col = int.Parse(hideColumns); }
            catch { }
            if (col > -1) { grdView.Columns[col].Visible = false; }
        }
        HttpContext.Current.Response.ClearContent(); HttpContext.Current.Response.Buffer = true;
        HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}.xls", file_name));
        HttpContext.Current.Response.ContentType = "application/ms-excel";
        StringWriter sw = new StringWriter(); HtmlTextWriter htw = new HtmlTextWriter(sw);
        grdView.AllowPaging = false; grdView.DataBind();

        grdView.HeaderRow.Style.Add("background-color", "#FFFFFF");//Change the Header Row back to white color
        //Applying stlye to gridview header cells
        for (int i = 0; i < grdView.HeaderRow.Cells.Count; i++)
            grdView.HeaderRow.Cells[i].Style.Add("background-color", "#CFFFFF");
        int j = 1;
        //This loop is used to apply stlye to cells based on particular row
        foreach (GridViewRow gvrow in grdView.Rows)
        {            //gvrow.BackColor = Color.White;
            if (j <= grdView.Rows.Count)
            {
                if (j % 2 != 0)
                {
                    for (int k = 0; k < gvrow.Cells.Count; k++) { gvrow.Cells[k].Style.Add("background-color", "#AFF3FF"); }
                }
            } j++;
        }
        grdView.RenderControl(htw); HttpContext.Current.Response.Write(sw.ToString()); HttpContext.Current.Response.End();
    }

    public static void WORD(GridView grdView, DataTable GridData, int[] hideColumns, string file_name, string HeaderText)
    {
        if (GridData == null) { HttpContext.Current.Response.Write("No Data to Export"); return; }
        try { for (int i = 0; i < grdView.Columns.Count; i++) grdView.Columns[i].Visible = true; }
        catch { }
        grdView.AllowPaging = false; grdView.ShowFooter = false; grdView.DataSource = GridData; grdView.DataBind();
        for (int i = 0; i < hideColumns.Count(); i++) grdView.Columns[hideColumns[i]].Visible = false;

        HttpContext.Current.Response.ClearContent();
        HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}.doc", file_name));
        HttpContext.Current.Response.Charset = ""; HttpContext.Current.Response.ContentType = "application/ms-word";
        StringWriter sw = new StringWriter(); HtmlTextWriter htw = new HtmlTextWriter(sw);
        grdView.RenderControl(htw); HttpContext.Current.Response.Write(HeaderText + sw.ToString());
        HttpContext.Current.Response.End();
    }
    public static void WORD(GridView grdView, string hideColumns, string file_name, string HeaderText)
    {
        if (grdView == null) { HttpContext.Current.Response.Write("No Data to Export"); return; }
        try { for (int i = 0; i < grdView.Columns.Count; i++) grdView.Columns[i].Visible = true; }
        catch { }
        grdView.AllowPaging = false; grdView.ShowFooter = true; grdView.DataBind();
        if (hideColumns.Contains(','))
        {
            string[] hideCols = hideColumns.Split(',');
            foreach (string cols in hideCols)
            {
                int col = -1; try { col = int.Parse(cols); }
                catch { } if (col > -1) { grdView.Columns[col].Visible = false; }
            }
        }
        else if (hideColumns.Length > 0)
        {
            int col = -1; try { col = int.Parse(hideColumns); }
            catch { } if (col > -1) { grdView.Columns[col].Visible = false; }
        }
        HttpContext.Current.Response.ClearContent();
        HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}.doc", file_name));
        HttpContext.Current.Response.Charset = ""; HttpContext.Current.Response.ContentType = "application/ms-word";
        StringWriter sw = new StringWriter(); HtmlTextWriter htw = new HtmlTextWriter(sw);
        grdView.RenderControl(htw); HttpContext.Current.Response.Write(HeaderText + sw.ToString());
        HttpContext.Current.Response.End();
    }

}