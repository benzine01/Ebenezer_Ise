﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.IO;


public class Users
{
    public Users() {
        try { this.setEmailSMSsettings(); } catch { }
    }

    private SqlConnection _conn = new SqlConnection(Connect.CONN());
    public string _error;

    public bool LoginUser(string UserName, string PWD)
    {
        if (this.CountUsers() < 1)
        {
            try
            {
                this._conn.Open();
                if (this._conn.State == ConnectionState.Open)
                {
                    this._conn.Close(); this.IsFirstAdmin(); return true;
                }
                else
                {
                    _error = "<font color='red'>Please check your database connection...</font>"; return false;
                }
            }
            catch { _error = "<font color='red'>Please check your database connection...</font>"; return false; }            
        }
        else
        {
            string sql = "SELECT u.*, l.Name AS Location FROM Users u, invLocation l " +
                " WHERE BINARY_CHECKSUM(u.UserNm) = BINARY_CHECKSUM(@userNm) AND " +
                " BINARY_CHECKSUM(u.PWD) = BINARY_CHECKSUM(@pwd) AND l.ID = u.LocationID ";
            SqlCommand cmd = new SqlCommand(sql, this._conn); cmd.Parameters.AddWithValue("@userNm", UserName);
            cmd.Parameters.AddWithValue("@pwd", PWD);
            SqlDataReader dr = null; int n = 0; bool isLocked = true; string stfNm = "";
            try
            {
                this._conn.Open(); dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    n++;
                    bool isActive = false; try { isActive = bool.Parse(dr["IsActive"].ToString()); }  catch { }
                    if (isActive)
                    {
                        isLocked = false;
                        string idno = "", phone = "", location = "", lastLogDt = "";
                        int locId = 0, levId = 0; bool isAllowAdd = false, isAllowIssue = false, allowAirStatus = false;    
                        int userId = 0;
                        
                        idno = dr["IDNo"].ToString();                        stfNm = dr["StaffName"].ToString();
                        locId = int.Parse(dr["LocationID"].ToString());      location = dr["Location"].ToString();
                        phone = dr["Phone"].ToString();                      levId = int.Parse(dr["LevID"].ToString());
                        try { isAllowAdd = bool.Parse(dr["AllowInvAdd"].ToString()); } catch { }
                        try { isAllowIssue = bool.Parse(dr["AllowInvIssue"].ToString()); } catch { }
                        try { allowAirStatus = bool.Parse(dr["AllowAircraftStatus"].ToString()); } catch { }
                        try { userId = int.Parse(dr["ID"].ToString()); UserSession.UserId = userId; } catch { }

                        try
                        {
                            lastLogDt = DateTime.Parse(dr["LastLoginDate"].ToString()).ToString("MMM dd, yyyy hh:mm:ss tt");
                        }
                        catch { }
                        UserSession.SetUserInfo(idno, stfNm, locId, location, UserName, PWD, phone, levId,
                            isAllowAdd, isAllowIssue, allowAirStatus, lastLogDt);
                    }
                }
            }
            catch (Exception ex) { _error = ex.Message; }
            finally { this._conn.Close(); }

            bool return_valu = false;
            if (n < 1) this._error += "<br><font color='red'>Wrong Username/Passowrd... </font>";
            else if (n > 0 && isLocked)
                this._error += "<br>" + stfNm + " your account is <font color='red'> locked contact admin... </font>";
            else if (n > 0 && !isLocked)
            {
                this._error += "<br>Successfully Logged in..."; return_valu = true;
            }
            return return_valu;
        }
    }


    private void IsFirstAdmin()
    {
        //  SetUserInfo(string idno, string stfNm, int locID, string location, string userNm, string pwd, 
        //string phone, int levId, bool allowAdd, bool allowIssue, string lastLoginDt)
        UserSession.SetUserInfo("SuperUser", "Super Admin", 0, "", "admin1", "", "", 1, false, false, true, "");
        UserSession.IsFirstUser = true;
    }

    private int CountUsers()
    {
        string sql = "SELECT COUNT(ID) FROM Users ";
        SqlCommand cmd = new SqlCommand(sql, this._conn); int nUsers = 0;
        try
        {
            this._conn.Open(); nUsers = int.Parse(cmd.ExecuteScalar().ToString());
        }
        catch (Exception ex) { this._error = ex.Message; }
        finally { this._conn.Close(); } return nUsers;
    }


    public bool SetUser(string IDNo, string stfName, int locID, string userNm, string pwd, string phone, int levId,
         bool isAdd, bool isIssue, bool allowAircraftStatus, string RegBy)
    {
        if (this.IsUserNameExist(userNm))
        {
            this._error = "Username already used..."; return false;
        }
        else
        {
            string sql = "INSERT INTO Users(IDNo,StaffName,LocationID,UserNm,PWD,Phone,LevID, " +
                " IsActive,AllowInvAdd,AllowInvIssue,AllowAircraftStatus,RegBy,RegDt) " +
                " VALUES(@IDNo,@StfName,@LocID,@UserNm,@PWD,@Phone,@LevID,@IsActive,@AllowAdd,@AllowIssue," +
                " @allowAirStatus,@RegBy,@RegDt) ";
            SqlCommand cmd = new SqlCommand(sql, this._conn);
            cmd.Parameters.AddWithValue("@IDNo", IDNo); cmd.Parameters.AddWithValue("@StfName", stfName);
            cmd.Parameters.AddWithValue("@LocID", locID); cmd.Parameters.AddWithValue("@UserNm", userNm);
            cmd.Parameters.AddWithValue("@PWD", pwd); cmd.Parameters.AddWithValue("@Phone", phone);
            cmd.Parameters.AddWithValue("@LevID", levId); cmd.Parameters.AddWithValue("@IsActive", true);
            cmd.Parameters.AddWithValue("@AllowAdd", isAdd); cmd.Parameters.AddWithValue("@AllowIssue", isIssue);
            cmd.Parameters.AddWithValue("@allowAirStatus", allowAircraftStatus);
            cmd.Parameters.AddWithValue("@RegBy", RegBy); cmd.Parameters.AddWithValue("@RegDt", DateTime.Now); int added = 0;
            try
            {
                this._conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString());
            }
            catch (Exception ex) { this._error = ex.Message; }
            finally { this._conn.Close(); }
            return (added > 0) ? true : false;
        }
    }

    private DataTable GetUserTBL(string userName)
    {
        string sql = "SELECT * FROM Users WHERE UserNm = @user ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn);
        dr.SelectCommand.Parameters.AddWithValue("@user", userName);
        DataSet dtSet = new DataSet();
        dr.Fill(dtSet, "TBL"); this._conn.Close(); return dtSet.Tables["TBL"];
    }
    private DataTable GetUserTBL(string userName, string IDNo)
    {
        string sql = "SELECT * FROM Users WHERE UserNm = @user AND IDNo = @idNo ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn);
        dr.SelectCommand.Parameters.AddWithValue("@user", userName);
        dr.SelectCommand.Parameters.AddWithValue("@idNo", IDNo);     DataSet dtSet = new DataSet();
        dr.Fill(dtSet, "TBL"); this._conn.Close(); return dtSet.Tables["TBL"];
    }


    public bool DeleteUser(string IDNo)
    {
        string sql = "DELETE FROM Users WHERE IDNo = @id "; SqlCommand Qry = new SqlCommand(sql, this._conn);
        Qry.Parameters.AddWithValue("@id", IDNo); int deleted = 0;
        try { this._conn.Open(); deleted = int.Parse(Qry.ExecuteNonQuery().ToString()); }
        catch (Exception err) { _error = err.Message; }
        finally { this._conn.Close(); } return (deleted > 0) ? true : false;
    }

    public bool IsUserNameExist(string UserName)
    {
        string sql = "SELECT COUNT(ID) FROM Users WHERE UserNm = @user ";
        SqlCommand cmd = new SqlCommand(sql, this._conn); cmd.Parameters.AddWithValue("@user", UserName);
        int isExist = 0;
        try
        {
            this._conn.Open(); isExist = int.Parse(cmd.ExecuteScalar().ToString());
        }
        catch (Exception ex) { this._error = ex.Message; }
        finally { this._conn.Close(); }
        return (isExist > 0) ? true : false;
    }

    public bool changeUserNm(int userId, string newUserNm)
    {
        string sql = "UPDATE Users SET UserNm = @usernm WHERE ID = @id ";
        SqlCommand cmd = new SqlCommand(sql, this._conn);
        cmd.Parameters.AddWithValue("@usernm", newUserNm); cmd.Parameters.AddWithValue("@id", userId); int updated = 0;
        try
        {
            this._conn.Open(); updated = int.Parse(cmd.ExecuteNonQuery().ToString());
        }
        catch (Exception err) { _error = err.Message; }
        finally { this._conn.Close(); }
        return (updated > 0) ? true : false;
    }

    public bool changePWD(int userId, string newPWD)
    {
        string sql = "UPDATE Users SET PWD = @pwd WHERE ID = @id ";
        SqlCommand cmd = new SqlCommand(sql, this._conn); cmd.Parameters.AddWithValue("@pwd", newPWD);
        cmd.Parameters.AddWithValue("@id", userId); int updated = 0;
        try
        {
            this._conn.Open(); updated = int.Parse(cmd.ExecuteNonQuery().ToString());
        }
        catch (Exception err) { _error = err.Message; }
        finally { this._conn.Close(); } return (updated > 0) ? true : false;
    }


    public static string ForgotPassword(string UserName, string IDNo)
    {
        Users obj = new Users();
        DataTable TBL = new DataTable();    try { TBL = obj.GetUserTBL(UserName, IDNo); } catch { }
        if (TBL.Rows.Count > 0)
        {
            string phone = "", pwd = "";
            try { phone = TBL.Rows[0]["Phone"].ToString(); } catch { }
            try { pwd = TBL.Rows[0]["PWD"].ToString(); } catch { }
            string sms_msg = "NAF Login Details, Username: " + UserName + ", Password: " + pwd + " Phone:" + phone;
            try
            {
                SMS.SendSMS("NAF LOGIN", phone, sms_msg);             return " Successfully Send SMS to your phone...";
            }
            catch (Exception ex)
            {
                return "<font color='red'> " + ex.Message + " </font>";
            }
            
        }
        else
            return "<font color='red'>Wrong Username/IDNo...</font>";
    }

    public static string generatePWD(int nStrs)
    {
        string xters = "-*=?(>)<"; string numbs = "123456789";
        string letters = "qwertyuipkjhgfdsazxcvbnmQWERTYUIPLKJHGFDSAZXCVBNM";
        string pwd = ""; Random rnd = new Random();
        while (pwd.Length < (nStrs - 2)) { int index = rnd.Next(0, letters.Length - 1); pwd += (letters.Substring(index, 1)); }
        pwd += (xters.Substring(rnd.Next(0, xters.Length - 1), 1));
        pwd += (numbs.Substring(rnd.Next(0, xters.Length - 1), 1)); return pwd;
    }


    //=================== EMAIL SMS SETTINGS =========================
    //=================== EMAIL SMS SETTINGS =========================
    //=================== EMAIL SMS SETTINGS =========================
    public bool setEmailSettings(string server, int port, string email, string pwd, string display)
    {
        this.setEmailSMSsettings();
        string sql = "UPDATE emailSMSsetting SET SmtpServer = @server, SmtpPort = @port, SmtpEmail = @email, SmtpPWD = @pwd, " +
            " SmtpDisplay = @display "; SqlCommand cmd = new SqlCommand(sql, this._conn);
        cmd.Parameters.AddWithValue("@server", server); cmd.Parameters.AddWithValue("@port", port);
        cmd.Parameters.AddWithValue("@email", email); cmd.Parameters.AddWithValue("@pwd", pwd);
        cmd.Parameters.AddWithValue("@display", display); int updated = 0;
        try { this._conn.Open(); updated = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { this._error = ex.Message; }
        finally { this._conn.Close(); } return (updated > 0) ? true : false;
    }
    public bool setSmsSettings(string title, string sesID)
    {
        this.setEmailSMSsettings();
        string sql = "UPDATE emailSMSsetting SET SmsTitle = @title, SmsSesID = @sesID ";
        SqlCommand cmd = new SqlCommand(sql, this._conn);
        cmd.Parameters.AddWithValue("@title", title); cmd.Parameters.AddWithValue("@sesID", sesID);
        int updated = 0;
        try { this._conn.Open(); updated = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { this._error = ex.Message; }
        finally { this._conn.Close(); } return (updated > 0) ? true : false;
    }
    public bool setCalendarInspMth(int mth)
    {
        this.setEmailSMSsettings();
        string sql = "UPDATE emailSMSsetting SET calendarInspMth = @mth ";
        SqlCommand cmd = new SqlCommand(sql, this._conn);  cmd.Parameters.AddWithValue("@mth", mth); 
        int updated = 0;
        try { this._conn.Open(); updated = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { this._error = ex.Message; }
        finally { this._conn.Close(); } return (updated > 0) ? true : false;
    }
    public DataTable getEmailSmsTBL()
    {
        string sql = "SELECT * FROM emailSMSsetting "; SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn);
        DataTable tbl = new DataTable(); dr.Fill(tbl); this._conn.Close(); return tbl;
    }
    private int countEmailSmsSettings() { return this.getEmailSmsTBL().Rows.Count; }
    private void setEmailSMSsettings()
    {
        if (this.countEmailSmsSettings() > 0) return;
        string sql = "INSERT INTO emailSMSsetting(SmtpServer,SmtpPort,SmtpEmail,SmtpPWD,SmtpDisplay,SmsTitle,SmsSesID, " +
            " calendarInspMth) VALUES(@server,@port,@email,@pwd,@display,@title,@sesID,@mth) ";
        SqlCommand cmd = new SqlCommand(sql, this._conn);
        cmd.Parameters.AddWithValue("@server", ""); cmd.Parameters.AddWithValue("@port", 0);
        cmd.Parameters.AddWithValue("@email", ""); cmd.Parameters.AddWithValue("@pwd", "");
        cmd.Parameters.AddWithValue("@display", "");
        cmd.Parameters.AddWithValue("@title", ""); cmd.Parameters.AddWithValue("@sesID", "");
        cmd.Parameters.AddWithValue("@mth", 0);
        try { this._conn.Open(); cmd.ExecuteNonQuery().ToString(); }
        catch (Exception ex) { this._error = ex.Message; }
        finally { this._conn.Close(); }
    }

    //=====================  SMS & EMAIL ALERTS ================
    //=====================  SMS & EMAIL ALERTS ================
    //=====================  SMS & EMAIL ALERTS ================
    public bool setEmailSMSalert(int typId, int locId, int deptId, string title, string msg)
    {
        DateTime dt = DateTime.Now;
       // if (this.getEmailSMSalertTBL(typId, locId, deptId, title, msg, dt).Rows.Count > 0) return true;
        string sql = "INSERT INTO emailSMSalerts(typId,locId,deptId,title,msg,regDate) " +
            " VALUES(@typId,@locId,@deptId,@title,@msg,@dt) ";
        SqlCommand cmd = new SqlCommand(sql, this._conn); int added = 0;
        cmd.Parameters.AddWithValue("@typId", typId);       cmd.Parameters.AddWithValue("@locId", locId);
        cmd.Parameters.AddWithValue("@deptId", deptId);     cmd.Parameters.AddWithValue("@title", title);
        cmd.Parameters.AddWithValue("@msg", msg);           cmd.Parameters.AddWithValue("@dt", dt);
        try { this._conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { this._error = ex.Message; }  finally { this._conn.Close(); }
        return (added > 0) ? true : false;
    }

    public DataTable getEmailSMSalertTBL(int typId, int locId, int deptId, string title, string msg, DateTime dt)
    {
        string sql = "SELECT * FROM emailSMSalerts WHERE typId = @typId AND locId = @locId AND deptId = @deptId " +
         " AND title = @title AND msg = @msg AND cast(CONVERT(varchar(8), regDate, 112) AS datetime) = @Dt ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn);
        dr.SelectCommand.Parameters.AddWithValue("@typId", typId);      dr.SelectCommand.Parameters.AddWithValue("@locId", locId);
        dr.SelectCommand.Parameters.AddWithValue("@deptId", deptId);    dr.SelectCommand.Parameters.AddWithValue("@title", title);
        dr.SelectCommand.Parameters.AddWithValue("@msg", msg);          dr.SelectCommand.Parameters.AddWithValue("@Dt", dt);       
        DataTable tbl = new DataTable();  try { dr.Fill(tbl); this._conn.Close(); } catch { } return tbl;
    }

    public bool isEmailSMSalertSent(int typId) {
        return (this.getEmailSMSalertTBL(typId).Rows.Count > 0) ? true : false;
    }
    public DataTable getEmailSMSalertTBL(int typId)
    {
        DateTime dt = new DateTime(); dt = DateTime.Now;
        string sql = "SELECT * FROM emailSMSalerts WHERE typId = @typ AND " +
            " YEAR(regDate) = @yr AND MONTH(regDate) = @mth AND DAY(regDate) = @day  ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); DataTable tbl = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@typ", typId);     dr.SelectCommand.Parameters.AddWithValue("@yr", dt.Year);
        dr.SelectCommand.Parameters.AddWithValue("@mth", dt.Month);  dr.SelectCommand.Parameters.AddWithValue("@day", dt.Day);  
        try { dr.Fill(tbl); this._conn.Close(); }  catch { } return tbl;
    }
    public DataTable getEmailSMSalertTBL(int typId, DateTime fromDt, DateTime toDate)
    {
        string sql = "SELECT * FROM emailSMSalerts WHERE typId = @typ AND " +
            " cast(CONVERT(varchar(8), regDate, 112) AS datetime) >= @fromDt AND " +
            " cast(CONVERT(varchar(8), regDate, 112) AS datetime) <= @toDt ORDER BY deptId ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn);    DataTable tbl = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@typ", typId);    dr.SelectCommand.Parameters.AddWithValue("@fromDt", fromDt); 
        dr.SelectCommand.Parameters.AddWithValue("@toDt", toDate);  try { dr.Fill(tbl); this._conn.Close(); }   catch { } return tbl;
    }


    public DataTable getLedgerDueReordeCritExpiryTBL()
    {
        DateTime dt = DateTime.Now.AddMonths(1);
        string sql = "SELECT l.ID, l.Name," +
            " (SELECT COUNT(ID) FROM invLedger WHERE (ExpDate <= @dt AND IsExpiry = @isExp AND Qty > @zero) AND LocationID = l.ID) " +
            "  AS nExpiry, " +
            " (SELECT COUNT(ID) FROM invLedger WHERE CriticalQty >= Qty AND LocationID = l.ID) AS nCritical, " +
            " (SELECT COUNT(ID) FROM invLedger WHERE ReorderQty >= Qty AND LocationID = l.ID) AS nReorder FROM invLocation l " +
            " ORDER BY l.Name ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn);  
        dr.SelectCommand.Parameters.AddWithValue("@dt", dt); dr.SelectCommand.Parameters.AddWithValue("@isExp", true);
        dr.SelectCommand.Parameters.AddWithValue("@zero", 0); DataTable tbl = new DataTable(); 
        try { dr.Fill(tbl); this._conn.Close(); } catch { } return tbl;
    }
     
    public static void sendInventoryDueAlert()
    {
        Users obj = new Users();       if (obj.isEmailSMSalertSent(1) == true) return;

        DataTable locLedgQtyTBL = obj.getLedgerDueReordeCritExpiryTBL();
        string alertSMSMsgs = "", alertEmailMsgs = ""; int kAlerts = 0;
        foreach (DataRow dr in locLedgQtyTBL.Rows)
        {
            int locId = 0, nExp = 0, nCrit = 0, nReorder = 0;             string locName = "";
            try { locId = int.Parse(dr["ID"].ToString()); } catch { }     locName = dr["Name"].ToString();
            try { nExp = int.Parse(dr["nExpiry"].ToString()); } catch { }
            try { nCrit = int.Parse(dr["nCritical"].ToString()); } catch { }
            try { nReorder = int.Parse(dr["nReorder"].ToString()); } catch { }
            string alertMsg = "";
            if (nExp > 0 || nCrit > 0 || nReorder > 0)
            {
                alertMsg = "LOC:" + locName + ", Exp:" + nExp.ToString() + ", Crit:" + nCrit.ToString() +
                     ", Re-Ord:" + nReorder.ToString();
                alertSMSMsgs += alertMsg + ".  "; alertEmailMsgs += alertMsg + "<br>";

                DataTable phoneEmailTBL = new DataTable(); try { phoneEmailTBL = obj.getEmailPhonesTBL(1, locId); } catch { }
                string phone = "", email = ""; 
                try { phone = phoneEmailTBL.Rows[0]["phones"].ToString(); } catch { }
                try { email = phoneEmailTBL.Rows[0]["emails"].ToString(); } catch { }
                try {
                    Mailer.sendSMS("NAF.INVTRY.", phone, alertMsg);  Mailer.sendEmail(email, "NAF INVENTORY ALERT", alertMsg);
                    if (Mailer.IsSmsSent || Mailer.IsEmailSent) kAlerts++;
                } catch { }
            }
        }
        //setEmailSMSalert(int typId, int locId, int deptId, string title, string msg)
        DataTable phoneEmailTBLs = new DataTable(); try { phoneEmailTBLs = obj.getEmailPhonesTBL(1, 0); } catch { }
        string phones = "", emails = "";  
        try { phones = phoneEmailTBLs.Rows[0]["phones"].ToString(); } catch { }
        try { emails = phoneEmailTBLs.Rows[0]["emails"].ToString(); } catch { }
        try
        {
            Mailer.sendSMS("NAF.INVTRY.", phones, alertSMSMsgs);
            Mailer.sendEmail(emails, "NAF INVENTORY ALERT", alertEmailMsgs);
            if (Mailer.IsSmsSent || Mailer.IsEmailSent) kAlerts++;
        }
        catch { }
        if (kAlerts > 0) obj.setEmailSMSalert(1, 0, 0, "NAF.INVTRY", (alertSMSMsgs + " Phones: " + phones));
    }

    /*1 	1	0	0	07030378600	keltangs@gmail.com */
    //====================== SMS PHONES Numbers ======================
    public bool setEmailPhoneNos(int typId, int locId, int deptId, string phones, string emails)
    {
        string sql = "";
        if (this.getEmailPhonesTBL(typId, locId).Rows.Count > 0)
            sql = "UPDATE emailPhoneNos SET phones = @phones, emails = @emails WHERE typId = @typ AND locId = @loc AND deptId = @dept";
        else 
            sql = "INSERT INTO emailPhoneNos(typId,locId,deptId,phones,emails) VALUES(@typ,@loc,@dept,@phones,@emails) ";
        SqlCommand cmd = new SqlCommand(sql, this._conn);
        cmd.Parameters.AddWithValue("@typ", typId);      cmd.Parameters.AddWithValue("@loc", locId);
        cmd.Parameters.AddWithValue("@dept", deptId);    cmd.Parameters.AddWithValue("@phones", phones);
        cmd.Parameters.AddWithValue("@emails", emails);  int added = 0;
        try { this._conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { this._error = ex.Message; } finally { this._conn.Close(); }    return (added > 0) ? true : false;
    }

    public DataTable getEmailPhonesTBL(int typId, int locId, int deptId)
    {
        string sql = "SELECT * FROM emailPhoneNos WHERE typId = @typ AND locId = @loc AND deptId = @dept";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn);    dr.SelectCommand.Parameters.AddWithValue("@typ", typId);
        dr.SelectCommand.Parameters.AddWithValue("@loc", locId);    dr.SelectCommand.Parameters.AddWithValue("@dept", deptId);
        DataTable tbl = new DataTable(); try { dr.Fill(tbl); this._conn.Close(); } catch { } return tbl;
    }
    public DataTable getEmailPhonesTBL(int typId, int locId)
    {
        string sql = "SELECT * FROM emailPhoneNos WHERE typId = @typ AND locId = @loc ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); dr.SelectCommand.Parameters.AddWithValue("@typ", typId);
        dr.SelectCommand.Parameters.AddWithValue("@loc", locId); 
        DataTable tbl = new DataTable(); try { dr.Fill(tbl); this._conn.Close(); }        catch { } return tbl;
    }

}