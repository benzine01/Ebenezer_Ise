﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

public class UserSession
{

    public static string getEmailSMStyp(string typId)
    {
        int _typId = 0;    try { _typId = int.Parse(typId.Trim()); } catch { }
        string[] types = { "", "Inventory", "Aircraft Status" };     return types[_typId];
    }

    public static string GetLevel(int levId) { return UserSession.GetUserLevels()[levId]; }
    public static string[] GetUserLevels()
    {
        string[] _users = { "", "Administrator", "Super User", "User" }; return _users;
    }

    public static void SetUserInfo(string idno, string stfNm, int locID, string location, string userNm, string pwd,
        string phone, int levId, bool allowAdd, bool allowIssue, bool allowAircraftStatus, string lastLoginDt)
    {
        IsActive = true; IDNo = idno; Name = stfNm; LocationID = locID; Location = location;
        UserName = userNm; PWD = pwd; Phone = phone; LevID = levId; Level = GetLevel(levId);
        IsAllowAdd = allowAdd; IsAllowIssue = allowIssue; IsAllowAircraftStatus = allowAircraftStatus;
        LastLoginDate = lastLoginDt;
        try { Users.sendInventoryDueAlert(); }  catch { }
    }

    public static int UserId
    {
        get
        {
            int valu = 0; try { valu = int.Parse(System.Web.HttpContext.Current.Session["sesUserId"].ToString()); }
            catch { }
            return valu;
        }
        set { System.Web.HttpContext.Current.Session["sesUserId"] = value; }
    }

    public static bool IsFirstUser
    {
        get
        {
            bool valu = false;
            try { valu = (System.Web.HttpContext.Current.Session["sesIsFirstUser"].ToString() == "True") ? true : false; }
            catch { }
            return valu;
        }
        set { System.Web.HttpContext.Current.Session["sesIsFirstUser"] = value; }
    }

    public static bool IsActive
    {
        get
        {
            bool valu = false;
            try { valu = (System.Web.HttpContext.Current.Session["sesIsActive"].ToString() == "True") ? true : false; }
            catch { }
            return valu;
        }
        set { System.Web.HttpContext.Current.Session["sesIsActive"] = value; }
    }

    public static string IDNo
    {
        get
        {
            string valu = ""; try { valu = System.Web.HttpContext.Current.Session["sesStfIDNo"].ToString(); }
            catch { } return valu;
        }
        set { System.Web.HttpContext.Current.Session["sesStfIDNo"] = value; }
    }

    public static string Name
    {
        get
        {
            string valu = ""; try { valu = System.Web.HttpContext.Current.Session["sesStfName"].ToString(); }
            catch { } return valu;
        }
        set { System.Web.HttpContext.Current.Session["sesStfName"] = value; }
    }

    public static string Name_IDNo
    {
        get { return UserSession.Name + " (" + UserSession.IDNo + ")"; }
        set { UserSession.Name_IDNo = value; }
    }

    public static int LocationID
    {
        get
        {
            int valu = 0; try { valu = int.Parse(System.Web.HttpContext.Current.Session["sesLocID"].ToString()); }
            catch { }
            return valu;
        }
        set { System.Web.HttpContext.Current.Session["sesLocID"] = value; }
    }

    public static string Location
    {
        get
        {
            string valu = ""; try { valu = System.Web.HttpContext.Current.Session["sesLocation"].ToString(); }
            catch { } return valu;
        }
        set { System.Web.HttpContext.Current.Session["sesLocation"] = value; }
    }

    public static string UserName
    {
        get
        {
            string valu = ""; try { valu = System.Web.HttpContext.Current.Session["sesUserName"].ToString(); }
            catch { } return valu;
        }
        set { System.Web.HttpContext.Current.Session["sesUserName"] = value; }
    }

    public static string PWD
    {
        get
        {
            string valu = ""; try { valu = System.Web.HttpContext.Current.Session["sesPWD"].ToString(); }
            catch { } return valu;
        }
        set { System.Web.HttpContext.Current.Session["sesPWD"] = value; }
    }

    public static string Phone
    {
        get
        {
            string valu = ""; try { valu = System.Web.HttpContext.Current.Session["sesPhone"].ToString(); }
            catch { } return valu;
        }
        set { System.Web.HttpContext.Current.Session["sesPhone"] = value; }
    }

    public static int LevID
    {
        get
        {
            int valu = 0; try { valu = int.Parse(System.Web.HttpContext.Current.Session["sesLevID"].ToString()); }
            catch { }
            return valu;
        }
        set { System.Web.HttpContext.Current.Session["sesLevID"] = value; }
    }
    public static string Level
    {
        get
        {
            string valu = ""; try { valu = System.Web.HttpContext.Current.Session["sesLevelName"].ToString(); }
            catch { } return valu;
        }
        set { System.Web.HttpContext.Current.Session["sesLevelName"] = value; }
    }

    public static bool IsAllowAdd
    {
        get
        {
            bool valu = false;
            try
            {
                valu = (System.Web.HttpContext.Current.Session["sesIsAllowAdd"].ToString() == "True") ? true : false;
            }
            catch { } return valu;
        }
        set { System.Web.HttpContext.Current.Session["sesIsAllowAdd"] = value; }
    }

    public static bool IsAllowIssue
    {
        get
        {
            bool valu = false;
            try
            {
                valu = (System.Web.HttpContext.Current.Session["sesIsAllowIssue"].ToString() == "True") ? true : false;
            }
            catch { } return valu;
        }
        set { System.Web.HttpContext.Current.Session["sesIsAllowIssue"] = value; }
    }

    public static bool IsAllowAircraftStatus
    {
        get
        {
            bool valu = false;
            try
            {
                valu = (System.Web.HttpContext.Current.Session["sesIsAllowAircraftStatus"].ToString() == "True") ? true : false;
            }
            catch { } return valu;
        }
        set { System.Web.HttpContext.Current.Session["sesIsAllowAircraftStatus"] = value; }
    }

    public static string LastLoginDate
    {
        get
        {
            string valu = ""; try { valu = System.Web.HttpContext.Current.Session["sesLastLoginDt"].ToString(); }
            catch { } return valu;
        }
        set { System.Web.HttpContext.Current.Session["sesLastLoginDt"] = value; }
    }


    public static void End()
    {
        try
        {
            System.Web.HttpContext.Current.Session.Clear();
        }
        catch { }
    }




    //========================================================
    //========================================================
    public static string getLinks()
    {
        return " <link rel='stylesheet' type='text/css' href='../css/main.css' media='all' /> " +
            "<link rel='stylesheet' type='text/css' href='../jq/themes/redmond/jquery.ui.all.css' /> " +
               "<script type='text/javascript' src='../jq/jquery-1.7.1.js'></script> " +
               "<script type='text/javascript' src='../jq/ui/jquery.ui.core.js'></script>    " +
               "<script type='text/javascript' src='../jq/ui/jquery.ui.widget.js'></script> " +
               "<script type='text/javascript' src='../jq/ui/jquery.ui.accordion.js'></script> " +
               "<script type='text/javascript' src='../jq/ui/jquery.ui.mouse.js'></script>" +
               "<script type='text/javascript' src='../jq/ui/jquery.ui.resizable.js'></script> " +
               "<script type='text/javascript' src='../jq/ui/jquery.ui.tabs.js'></script>     " +
               "<script type='text/javascript' src='../jq/ui/jquery.ui.draggable.js'></script>" +
               "<script type='text/javascript' src='../jq/ui/jquery.ui.position.js'></script>" +
               "<script type='text/javascript' src='../jq/ui/jquery.ui.dialog.js'></script>" +
               "<script type='text/javascript' src='../jq/ui/jquery.ui.sortable.js'></script> " +
               "<script src='../jq/sync.js' type='text/javascript'></script>";
    }

    
    public static string getFooter()
    {
        return "<div id='footer'><div id='footer-inner'>&copy;Copyright " + DateTime.Now.Year.ToString() +
            ". |&nbsp;All Rights Reserved... </div></div>";
    }

    public static string getUserNmPWD_btns()
    {
        return "<div style='float:left;padding:5px;'> " +
               "<a class='comment-reply-link' href=\"javascript:openDialog('div_changeUser');\" title='Click to Change Username'> " +
                       "<img src='../images/edit_user.gif' width='28' height='28' alt='' /></a></div> " +
               "<div style='float:left;padding:5px;'> " +
               "<a class='comment-reply-link' href=\"javascript:openDialog('div_changePWD');\" title='Click to Change Password'> " +
                       "<img src='../images/edit_pwd.gif' width='28' height='28' alt='' /></a></div>";
    }

    public static string getUserNmPWD_dialog()
    {
        return "<div id='div_changeUser' title='CHANGE USERNAME:'> " + "<div id='spanChangeUser'></div> " +
              "<table><tr valign='top'> <td> <img src='../images/edituser.gif' />  </td> <td> <div> " +
              "USERNAME:<br /> &nbsp; &nbsp;&nbsp; &nbsp; " +
              "    <input type='text' id='txtOldUNm' /><span id='txtOldUNm_' class='err'></span><br /> " +
              "NEW USERNAME:<br /> &nbsp; &nbsp;&nbsp; &nbsp; " +
              "    <input type='text' id='txtNewUNm' /><span id='txtNewUNm_' class='err'></span> <br /> " +
              "RE-TYPE USERNAME:<br /> &nbsp; &nbsp;&nbsp; &nbsp; " +
              "    <input type='text' id='txtRNewUNm' /><span id='txtRNewUNm_' class='err'></span> <br /> </div> </td></tr></table> " +
        "</div> <div id='div_changePWD' title='CHANGE PASSWORD:'> <div id='spanChangePWD'></div>  <table><tr valign='top'> " +
              " <td> <img src='../images/key.gif' style='height: 115px' />  </td> <td>PASSWORD:<br /> &nbsp; &nbsp;&nbsp; &nbsp; " +
              "    <input type='password' id='txtOldPWD' /> <span id='txtOldPWD_' class='err'></span><br /> " +
              "    NEW PASSWORD:<br /> &nbsp; &nbsp;&nbsp; &nbsp; <input type='password' id='txtNewPWD' />  " +
              "    <span id='pwd_strength'></span><span id='txtNewPWD_' class='err'></span><br /> " +
              "    RE-TYPE PASSWORD:<br /> &nbsp; &nbsp;&nbsp; &nbsp; <input type='password' id='txtRNewPWD' /> " +
              "    <span id='txtRNewPWD_' class='err'></span><br />  </td></tr></table> </div> ";
    }



}