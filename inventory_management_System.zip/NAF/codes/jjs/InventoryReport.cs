﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data.SqlClient;
using System.Configuration;
using System.Data; 

public class InventoryReport
{
    private SqlConnection _conn = new SqlConnection(Connect.CONN());
    public string _error;


    //------------------Ledger Table ------------------------
    public string getLedgerDue(int locID)
    {
        DataTable TBL = this.getLedgerDueReordeCritExpiryTBL(locID);
        int nExp = 0, nReorder = 0, nCritical = 0;
        if (TBL.Rows.Count > 0)
        {
            DataRow dr = TBL.Rows[0];
            try { nExp = int.Parse(dr["nExpiry"].ToString()); }  catch { }
            try { nReorder = int.Parse(dr["nReorder"].ToString()); } catch { }
            try { nCritical = int.Parse(dr["nCritical"].ToString()); } catch { }
        }
        string tbl = "<b>DUE EXP: </b><span class='red'>" + nExp.ToString() + "</span> &nbsp; " +
                     "<b>DUE RE-ORDER: </b><span class='red'>" + nReorder.ToString() + "</span> &nbsp;" +
                     "<b>DUE CRITICAL: </b><span class='red'>" + nCritical.ToString() + "</span> ";
        return tbl;
    }
    public DataTable getLedgerDueReordeCritExpiryTBL(int locID)
    {        
        DateTime dt = DateTime.Now.AddMonths(1); 
        string sql = "SELECT COUNT(ID) AS nExpiry, " +
            " (SELECT COUNT(ID) FROM invLedger WHERE CriticalQty >= Qty AND LocationID = @locID) AS nCritical, " +
            " (SELECT COUNT(ID) FROM invLedger WHERE ReorderQty >= Qty AND LocationID = @locID) AS nReorder " +
            " FROM invLedger WHERE LocationID = @locID AND (ExpDate <= @dt AND IsExpiry = @isExp AND Qty > @zero)   ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); DataSet dtSet = new DataSet();
        dr.SelectCommand.Parameters.AddWithValue("@locID", locID);
        dr.SelectCommand.Parameters.AddWithValue("@dt", dt);
        dr.SelectCommand.Parameters.AddWithValue("@isExp", true);
        dr.SelectCommand.Parameters.AddWithValue("@zero", 0);
        dr.Fill(dtSet, "TBL"); this._conn.Close(); return dtSet.Tables["TBL"];
    }

    public DataTable getLedgerDueReordeCritExpiryTBL()
    {
        DateTime dt = DateTime.Now.AddMonths(1);
        string sql = "SELECT l.ID, l.Name," +
            " (SELECT COUNT(ID) FROM invLedger WHERE (ExpDate <= @dt AND IsExpiry = @isExp AND Qty > @zero) AND LocationID = l.ID) " +
            "  AS nExpiry, " +
            " (SELECT COUNT(ID) FROM invLedger WHERE CriticalQty >= Qty AND LocationID = l.ID) AS nCritical, " +
            " (SELECT COUNT(ID) FROM invLedger WHERE ReorderQty >= Qty AND LocationID = l.ID) AS nReorder FROM invLocation l " +
            " ORDER BY l.Name ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); DataSet dtSet = new DataSet();        
        dr.SelectCommand.Parameters.AddWithValue("@dt", dt);        dr.SelectCommand.Parameters.AddWithValue("@isExp", true);
        dr.SelectCommand.Parameters.AddWithValue("@zero", 0);       dr.Fill(dtSet, "TBL");      this._conn.Close(); 
        return dtSet.Tables["TBL"];
    }

    public DataTable getLedgerTBL()
    {
        string sql = "SELECT i.*, d.Name AS Dept, l.Name AS Location " +
            " FROM invLedger i, invDept d, invLocation l WHERE l.ID = i.LocationID AND d.ID = i.DeptID ORDER BY i.LocationID, i.DeptID  ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); DataSet dtSet = new DataSet();        
        dr.Fill(dtSet, "TBL"); this._conn.Close(); return dtSet.Tables["TBL"];
    }
    public DataTable getLedgerTBL(int locID)
    {
        string sql = "SELECT i.*, d.Name AS Dept, l.Name AS Location " +
            " FROM invLedger i, invDept d, invLocation l WHERE i.LocationID = @locID " +
            " AND l.ID = i.LocationID AND d.ID = i.DeptID ORDER BY i.DeptID  ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); DataSet dtSet = new DataSet();
        dr.SelectCommand.Parameters.AddWithValue("@locID", locID);
        dr.Fill(dtSet, "TBL"); this._conn.Close(); return dtSet.Tables["TBL"];
    }

    public DataTable getLedgerTBL(int locId, string CardNo)
    {
        string sql = "SELECT i.*, d.Name AS Dept, l.Name AS Location FROM invLedger i, invDept d, invLocation l " +
            " WHERE i.LocationID = @locID AND i.CardNo = @cardNo AND l.ID = i.LocationID AND d.ID = i.DeptID " +
            " ORDER BY i.DeptID  ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); DataSet dtSet = new DataSet();
        dr.SelectCommand.Parameters.AddWithValue("@locID", locId);
        dr.SelectCommand.Parameters.AddWithValue("@cardNo", CardNo);
        dr.Fill(dtSet, "TBL"); this._conn.Close(); return dtSet.Tables["TBL"];
    }

    public DataTable getLedgerPartCardTBL(int locID, string PartCardNo)
    {
        string sql = "SELECT i.*, d.Name AS Dept FROM invLedger i, invDept d WHERE i.LocationID = @locID " +
            " AND (i.PartNo = @numb OR i.CardNo = @numb) AND d.ID = i.DeptID ORDER BY i.DeptID  ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); DataSet dtSet = new DataSet();
        dr.SelectCommand.Parameters.AddWithValue("@locID", locID);
        dr.SelectCommand.Parameters.AddWithValue("@numb", PartCardNo);
        dr.Fill(dtSet, "TBL"); this._conn.Close(); return dtSet.Tables["TBL"];
    }

    public DataTable searchLedgerTBL(int locID, string searchKey)
    {
        string sql = "SELECT i.*, d.Name AS Dept, l.Name AS Location " +
            " FROM invLedger i, invDept d, invLocation l WHERE i.LocationID = @locID AND l.ID = i.LocationID AND d.ID = i.DeptID AND (i.RackNo LIKE @valu OR i.CardNo LIKE @valu OR i.PartNo LIKE @valu OR i.SerialNo LIKE @valu OR i.Name LIKE @valu OR i.UsedOnAircraft LIKE @valu OR i.OtherInfo LIKE @valu) ORDER BY i.DeptID, i.CardNo ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); DataSet dtSet = new DataSet();
        dr.SelectCommand.Parameters.AddWithValue("@locID", locID);
        dr.SelectCommand.Parameters.AddWithValue("@valu", ("%" + searchKey + "%"));
        dr.Fill(dtSet, "TBL"); this._conn.Close(); return dtSet.Tables["TBL"];
    }

    public DataTable searchLedgersTBL(string srchValu)
    {
        string sql = "SELECT i.*, d.Name AS Dept, l.Name AS Location " +
            " FROM invLedger i, invDept d, invLocation l WHERE l.ID = i.LocationID AND d.ID = i.DeptID AND " +
            " (i.PartNo LIKE @valus OR  i.Name LIKE @valus) ORDER BY i.LocationID, i.DeptID ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); DataTable TBL = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@valus", ("%" + srchValu + "%"));
        try { dr.Fill(TBL); this._conn.Close(); }  catch { } return TBL;
    }

    public DataTable getLedgerCriticalTBL(int locID)
    {
        string sql = "SELECT i.*, d.Name AS Dept, l.Name AS Location " +
            " FROM invLedger i, invDept d, invLocation l WHERE i.LocationID = @locID AND l.ID = i.LocationID AND d.ID = i.DeptID AND (i.CriticalQty >= i.Qty) ORDER BY i.DeptID, i.CardNo ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); DataSet dtSet = new DataSet();
        dr.SelectCommand.Parameters.AddWithValue("@locID", locID);        
        dr.Fill(dtSet, "TBL"); this._conn.Close(); return dtSet.Tables["TBL"];
    }
    public DataTable getLedgerReorderTBL(int locID)
    {
        string sql = "SELECT i.*, d.Name AS Dept, l.Name AS Location " +
            " FROM invLedger i, invDept d, invLocation l WHERE i.LocationID = @locID AND l.ID = i.LocationID AND d.ID = i.DeptID AND (i.ReorderQty >= i.Qty) ORDER BY i.DeptID, i.CardNo ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); DataSet dtSet = new DataSet();
        dr.SelectCommand.Parameters.AddWithValue("@locID", locID);
        dr.Fill(dtSet, "TBL"); this._conn.Close(); return dtSet.Tables["TBL"];
    }
    public DataTable getLedgerDueExpiryTBL(int locID)
    {
        DateTime dt = DateTime.Now.AddMonths(1); 
        string sql = "SELECT i.*, d.Name AS Dept, l.Name AS Location " +
            " FROM invLedger i, invDept d, invLocation l WHERE i.LocationID = @locID AND l.ID = i.LocationID AND d.ID = i.DeptID AND (i.ExpDate <= @dt AND i.IsExpiry = @isExp AND i.Qty > @zero) " +
            " ORDER BY i.LocationID, i.DeptID ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); DataSet dtSet = new DataSet();
        dr.SelectCommand.Parameters.AddWithValue("@locID", locID);
        dr.SelectCommand.Parameters.AddWithValue("@dt", dt);
        dr.SelectCommand.Parameters.AddWithValue("@isExp", true);
        dr.SelectCommand.Parameters.AddWithValue("@zero", 0);
        dr.Fill(dtSet, "TBL"); this._conn.Close(); return dtSet.Tables["TBL"];
    }

    /* 
def getPieChartValus():
    sql = "SELECT DISTINCT d.Levels, \
            (SELECT COUNT(Levels) FROM student WHERE Levels = d.Levels) AS nStuds \
            FROM student d ORDER BY d.Levels "
    rows = getDBrows(sql)
    pieValus = ""
    for row in rows :
        pieValus += ('%s:%s,' % (row.Levels , row.nStuds) )     
    return  "<input type='hidden' id='hidPieChartValus' value='%s' /> " % pieValus

def getBarChartValus():
    sql = "SELECT DISTINCT d.Levels, \
            (SELECT COUNT(Levels) FROM student WHERE Levels = d.Levels AND Sex = 'Male') AS nMales, \
            (SELECT COUNT(Levels) FROM student WHERE Levels = d.Levels AND Sex = 'Female') AS nFemales \
            FROM student d ORDER BY d.Levels "
    rows = getDBrows(sql)
    barValus = ""
    for row in rows :
        barValus += ('%s,%s,%s;' % (row.Levels, row.nMales, row.nFemales) )     
    return  "<input type='hidden' id='hidBarChatValus' value='%s' /> " % barValus  
     
#<input type="hidden" id="hidPieChartValus" value="100:12,200:34,300:52,400:56,500:63,PGD:67,MASTERS:90" />
#<input type="hidden" id="hidBarChatValus" value="catg,male,female;catg,male,female;" />

 */
    public string PieChartValus, BarChartValus;
    public void getLedgerChartValus(DataTable TBL)
    {
        this.PieChartValus = "";    this.BarChartValus = "";
        string pieValus = "", barValus = "";
        var deptRows = (from DataRow row in TBL.Rows
                        select new { deptName = row["Dept"] }).Distinct();
        foreach (var dRow in deptRows)
        {
            string dept = dRow.deptName.ToString();    int items = 0;
            items = TBL.AsEnumerable().Count(n => (n.Field<string>("Dept") == dept));
            pieValus += (dept + ":" + items.ToString() + ",");

            int reOrderQty = 0, critQty = 0, normalQty = 0, expiryQty = 0;                       
            int totalQty = TBL.AsEnumerable().Count();
            reOrderQty = TBL.AsEnumerable().Count(n => (n.Field<int>("ReorderQty") >= n.Field<int>("Qty")));
            critQty = TBL.AsEnumerable().Count(n => (n.Field<int>("CriticalQty") >= n.Field<int>("Qty")));
            reOrderQty = reOrderQty - critQty;
            
            DateTime dt = DateTime.Now.AddMonths(1);
            expiryQty = TBL.AsEnumerable().Count(n => (n.Field<DateTime>("ExpDate") <= dt 
                && n.Field<bool>("IsExpiry") == true && n.Field<int>("Qty") > 0));
            normalQty = totalQty - reOrderQty - critQty;
            //<input type="hidden" id="hidBarChatValus" value="catg,male,female;catg,male,female;" />
            barValus += (dept + "," + normalQty.ToString() + "," + reOrderQty.ToString() + "," + critQty.ToString() + "," + expiryQty.ToString() + ";");
        }
        this.PieChartValus = pieValus;
        this.BarChartValus = barValus;
    }
    
    //================ Supply History -----------------------
    public DataTable searchSupplyHistTBL(int locID, string searchKey)
    {
        string sql = "SELECT s.*, d.Name AS Dept, l.Name AS Location " +
           " FROM invSupplyHistory s, invDept d, invLocation l WHERE s.LocationID = @locID AND l.ID = s.LocationID AND d.ID = s.DeptID AND (s.RackNo LIKE @valu OR s.CardNo LIKE @valu OR s.PartNo LIKE @valu OR s.SerialNo LIKE @valu OR s.Name LIKE @valu OR s.UsedOnAircraft LIKE @valu OR s.Supplier LIKE @valu OR s.OtherInfo LIKE @valu OR s.RegByIDNo LIKE @valu) ORDER BY s.DeptID ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); DataSet dtSet = new DataSet();
        dr.SelectCommand.Parameters.AddWithValue("@locID", locID);
        dr.SelectCommand.Parameters.AddWithValue("@valu", ("%" + searchKey + "%"));
        dr.Fill(dtSet, "TBL"); this._conn.Close(); return dtSet.Tables["TBL"];
    }

    public DataTable getSupplyHistTBL_PartNo(int locID, string partNo)
    {
        string sql = "SELECT s.*, d.Name AS Dept, l.Name AS Location " +
           " FROM invSupplyHistory s, invDept d, invLocation l WHERE s.LocationID = @locID AND l.ID = s.LocationID AND d.ID = s.DeptID AND s.PartNo = @valu ORDER BY s.DeptID ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); DataSet dtSet = new DataSet();
        dr.SelectCommand.Parameters.AddWithValue("@locID", locID);
        dr.SelectCommand.Parameters.AddWithValue("@valu", partNo);
        dr.Fill(dtSet, "TBL"); this._conn.Close(); return dtSet.Tables["TBL"];
    }
    public DataTable getSupplyHistTBL_CardNo(int locID, string cardNo)
    {
        string sql = "SELECT s.*, d.Name AS Dept, l.Name AS Location " +
           " FROM invSupplyHistory s, invDept d, invLocation l WHERE s.LocationID = @locID AND l.ID = s.LocationID AND d.ID = s.DeptID AND s.CardNo = @valu ORDER BY s.DeptID, s.Name ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); DataSet dtSet = new DataSet();
        dr.SelectCommand.Parameters.AddWithValue("@locID", locID);
        dr.SelectCommand.Parameters.AddWithValue("@valu", cardNo);
        dr.Fill(dtSet, "TBL"); this._conn.Close(); return dtSet.Tables["TBL"];
    }
    public DataTable getSupplyHistTBL_IDNo(int locID, string IDNo)
    {
        string sql = "SELECT s.*, d.Name AS Dept, l.Name AS Location " +
           " FROM invSupplyHistory s, invDept d, invLocation l WHERE s.LocationID = @locID AND l.ID = s.LocationID AND d.ID = s.DeptID AND s.RegByIDNo = @valu ORDER BY s.DeptID ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); DataSet dtSet = new DataSet();
        dr.SelectCommand.Parameters.AddWithValue("@locID", locID);
        dr.SelectCommand.Parameters.AddWithValue("@valu", IDNo);
        dr.Fill(dtSet, "TBL"); this._conn.Close(); return dtSet.Tables["TBL"];
    }
    public DataTable getSupplyHistTBL_Supplier(int locID, string supplier)
    {
        string sql = "SELECT s.*, d.Name AS Dept, l.Name AS Location " +
           " FROM invSupplyHistory s, invDept d, invLocation l WHERE s.LocationID = @locID AND l.ID = s.LocationID AND d.ID = s.DeptID AND s.Supplier = @valu ORDER BY s.DeptID, s.CardNo ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); DataSet dtSet = new DataSet();
        dr.SelectCommand.Parameters.AddWithValue("@locID", locID);
        dr.SelectCommand.Parameters.AddWithValue("@valu", supplier);
        dr.Fill(dtSet, "TBL"); this._conn.Close(); return dtSet.Tables["TBL"];
    }
    public DataTable getSupplyHistTBL_Dept(int locID, int deptID)
    {
        string sql = "SELECT s.*, d.Name AS Dept, l.Name AS Location " +
           " FROM invSupplyHistory s, invDept d, invLocation l WHERE s.LocationID = @locID AND " +
           " l.ID = s.LocationID AND s.DeptID = @deptId AND d.ID = s.DeptID ORDER BY s.CardNo ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); DataSet dtSet = new DataSet();
        dr.SelectCommand.Parameters.AddWithValue("@locID", locID);
        dr.SelectCommand.Parameters.AddWithValue("@deptId", deptID);
        dr.Fill(dtSet, "TBL"); this._conn.Close(); return dtSet.Tables["TBL"];
    }
    public DataTable getSupplyHistTBL_Date(int locID, DateTime dt)
    {
        string sql = "SELECT s.*, d.Name AS Dept, l.Name AS Location " +
           " FROM invSupplyHistory s, invDept d, invLocation l WHERE s.LocationID = @locID AND " +
           " l.ID = s.LocationID AND d.ID = s.DeptID AND " +
           " (YEAR(s.RegDate) = @yr AND MONTH(s.RegDate) = @mth AND DAY(s.RegDate) = @day) " +
           " ORDER BY s.DeptID, s.CardNo ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); DataSet dtSet = new DataSet();
        dr.SelectCommand.Parameters.AddWithValue("@locID", locID);
        dr.SelectCommand.Parameters.AddWithValue("@yr", dt.Year);
        dr.SelectCommand.Parameters.AddWithValue("@mth", dt.Month);
        dr.SelectCommand.Parameters.AddWithValue("@day", dt.Day);
        dr.Fill(dtSet, "TBL"); this._conn.Close(); return dtSet.Tables["TBL"];
    }
    public DataTable getSupplyHistTBL(int locID, int deptId, DateTime fromDt, DateTime toDt)
    {
       string locField = "";     if (locID > 0) locField = " s.LocationID = @locID AND ";
        string deptField = ""; if (deptId > 0) deptField = " s.DeptID = @deptId AND ";
        string sql = "SELECT s.*, d.Name AS Dept, l.Name AS Location " +
           " FROM invSupplyHistory s, invDept d, invLocation l WHERE " + locField + deptField +
           " l.ID = s.LocationID AND d.ID = s.DeptID " +
            " AND cast(CONVERT(varchar(8), s.RegDate, 112) AS datetime) >= @fromDt AND " +
            " cast(CONVERT(varchar(8), s.RegDate, 112) AS datetime) <= @toDt  ORDER BY s.DeptID, s.CardNo ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn);      DataTable tbl = new DataTable();
        if(locID > 0) dr.SelectCommand.Parameters.AddWithValue("@locID", locID);
        if (deptId > 0) dr.SelectCommand.Parameters.AddWithValue("@deptId", deptId); 
        dr.SelectCommand.Parameters.AddWithValue("@fromDt", fromDt);
        dr.SelectCommand.Parameters.AddWithValue("@toDt", toDt);
        try { dr.Fill(tbl); this._conn.Close(); } catch { } return tbl;
    }
   

    public DataTable getSupplyHistTBL(Int64 Id)
    {
        string sql = "SELECT s.*, d.Name AS Dept, l.Name AS Location " +
          " FROM invSupplyHistory s, invDept d, invLocation l WHERE s.ID = @ID AND l.ID = s.LocationID AND d.ID = s.DeptID ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); DataSet dtSet = new DataSet();
        dr.SelectCommand.Parameters.AddWithValue("@ID", Id);
        dr.Fill(dtSet, "TBL"); this._conn.Close(); return dtSet.Tables["TBL"];
    }


    //=================== Receiving Techinicians ======================
    public DataTable getReceivTechTBL_IssueDate(int locID, DateTime dt)
    {
        string sql = "SELECT r.*, l.Name AS Location FROM invReceivinTech r, invLocation l WHERE r.LocationID = @locID AND " +
           " l.ID = r.LocationID AND " +
           " (YEAR(r.RegDate) = @yr AND MONTH(r.RegDate) = @mth AND DAY(r.RegDate) = @day) ORDER BY r.RegDate ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); DataSet dtSet = new DataSet();
        dr.SelectCommand.Parameters.AddWithValue("@locID", locID);
        dr.SelectCommand.Parameters.AddWithValue("@yr", dt.Year);
        dr.SelectCommand.Parameters.AddWithValue("@mth", dt.Month);
        dr.SelectCommand.Parameters.AddWithValue("@day", dt.Day);
        dr.Fill(dtSet, "TBL"); this._conn.Close(); return dtSet.Tables["TBL"];
    }
    public DataTable getReceivTechTBL_RegIDNo(int locID, string regIDNo, DateTime dt)
    {
        string sql = "SELECT r.*, l.Name AS Location FROM invReceivinTech r, invLocation l WHERE r.LocationID = @locID AND " +
           " l.ID = r.LocationID AND r.RegByIDNo = @IDNo AND " +
           " (YEAR(r.RegDate) = @yr AND MONTH(r.RegDate) = @mth AND DAY(r.RegDate) = @day) ORDER BY r.RegDate ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn);      DataSet dtSet = new DataSet();
        dr.SelectCommand.Parameters.AddWithValue("@locID", locID);    dr.SelectCommand.Parameters.AddWithValue("@IDNo", regIDNo);
        dr.SelectCommand.Parameters.AddWithValue("@yr", dt.Year);     dr.SelectCommand.Parameters.AddWithValue("@mth", dt.Month);
        dr.SelectCommand.Parameters.AddWithValue("@day", dt.Day);
        dr.Fill(dtSet, "TBL"); this._conn.Close(); return dtSet.Tables["TBL"];
    }
    public DataTable getReceivTBL(int locID, DateTime fromDt, DateTime toDate)
    {
       string locField = "";
        if (locID > 0) locField = " AND r.LocationID = @locId ";
        string sql = "SELECT r.*, l.Name AS Location FROM invReceivinTech r, invLocation l WHERE l.ID = r.LocationID " + locField +
            " AND cast(CONVERT(varchar(8), r.RegDate, 112) AS datetime) >= @fromDt AND " +
            " cast(CONVERT(varchar(8), r.RegDate, 112) AS datetime) <= @toDt ORDER BY r.RegDate DESC, l.Name ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn);
        if (locID > 0) dr.SelectCommand.Parameters.AddWithValue("@locId", locID);
        dr.SelectCommand.Parameters.AddWithValue("@fromDt", fromDt); dr.SelectCommand.Parameters.AddWithValue("@toDt", toDate);
        DataTable tbl = new DataTable(); try { dr.Fill(tbl);   this._conn.Close(); } catch { } return tbl;
    }

    ////locId,deptId,fromDate,toDate


}