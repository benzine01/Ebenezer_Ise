﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


using System.Data.SqlClient;
using System.Configuration;
using System.Data; 

public class AircraftStatus
{

    private SqlConnection _conn = new SqlConnection(Connect.CONN());
    public string _error;

    public bool setServLev(int lev, string info)
    {
        if (lev > 1000) return false;
        string sql = "INSERT INTO airServLev(Level,Info) VALUES(@lev,@info) ";
        SqlCommand cmd = new SqlCommand(sql, this._conn); int added = 0;
        cmd.Parameters.AddWithValue("@lev", lev); cmd.Parameters.AddWithValue("@info", info);
        try {   this._conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString());
        } catch (Exception ex) { this._error = ex.Message; } finally { this._conn.Close(); }
        return (added > 0) ? true : false;
    }
    public int getServLev(int level)
    {
        string sql = "SELECT MIN(Level) FROM airServLev WHERE Level >= @lev ";
        SqlCommand cmd = new SqlCommand(sql, this._conn);
        cmd.Parameters.AddWithValue("@lev", level);     int lev = 0;
        try { this._conn.Open(); lev = int.Parse(cmd.ExecuteScalar().ToString()); }
        catch (Exception ex) { this._error = ex.Message; }  finally { this._conn.Close(); }     return lev;
    }
    public int getPrevServLev(int level)
    {
        string sql = "SELECT MAX(Level) FROM airServLev WHERE Level < @lev ";
        SqlCommand cmd = new SqlCommand(sql, this._conn);
        cmd.Parameters.AddWithValue("@lev", level); int lev = 0;
        try { this._conn.Open(); lev = int.Parse(cmd.ExecuteScalar().ToString()); }
        catch (Exception ex) { this._error = ex.Message; }
        finally { this._conn.Close(); } return lev;
    }
    public int getNextServLev(int level) {    int nxtLev = level + 25; return this.getServLev(nxtLev);   }
    public int getMinServLev()
    {
        string sql = "SELECT MIN(Level) FROM airServLev ";
        SqlCommand cmd = new SqlCommand(sql, this._conn); int lev = 0;
        try { this._conn.Open(); lev = int.Parse(cmd.ExecuteScalar().ToString()); }
        catch (Exception ex) { this._error = ex.Message; } finally { this._conn.Close(); } return lev;
    }
    public int getMaxServLev()
    {
        string sql = "SELECT MAX(Level) FROM airServLev ";
        SqlCommand cmd = new SqlCommand(sql, this._conn); int lev = 0;
        try { this._conn.Open(); lev = int.Parse(cmd.ExecuteScalar().ToString()); }
        catch (Exception ex) { this._error = ex.Message; }
        finally { this._conn.Close(); } return lev;
    }



    //-------------------- AIRCRAFT AND CURRENT STATUS --------------------
    public bool setAircraft(int locId, string callSign, string name)
    {
        string sql = "INSERT INTO airAircraft(locId,callSign,Name,curHR,curMins,curLev,nextLev,nMaintCycle,HRsLeft,MinsLeft, " +
       " IsSnag,IsService,details) VALUES(@locId,@callSign,@name,@cHr,@cMin,@cLev,@nextLev,@nMaint,@lHr,@lMin,@isSnag,@isServ,@det)";
        SqlCommand cmd = new SqlCommand(sql, this._conn);
        cmd.Parameters.AddWithValue("@locId", locId);        cmd.Parameters.AddWithValue("@callSign", callSign.Trim());
        cmd.Parameters.AddWithValue("@name", name.Trim()); cmd.Parameters.AddWithValue("@cHr", 0);
        cmd.Parameters.AddWithValue("@cMin", 0);             cmd.Parameters.AddWithValue("@cLev", 0);
        cmd.Parameters.AddWithValue("@nextLev", 0);          cmd.Parameters.AddWithValue("@nMaint", 0);
        cmd.Parameters.AddWithValue("@lHr", 0);              cmd.Parameters.AddWithValue("@lMin", 0);
        cmd.Parameters.AddWithValue("@isSnag", 0);           cmd.Parameters.AddWithValue("@isServ", true);
        cmd.Parameters.AddWithValue("@det", "");             int added = 0;
        try { this._conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { this._error = ex.Message; } finally { this._conn.Close(); }
        return (added > 0) ? true : false;
    }

    public DataTable getAirCraftStatus() { return this.getAirCraftStatus(0, ""); }
    public DataTable getAirCraftStatus(int locId)  {   return this.getAirCraftStatus(locId, "");  }
    public DataTable getAirCraftStatus(string callSign) { return this.getAirCraftStatus(0, callSign); }
    public DataTable getAirCraftStatus(int locId, string callSign)
    {
        string where = " WHERE ", loc = "", call = "", and = " AND ";    int n = 0;      string fields = "";
        if (locId > 0) { loc = " locId = @locId "; n++; }
        if (callSign.Length > 1) { call = " LTRIM(callSign) = @callSign "; n++; } if (n < 2) and = ""; if (n < 1) where = "";
        fields = where + loc + and + call; //WHERE locId = @locId AND callSign = @callSign
        string sql = "SELECT *, (callSign + ' - ' + Name) AS CallSignName, " +
            " (SELECT l.Name FROM invLocation l WHERE l.ID = locId) AS Location, " +
            " (SELECT MAX(m.schInspLev) FROM airMaint m WHERE m.callSign = callSign AND m.nMaintCycle = nMaintCycle) AS LastInsp " +
            " FROM airAircraft " + fields 
            + " ORDER BY locId, CallSign ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn);   DataTable tbl = new DataTable();
        if(locId > 0) dr.SelectCommand.Parameters.AddWithValue("@locId", locId);
        if (callSign.Length > 0) dr.SelectCommand.Parameters.AddWithValue("@callSign", callSign.Trim());     
        dr.Fill(tbl); this._conn.Close(); return tbl;

    }
    public int getAircraftCycle(string callSign)
    {
        DataTable airTBL = this.getAirCraftStatus(callSign); if (airTBL.Rows.Count < 1) return 0;
        int nCycle = 0; try { nCycle = int.Parse(airTBL.Rows[0]["nMaintCycle"].ToString()); }  catch { }
        return nCycle;
    }

    private bool updateAircraftStatus(string callSign, int nCycle, int curLev, int nextLev)
    {
        string sql = "UPDATE airAircraft SET nMaintCycle = @nCycle, curLev = @curLev, nextLev = @nextLev WHERE callSign = @sign";
        SqlCommand cmd = new SqlCommand(sql, this._conn);       cmd.Parameters.AddWithValue("@nCycle", nCycle);
        cmd.Parameters.AddWithValue("@curLev", curLev);         cmd.Parameters.AddWithValue("@nextLev", nextLev);
        cmd.Parameters.AddWithValue("@sign", callSign); int updated = 0;
        try { this._conn.Open(); updated = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { this._error = ex.Message; }  finally { this._conn.Close(); }
        return (updated > 0) ? true : false;
    }
    //-------------------------------
    public bool setMaintenance(string callSign, int servLev, string details, string RegIDNo, string RegName)
    {
        int nCycle = this.getAircraftCycle(callSign);
        string sql = "INSERT INTO airMaint(callSign,nMaintCycle,servLev,details,RegID,RegName,RegDate) " +
            " VALUES(@callSign,@nCycle,@Lev,@details,@RegID,@RegName,@dt) ";
        SqlCommand cmd = new SqlCommand(sql, this._conn); cmd.Parameters.AddWithValue("@callSign", callSign.Trim());
        cmd.Parameters.AddWithValue("@nCycle", nCycle);
        cmd.Parameters.AddWithValue("@Lev", servLev);        cmd.Parameters.AddWithValue("@details", details);
        cmd.Parameters.AddWithValue("@RegID", RegIDNo.Trim()); cmd.Parameters.AddWithValue("@RegName", RegName);
        cmd.Parameters.AddWithValue("@dt", DateTime.Now); int added = 0;
        try {  this._conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString());
        }  catch (Exception ex) {  this._error = ex.Message; } finally  {  this._conn.Close();   }

        if (added > 0)
        {
            int maxServLev = this.getMaxServLev();
            if (maxServLev == servLev)
            {
                //it has reached the end of a cycle, restart
                int minServLev = this.getMinServLev();          nCycle += 1;
                int nextServLev = this.getNextServLev(minServLev);
                this.updateAircraftStatus(callSign, nCycle, minServLev, nextServLev);
            }
        }
        return (added > 0) ? true : false;
    }

    public bool isMaintained(string callSign, int lev)
    {
        int nCycle = this.getAircraftCycle(callSign);
        string sql = "SELECT * FROM airMaint WHERE LTRIM(callSign) = @sign AND nMaintCycle = @cycle AND servLev < @lev";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn);
        dr.SelectCommand.Parameters.AddWithValue("@sign", callSign.Trim());
        dr.SelectCommand.Parameters.AddWithValue("@cycle", nCycle);
        dr.SelectCommand.Parameters.AddWithValue("@lev", lev);

        return true;
    }/**/
    
    public DataTable getAircraftDue4maintainance()
    {
        string sql = "SELECT a.callSign,a.curLev FROM airAircraft a WHERE " +
                    " LTRIM(a.callSign) NOT IN (SELECT LTRIM(m.callSign) FROM airMaint m " +
                    " WHERE LTRIM(m.callSign) = LTRIM(a.callSign)  AND m.servLev < a.curLev AND " +
                    " m.nMaintCycle = a.nMaintCycle) ";   SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); 
        DataTable tbl = new DataTable();     dr.Fill(tbl); this._conn.Close(); return tbl;
    }

    //===================================================================
    public DataTable getAircraftLastFlight(string callSign)
    {
        string sql = "SELECT *, (SELECT Name FROM airAircraft WHERE LTRIM(callSign) = @sign) AS AircraftName " +
            " FROM airTakeOff WHERE LTRIM(callSign) = @sign AND " +
            " Id = (SELECT MAX(Id) FROM airTakeOff WHERE LTRIM(callSign) = @sign)";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); DataTable tbl = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@sign", callSign.Trim()); dr.Fill(tbl); this._conn.Close(); return tbl;
    }

    public bool setTakeOff(string callSign, string takeOffLoc, DateTime takeOffTime, string landLoc, DateTime landTime,
        int hr, int mins, int taskId, string taskName, int isSnag, string details, string RegIDNo, string RegName)
    {
        int nCycle = this.getAircraftCycle(callSign.Trim());
        DateTime regDt = DateTime.Now;
        string sql = "INSERT INTO airTakeOff(callSign,takeOffLoc,takeOffTime,landLoc,landTime,nMaintCycle, HR,Mins,taskId,taskName," +
        " IsSnag,details,RegIDNo,RegName,RegDate) VALUES(@cSign,@offLoc,@offTime,@landLoc,@landTime,@nCycle, " +
        " @HR,@Mins,@taskId,@taskName, @isSnag,@detail,@IDNo,@RegName,@dt) ";
        SqlCommand cmd = new SqlCommand(sql, this._conn);
        cmd.Parameters.AddWithValue("@cSign", callSign.Trim()); cmd.Parameters.AddWithValue("@offLoc", takeOffLoc);
        cmd.Parameters.AddWithValue("@offTime", takeOffTime);   cmd.Parameters.AddWithValue("@landLoc", landLoc);
        cmd.Parameters.AddWithValue("@landTime", landTime);     cmd.Parameters.AddWithValue("@nCycle", nCycle);
        cmd.Parameters.AddWithValue("@HR", hr);
        cmd.Parameters.AddWithValue("@Mins", mins);             cmd.Parameters.AddWithValue("@taskId", taskId);
        cmd.Parameters.AddWithValue("@taskName", taskName);     cmd.Parameters.AddWithValue("@isSnag", isSnag);
        cmd.Parameters.AddWithValue("@detail", details);        cmd.Parameters.AddWithValue("@IDNo", RegIDNo);
        cmd.Parameters.AddWithValue("@RegName", RegName);       cmd.Parameters.AddWithValue("@dt", regDt);
        int added = 0;
        try { this._conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { this._error = ex.Message; }  finally { this._conn.Close(); }
        if (added > 0)
        {
            bool isSuccess = this.updateAircraftStatus(callSign, nCycle, isSnag);
            if (!isSuccess)
            {
                string sql2 = "DELETE FROM airAircraft WHERE callSign = @cSign AND nMaintCycle = @nCycle " +
                    " AND RegIDNo = @IDNo AND RegDate = @dt ";
                SqlCommand cmd2 = new SqlCommand(sql2, _conn);
                cmd2.Parameters.AddWithValue("@cSign", callSign);           cmd2.Parameters.AddWithValue("@nCycle", nCycle);
                cmd2.Parameters.AddWithValue("@IDNo", RegIDNo);             cmd2.Parameters.AddWithValue("@dt", regDt);
                int deleted = 0;
                try { this._conn.Open(); deleted = int.Parse(cmd2.ExecuteNonQuery().ToString()); }
                catch (Exception ex) { this._error += ex.Message; } finally { this._conn.Close(); } added = 0;
            }
        }
        return (added > 0) ? true : false;
    }

    private bool updateAircraftStatus(string callSign, int nCycle, int isSnag)
    {
        callSign = callSign.Trim();
        DataTable tbl = new DataTable(); tbl = this.getTakeOffSumHrs(callSign, nCycle);
        int curHr = 0, curMins = 0;
        if (tbl.Rows.Count > 0)  {      DataRow dr = tbl.Rows[0];
            curHr = int.Parse(dr["curHR"].ToString()); curMins = int.Parse(dr["curMins"].ToString());
        }        
        if (curMins > 59) { curHr += Convert.ToInt32(curMins / 60); curMins = (curMins % 60); }

        int prevCurLev = 0, newNextLev = 0;
        if(curHr >= 25)   prevCurLev = curHr - (curHr % 25); //400
        newNextLev = prevCurLev + 25;
        if (curHr > 1000) newNextLev = 1000;

        int hoursLeft = newNextLev - curHr; int minsLeft = 0;
        if (curMins > 0) { hoursLeft -= 1; minsLeft = 60 - curMins; }

        bool isService = true;      if (isSnag == 2) isService = false;

        string _details = "";
        if (prevCurLev > 0 && !this.isMaintained(callSign, prevCurLev))
        {
            //Is not maintained
            isSnag = 2; isService = false;
            _details = "Maintainance of Service Hour: " + prevCurLev.ToString() + " has not been done...";
        }
        //===========================================
        string sql = "UPDATE airAircraft SET curHR = @cHr, curMins = @cMins, curLev = @cLev, nextLev = @nxtLev, " +
        " HRsLeft = @lHr, MinsLeft = @lMins, IsSnag = @snag, IsService = @service, details = @details WHERE LTRIM(callSign) = @callSign  ";
        SqlCommand cmd = new SqlCommand(sql, this._conn); int updated = 0;
        cmd.Parameters.AddWithValue("@cHr", curHr);          cmd.Parameters.AddWithValue("@cMins", curMins);
        cmd.Parameters.AddWithValue("@cLev", prevCurLev);    cmd.Parameters.AddWithValue("@nxtLev", newNextLev);
        cmd.Parameters.AddWithValue("@lHr", hoursLeft);      cmd.Parameters.AddWithValue("@lMins", minsLeft);
        cmd.Parameters.AddWithValue("@snag", isSnag);        cmd.Parameters.AddWithValue("@service", isService);
        cmd.Parameters.AddWithValue("@details", _details);
        cmd.Parameters.AddWithValue("@callSign", callSign);
        try
        {
            this._conn.Open(); updated = int.Parse(cmd.ExecuteNonQuery().ToString());
        } catch (Exception ex) { this._error = ex.Message; } finally { this._conn.Close(); }
        return (updated > 0) ? true : false;
    }
   
    /*private bool updateAircraftStatus(string callSign, int nCycle, int isSnag)
    {
        DataTable tbl = new DataTable(); tbl = this.getTakeOff(callSign, nCycle);     
        int curHr = 0, curMins = 0;
        if (tbl.Rows.Count > 0) {        DataRow dr = tbl.Rows[0]; 
            curHr = int.Parse(dr["curHR"].ToString()); curMins = int.Parse(dr["curMins"].ToString());
        }
        int maxServiceHrs = this.getMaxServLev();          int minServiceHrs = this.getMinServLev();

        int leftHR = 0, leftMins = 0;        
        if (curMins > 59) { curHr += Convert.ToInt32(curMins / 60); curMins = (curMins % 60); }

        int currentServLev = this.getServLev(curHr);       
        int prevServLev =  this.getPrevServLev(curHr);        string _details = "";

        int nextServiceLev = 0;    bool isService = (isSnag < 2)? true : false;
        if (currentServLev >= maxServiceHrs)
        {
            nextServiceLev = maxServiceHrs;
            if (curHr >= maxServiceHrs)
            {
                nextServiceLev = 0; isSnag = 2; isService = false;
                _details = "Maximum Flying Service Hours of " + maxServiceHrs.ToString() + " is exceeded...";
            } 
        }
        else  {   nextServiceLev = this.getNextServLev(curHr);  }        

        leftHR = maxServiceHrs - curHr;   if (curMins > 0) {  leftHR -= 1; leftMins = 60 - curMins;   }

        if (prevServLev > 0 && !this.isMaintained(callSign, prevServLev))
        {
            //Is not maintained
            isSnag = 2; isService = false;
            _details = "Maintainance of Service Hour: " + prevServLev.ToString() + " has not been done...";
        }

        
       
    }
    */
    private DataTable getTakeOffSumHrs(string callSign, int nCycle)
    {
        string sql = "SELECT SUM(HR) AS curHR, SUM(Mins) AS curMins FROM airTakeOff " +
            " WHERE LTRIM(callSign) = @callSign AND nMaintCycle = @nCycle  ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); DataTable tbl = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@callSign", callSign.Trim());
        dr.SelectCommand.Parameters.AddWithValue("@nCycle", nCycle);    dr.Fill(tbl); this._conn.Close(); return tbl;
    }

    public DataTable getTakeOffHist(string callSign)
    {
        string sql = "SELECT t.* FROM airTakeOff t, airAircraft a WHERE LTRIM(a.callSign) = @callSign AND t.nMaintCycle = a.nMaintCycle " +
            " AND LTRIM(t.callSign) = LTRIM(a.callSign) ORDER BY RegDate ";   DataTable tbl = new DataTable();
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn);
        dr.SelectCommand.Parameters.AddWithValue("@callSign", callSign.Trim()); dr.Fill(tbl); this._conn.Close(); return tbl;
    }

}