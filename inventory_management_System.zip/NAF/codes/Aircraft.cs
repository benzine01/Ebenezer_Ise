﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.IO;


public class ECO
{
    private static SqlConnection conn = new SqlConnection(Connect.CONN());
    public static string error;

    public static bool setSnagType(string name)
    {
        error = "Snag Type: " + name + " already exist...";     if (isSnagTypeExist(name) || name.Length < 3) return false; error = "";
        string sql = "INSERT INTO snagType(Name) VALUES(@name)";
        SqlCommand cmd = new SqlCommand(sql, conn);   cmd.Parameters.AddWithValue("@name", name); int n = 0;
        try { conn.Open(); n = int.Parse(cmd.ExecuteNonQuery().ToString());
        } catch (Exception ex) { error = ex.Message; }  finally { conn.Close(); }
        string trailMsg = "added Snag Type: " + name;
        Trail.setNew(Role.modECO, "ADD", "", trailMsg, true, ""); return (n > 0) ? true : false;
    }
    public static bool isSnagTypeExist(string name) { return (getSnagType(name).Rows.Count > 0) ? true : false; }
    public static DataTable getSnagType() { return getSnagType(""); }
    public static DataTable getSnagType(string name)
    {
        string where = ""; if (name.Trim().Length > 1) where = " WHERE Name = @name ";
        string sql = "SELECT * FROM snagType " + where + " ORDER BY Name ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn); DataTable TBL = new DataTable();
        if (name.Trim().Length > 1) dr.SelectCommand.Parameters.AddWithValue("@name", name.Trim());
        try { dr.Fill(TBL); conn.Close(); } catch { } return TBL;
    }
    public static DataTable getSnagType(int Id)
    {
        string sql = "SELECT * FROM snagType WHERE Id = @id ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn); DataTable TBL = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@id", Id); try { dr.Fill(TBL); conn.Close(); }
        catch { } return TBL;
    }
    public static string getTypeName(int Id) { try { return getSnagType(Id).Rows[0]["Name"].ToString(); } catch { return ""; } }
    
    public static bool setSnagAlertNos(int locId, int typId, string phone, string email, string RegIDNo)
    {
        string sql = "INSERT INTO invAlertNo(locId,typId,phone,email,RegIDNo,RegDate) VALUES(@locId,@typId,@phone,@email,@IDNo,@dt) ";
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@locId", locId);        cmd.Parameters.AddWithValue("@typId", typId);
        cmd.Parameters.AddWithValue("@phone", phone.Trim()); cmd.Parameters.AddWithValue("@email", email.Trim());
        cmd.Parameters.AddWithValue("@IDNo", RegIDNo);       cmd.Parameters.AddWithValue("@dt", DateTime.Now); int added = 0;
        try {  conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString());
        } catch (Exception ex) { error = ex.Message; } finally { conn.Close(); }
        string trailMsg = "added Snag alert numbers, LOCATION: " + ((locId == 0) ? "ALL LOCATIONS" : AppSet.getLocationName(locId)) +
            ", TYPE: " + ((typId == 0) ? "ALL TYPES" : getTypeName(typId)) + ", PHONE: " + phone + ", EMAIL: " + email;
        Trail.setNew(Role.modECO, "ADD", "", trailMsg, ((added > 0) ? true : false), error); return (added > 0) ? true : false;
    }

    public static DataTable getSnagAlertNos(int locId, int typId)
    {
        string where = "";
        if (locId > 0) where = " OR (a.locId = @locId ";   else where = " OR (a.locId >= @locId ";
        if (typId > 0) where += " AND a.typId = @typId) "; else where += " AND a.typId >= @typId) ";

        string sql = "SELECT a.*, (SELECT l.Name FROM location l WHERE l.Id = a.locId) AS Location, " +
            " (SELECT t.Name FROM snagType t WHERE t.Id = a.typId) AS typeName FROM snagAlertNo a WHERE a.locId = @zero " + where;
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);          dr.SelectCommand.Parameters.AddWithValue("@zero", 0);
        dr.SelectCommand.Parameters.AddWithValue("@locId", locId);  dr.SelectCommand.Parameters.AddWithValue("@typId", typId);
        DataTable TBL = new DataTable(); try { dr.Fill(TBL); conn.Close(); } catch { } return TBL;
    }

    private static DataTable getSnagAlertNos(int Id)
    {
        string sql = "SELECT a.*, (SELECT l.Name FROM location l WHERE l.Id = a.locId) AS Location, " +
            " (SELECT t.Name FROM snagType t WHERE t.Id = a.typId) AS typeName FROM snagAlertNo a WHERE a.Id = @id ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);      dr.SelectCommand.Parameters.AddWithValue("@id", Id);
        DataTable TBL = new DataTable(); try { dr.Fill(TBL); conn.Close(); } catch { } return TBL;
    }

    public static bool deleteSnagAlertNos(int Id)
    {
        DataTable TBL = getSnagAlertNos(Id);                string sql = "DELETE FROM snagAlertNo WHERE Id = @id ";
        SqlCommand cmd = new SqlCommand(sql, conn);         cmd.Parameters.AddWithValue("@id", Id); int added = 0;
        try {  conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString());
        } catch (Exception ex) { error = ex.Message; } finally { conn.Close(); }
        if (added > 0 && TBL.Rows.Count > 0)
        {
            DataRow dr = TBL.Rows[0];   string loc = dr["Location"].ToString().Trim(); string typ = dr["typeName"].ToString().Trim(); 
            string trailMsg = "deleted alert numbers, LOCATION: " + ((loc.Length < 2) ? "ALL LOCATIONS" : loc) +
                ", TYPE: " + ((typ.Length < 2) ? "ALL TYPES" : typ) + ", PHONE: " + dr["phone"].ToString() +
                ", EMAIL: " + dr["email"].ToString();
            Trail.setNew(Role.modECO, "DELETE", "", trailMsg, ((added > 0) ? true : false), error);
        }
        return (added > 0) ? true : false;
    }


}


public class Aircraft
{
    private static SqlConnection conn = new SqlConnection(Connect.CONN());
    public static string error;   
    //========================== ============================
    //=======================================================
    public static bool setServLev(int lev, string info)
    {
        if (lev > 1000) return false;                    string sql = "INSERT INTO airServLev(Level,Info) VALUES(@lev,@info) ";
        SqlCommand cmd = new SqlCommand(sql, conn);      int added = 0;
        cmd.Parameters.AddWithValue("@lev", lev);        cmd.Parameters.AddWithValue("@info", info);
        try {  conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString());
        } catch (Exception ex) { error = ex.Message; } finally { conn.Close(); }        return (added > 0) ? true : false;
    }
    public static int getServLev(int level)
    {
        string sql = "SELECT MIN(Level) FROM airServLev WHERE Level >= @lev ";
        SqlCommand cmd = new SqlCommand(sql, conn);     cmd.Parameters.AddWithValue("@lev", level); int lev = 0;
        try { conn.Open(); lev = int.Parse(cmd.ExecuteScalar().ToString()); } catch (Exception ex) { error = ex.Message; 
        } finally { conn.Close(); } return lev;
    }
    public static int getPrevServLev(int level)
    {
        string sql = "SELECT MAX(Level) FROM airServLev WHERE Level < @lev ";
        SqlCommand cmd = new SqlCommand(sql, conn);      cmd.Parameters.AddWithValue("@lev", level);        int lev = 0;
        try { conn.Open(); lev = int.Parse(cmd.ExecuteScalar().ToString()); } catch (Exception ex) { error = ex.Message; 
        } finally { conn.Close(); } return lev;
    }
    public static int getNextServLev(int level) { int nxtLev = level + 25; return getServLev(nxtLev); }
    public static int getMinServLev()
    {
        string sql = "SELECT MIN(Level) FROM airServLev ";     SqlCommand cmd = new SqlCommand(sql, conn); int lev = 0;
        try { conn.Open(); lev = int.Parse(cmd.ExecuteScalar().ToString()); }
        catch (Exception ex) { error = ex.Message; } finally { conn.Close(); } return lev;
    }
    public static int getMaxServLev()
    {
        string sql = "SELECT MAX(Level) FROM airServLev ";       SqlCommand cmd = new SqlCommand(sql, conn); int lev = 0;
        try { conn.Open(); lev = int.Parse(cmd.ExecuteScalar().ToString()); } catch (Exception ex) { error = ex.Message; 
        } finally { conn.Close(); } return lev;
    }
    

    //-------------------- AIRCRAFT AND CURRENT STATUS --------------------
    
    //public static DataTable getAircraft(string callsign)
    //{
    //    string sql = "SELECT a.*, (SELECT l.Name FROM location l WHERE l.Id = a.locId) AS Location " +
    //        " FROM aircraft a WHERE a.callSign = @callSign ";
    //    SqlDataAdapter dr = new SqlDataAdapter(sql, conn); dr.SelectCommand.Parameters.AddWithValue("@callSign", callsign.Trim());
    //    DataTable TBL = new DataTable(); try { dr.Fill(TBL); conn.Close(); }
    //    catch { } return TBL;
    //}
    //public static DataTable getAircraft() { return getAircraft(0); }
    //public static DataTable getAircraft(int locId)
    //{
    //    string where = ""; if (locId > 0) where = " WHERE a.locId = @loc ";
    //    string sql = "SELECT a.*, (SELECT l.Name FROM location l WHERE l.Id = a.locId) AS Location " +
    //        " FROM aircraft a " + where + " ORDER BY a.callSign ";
    //    SqlDataAdapter dr = new SqlDataAdapter(sql, conn);
    //    if (locId > 0) dr.SelectCommand.Parameters.AddWithValue("@loc", locId);
    //    DataTable TBL = new DataTable(); try { dr.Fill(TBL); conn.Close(); }
    //    catch { } return TBL;
    //}

    public static bool setAircraft(int locId, string callSign, string name)
    {
        error = "<font color='red'>Aircraft CallSign already exist...</font>";
        if (getAirCraftStatus(callSign).Rows.Count > 0) return false; error = "";
        string sql = "INSERT INTO aircraft(locId,callSign,Name,curHR,curMins,curLev,nextLev,nMaintCycle,HRsLeft,MinsLeft, " +
       " IsSnag,IsService,details) VALUES(@locId,@callSign,@name,@cHr,@cMin,@cLev,@nextLev,@nMaint,@lHr,@lMin,@isSnag,@isServ,@det)";
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@locId", locId);           cmd.Parameters.AddWithValue("@callSign", callSign.Trim());
        cmd.Parameters.AddWithValue("@name", name.Trim());      cmd.Parameters.AddWithValue("@cHr", 0);
        cmd.Parameters.AddWithValue("@cMin", 0);                cmd.Parameters.AddWithValue("@cLev", 0);
        cmd.Parameters.AddWithValue("@nextLev", 0);             cmd.Parameters.AddWithValue("@nMaint", 0);
        cmd.Parameters.AddWithValue("@lHr", 0);                 cmd.Parameters.AddWithValue("@lMin", 0);
        cmd.Parameters.AddWithValue("@isSnag", 0);              cmd.Parameters.AddWithValue("@isServ", true);
        cmd.Parameters.AddWithValue("@det", "");                int added = 0;
        try { conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString()); 
        } catch (Exception ex) { error = ex.Message; } finally { conn.Close(); }
        string trailMsg = "Location: " + AppSet.getLocationName(locId) + ", Call Sign: " + callSign + ", Name: " + name;
        Trail.setNew(Role.modAircraft, "ADD", "", trailMsg, true, ""); return (added > 0) ? true : false; 
    }

    public static DataTable getAirCraftStatus() { return getAirCraftStatus(0, ""); }
    public static DataTable getAirCraftStatus(int locId) { return getAirCraftStatus(locId, ""); }
    public static DataTable getAirCraftStatus(string callSign) { return getAirCraftStatus(0, callSign); }
    public static DataTable getAirCraftStatus(int locId, string callSign)
    {
        string where = " WHERE ", loc = "", call = "", and = " AND "; int n = 0; string fields = "";
        if (locId > 0) { loc = " locId = @locId "; n++; }
        if (callSign.Length > 1) { call = " LTRIM(callSign) = @callSign "; n++; } if (n < 2) and = ""; if (n < 1) where = "";
        fields = where + loc + and + call; //WHERE locId = @locId AND callSign = @callSign
        string sql = "SELECT *, (callSign + ' - ' + Name) AS CallSignName, (SELECT l.Name FROM location l WHERE l.Id = locId) AS Location, " +
            " (SELECT MAX(m.schInspLev) FROM airMaint m WHERE m.callSign = callSign AND m.nMaintCycle = nMaintCycle) AS LastInsp " +
            " FROM aircraft " + fields + " ORDER BY locId, CallSign ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);          DataTable tbl = new DataTable();
        if (locId > 0) dr.SelectCommand.Parameters.AddWithValue("@locId", locId);
        if (callSign.Length > 0) dr.SelectCommand.Parameters.AddWithValue("@callSign", callSign.Trim());
        try { dr.Fill(tbl); conn.Close(); } catch { } return tbl;
    }
    public static int getAircraftCycle(string callSign)
    {
        DataTable airTBL = getAirCraftStatus(callSign); if (airTBL.Rows.Count < 1) return 0;
        int nCycle = 0; try { nCycle = int.Parse(airTBL.Rows[0]["nMaintCycle"].ToString()); } catch { }   return nCycle;
    }

    private static bool updateAircraftStatus(string callSign, int nCycle, int curLev, int nextLev)
    {
        string sql = "UPDATE aircraft SET nMaintCycle = @nCycle, curLev = @curLev, nextLev = @nextLev WHERE callSign = @sign";
        SqlCommand cmd = new SqlCommand(sql, conn);             cmd.Parameters.AddWithValue("@nCycle", nCycle);
        cmd.Parameters.AddWithValue("@curLev", curLev);         cmd.Parameters.AddWithValue("@nextLev", nextLev);
        cmd.Parameters.AddWithValue("@sign", callSign);         int updated = 0;
        try { conn.Open(); updated = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { error = ex.Message; } finally { conn.Close(); }     return (updated > 0) ? true : false;
    }
    //-------------------------------
    public static bool setMaintenance(string callSign, int servLev, string details, string RegIDNo, string RegName)
    {
        int nCycle = getAircraftCycle(callSign);
        string sql = "INSERT INTO airMaint(callSign,nMaintCycle,servLev,details,RegID,RegName,RegDate) " +
            " VALUES(@callSign,@nCycle,@Lev,@details,@RegID,@RegName,@dt) ";
        SqlCommand cmd = new SqlCommand(sql, conn);             cmd.Parameters.AddWithValue("@callSign", callSign.Trim());
        cmd.Parameters.AddWithValue("@nCycle", nCycle);
        cmd.Parameters.AddWithValue("@Lev", servLev);           cmd.Parameters.AddWithValue("@details", details);
        cmd.Parameters.AddWithValue("@RegID", RegIDNo.Trim());  cmd.Parameters.AddWithValue("@RegName", RegName);
        cmd.Parameters.AddWithValue("@dt", DateTime.Now);       int added = 0;
        try {  conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString());
        } catch (Exception ex) { error = ex.Message; } finally { conn.Close(); }
        if (added > 0)
        {
            int maxServLev = getMaxServLev();
            if (maxServLev == servLev)
            {
                //it has reached the end of a cycle, restart
                int minServLev = getMinServLev(); nCycle += 1;
                int nextServLev = getNextServLev(minServLev);
                updateAircraftStatus(callSign, nCycle, minServLev, nextServLev);
            }
        }
        return (added > 0) ? true : false;
    }

    public static bool isMaintained(string callSign, int lev)
    {
        int nCycle = getAircraftCycle(callSign);
        string sql = "SELECT * FROM airMaint WHERE LTRIM(callSign) = @sign AND nMaintCycle = @cycle AND servLev < @lev";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);
        dr.SelectCommand.Parameters.AddWithValue("@sign", callSign.Trim());      dr.SelectCommand.Parameters.AddWithValue("@cycle", nCycle);
        dr.SelectCommand.Parameters.AddWithValue("@lev", lev);                   return true;
    }/**/

    public static DataTable getAircraftDue4maintainance()
    {
        string sql = "SELECT a.callSign,a.curLev FROM aircraft a WHERE " +
                    " LTRIM(a.callSign) NOT IN (SELECT LTRIM(m.callSign) FROM airMaint m " +
                    " WHERE LTRIM(m.callSign) = LTRIM(a.callSign)  AND m.servLev < a.curLev AND " +
                    " m.nMaintCycle = a.nMaintCycle) "; SqlDataAdapter dr = new SqlDataAdapter(sql, conn);
        DataTable tbl = new DataTable(); try { dr.Fill(tbl); conn.Close(); } catch { } return tbl;
    }

    //===================================================================
    public static DataTable getAircraftLastFlight(string callSign)
    {
        string sql = "SELECT *, (SELECT Name FROM aircraft WHERE LTRIM(callSign) = @sign) AS AircraftName " +
            " FROM airTakeOff WHERE LTRIM(callSign) = @sign AND " +
            " Id = (SELECT MAX(Id) FROM airTakeOff WHERE LTRIM(callSign) = @sign)";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);                     DataTable tbl = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@sign", callSign.Trim());    try { dr.Fill(tbl); conn.Close(); } catch { } return tbl;
    }

    public static bool setTakeOff(string callSign, string takeOffLoc, DateTime takeOffTime, string landLoc, DateTime landTime,
        int hr, int mins, int taskId, string taskName, int isSnag, string details, string RegIDNo, string RegName)
    {
        int nCycle = getAircraftCycle(callSign.Trim());       DateTime regDt = DateTime.Now;
        string sql = "INSERT INTO airTakeOff(callSign,takeOffLoc,takeOffTime,landLoc,landTime,nMaintCycle, HR,Mins,taskId,taskName," +
        " IsSnag,details,RegIDNo,RegName,RegDate) VALUES(@cSign,@offLoc,@offTime,@landLoc,@landTime,@nCycle, " +
        " @HR,@Mins,@taskId,@taskName, @isSnag,@detail,@IDNo,@RegName,@dt) ";
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@cSign", callSign.Trim());     cmd.Parameters.AddWithValue("@offLoc", takeOffLoc);
        cmd.Parameters.AddWithValue("@offTime", takeOffTime);       cmd.Parameters.AddWithValue("@landLoc", landLoc);
        cmd.Parameters.AddWithValue("@landTime", landTime);         cmd.Parameters.AddWithValue("@nCycle", nCycle);
        cmd.Parameters.AddWithValue("@HR", hr);
        cmd.Parameters.AddWithValue("@Mins", mins);                 cmd.Parameters.AddWithValue("@taskId", taskId);
        cmd.Parameters.AddWithValue("@taskName", taskName);         cmd.Parameters.AddWithValue("@isSnag", isSnag);
        cmd.Parameters.AddWithValue("@detail", details);            cmd.Parameters.AddWithValue("@IDNo", RegIDNo);
        cmd.Parameters.AddWithValue("@RegName", RegName);           cmd.Parameters.AddWithValue("@dt", regDt);              int added = 0;
        try { conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString()); } catch (Exception ex) { error = ex.Message; 
        } finally { conn.Close(); }
        if (added > 0)
        {
            bool isSuccess = updateAircraftStatus(callSign, nCycle, isSnag);
            if (!isSuccess)
            {
     string sql2 = "DELETE FROM airTakeOff WHERE callSign = @cSign AND nMaintCycle = @nCycle AND RegIDNo = @IDNo AND RegDate = @dt ";
                SqlCommand cmd2 = new SqlCommand(sql2, conn);
                cmd2.Parameters.AddWithValue("@cSign", callSign);   cmd2.Parameters.AddWithValue("@nCycle", nCycle);
                cmd2.Parameters.AddWithValue("@IDNo", RegIDNo);     cmd2.Parameters.AddWithValue("@dt", regDt);            
                int deleted = 0;
                try { conn.Open(); deleted = int.Parse(cmd2.ExecuteNonQuery().ToString()); }
                catch (Exception ex) { error += ex.Message; } finally { conn.Close(); } added = 0;
            }
        }
        return (added > 0) ? true : false;
    }

    private static bool updateAircraftStatus(string callSign, int nCycle, int isSnag)
    {
        callSign = callSign.Trim();  DataTable tbl = new DataTable(); tbl = getTakeOffSumHrs(callSign, nCycle);
        int curHr = 0, curMins = 0;
        if (tbl.Rows.Count > 0)
        {
            DataRow dr = tbl.Rows[0];
            curHr = int.Parse(dr["curHR"].ToString()); curMins = int.Parse(dr["curMins"].ToString());
        }
        if (curMins > 59) { curHr += Convert.ToInt32(curMins / 60); curMins = (curMins % 60); }

        int prevCurLev = 0, newNextLev = 0;
        if (curHr >= 25) prevCurLev = curHr - (curHr % 25); //400
        newNextLev = prevCurLev + 25;
        if (curHr > 1000) newNextLev = 1000;

        int hoursLeft = newNextLev - curHr; int minsLeft = 0;
        if (curMins > 0) { hoursLeft -= 1; minsLeft = 60 - curMins; }

        bool isService = true; if (isSnag == 2) isService = false;

        string _details = "";
        if (prevCurLev > 0 && !isMaintained(callSign, prevCurLev))
        {
            //Is not maintained
            isSnag = 2; isService = false;
            _details = "Maintainance of Service Hour: " + prevCurLev.ToString() + " has not been done...";
        }
        //===========================================
        string sql = "UPDATE aircraft SET curHR = @cHr, curMins = @cMins, curLev = @cLev, nextLev = @nxtLev, " +
        " HRsLeft = @lHr, MinsLeft = @lMins, IsSnag = @snag, IsService = @service, details = @details WHERE LTRIM(callSign) = @callSign  ";
        SqlCommand cmd = new SqlCommand(sql, conn);             int updated = 0;
        cmd.Parameters.AddWithValue("@cHr", curHr);             cmd.Parameters.AddWithValue("@cMins", curMins);
        cmd.Parameters.AddWithValue("@cLev", prevCurLev);       cmd.Parameters.AddWithValue("@nxtLev", newNextLev);
        cmd.Parameters.AddWithValue("@lHr", hoursLeft);         cmd.Parameters.AddWithValue("@lMins", minsLeft);
        cmd.Parameters.AddWithValue("@snag", isSnag);           cmd.Parameters.AddWithValue("@service", isService);
        cmd.Parameters.AddWithValue("@details", _details);      cmd.Parameters.AddWithValue("@callSign", callSign);
        try {    conn.Open(); updated = int.Parse(cmd.ExecuteNonQuery().ToString());
        } catch (Exception ex) { error = ex.Message; } finally { conn.Close(); } return (updated > 0) ? true : false;
    }

    /*private bool updateAircraftStatus(string callSign, int nCycle, int isSnag)
    {
        DataTable tbl = new DataTable(); tbl = this.getTakeOff(callSign, nCycle);     
        int curHr = 0, curMins = 0;
        if (tbl.Rows.Count > 0) {        DataRow dr = tbl.Rows[0]; 
            curHr = int.Parse(dr["curHR"].ToString()); curMins = int.Parse(dr["curMins"].ToString());
        }
        int maxServiceHrs = this.getMaxServLev();          int minServiceHrs = this.getMinServLev();

        int leftHR = 0, leftMins = 0;        
        if (curMins > 59) { curHr += Convert.ToInt32(curMins / 60); curMins = (curMins % 60); }

        int currentServLev = this.getServLev(curHr);       
        int prevServLev =  this.getPrevServLev(curHr);        string _details = "";

        int nextServiceLev = 0;    bool isService = (isSnag < 2)? true : false;
        if (currentServLev >= maxServiceHrs)
        {
            nextServiceLev = maxServiceHrs;
            if (curHr >= maxServiceHrs)
            {
                nextServiceLev = 0; isSnag = 2; isService = false;
                _details = "Maximum Flying Service Hours of " + maxServiceHrs.ToString() + " is exceeded...";
            } 
        }
        else  {   nextServiceLev = this.getNextServLev(curHr);  }        

        leftHR = maxServiceHrs - curHr;   if (curMins > 0) {  leftHR -= 1; leftMins = 60 - curMins;   }

        if (prevServLev > 0 && !this.isMaintained(callSign, prevServLev))
        {
            //Is not maintained
            isSnag = 2; isService = false;
            _details = "Maintainance of Service Hour: " + prevServLev.ToString() + " has not been done...";
        }

        
       
    }
    */
    private static DataTable getTakeOffSumHrs(string callSign, int nCycle)
    {
        string sql = "SELECT SUM(HR) AS curHR, SUM(Mins) AS curMins FROM airTakeOff " +
            " WHERE LTRIM(callSign) = @callSign AND nMaintCycle = @nCycle  ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);          DataTable tbl = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@callSign", callSign.Trim());
        dr.SelectCommand.Parameters.AddWithValue("@nCycle", nCycle);   try { dr.Fill(tbl); conn.Close(); } catch { } return tbl;
    }

    public static DataTable getTakeOffHist(string callSign)
    {
        string sql = "SELECT t.* FROM airTakeOff t, aircraft a WHERE LTRIM(a.callSign) = @callSign AND t.nMaintCycle = a.nMaintCycle " +
            " AND LTRIM(t.callSign) = LTRIM(a.callSign) ORDER BY RegDate ";         DataTable tbl = new DataTable();
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);      dr.SelectCommand.Parameters.AddWithValue("@callSign", callSign.Trim());
        try { dr.Fill(tbl); conn.Close(); } catch { } return tbl;
    }



}