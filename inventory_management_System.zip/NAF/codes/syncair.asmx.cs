﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;


using System.IO;
using System.Text;
using System.Data;
 

namespace NAF.codes
{
    /// <summary>
    /// Summary description for syncair
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
   
    [System.Web.Script.Services.ScriptService]
    public class syncair : System.Web.Services.WebService
    {

        private string timeoutMsg = "<font color='red'>session timeout, please login...</font>";


        [WebMethod(EnableSession = true)]
        public string setCalendarInspMth(string mth)
        {
            int mthId = 0; try { mthId = int.Parse(mth.Trim()); } catch { } Users obj = new Users();
            bool isAdded = false; // obj.setCalendarInspMth(mthId);
            if (isAdded) return "<font color='green'>Successfully added Calendar Months</font>";
            else return "<font color='red'>unable to add Calendar Months, <i> " + obj._error + " </i></font>";
        }


        [WebMethod(EnableSession = true)]
        public string setAircraft(string loc, string sign, string name)
        {
            if (!UserSession.IsActive) return timeoutMsg;
            int locId = 0; try { locId = int.Parse(loc); } catch { }       bool isAdded = Aircraft.setAircraft(locId, sign.Trim(), name.Trim());
            if (isAdded) return "<font color='green'>Successfully added Aircraft</font>";
            else return "<font color='red'>unable to add Aircraft, <i> " + Aircraft.error + " </i></font>";
        }

        [WebMethod(EnableSession = true)]
        public string setServLev(string lev, string info)
        {
            if (!UserSession.IsActive) return timeoutMsg; int level = 0; try { level = int.Parse(lev); } catch { }
            bool isAdded = Aircraft.setServLev(level, info);
            if (isAdded) return "<font color='green'>Successfully added Aircraft Service Level</font>";
            else return "<font color='red'>unable to add Aircraft Service Level, <i> " + Aircraft.error + " </i></font>";
        }
        
        [WebMethod(EnableSession = true)]
        public string setTakeOff(string sign, string task, string name, string tLocNm,
            string tHr, string tMins, string lLocNm, string lHr, string lMins, string spHr, string spMins, string isSnag, string rmk)
        {
            if (!UserSession.IsActive) return timeoutMsg;
            DateTime today = new DateTime(); today = DateTime.Now;
            int _tHr = 0, _tMins = 0; try { _tHr = int.Parse(tHr); _tMins = int.Parse(tMins); } catch { }
            int _lHr = 0, _lMins = 0; try { _lHr = int.Parse(lHr); _lMins = int.Parse(lMins); } catch { }

            int _spHr = 0, _spMins = 0, _IsSnag = 0;
            DateTime takeOffTime = new DateTime(today.Year, today.Month, today.Day, _tHr, _tMins, 0);
            DateTime landTime = new DateTime(today.Year, today.Month, today.Day, _lHr, _lMins, 0);
            try { _spHr = int.Parse(spHr); _spMins = int.Parse(spMins); _IsSnag = int.Parse(isSnag); } catch { }

            int _taskId = 0; try { _taskId = int.Parse(task); } catch { }
            
            //setTakeOff(string callSign, string takeOffLoc, DateTime takeOffTime, string landLoc, DateTime landTime,
            //int hr, int mins, int taskId, string taskName, int isSnag, string details, string RegIDNo, string RegName)
            bool isAdded = Aircraft.setTakeOff(sign, tLocNm, takeOffTime, lLocNm, landTime, _spHr, _spMins, _taskId, name, _IsSnag,
                rmk, UserSession.IDNo, UserSession.FullName);
            if (isAdded) return "<font color='green'>Successfully added...</font>";
            else return "<font color='red'>unable to add record..., <i> " + Aircraft.error + " </i></font>";
        }

        [WebMethod(EnableSession = true)]
        public string getCraftStatus(string calSign)
        {
            if (!UserSession.IsActive) return timeoutMsg;
            DataTable tbl = Aircraft.getAirCraftStatus(calSign);  
            if (tbl.Rows.Count < 1) return "<font color='red'>no record...</font>";     DataRow dr = tbl.Rows[0];
            int isSnag = 2;             try { isSnag = int.Parse(dr["IsSnag"].ToString()); } catch { }
            bool isService = false;     try { isService = bool.Parse(dr["IsService"].ToString()); } catch { }
            string snag = "";
            if (isSnag == 0) snag = "<font color='green'><b>No</b></font>";
            else if (isSnag == 1) snag = "<font color='orange'><b>Delay Discripancy</b></font> ";
            else if (isSnag == 2) snag = "<font color='red'><b>YES</b></font> ";
            string service = (isService && isSnag < 2) ? "<font color='green'><b>S</b></font> " : "<font color='red'><b>US</b></font> ";
            if (isSnag == 1) service = "<font color='orange'><b>S</b></font> ";

            string _tbl = "<table border='0' cellpadding='2' cellspacing='4'> " +
            "<tr align='left'><th>LOCATION: </th> <td> " + dr["Location"].ToString() + " </td></tr>" +
            "<tr align='left'><th>AIRCRAFT: </th> <td> " + dr["callSign"].ToString() + "</td></tr>" +
            "<tr align='left'><th>CURRENT HOURS: </th> <td> " + dr["curHR"].ToString() + " hrs, " +
                           dr["curMins"].ToString() + " mins </td></tr>" +
            "<tr align='left'><th>REMAINING HOURS: </th> <td> " + dr["HRsLeft"].ToString() + " hrs, " +
                           dr["MinsLeft"].ToString() + " mins </td></tr>" +
            "<tr align='left'><th>LAST INSPECTION: </th> <td> " + dr["curLev"].ToString() + "</td></tr>" +
            "<tr align='left'><th>NEXT INSPECTION: </th> <td> " + dr["nextLev"].ToString() + "</td></tr>" +
            "<tr align='left'><th>SNAG: </th> <td> " + snag + "</td></tr>" +
            "<tr align='left'><th>STATUS: </th> <td> " + service + "</td></tr>" +
            "<tr align='left' valign='top'><th>REMARK </th> <td> " + dr["details"].ToString() + "</td></tr></table>";
            return _tbl;
        }

        [WebMethod(EnableSession = true)]
        public string getCraftLastFlight(string calSign)
        {
            if (!UserSession.IsActive) return timeoutMsg;        DataTable tbl = Aircraft.getAircraftLastFlight(calSign);
            if (tbl.Rows.Count < 1) return "<font color='red'>no record...</font>";          DataRow dr = tbl.Rows[0];
            int isSnag = 2; try { isSnag = int.Parse(dr["IsSnag"].ToString()); } catch { }
            string snag = "";
            if (isSnag == 0) snag = "<font color='green'><b>No</b></font>";
            else if (isSnag == 1) snag = "<font color='orange'><b>Delay Discripancy</b></font> ";
            else if (isSnag == 2) snag = "<font color='red'><b>YES</b></font> ";
            int taskId = 0; try { taskId = int.Parse(dr["taskId"].ToString()); } catch { }
            string[] tasks = { "", "Mission", "FCF", "Hovering", "Ground Running" };

            // <option value="1">Mission</option>   <option value="2">Hovering</option> <option value="3">Grounding</option>

            string _tbl = "<table border='0' cellpadding='2' cellspacing='4'> " +
            "<tr><th align='left'>CALL SIGN: </th> <td> " + dr["callSign"].ToString() +
                     " </td></tr> <tr><th align='left'>TASK TYPE: </th> <td> " + tasks[taskId] + "</td></tr>" +
            "<tr><th align='left'>TASK NAME: </th> <td> " + dr["taskName"].ToString() + "</td></tr>" +
            "<tr><th align='left'>TAKE-OFF LOCATION: </th> <td> " + dr["takeOffLoc"].ToString() + "</td></tr>" +
            "<tr><th align='left'>TAKE-OFF TIME: </th> <td> " +
                DateTime.Parse(dr["takeOffTime"].ToString()).ToString("dd MMM yyyy. hh:mm tt") + " </td></tr>" +
            "<tr><th align='left'>LAND LOCATION: </th> <td> " + dr["landLoc"].ToString() + "</td></tr>" +
            "<tr><th align='left'>LAND TIME: </th> <td> " +
                 DateTime.Parse(dr["landTime"].ToString()).ToString("dd MMM yyyy. hh:mm tt") + " </td></tr>" +
            "<tr><th align='left'>FLIGHT TIME: </th> <td> " + dr["HR"].ToString() + " hrs, " +
                 dr["Mins"].ToString() + " mins</td></tr>" +
            "<tr><th align='left'>SNAG: </th> <td> " + snag + "</td></tr>" +
            "<tr valign='top'><th align='left'>REMARK: </th> <td> " + dr["details"].ToString() + "</td></tr>" +
            "<tr><th align='left'>REG. BY: </th> <td> " + dr["RegName"].ToString() + " (" + dr["RegIDNo"].ToString() + ") </td></tr>" +
            "<tr><th align='left'>REG. DATE: </th> <td> " +
                  DateTime.Parse(dr["landTime"].ToString()).ToString("dd MMM yyyy. hh:mm tt") + " </td></tr></table>";
            return _tbl;
        }


        [WebMethod(EnableSession = true)]
        public string getAircraftStatus(string loc)
        {
            if (!UserSession.IsActive) return timeoutMsg;     
            int locId = 0; try { locId = int.Parse(loc); } catch { }         DataTable airTBL = Aircraft.getAirCraftStatus(locId);
            if (airTBL.Rows.Count < 1)  return "<font color='red'>no record</font>";
            StringBuilder tbl = new StringBuilder();
            tbl.Append("<div class='tblHead' style='width:800px;align:center;'> LOCATION: " + airTBL.Rows[0]["Location"].ToString() + "</div>" +
                       "<table  style='font-size:12px; font-weight:100px;' cellpadding='0' cellspacing='0' border='0' " +
                       " class='display' id='craftStatusTBL'> <thead> <th>CALL SIGN</th> " +
                       " <th>CUR. HRs</th> <th>LAST INSP.</th>  <th>NEXT INSP.</th> <th>HRs. To NEXT INSP.</th> " +
                       " <th>SNAG</th><th>STATUS</th> <th>REMARK</th><th> </th> </tr></thead> " +
                       " <tfoot> <tr>  <th>CALL SIGN</th> <th>CUR. HRs</th> <th>LAST INSP.</th>  <th>NEXT INSP.</th> <th>HRs. To NEXT INSP.</th> " +
                       " <th>SNAG</th> <th>STATUS</th> <th>REMARK</th> <th> </th> </tr></tfoot> <tbody>");
            string img = "<img src='../images/arrow_right_16.png' alt='add' />";
            foreach (DataRow dr in airTBL.Rows)
            {
                /* CallSignName,  Location LastInsp */
                /*<tr> <th>AIRCRAFT TYPE</th><th>CALL SIGN</th> " +
                      " <th>CUR. HRs</th> <th>LAST INSP.</th>  <th>NEXT INSP.</th> <th>HRs. To NEXT INSP.</th> " +
                      " <th>STATUS</th> <th>REMARK</th> */
                int isSnag = 0; string snag = "", service = ""; try { isSnag = int.Parse(dr["IsSnag"].ToString()); } catch { }
                if (isSnag == 0) {         snag = "<font color='green'><b>NO</b></font>"; service = "<font color='green'><b>S</b></font>";
                } else if (isSnag == 1) {  service = "<font color='orange'><b>S</b></font>";   snag = "<font color='orange'><b>Delay Discripancy</b></font>";
                } else if (isSnag == 2) {  service = "<font color='red'><b>US</b></font>";     snag = "<font color='red'><b>YES</b></font>";     }

                string callSign = dr["callSign"].ToString().Trim();
                tbl.Append("<tr align='center'><td>" + callSign + " </td><td>" + dr["curHR"].ToString() + " Hrs, " + dr["curMins"].ToString() + " Mins</td>" +
                     " <td> " + dr["LastInsp"].ToString() + " </td><td> " + dr["nextLev"].ToString() + " </td><td>" + dr["HRsLeft"].ToString() + " Hrs, " +
                     dr["MinsLeft"].ToString() + " Mins </td><td>" + snag + " </td><td>" + service + " </td><td align='left'> " + dr["details"].ToString() +
                     " </td><td><a href='takeoff_hist.aspx?cs=" + callSign + "' target='_blank'> " + img + " </a> </td> </tr>");
            }
            tbl.Append("</tbody></table>"); return tbl.ToString();
        }


        [WebMethod]
        public object getDateDiff(string dt1, string dt2)
        {
            //var date1 = tYr + ',' + tMth + ',' + tDay + ',' + tHr + ',' + tMin;
            //var date2 = lYr + ',' + lMth + ',' + lDay + ',' + lHr + ',' + lMin;
            int _tDay = 0, _tMth = 0, _tYr = 0, _tHr = 0, _tMins = 0;
            int _lDay = 0, _lMth = 0, _lYr = 0, _lHr = 0, _lMins = 0;
            string[] t1 = dt1.Split(','); string[] t2 = dt2.Split(',');
            _tYr = int.Parse(t1[0]); _tMth = int.Parse(t1[1]); _tDay = int.Parse(t1[2]);
            _tHr = int.Parse(t1[3]); _tMins = int.Parse(t1[4]);

            _lYr = int.Parse(t2[0]); _lMth = int.Parse(t2[1]); _lDay = int.Parse(t2[2]);
            _lHr = int.Parse(t2[3]); _lMins = int.Parse(t2[4]);

            DateTime _dt1 = new DateTime(_tYr, _tMth, _tDay, _tHr, _tMins, 0);
            DateTime _dt2 = new DateTime(_lYr, _lMth, _lDay, _lHr, _lMins, 0);

            TimeSpan t = _dt2 - _dt1;
            double noOfDays = t.TotalDays; double noOfHours = t.TotalHours; double noOfMins = t.TotalMinutes;

            string str = "Days: " + noOfDays.ToString() + ", Hours: " + noOfHours.ToString() + ", Mins: " + noOfMins.ToString();
            //string msg = str + "<br>Date1: " + _dt1.ToString("MMM dd, yyyy hh:mm tt") + ",, " + dt1 + " <br>Date2: " +
            //    _dt2.ToString("MMM dd, yyyy hh:mm tt") + ",, " + dt2;
            var obj = new { HR = Convert.ToInt32(noOfMins / 60), Mins = noOfMins % 60 }; return obj;
        }


        [WebMethod(EnableSession = true)]
        public string getTakeOffHist(string callSign)
        {
            if (!UserSession.IsActive) return timeoutMsg;              DataTable TBL = Aircraft.getTakeOffHist(callSign);
            if (TBL.Rows.Count < 1) return "<font color='red'>no record in " + callSign + "...</font>";
            DataTable airTBL = Aircraft.getAirCraftStatus(callSign);   StringBuilder tbl = new StringBuilder();
            tbl.Append("<div class='tblHead' style='width:800px;align:center;'> LOCATION: " + airTBL.Rows[0]["Location"].ToString() + "</div>" +
                       "<table  style='font-size:12px; font-weight:100px;' cellpadding='0' cellspacing='0' border='0' " +
                       " class='display tbls' id='takeOffHistTBL'> <thead> <th>S/N</th> <th>CALL SIGN</th> <th>TASK</th>" +
                       " <th>TAKE-OFF LOC.</th> <th>LAND LOC.</th> <th>FLIGHT DATE</th> <th>TAKE-OFF TIME</th> " +
                       " <th>LAND TIME</th> <th>FLIGHT TIME</th> <th>IS SNAG</th><th>REMARK</th><th>REGISTERED BY</th> </tr></thead> " +
                       " <!--<tfoot> <tr> <th>S/N </th> <th>CALL SIGN</th> <th>TASK</th> <th>TAKE-OFF LOCATION</th>" +
                       "  <th>LAND LOCATION</th> <th>FLIGHT DATE</th><th>TAKE-OFF TIME</th> <th>LAND TIME</th> " +
                       " <th>FLIGHT TIME</th> <th>IS SNAG</th><th>REMARK</th><th>REGISTERED BY</th> </tr></tfoot>//--> <tbody>");
            //string del_img = "<img src='../images/delete.gif' alt='delete' title='Click to delete Item' />";
            int n = 0; string[] tasks = { "", "Mission", "FCF", "Hovering", "Ground Running" };
            foreach (DataRow dr in TBL.Rows)
            {
                n++;
                int isSnag = 2; try { isSnag = int.Parse(dr["IsSnag"].ToString()); } catch { }
                string snag = "";
                if (isSnag == 0) snag = "<font color='green'><b>NO</b></font>";
                else if (isSnag == 1) snag = "<font color='orange'><b>Delay Discripancy</b></font> ";
                else if (isSnag == 2) snag = "<font color='red'><b>YES</b></font> ";
                int taskId = 0; try { taskId = int.Parse(dr["taskId"].ToString()); } catch { }                
                string task = tasks[taskId] + " - " + dr["taskName"].ToString();
                tbl.Append("<tr><td> " + n.ToString() + ". </td><td> " + dr["callSign"].ToString() + " </td><td>" + task
                    + " </td><td> " + dr["takeOffLoc"].ToString() + "</td><td> " + dr["landLoc"].ToString() + " </td> <td>" +
                    DateTime.Parse(dr["RegDate"].ToString()).ToString("MMM dd, yyyy") + " </td><td> " +
                    DateTime.Parse(dr["takeOffTime"].ToString()).ToString("HH:mm") + " </td><td>" +
                    DateTime.Parse(dr["landTime"].ToString()).ToString("HH:mm") + " </td> " +
                " <td> " + dr["HR"].ToString() + ":" + dr["Mins"].ToString() + " </td><td> " + snag + " </td><td> " +
                dr["details"].ToString() + " </td><td> " + dr["RegName"].ToString() + " </td> </tr>");
            }
            tbl.Append("</tbody></table>"); return tbl.ToString();
        }
        
    }
}
