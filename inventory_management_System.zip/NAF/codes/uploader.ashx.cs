﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.IO;
using System.Web.Services;

namespace NAF.codes
{
     
    public class uploader : IHttpHandler
    {

        [WebMethod(EnableSession = true)]
        public void ProcessRequest(HttpContext context)
        {
            if (context.Request.Files.Count > 0)
            {
                string path = context.Server.MapPath("~/fTemp");
                if (!Directory.Exists(path)) Directory.CreateDirectory(path);

                var file = context.Request.Files[0];
                string fileName = System.IO.Path.GetFileName(file.FileName);
                string strFileName = fileName;

                string prevFile = ""; try { prevFile = context.Request.Params["prevFile"].ToString(); }
                catch { }
                string preFix = ""; try { preFix = context.Request.Params["name"].ToString(); }
                catch { }

                if (prevFile.Length > 4)
                {
                    string prevFilePath = Path.Combine(path, prevFile);
                    if (File.Exists(prevFilePath)) { try { File.Delete(prevFilePath); } catch { } }
                }

                string newFileNm = "";
                string dt = DateTime.Now.ToString("_yyyy.MM.dd.HH.mm.ss_") + DateTime.Now.Millisecond.ToString() + "_";
                string ext = Path.GetExtension(fileName).ToLower();
                Random rnd = new Random();
                newFileNm = preFix + dt + rnd.Next(1, 9999).ToString() + ext;
                fileName = Path.Combine(path, newFileNm); file.SaveAs(fileName);

                string msg = "{"; msg += string.Format("error:'{0}',\n", string.Empty);
                msg += string.Format("newFileName:'{0}',\n", newFileNm);
                msg += string.Format("fileName:'{0}'\n", strFileName);
                msg += "}"; context.Response.Write(msg);
            }
        }
        public bool IsReusable { get { return false; } }

    }
}