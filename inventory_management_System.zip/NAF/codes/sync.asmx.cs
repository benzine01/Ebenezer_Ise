﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

using System.IO;
using System.Text;
using System.Data;

namespace NAF.codes
{
     
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    
    [System.Web.Script.Services.ScriptService]
    public class sync : System.Web.Services.WebService
    {

        private string timeoutMsg = "<font color='red'>session timeout, please login...</font>";

        [WebMethod(EnableSession = true)]
        public object setBrowser(string info)
        {
            try { UserSession.browserInfo = info; } catch { }
            if (UserSession.idleMins < 2)
            {
                var _ob = new { Id = 0, idleMin = UserSession.countIdleMins }; return _ob;
            }
            DateTime curTime = DateTime.Now, prevTime = UserSession.idleSetTime;
            int prevMin = prevTime.Minute, prevSecs = prevTime.Second;
            int curMins = curTime.Minute, curSecs = curTime.Second;

            if (prevMin != curMins) { UserSession.countIdleMins++; UserSession.idleSetTime = curTime; }

            try
            {
                if (UserSession.countIdleMins > UserSession.idleMins && UserSession.idleMins > 0)
                {
                    try { UserSession.End(); }
                    catch { } var obj = new { Id = 1, idleMin = UserSession.countIdleMins }; return obj;
                }
            }
            catch { }
            var _obj = new { Id = 0, idleMin = UserSession.countIdleMins }; return _obj;
        }
        [WebMethod(EnableSession = true)]
        public void clearIdle() { UserSession.countIdleMins = 0; }


        [WebMethod(EnableSession = true)]
        public string changePWD(string oldPWD, string newPWD)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;
            string msg = "";
            if (oldPWD == UserSession.PWD)
            {
                Users obj = new Users();
                if (newPWD.Length > 4 && UserSession.PWD.Length > 4 && UserSession.UserId > 0)
                {

                    bool isValid =  obj.changePWD(UserSession.UserId, newPWD);
                    
                    if (isValid)
                    {
                        UserSession.PWD = newPWD; msg = "<font color='green'>Successfully changed password </font>";
                    }
                    else msg = "<font color='red'>unable to change password, <i>" + obj._error + "</i> </font>";
                }
                else if (UserSession.PWD.Length < 4 || UserSession.UserId < 1)
                    msg = "<font color='red'>session closed, please login to change password... </font>";
                else
                    msg = "<font color='red'>unknown operation, please login to change password... </font>";
                return msg;
            }
            else return "<font color='red'>please enter a valid password...</font>";


        }

        [WebMethod(EnableSession = true)]
        public string changeUserNm(string oldUserNm, string newUserNm)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;
            string msg = "";
            if (oldUserNm == UserSession.UserName)
            {
                Users obj = new Users();
                if (newUserNm.Length > 4 && UserSession.UserName.Length > 4 && UserSession.UserId > 0)
                {
                    bool isValid =  obj.changeUserNm(UserSession.UserId, newUserNm);
                    
                    if (isValid)
                    {
                        UserSession.UserName = newUserNm;
                        msg = "<font color='green'>Successfully changed username... </font>";
                    }
                    else msg = "<font color='red'>unable to change username, <i>" + obj._error + "</i> </font>";
                }
                else if (UserSession.UserName.Length < 4 || UserSession.UserId < 1)
                    msg = "<font color='red'>session closed, please login to change username... </font>";
                else
                    msg = "<font color='red'>unknown operation, please login to change username... </font>";
                return msg;
            }
            else return "<font color='red'>please enter a valid username...</font>";

        }

        [WebMethod]
        public string forgetPWD(string IDNo)
        {
            string msg = "";
            try { msg = Users.forgotPWD(IDNo); }
            catch (Exception ex)
            { msg = "<font color='red'>Error:" + ex.Message + "</font>"; } return msg;
        }

        [WebMethod(EnableSession = true)]
        public string getSMS_Balance()
        {
            if (!UserSession.IsActive) return this.timeoutMsg; return Mailer.getSmsBalance();
        }

        [WebMethod(EnableSession = true)]
        public string sendSMS(string sender, string phones, string msg)
        {
            if (!UserSession.IsActive) return this.timeoutMsg; return Mailer.sendSMS(sender, phones, msg);
        }

        
    }
}
