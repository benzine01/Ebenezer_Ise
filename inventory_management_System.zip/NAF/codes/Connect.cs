﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Configuration;

using System.Data.SqlClient; 
using System.Data;
using System.IO;

public class Connect {
    public static string CONN() { return ConfigurationManager.ConnectionStrings["DBConnID"].ConnectionString; }
}

public class AppSet
{
    private static SqlConnection conn = new SqlConnection(Connect.CONN());
    public static string _error;

    public static void set()
    {
        if (AppSet.countRows() > 0) return;
        string sql = "INSERT INTO appSet(IdleMins,SmtpServer,SmtpPort,SmtpEmail,SmtpPWD,SmtpDisplay,SmsTitle,SmsID,isLogin,loginTime, " +
        " isLogout,logoutTime,maxAdmin,maxSuper,maxUser) " +
        " VALUES(@IdleMins,@server, @port, @email,@PWD,@SmtpDisplay,@SmsTitle,@SmsID, " +
      " @isLogin, @loginTime,@isLogout,@logoutTime,@maxAdmin,@maxSuper,@maxUser) ";
        SqlCommand cmd = new SqlCommand(sql, conn);         cmd.Parameters.AddWithValue("@IdleMins", 10);
        cmd.Parameters.AddWithValue("@server", "");         cmd.Parameters.AddWithValue("@port", 0);
        cmd.Parameters.AddWithValue("@email", "");          cmd.Parameters.AddWithValue("@PWD", "");
        cmd.Parameters.AddWithValue("@SmtpDisplay", "");
        cmd.Parameters.AddWithValue("@SmsTitle", "");       cmd.Parameters.AddWithValue("@SmsID", "");
        cmd.Parameters.AddWithValue("@isLogin", false);     cmd.Parameters.AddWithValue("@loginTime", DateTime.Now);
        cmd.Parameters.AddWithValue("@isLogout", false);    cmd.Parameters.AddWithValue("@logoutTime", DateTime.Now);
        cmd.Parameters.AddWithValue("@maxAdmin", 0);        cmd.Parameters.AddWithValue("@maxSuper", 0);
        cmd.Parameters.AddWithValue("@maxUser", 0);
        try { conn.Open(); cmd.ExecuteNonQuery(); } catch (Exception ex) { _error = ex.Message; } finally { conn.Close(); }
    }

    public static int countRows() { return getTBL().Rows.Count; }
    private static DataTable getTBL()
    {
        string sql = "SELECT * FROM appSet "; SqlDataAdapter drs = new SqlDataAdapter(sql, conn);
        DataTable TBL = new DataTable(); try { drs.Fill(TBL); conn.Close(); } catch { } return TBL;
    }

    public static void getValus()
    {
        DataTable TBLs = getTBL(); int nRows = TBLs.Rows.Count;
        if (nRows < 1)
        {
            smtpServer = ""; smtpPort = 0; smtpEmail = ""; smtpPWD = ""; smtpDisplay = ""; smsTitle = ""; smsID = "";
            isLoginActive = false; loginTime = DateTime.Now; isLogoutActive = false; logoutTime = DateTime.Now;
            maxAdmin = 0; maxSuper = 0; maxUser = 0;  idleMins = 0;
        }
        else
        {
            DataRow dr = TBLs.Rows[0];
            smtpServer = dr["SmtpServer"].ToString().Trim();        smtpPort = int.Parse(dr["SmtpPort"].ToString());
            smtpEmail = dr["SmtpEmail"].ToString().Trim();          smtpPWD = dr["SmtpPWD"].ToString().Trim();
            smtpDisplay = dr["SmtpDisplay"].ToString().Trim();
            smsTitle = dr["SmsTitle"].ToString();                   smsID = dr["SmsID"].ToString().Trim();

            isLoginActive = bool.Parse(dr["isLogin"].ToString());       loginTime = DateTime.Parse(dr["loginTime"].ToString());
            isLogoutActive = bool.Parse(dr["isLogout"].ToString());     logoutTime = DateTime.Parse(dr["logoutTime"].ToString());
            maxAdmin = int.Parse(dr["maxAdmin"].ToString());            maxSuper = int.Parse(dr["maxSuper"].ToString());
            maxUser = int.Parse(dr["maxUser"].ToString());              idleMins = int.Parse(dr["IdleMins"].ToString()); 
        }
    }

    public static int idleMins { get; set; }

    public static string smtpServer { get; set; }        public static int smtpPort { get; set; }
    public static string smtpEmail { get; set; }         public static string smtpPWD { get; set; }
    public static string smtpDisplay { get; set; }
    public static string smsTitle { get; set; }           public static string smsID { get; set; }

    public static bool isLoginActive { get; set; }        public static DateTime loginTime { get; set; }
    public static bool isLogoutActive { get; set; }       public static DateTime logoutTime { get; set; }

    public static int maxAdmin { get; set; }   public static int maxSuper { get; set; }    public static int maxUser { get; set; }       
     
    //===============================================================
    //===============================================================
    public static bool setEmail(string server, int port, string email, string pwd, string display)
    {
        AppSet.set();
        string sql = "UPDATE appSet SET SmtpServer = @server, SmtpPort = @port, SmtpEmail = @email, SmtpPWD = @pwd, " +
            " SmtpDisplay = @display "; SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@server", server); cmd.Parameters.AddWithValue("@port", port);
        cmd.Parameters.AddWithValue("@email", email); cmd.Parameters.AddWithValue("@pwd", pwd);
        cmd.Parameters.AddWithValue("@display", display); int updated = 0;
        try { conn.Open(); updated = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { _error = ex.Message; }
        finally { conn.Close(); }
        string trailMsg = "SMTP Server: " + server + ", PORT: " + port.ToString() + ", EMAIL ADDR: " + email +
            ", DISPLAY NAME: " + display;
        Trail.setNew("SETTINGS", "EMAIL", "", "configured EMAIL OUT-GOING SMTP DETAILS, " + trailMsg,
            ((updated > 0) ? true : false), _error); return (updated > 0) ? true : false;
    }
    public static bool setSMS(string title, string sesID)
    {
        AppSet.set();
        string sql = "UPDATE appSet SET SmsTitle = @title, SmsID = @sesID ";
        SqlCommand cmd = new SqlCommand(sql, conn); cmd.Parameters.AddWithValue("@title", title);
        cmd.Parameters.AddWithValue("@sesID", sesID); int updated = 0;
        try { conn.Open(); updated = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { _error = ex.Message; }
        finally { conn.Close(); }
        Trail.setNew("SETTINGS", "SMS", "", "configured SMS GATEWAY ID: " + sesID + " TITLE: " + title,
            ((updated > 0) ? true : false), _error);       return (updated > 0) ? true : false;
    }
    public static bool setLogin(bool isActive, DateTime loginOutTime, bool isLogin)
    {
        AppSet.set(); _error = "";
        string field = "isLogin = @active, loginTime = @time "; if (!isLogin) field = "isLogout = @active, logoutTime = @time ";
        string sql = "UPDATE appSet SET  " + field;
        SqlCommand cmd = new SqlCommand(sql, conn); cmd.Parameters.AddWithValue("@active", isActive);
        cmd.Parameters.AddWithValue("@time", loginOutTime); int updated = 0;
        try { conn.Open(); updated = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { _error = ex.Message; }
        finally { conn.Close(); }
        string trialMsg = "";
        if (isActive) trialMsg = "Activated " + ((isLogin) ? "LOGIN" : "LOGOUT") + " TIMER: " + loginOutTime.ToString("hh:mm tt");
        else trialMsg = "De-Activated " + ((isLogin) ? "LOGIN" : "LOGOUT") + " TIMER ";
        Trail.setNew("SETTINGS", trialMsg + " TIMER", "", trialMsg, ((updated > 0) ? true : false), _error);
        return (updated > 0) ? true : false;
    }
    public static bool setMaxUsers(int _maxAdmin, int _maxSuper, int _maxUser)
    {
        AppSet.set();
        string sql = "UPDATE appSet SET maxAdmin = @admin, maxSuper = @super, maxUser = @user  ";
        SqlCommand cmd = new SqlCommand(sql, conn); cmd.Parameters.AddWithValue("@admin", _maxAdmin);
        cmd.Parameters.AddWithValue("@super", _maxSuper);
        cmd.Parameters.AddWithValue("@user", _maxUser); int updated = 0;
        try { conn.Open(); updated = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { _error = ex.Message; }
        finally { conn.Close(); }
        string trailMsg = "Admin: " + ((_maxAdmin == 0) ? "Unlimited" : _maxAdmin.ToString()) +
            ", Super User: " + ((_maxSuper == 0) ? "Unlimited" : _maxSuper.ToString()) +
            ", User: " + ((_maxUser == 0) ? "Unlimited" : _maxUser.ToString());
        Trail.setNew("SETTINGS", "MAXIMUM USERS", "", "configured the application maximum users " + trailMsg,
           ((updated > 0) ? true : false), _error); return (updated > 0) ? true : false;
    }

    public static bool setIdleMins(int mins)
    {
        AppSet.set();
        string sql = "UPDATE appSet SET IdleMins = @mins  ";
        SqlCommand cmd = new SqlCommand(sql, conn); cmd.Parameters.AddWithValue("@mins", mins);      int updated = 0;
        try { conn.Open(); updated = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { _error = ex.Message; } finally { conn.Close(); }
        string trailMsg = "Idle Minutes: " + ((mins == 0) ? "Unlimited" : mins.ToString());
        Trail.setNew("SETTINGS", "IDLE MINs", "", "configured the idle minutes timeout, " + trailMsg,
           ((updated > 0) ? true : false), _error); return (updated > 0) ? true : false;
    }
    
    
    
    //--------------------------------------
    public static bool setLocation(string name)
    {
        _error = "<font color='red'>Type Name: " + name + ", already exist...</font>";
        if (getLocation(name).Rows.Count > 0) return false; _error = "";
        string sql = "INSERT INTO location(Name) VALUES(@name) "; SqlCommand cmd = new SqlCommand(sql, conn); int added = 0;
        cmd.Parameters.AddWithValue("@name", name.Trim());
        try { conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception ex) { _error = ex.Message; } finally { conn.Close(); }
        Trail.setNew(Role.modSettings, "ADD", "", "added Location, NAME: " + name, ((added > 0) ? true : false), _error);
        return (added > 0) ? true : false;
    }
    public static DataTable getLocation() { return getLocation(""); }
    public static DataTable getLocation(string name)
    {
        string where = ""; if (name.Length > 2) where += " WHERE Name = @name ";
        string sql = "SELECT *, Id AS locId FROM location " + where + " ORDER BY Name ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn); DataTable TBL = new DataTable();
        if (name.Length > 2) dr.SelectCommand.Parameters.AddWithValue("@name", name);
        try { dr.Fill(TBL); conn.Close(); } catch { } return TBL;
    }
    public static string getLocationName(int locId)
    {
        string sql = "SELECT Name FROM location WHERE Id = @id ";
        SqlCommand cmd = new SqlCommand(sql, conn); SqlDataReader dr = null;
        cmd.Parameters.AddWithValue("@id", locId); string name = "";
        try { conn.Open(); dr = cmd.ExecuteReader();  while (dr.Read()) { name = dr["Name"].ToString(); } }
        catch (Exception ex) { _error = ex.Message; } finally { conn.Close(); } return name;
    }  
}



public class Trail
{
    private static SqlConnection conn = new SqlConnection(Connect.CONN());
    public static string error { get; set; } 
    
    public static bool setNew(string module, string action, string affectedStaffName, string actionMsg, bool isSuccess, string errMsg)
    {
        string sql = "INSERT INTO AuditTrail(Module,Action,STAFF,ActionMSG,IsSuccess,ErrMSG, " +
        " MachInfo,RegName,RegDate) VALUES(@Module,@Action,@membID,@actionMsg,@IsSuccess,@ErrMSG,@mach,@regNm,@dt) ";  
        if (errMsg == null || errMsg.Length < 2) errMsg = "";
        SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@Module", module);             cmd.Parameters.AddWithValue("@Action", action);
        cmd.Parameters.AddWithValue("@membID", affectedStaffName);
        cmd.Parameters.AddWithValue("@actionMsg", actionMsg);       cmd.Parameters.AddWithValue("@IsSuccess", isSuccess);
        cmd.Parameters.AddWithValue("@ErrMSG", errMsg);
        cmd.Parameters.AddWithValue("@mach", UserSession.browserInfo);
        cmd.Parameters.AddWithValue("@regNm", UserSession.FullName);
        cmd.Parameters.AddWithValue("@dt", DateTime.Now); int added = 0;
        try  {  conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString());
        }   catch (Exception ex) { error = ex.Message; }   finally { conn.Close(); }     return (added > 0) ? true : false;
    }
     
    public static DataTable getTrail(string module, string action, DateTime fromDt, DateTime toDate)
    {
        string moduleF = (module.Trim().Length < 3) ? "" : " a.Module = @modul AND ";
        string actionF = (action.Trim().Length < 3) ? "" : " a.Action = @action AND ";

        string sql = "SELECT a.* FROM AuditTrail a WHERE " + moduleF + actionF +
            " cast(CONVERT(varchar(8), a.RegDate, 112) AS datetime) >= @fromDt AND " +
            " cast(CONVERT(varchar(8), a.RegDate, 112) AS datetime) <= @toDt ORDER BY a.RegDate DESC ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn); DataTable tbl = new DataTable();
        if (moduleF.Length > 2) dr.SelectCommand.Parameters.AddWithValue("@modul", module);
        if (actionF.Length > 2) dr.SelectCommand.Parameters.AddWithValue("@action", action);
        dr.SelectCommand.Parameters.AddWithValue("@fromDt", fromDt);
        dr.SelectCommand.Parameters.AddWithValue("@toDt", toDate);
        try { dr.Fill(tbl); conn.Close(); } catch { } return tbl;
    }

    //Trail.setNew(Role.modInventory, "DAILY ALERT", "", "sent daily SMS/Email Alert", true, "");
    public static bool isDailyAlertSent()
    {
        string sql = "SELECT COUNT(Id) FROM AuditTrail WHERE Module = @module AND Action = @daily AND " +
            " cast(CONVERT(varchar(8), RegDate, 112) AS datetime) == @dt ";
        SqlCommand cmd = new SqlCommand(sql, conn);                 cmd.Parameters.AddWithValue("@module", Role.modInventory);
        cmd.Parameters.AddWithValue("@daily", "DAILY ALERT");       cmd.Parameters.AddWithValue("@dt", DateTime.Now);
        int nRows = 0;
        try { conn.Open(); nRows = int.Parse(cmd.ExecuteScalar().ToString()); }
        catch (Exception ex) { error = ex.Message; } finally { conn.Close(); }     return (nRows > 0) ? true : false;
    }

}



public class Include
{

    public static string getLinks()
    {
        return "<link rel='stylesheet' type='text/css' href='../jq/themes/cupertino/jquery.ui.all.css' /> " +
            "<script type='text/javascript' src='../jq/jq171.js'></script> " +
               "<script type='text/javascript' src='../jq/ui/jquery.ui.core.js'></script>    " +
               "<script type='text/javascript' src='../jq/ui/jquery.ui.widget.js'></script> " +
               "<script type='text/javascript' src='../jq/ui/jquery.ui.accordion.js'></script> " +
               "<script type='text/javascript' src='../jq/ui/jquery.ui.mouse.js'></script>" +
               "<script type='text/javascript' src='../jq/ui/jquery.ui.resizable.js'></script> " +
               "<script type='text/javascript' src='../jq/ui/jquery.ui.tabs.js'></script>     " +
               "<script type='text/javascript' src='../jq/ui/jquery.ui.draggable.js'></script>" +
               "<script type='text/javascript' src='../jq/ui/jquery.ui.position.js'></script>" +
               "<script type='text/javascript' src='../jq/ui/jquery.ui.dialog.js'></script>" +
               "<script type='text/javascript' src='../jq/ui/jquery.ui.sortable.js'></script> " +
               "<script type='text/javascript' src='../jq/sync.js'></script>";
    }
    
    public static string getNavigators()
    {
        return "<div id='header-wrapper'>  <div id='header'> " +
            "<h1>  <a id='rtd' href='#' title='Go to homepage'></a>  </h1> <ul class='nav'> " +
            ((UserSession.LevId == 1) ? "<li><a href='appset.aspx' title='Settings Management'>SETTINGS</a></li>" : "") +
            " <li><a href='membmgt.aspx' title='Membership Management'>MEMBERSHIP</a></li> " +
            " <li><a href='../authuser.aspx' title='Log out from the Application'>LOGOUT</a></li> </ul> </div>  </div>";
    }

    public static string getFooter()
    {
        return "<div id='footer'><div id='footer-inner'>&copy;Copyright " + DateTime.Now.Year.ToString()
            + ". |&nbsp;All Rights Reserved... </div></div>";
    }

    public static string getUserNmPWD_btns()
    {
        return "<div style='float:left;padding:5px;'> " +
               "<a class='comment-reply-link' href=\"javascript:location.href='../authuser.aspx';\" title='Click to Logout'> " +
                       "<img src='../images/btn_logoff.gif' alt='' /> </a></div> " +
           "<div style='float:left;padding:5px;'> " +
               "<a class='comment-reply-link' href=\"javascript:location.reload();\" title='Click to Reload Page'> " +
                       "<img src='../images/btn_refresh.gif' alt='' /> </a></div> " +
            "<div style='float:left;padding:5px;'> " + // width='30' height='30'
               "<a class='comment-reply-link' href=\"javascript:openDialog('div_changeUser');\" title='Click to Change Your Username'> " +
                       "<img src='../images/edit_user.gif'  alt='' /> </a></div> " +
            "<div style='float:left;padding:5px;'> " +
            "<a class='comment-reply-link' href=\"javascript:openDialog('div_changePWD');\" title='Click to Change Your Password'> " +
                       "<img src='../images/edit_pwd.gif' alt='' /> </a></div>";
    }

    public static string getUserNmPWD_dialog()
    {
        return "<div id='div_changeUser' title='CHANGE USERNAME:'> " + "<div id='spanChangeUser'></div> " +
              "<table><tr valign='top'> <td> <img src='../images/edituser.gif' />  </td> <td> <div> " +
              "OLD USERNAME:<br /> &nbsp; &nbsp;&nbsp; &nbsp; " +
              "    <input type='text' id='txtOldUNm' /><span id='txtOldUNm_' class='err'></span><br /> " +
              "NEW USERNAME:<br /> &nbsp; &nbsp;&nbsp; &nbsp; " +
              "    <input type='text' id='txtNewUNm' /><span id='txtNewUNm_' class='err'></span> <br /> " +
              "RE-TYPE USERNAME:<br /> &nbsp; &nbsp;&nbsp; &nbsp; " +
              "    <input type='text' id='txtRNewUNm' /><span id='txtRNewUNm_' class='err'></span> <br /> </div> </td></tr></table> " +
        "</div> <div id='div_changePWD' title='CHANGE PASSWORD:'> <div id='spanChangePWD'></div>  <table><tr valign='top'> " +
              " <td> <img src='../images/key.gif' style='height: 115px' />  </td> <td>OLD PASSWORD:<br /> &nbsp; &nbsp;&nbsp; &nbsp; " +
              "    <input type='password' id='txtOldPWD' /> <span id='txtOldPWD_' class='err'></span><br /> " +
              "    NEW PASSWORD:<br /> &nbsp; &nbsp;&nbsp; &nbsp; <input type='password' id='txtNewPWD' />  " +
              "    <span id='pwd_strength'></span><span id='txtNewPWD_' class='err'></span><br /> " +
              "    RE-TYPE PASSWORD:<br /> &nbsp; &nbsp;&nbsp; &nbsp; <input type='password' id='txtRNewPWD' /> " +
              "    <span id='txtRNewPWD_' class='err'></span><br />  </td></tr></table> </div> ";
    }

    private static string DeCode(string Str)
    {
        return HttpUtility.HtmlDecode(Str).Replace("<p>", "").Replace("</p>", "<br>")
            .Replace("<script", "<pre").Replace("</script>", "</pre>").Replace("<iframe", "<pre").Replace("</iframe>", "</pre>");
    }

}