﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.IO;

public class Users
{
    public Users() { try { AppSet.set();   } catch { } }

    private SqlConnection _conn = new SqlConnection(Connect.CONN());
    private static SqlConnection conn = new SqlConnection(Connect.CONN());
    public string _error = ""; public static string error { get; set; }

    public static string Module { get { return "USERS"; } }
   
    public bool loginUser(string userName, string pwd)
    {
        userName = userName.Trim(); pwd = pwd.Trim();
        if (this.countUsers(0) < 1)
        {
            try {  this._conn.Open();
                if (this._conn.State == ConnectionState.Open) {  this._conn.Close();
                    UserSession.setNew(0, 0, "", "", "", "", 1, "07030378600", "keltangs@gmail.com", "");
                    UserSession.IsFirstUser = true;    Role.startFirstUserRole();     return true;
                } else {  _error = "<font color='red'>Please check your database connection...</font>"; return false; }
            } catch { _error = "<font color='red'>Please check your database connection...</font>"; return false; }             
        } else {

            bool isActive = false; int k = 0; string fullname = "", IDNo = ""; int UserId = 0, levId = 0, locId = 0;
            string sql = "SELECT * FROM Users WHERE UserName = @userNm AND BINARY_CHECKSUM(PWD) = BINARY_CHECKSUM(@pwd) " ;
            SqlCommand cmd = new SqlCommand(sql, this._conn); cmd.Parameters.AddWithValue("@userNm", userName);
            cmd.Parameters.AddWithValue("@pwd", pwd);         SqlDataReader dr = null;  
            try { this._conn.Open(); dr = cmd.ExecuteReader();
                while (dr.Read()) {
                    k++; isActive = bool.Parse(dr["IsActive"].ToString()); fullname = dr["FullName"].ToString();
                    IDNo = dr["IDNo"].ToString().Trim();
                    if (isActive) {
                        string  phone = dr["Phone"].ToString(), email = dr["Email"].ToString(), lastLogDt = "";                        
                        levId = int.Parse(dr["LevId"].ToString());    UserId = int.Parse(dr["Id"].ToString());
                        locId = int.Parse(dr["locId"].ToString());
                        try { lastLogDt = DateTime.Parse(dr["LastLoginDt"].ToString()).ToString("MMM dd, yyyy hh:mm tt"); } catch { } 
                        UserSession.setNew(UserId, locId, IDNo, fullname, userName, pwd, levId, phone, email, lastLogDt);                        
            } } } catch (Exception ex) { _error = ex.Message; } finally { this._conn.Close(); }

            fullname += " (" + IDNo + ")";

            if (isActive && k == 1) {       //Successfull Valid Login
                this.updateLoginDate(UserId); Trail.setNew(Users.Module, "LOGIN", fullname, "login successfull", true, "");
                this._error += "<br>Successfully Logged in..."; return true;
                //if (levId == 1) //UserSession.isTimeToLogIn || 
                //{
                //    if (levId > 1)//UserSession.isTimeToLogOut && 
                //    {
                //        string trailMsg = "Logout Time is " + UserSession.LogoutTime.ToString("hh:mm tt") + 
                //            ". You can only login from " + UserSession.LoginTime.ToString("hh:mm tt") + " upwards.";
                //        Trail.setNew(Users.Module, "LOGIN", fullname, trailMsg, false, ""); this._error += trailMsg; return false;
                //    } else {
                //        this.updateLoginDate(UserId); Trail.setNew(Users.Module, "LOGIN", fullname, "login successfull", true, "");
                //        this._error += "<br>Successfully Logged in..."; return true;
                //    }                    
                //} else {
                //    string trailMsg = "You can only login from " + UserSession.LoginTime.ToString("hh:mm tt") + " upwards";
                //    Trail.setNew(Users.Module, "LOGIN", fullname, trailMsg, false, ""); this._error += trailMsg; return false;
                //}                
            }else{
                UserSession.IsActive = false;
                if (k > 0 && !isActive)
                {
                    this._error += fullname.ToUpper() + " your account is <font color='red'> locked contact admin... </font>";
                    UserSession.FullName = fullname;
                    Trail.setNew(Users.Module, "LOGIN", fullname, "your account is locked, contact admin", false, ""); return false;
                }
                else if (!isActive && k == 0)
                {
                    DataTable userTbl = this.getUserName(userName);
                    if (userTbl.Rows.Count > 0)
                    { //wrong username, count nFailed logins
                        DataRow _dr = userTbl.Rows[0]; bool _isActive = bool.Parse(_dr["IsActive"].ToString());
                        int _userId = int.Parse(_dr["Id"].ToString()); int _nfail = int.Parse(_dr["nFail"].ToString()); _nfail++;
                        string _fullname = _dr["FullName"].ToString() + " (" + _dr["IDNo"].ToString() + ")";
                        if (_nfail >= 3) _isActive = false; this.updateFailLogin(_userId, _nfail, _isActive);

                        string trailMsg = "failed login: " + _nfail.ToString() + " account status: " + ((_isActive) ? "OPEN" : "LOCKED");
                        UserSession.FullName = _fullname; Trail.setNew(Users.Module, "LOGIN", _fullname, trailMsg, false, ""); 
                    } this._error += "<br><font color='red'>wrong login credentials... </font>";  return false;
                } else { this._error += "<br><font color='red'>unknown process...</font>"; return false; }   
            }
        }
    }
  
    private void updateFailLogin(int Id, int nFail, bool isActive)
    {
        string sql = "UPDATE Users SET nFail = @nFail, IsActive = @isactive WHERE Id = @id ";
        SqlCommand cmd = new SqlCommand(sql, this._conn);
        cmd.Parameters.AddWithValue("@nFail", nFail);    cmd.Parameters.AddWithValue("@isactive", isActive);
        cmd.Parameters.AddWithValue("@id", Id);
        try { this._conn.Open(); cmd.ExecuteNonQuery(); }  catch (Exception ex) { this._error = ex.Message; 
        } finally { this._conn.Close(); }
    }
  
    private void updateLoginDate(int Id)
    {
        string sql = "UPDATE Users SET LastLoginDt = @dt, nFail = @nFail WHERE Id = @id ";
        SqlCommand cmd = new SqlCommand(sql, this._conn);       cmd.Parameters.AddWithValue("@dt", DateTime.Now);
        cmd.Parameters.AddWithValue("@nFail", 0);               cmd.Parameters.AddWithValue("@id", Id);
        try { this._conn.Open(); cmd.ExecuteNonQuery(); } catch (Exception ex) { this._error = ex.Message;
        } finally { this._conn.Close(); }
    }
  
    //=================================================================================
    //=================================================================================
    public int countUsers(int levId) {    return getUsers(levId).Rows.Count;   }
    public bool setNew(int locId, string IDNo, string fullName, string pwd, int levId, string phone, string email, string RegName)
    {
        if (this.isUserNameExist(IDNo)) {        this._error = "Username already used..."; return false;
        } else if (getIDNo(IDNo).Rows.Count > 0) {           this._error = "NAF Number already exist..."; return false;
        } else if (this.getPhone(phone).Rows.Count > 0 && phone.Length > 4) {     this._error = "Phone already exist..."; return false;
        } else if (this.getEmail(email).Rows.Count > 0 && email.Length > 4) {      this._error = "Email already exist..."; return false;
        } else {   AppSet.getValus();
            if (levId == 1 && AppSet.maxAdmin > 0 && (this.countUsers(levId) >= AppSet.maxAdmin)) {
                this._error = "numbers of Administrators exceeded..."; return false; }
            if (levId == 2 && AppSet.maxSuper > 0 && (this.countUsers(levId) >= AppSet.maxSuper)) {
                this._error = "numbers of Super Users exceeded..."; return false;    }
            if (levId == 3 && AppSet.maxUser > 0 && (this.countUsers(levId) >= AppSet.maxUser)) {
                this._error = "numbers of Users exceeded..."; return false;  }

            string sql = "INSERT INTO Users(locId,IDNo,FullName,UserName,PWD,LevId,Phone,Email,nFail,IsActive,RegName,RegDate) " +
                " VALUES(@locId,@IDNo,@fullNm,@userNm,@pwd,@lev,@phone,@email,@nFail,@isActive,@regNm,@dt) ";
            SqlCommand cmd = new SqlCommand(sql, this._conn);
            cmd.Parameters.AddWithValue("@locId", locId);           cmd.Parameters.AddWithValue("@IDNo", IDNo.Trim());
            cmd.Parameters.AddWithValue("@fullNm", fullName); cmd.Parameters.AddWithValue("@userNm", IDNo.Trim());
            cmd.Parameters.AddWithValue("@pwd", pwd.Trim()); cmd.Parameters.AddWithValue("@lev", levId);
            cmd.Parameters.AddWithValue("@phone", phone.Trim()); cmd.Parameters.AddWithValue("@email", email.Trim());
            cmd.Parameters.AddWithValue("@nFail", 0);         cmd.Parameters.AddWithValue("@isActive", true);   
            cmd.Parameters.AddWithValue("@regNm", RegName);   cmd.Parameters.AddWithValue("@dt", DateTime.Now);  int added = 0;
            try {  this._conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString());
            } catch (Exception ex) { this._error = ex.Message; } finally { this._conn.Close(); }
            Trail.setNew(Users.Module, "ADD", fullName + " (" + IDNo + ")", "adding new user ", (added > 0) ? true : false, this._error);
            return (added > 0) ? true : false;
        }
    }
       
    public static bool deleteUser(int Id)
    {
        string sql = "DELETE FROM Users WHERE Id = @id "; SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", Id);    int deleted = 0;
        try { conn.Open(); deleted = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception err) { error = "deleting user: " + err.Message; } finally { conn.Close(); }
        Trail.setNew(Users.Module, "DELETE", getFullName(Id), "deleting of user", (deleted > 0) ? true : false, error);  
        return (deleted > 0) ? true : false;
    }
    public static bool lockUnlockUser(int Id, bool isActive)
    {
        string sql = "UPDATE Users SET IsActive = @active WHERE Id = @id "; SqlCommand cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", Id); cmd.Parameters.AddWithValue("@active", isActive); int updated = 0;
        try { conn.Open(); updated = int.Parse(cmd.ExecuteNonQuery().ToString()); }
        catch (Exception err) { error = err.Message; } finally { conn.Close(); }
        Trail.setNew(Users.Module, ((isActive) ? "OPEN USER" : "LOCK USER"), getFullName(Id), 
            ((isActive) ? "Opening/Unlocking User" : "Locking User from gaining Access to Application"),
            (updated > 0) ? true : false, error);     return (updated > 0) ? true : false;
    }
    public static string getFullName(int Id)
    {
        string sql = "SELECT FullName FROM Users WHERE Id = @id ";  string fullName = "";
        SqlCommand cmd = new SqlCommand(sql, conn);   cmd.Parameters.AddWithValue("@id", Id);
        try { conn.Open(); fullName = cmd.ExecuteScalar().ToString(); }
        catch (Exception ex) {  error = ex.Message; } finally { conn.Close(); } return fullName.Trim();
    }
    
    public bool isUserNameExist(string userName) { return (this.getUserName(userName).Rows.Count > 0) ? true : false;  }

    public bool changeUserNm(int userId, string newUserNm)
    {
        if (this.isUserNameExist(newUserNm))
        {
            _error = "<font color='red'>username already exist...</font>";
            Trail.setNew(Users.Module, "CHANGE USERNAME", UserSession.FullName, "username already exist",
             false, _error); return false;
        }
        string sql = "UPDATE Users SET UserName = @usernm WHERE Id = @id ";
        SqlCommand cmd = new SqlCommand(sql, this._conn);
        cmd.Parameters.AddWithValue("@usernm", newUserNm); cmd.Parameters.AddWithValue("@id", userId); int updated = 0;
        try{       this._conn.Open(); updated = int.Parse(cmd.ExecuteNonQuery().ToString());
        } catch (Exception err) { _error = err.Message; } finally { this._conn.Close(); }
        Trail.setNew(Users.Module, "CHANGE USERNAME", UserSession.FullNameIDNo, "changing username of user",
             (updated > 0) ? true : false, _error);     return (updated > 0) ? true : false;
    }

    public bool changePWD(int userId, string newPWD)
    {
        string sql = "UPDATE Users SET PWD = @pwd WHERE Id = @id ";
        SqlCommand cmd = new SqlCommand(sql, this._conn); cmd.Parameters.AddWithValue("@pwd", newPWD);
        cmd.Parameters.AddWithValue("@id", userId); int updated = 0;
        try {   this._conn.Open(); updated = int.Parse(cmd.ExecuteNonQuery().ToString());
        } catch (Exception err) { _error = err.Message; } finally { this._conn.Close(); }
        Trail.setNew(Users.Module, "CHANGE PASSWORD", UserSession.FullNameIDNo, "changing password of user", 
            (updated > 0) ? true : false, _error);     return (updated > 0) ? true : false;
    }
   
    public static string forgotPWD(string phoneEmail)
    {
        Users obj = new Users(); DataTable TBL = obj.getPhoneEmail(phoneEmail);
        if (TBL.Rows.Count < 1) return "<font color='red'><i>Wrong Phone/Email...</i></font>";
        DataRow dr = TBL.Rows[0];
        string idno = dr["IDNo"].ToString();
        string phone = dr["Phone"].ToString().Trim();       string email = dr["Email"].ToString().Trim();
        string pwd = dr["PWD"].ToString();                  string userName = dr["UserName"].ToString();
        string staffName = dr["FullName"].ToString() + " (" + idno + ")";       bool isActive = bool.Parse(dr["IsActive"].ToString());
        int levId = int.Parse(dr["LevId"].ToString());      string userLevel = UserSession.getLevel(levId);

        if (!isActive) return staffName + " <font color='red'>your account has been locked, contact admin</font>";

        string smsMsg = "Login Details, Username: " + userName + " and Password: " + pwd;
        string emailMsg = "Login Details <br /> USERNAME: " + userName + " <br /> PASSWORD: " + pwd;

        string msg = "";
        if (phone.Length > 6)
        {
            Mailer.sendSMS("NAF.Login", phone, smsMsg);
            if (Mailer.IsSmsSent) msg += "<font color='green'>successfully sent login details (via SMS)</font><br>";
            else msg += "<font color='red'>unable to send SMS</font><br>";
        }
        else msg += "<font color='red'> no phone number... </font><br>";

        if (email.Length > 4)
        {
            Mailer.sendEmail(email, "NAF LOGIN FORGOTTEN LOGIN DETAILS", emailMsg);
            if (Mailer.IsEmailSent) msg += "<font color='green'>successfully sent login details (via EMAIL)</font>";
            else msg += "<font color='red'>unable to send Email</font>";
        }
        else msg += "<font color='red'> no email address... </font>";
        bool isSent = (Mailer.IsSmsSent || Mailer.IsEmailSent) ? true : false;
        string trailMsg = "Phone: " + phone + ", Email: " + email + "<br>" + msg;
        Trail.setNew(Users.Module, "FORGET PASSWORD", staffName, trailMsg, isSent, ""); return msg;
        
    }

    public static DataTable getUserById(int userId)
    {
        string sql = "SELECT u.*, (SELECT l.Name FROM location l WHERE l.Id = u.locId) AS Location FROM Users u WHERE u.Id = @valu ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn); dr.SelectCommand.Parameters.AddWithValue("@valu", userId);
        DataTable dt = new DataTable(); try { dr.Fill(dt); conn.Close(); } catch { } return dt;
    }
    public static DataTable getIDNo(string idno)
    {
        string sql = "SELECT * FROM Users WHERE IDNo = @valu ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn); dr.SelectCommand.Parameters.AddWithValue("@valu", idno.Trim());
        DataTable dt = new DataTable(); try { dr.Fill(dt); conn.Close(); } catch { } return dt;
    }    
    private DataTable getUserName(string userName)
    {
        string sql = "SELECT * FROM Users WHERE UserName = @uNm ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); dr.SelectCommand.Parameters.AddWithValue("@uNm", userName);
        DataTable dt = new DataTable(); try { dr.Fill(dt); this._conn.Close(); } catch { } return dt;
    }
    private DataTable getPhone(string phone)
    {
        string sql = "SELECT * FROM Users WHERE Phone = @valu ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); dr.SelectCommand.Parameters.AddWithValue("@valu", phone.Trim());
        DataTable dt = new DataTable(); try { dr.Fill(dt); this._conn.Close(); } catch { } return dt;
    }
    private DataTable getEmail(string email)
    {
        string sql = "SELECT * FROM Users WHERE Email = @valu ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); dr.SelectCommand.Parameters.AddWithValue("@valu", email.Trim());
        DataTable dt = new DataTable(); try { dr.Fill(dt); this._conn.Close(); } catch { } return dt;
    }

    public DataTable getPhoneEmail(string phoneEmail)
    {
        string sql = "SELECT * FROM Users WHERE Phone = @valu OR Email = @valu ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, this._conn); dr.SelectCommand.Parameters.AddWithValue("@valu", phoneEmail);
        DataTable dt = new DataTable(); try { dr.Fill(dt); this._conn.Close(); } catch { } return dt;
    }
        
    public static DataTable getUsers() { return getUsers(0, 0); }
    public static DataTable getUsers(int levId) {  return getUsers(0, levId); }
    public static DataTable getUsers(int locId, int levId)
    {
        string field = "";
        if (locId > 0 && levId > 0)  field = " WHERE u.locId = @loc AND u.LevId = @lev ";
        else if (locId > 0 || levId > 0)
        {
            field = " WHERE "; if(locId > 0) field += " u.locId = @loc "; else if(levId > 0) field += " u.LevId = @lev ";
        }        
        string sql = "SELECT u.*, (SELECT Name FROM location WHERE Id = u.locId) AS Location FROM Users u " + field +
            " ORDER BY u.locId, u.LevId, u.IsActive DESC ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);
        if (locId > 0) dr.SelectCommand.Parameters.AddWithValue("@loc", locId);
        if (levId > 0) dr.SelectCommand.Parameters.AddWithValue("@lev", levId);
        DataTable tbl = new DataTable(); try { dr.Fill(tbl); conn.Close(); } catch { } return tbl;
    }

    public static string generatePWD(int nStrs){
		//string xters = "-()";  string numbs = "123456789";  string letters = "qwertyupkjhgfdazcvbnmQWERTYUPLKJHGFDAZXCVBNM";
		//string pwd  = ""; Random rnd = new Random();
		//while(pwd.Length < (nStrs - 2)){ int index = rnd.Next(0, letters.Length - 1);    pwd += (letters.Substring(index, 1)); }
		//pwd += (xters.Substring(rnd.Next(0, xters.Length - 1), 1));
		//pwd += (numbs.Substring(rnd.Next(0, xters.Length - 1), 1));   return pwd;
		return _generatePWD(nStrs, "", 2);
    }

	 
	private static string _generatePWD(int length, string prefix, int _1alphabet_2digit_3both)
	{
		string today = DateTime.Now.ToString("yymdhmsffffff");
		string[] _alphabets_digits = { "", "QWERTYUPLKJHGFDSAZXCVBNM", "123456789", "QW5ERT2YU4PLKJ1HGFD7SA3ZXC6VB8N9M" };
		if (_1alphabet_2digit_3both < 1 || _1alphabet_2digit_3both > 3) _1alphabet_2digit_3both = 3;
		string alpha_digits = _alphabets_digits[_1alphabet_2digit_3both]; if (_1alphabet_2digit_3both != 1) alpha_digits += today;
		string pinCode = ""; prefix = prefix.Trim(); Random rnd = new Random();

		if (length > prefix.Length) length = length - prefix.Length;
		while (pinCode.Length < length)
		{
			alpha_digits = new string(alpha_digits.ToCharArray().OrderBy(s => (rnd.Next(2) % 2) == 0).ToArray());

			int index = 0; try { index = rnd.Next(0, alpha_digits.Length - 1); } catch { }
			try { pinCode += (alpha_digits.Substring(index, 1)).Trim(); } catch { }
			try { if (pinCode.Substring(0, 1).Trim() == "0") pinCode = pinCode.Remove(0, 1); }	catch { }
		}
		return prefix + pinCode.Trim();
	}

	
     
     //try { Users.sendInventoryDueAlert(); }  catch { }
    //=====================  SMS & EMAIL ALERTS ================
    //=====================  SMS & EMAIL ALERTS ================
    //=====================  SMS & EMAIL ALERTS ================
     
    public static DataTable getLedgerDueReordeCritExpiryTBL(int locId, int typId)
    {
        DateTime dt = DateTime.Now.AddMonths(1);
        string locTypDept = " AND locId = @loc AND typId = @typ AND deptId = d.Id ";
        string sql = "SELECT d.*, " +
            " (SELECT COUNT(Id) FROM invLedger WHERE ExpDt <= @dt AND IsExp = @isExp AND Qty > @zero " + locTypDept + ") AS nExp," +
            " (SELECT COUNT(Id) FROM invLedger WHERE critQty >= Qty AND critQty > @zero " + locTypDept + ") AS nCrit, " +
            " (SELECT COUNT(Id) FROM invLedger WHERE orderQty >= Qty AND orderQty > @zero " + locTypDept + ") AS nReorder " +
            " FROM invDept d WHERE d.typId = @typ ORDER BY d.Name ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, conn);
        dr.SelectCommand.Parameters.AddWithValue("@dt", dt);        dr.SelectCommand.Parameters.AddWithValue("@isExp", true);
        dr.SelectCommand.Parameters.AddWithValue("@zero", 0);
        dr.SelectCommand.Parameters.AddWithValue("@loc", locId);    dr.SelectCommand.Parameters.AddWithValue("@typ", typId);        
        DataTable TBL = new DataTable();
        try { dr.Fill(TBL); conn.Close(); } catch (Exception ex) { error = ex.Message; } return TBL;
        //getLedgerDueReordeCritExpiryTBL(int locId, int typId)  Id,Name(Dept),nExp,nCrit,nReorder
    }

    public static void sendInventoryDueAlert()
    {        
        if (Trail.isDailyAlertSent()) return;

        DataTable locTBL = AppSet.getLocation(); DataTable invTBL = Inventory.getType();

        //string alertSMSMsgs = "", alertEmailMsgs = "";
        int kAlerts = 0;
        foreach (DataRow lR in locTBL.Rows)
        {
            int locId = int.Parse(lR["Id"].ToString()); string locNm = lR["Name"].ToString();

            foreach (DataRow invR in invTBL.Rows)
            {
                int typId = int.Parse(invR["Id"].ToString()); string invNm = invR["Name"].ToString();
                string locInvType = "<b>LOCATION/INVENTORY: </b>" + locNm + "/" + invNm;
                DataTable deptLedgTBL = getLedgerDueReordeCritExpiryTBL(locId, typId);
                string deptMsg = "<table><tr><th>DEPARTMENT</th><th>DUE EXPIRY</th><th>DUE RE-ORDER</th><th>DUE CRITICAL</th></tr>";
                foreach (DataRow dRw in deptLedgTBL.Rows)
                {
                    int deptId = int.Parse(dRw["Id"].ToString()); string deptNm = dRw["Name"].ToString();
                    int _nExp = 0, _nCrit = 0, _nReorder = 0;
                    try { _nExp = int.Parse(dRw["nExp"].ToString()); } catch { }
                    try { _nCrit = int.Parse(dRw["nCrit"].ToString()); } catch { }
                    try { _nReorder = int.Parse(dRw["nReorder"].ToString()); } catch { }

                    
                    if (_nExp > 0 || _nCrit > 0 || _nReorder > 0)
                    {
                        deptMsg += "<tr><td>" + deptNm + "</td> <td>" + _nExp.ToString() + "</td> <td>" +
                            _nReorder.ToString() + "</td> <td>" + _nCrit.ToString() + "</td></tr>";
                        
                        DataTable _deptNosTBL = Inventory.getAlertPhoneEmailNos(locId, typId, deptId);
                        string _phones = "", _emails = "";
                        string _deptSMSMsg =  locNm + ", " + deptNm + ", EXP:" + _nExp.ToString() + ", Re-Ord:" +
                            _nReorder.ToString() + ", CRIT:" + _nCrit.ToString();
                        if (_deptNosTBL.Rows.Count > 0)
                        {
                            foreach (DataRow ph in _deptNosTBL.Rows)
                            {
                                _phones += ph["phone"].ToString().Trim()+ ",";  _emails += ph["email"].ToString().Trim() + ",";
                            }
                            Mailer.sendSMS("NAF.INVTRY.", _phones, _deptSMSMsg); 
                            Mailer.sendEmail(_emails, "NAF INVENTORY ALERT", _deptSMSMsg);
                            if (Mailer.IsSmsSent || Mailer.IsEmailSent) kAlerts++;
                        }                        
                    }
                }
            }
        }
        if (kAlerts > 0) Trail.setNew(Role.modInventory, "DAILY ALERT", "", "sent daily SMS/Email Alert", true, "");
          
        //getLedgerDueReordeCritExpiryTBL(int locId, int typId)  Id,Name(Dept),nExp,nCrit,nReorder        
        //setEmailSMSalert(int typId, int locId, int deptId, string title, string msg)
        //DataTable phoneEmailTBLs = new DataTable();
       
        //try { phoneEmailTBLs = obj.getEmailPhonesTBL(1, 0); } catch { }
        //string phones = "", emails = "";
        //try { phones = phoneEmailTBLs.Rows[0]["phones"].ToString(); } catch { }
        //try { emails = phoneEmailTBLs.Rows[0]["emails"].ToString(); } catch { }
        //try
        //{
        //    Mailer.sendSMS("NAF.INVTRY.", phones, alertSMSMsgs);
        //    Mailer.sendEmail(emails, "NAF INVENTORY ALERT", alertEmailMsgs);
        //    if (Mailer.IsSmsSent || Mailer.IsEmailSent) kAlerts++;
        //}
        //catch { }
        
    } 

}
 
public class Role
{
    private static SqlConnection _conn = new SqlConnection(Connect.CONN());
    public static string _error;

    public static bool setNew(int locId, string IDNo, string roleCode,  bool isAdd, bool isView,  bool isEdit,
       bool isSet, bool isApprove)
    {
        string sql = "INSERT INTO UserRole(locId,IDNo,RoleCode,IsSet,IsAdd,IsEdit,IsView,IsApprove) " +
            " VALUES(@loc,@IDNo,@role,@isSet,@isAdd,@isEdit,@isView,@isApprove) ";
        if (isRoleExist(IDNo, roleCode, locId)) 
            sql = "UPDATE UserRole SET locId = @loc, IsSet = @isSet, IsAdd = @isAdd, IsEdit = @isEdit, IsView = @isView, " +
                " IsApprove = @isApprove WHERE IDNo = @IDNo AND RoleCode = @role ";     
        SqlCommand cmd = new SqlCommand(sql, _conn);
        cmd.Parameters.AddWithValue("@loc", locId);      cmd.Parameters.AddWithValue("@IDNo", IDNo.Trim());
        cmd.Parameters.AddWithValue("@role", roleCode.Trim());
        cmd.Parameters.AddWithValue("@isSet", isSet);    cmd.Parameters.AddWithValue("@isAdd", isAdd);
        cmd.Parameters.AddWithValue("@isEdit", isEdit);  cmd.Parameters.AddWithValue("@isView", isView);
        cmd.Parameters.AddWithValue("@isApprove", isApprove); int added = 0;
        try { _conn.Open(); added = int.Parse(cmd.ExecuteNonQuery().ToString());
        } catch (Exception ex) { _error = ex.Message; }  finally { _conn.Close(); }   return (added > 0) ? true : false;
    }

    public static bool deleteRole(string IDNo)
    {
        string sql = "DELETE FROM UserRole WHERE IDNo = @idno ";   SqlCommand cmd = new SqlCommand(sql, _conn);
        cmd.Parameters.AddWithValue("@idno", IDNo.Trim());         int n = 0;
        try { _conn.Open(); n = int.Parse(cmd.ExecuteNonQuery().ToString()); 
        } catch (Exception ex) { _error = ex.Message; } finally { _conn.Close(); }
        Trail.setNew(Role.modUsers, "USER ROLES", IDNo, "removing user access roles...", ((n > 0) ? true : false), _error);
        return (n > 0) ? true : false;
    }

    public static DataTable getRoles(string IDNo) {    return getRoles(IDNo, "");  }
    public static DataTable getRoles(string IDNo, string RoleCode)
    {
        string roleField = ""; if (RoleCode.Length > 2) roleField = " AND RoleCode = @role ";
        string sql = "SELECT DISTINCT RoleCode, IDNo, IsAdd, IsView, IsEdit, IsSet, IsApprove " +
            " FROM UserRole WHERE IDNo = @stfID " + roleField + " ORDER BY RoleCode ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, _conn);
        dr.SelectCommand.Parameters.AddWithValue("@stfID", IDNo.Trim());
        if (RoleCode.Length > 2) dr.SelectCommand.Parameters.AddWithValue("@role", RoleCode.Trim()); 
        DataTable tbl = new DataTable();    try { dr.Fill(tbl); _conn.Close(); } catch { } return tbl;
    }
    
    private static bool isRoleExist(string IDNo, string roleCode, int locId)
    {
        string sql = "SELECT COUNT(Id) FROM UserRole WHERE IDNo = @IDNo AND RoleCode = @role AND locId = @locId ";
        SqlCommand cmd = new SqlCommand(sql, _conn);
        cmd.Parameters.AddWithValue("@IDNo", IDNo.Trim());  cmd.Parameters.AddWithValue("@role", roleCode.Trim());
        cmd.Parameters.AddWithValue("@locId", locId);
        int nRows = 0; try { _conn.Open(); nRows = int.Parse(cmd.ExecuteScalar().ToString()); }
        catch (Exception ex) { _error = ex.Message; }   finally { _conn.Close(); }   return (nRows > 0) ? true : false;
    } 
    public static DataTable getLocIDs(string stfIDNo)
    {
        DataTable tbl = new DataTable();
        string sql = "SELECT DISTINCT r.locId, (SELECT l.Name FROM location l WHERE l.Id = r.locId) AS Name, " +
            " (SELECT l.Id FROM location l WHERE l.Id = r.locId) AS Id,  (SELECT l.Id FROM location l WHERE l.Id = r.locId) AS ID " +
            " FROM UserRole r WHERE r.IDNo = @idno ";       SqlDataAdapter dr = new SqlDataAdapter(sql, _conn);
        dr.SelectCommand.Parameters.AddWithValue("@idno", stfIDNo.Trim());
        try { dr.Fill(tbl); _conn.Close(); }  catch { } return tbl;
    }

    public static bool isStaffLocIDExist(string IDNo, int locId)
    {
        DataTable tbl = new DataTable();
        string sql = "SELECT DISTINCT locId FROM UserRole WHERE IDNo = @idno AND (locId = @locId OR locId = @zero) "; 
        SqlDataAdapter dr = new SqlDataAdapter(sql, _conn);
        dr.SelectCommand.Parameters.AddWithValue("@idno", IDNo.Trim());
        dr.SelectCommand.Parameters.AddWithValue("@locId", locId);
        dr.SelectCommand.Parameters.AddWithValue("@zero", 0);
        try { dr.Fill(tbl); _conn.Close(); } catch { }   return (tbl.Rows.Count > 0) ? true : false;
    }

    public static DataTable getApprovalPhoneEmails(int locId, string roleCode) //IDNo,Email,Phone
    {        
        string sql = "SELECT DISTINCT r.IDNo, (SELECT a.Email FROM Users a WHERE a.IDNo = r.IDNo) AS Email, " +
            " (SELECT b.Phone FROM Users b WHERE b.IDNo = r.IDNo) AS Phone " +
            " FROM UserRole r, Users u WHERE r.locId = @loc AND r.RoleCode = @code AND r.IDNo = u.IDNo AND u.IsActive = @true ";
        SqlDataAdapter dr = new SqlDataAdapter(sql, _conn);           DataTable TBL = new DataTable();
        dr.SelectCommand.Parameters.AddWithValue("@true", true);      dr.SelectCommand.Parameters.AddWithValue("@loc", locId);
        dr.SelectCommand.Parameters.AddWithValue("@code", roleCode.Trim());
        try { dr.Fill(TBL); _conn.Close(); } catch { } return TBL;
    }
    //===============================================
    public static string[] ModulesCode
    {
        get { string[] _roles = { "USERS",  "AIRCRAFT", "ECO", "INVENTORY" }; return _roles; }
    }
    public static string ModuleCodes {
        get { string roles = ""; int k = 0; foreach (string _rol in ModulesCode) { k++; if (k > 1) roles += (_rol + ","); } return roles; }
    }
    //{  "USERS",  "AIRCRAFT", "ENGR.", "INVENTORY" };
    public static string modUsers { get { return ModulesCode[0]; } }
    public static string modAircraft { get { return ModulesCode[1]; } }
    public static string modECO { get { return ModulesCode[2]; } } 
    public static string modInventory { get { return ModulesCode[3]; } }
    public static string modSettings { get { return "SETTINGS"; } }


    public static void startFirstUserRole()
    {
        foreach (string _role in ModulesCode)
        {            
            bool IsSet = true, IsAdd = true, IsEdit = true, IsView = true, IsApprove = true;
            HttpContext.Current.Session["role" + _role + "_Set"] = IsSet;
            HttpContext.Current.Session["role" + _role + "_Add"] = IsAdd;
            HttpContext.Current.Session["role" + _role + "_Edit"] = IsEdit;
            HttpContext.Current.Session["role" + _role + "_View"] = IsView;
            HttpContext.Current.Session["role" + _role + "_Approve"] = IsApprove;
            HttpContext.Current.Session["role" + _role + "_Valid"] = (IsView || IsSet || IsAdd || IsEdit || IsApprove) ? true : false;
        }
    }
            
    public static void startRole(string stfIDNo)
    {
        DataTable RoleTBL = getRoles(stfIDNo); if (RoleTBL.Rows.Count < 1) return;
        foreach (DataRow dr in RoleTBL.Rows)
        {
            string _role = dr["RoleCode"].ToString().Trim();
            bool IsSet = false, IsAdd = false, IsEdit = false, IsView = false, IsApprove = false;
            IsSet = bool.Parse(dr["IsSet"].ToString());        IsAdd = bool.Parse(dr["IsAdd"].ToString());
            IsEdit = bool.Parse(dr["IsEdit"].ToString());      IsView = bool.Parse(dr["IsView"].ToString());
            IsApprove = bool.Parse(dr["IsApprove"].ToString());
            HttpContext.Current.Session["role" + _role + "_Set"] = IsSet;
            HttpContext.Current.Session["role" + _role + "_Add"] = IsAdd;
            HttpContext.Current.Session["role" + _role + "_Edit"] = IsEdit;
            HttpContext.Current.Session["role" + _role + "_View"] = IsView;
            HttpContext.Current.Session["role" + _role + "_Approve"] = IsApprove;
            HttpContext.Current.Session["role" + _role + "_Valid"] = (IsView || IsSet || IsAdd || IsEdit || IsApprove) ? true : false;
        }
    }
    
    public static bool IsValid(string role)
    {
        bool valu = false; if (HttpContext.Current.Session["role" + role.Trim() + "_Valid"] != null)
     try { valu = (bool.Parse(HttpContext.Current.Session["role" + role.Trim() + "_Valid"].ToString())) ? true : false; } catch { } 
       return valu;
    }
    public static bool IsSet(string role)
    {
        bool valu = false;  if (HttpContext.Current.Session["role" + role.Trim() + "_Set"] != null)
     try { valu = (bool.Parse(HttpContext.Current.Session["role" + role.Trim() + "_Set"].ToString())) ? true : false; } catch { }
        return valu;
    }
    public static bool IsAdd(string role)
    {
        bool valu = false;   if (HttpContext.Current.Session["role" + role.Trim() + "_Add"] != null)
      try { valu = (bool.Parse(HttpContext.Current.Session["role" + role.Trim() + "_Add"].ToString())) ? true : false; } catch { }
        return valu;
    }
    public static bool IsEdit(string role)
    {
        bool valu = false; if (HttpContext.Current.Session["role" + role.Trim() + "_Edit"] != null)
        try{ valu = (bool.Parse(HttpContext.Current.Session["role" + role.Trim() + "_Edit"].ToString())) ? true : false; } catch { }
        return valu;
    }
    public static bool IsView(string role)
    {
        bool valu = false;   if (HttpContext.Current.Session["role" + role.Trim() + "_View"] != null)
     try {  valu = (bool.Parse(HttpContext.Current.Session["role" + role.Trim() + "_View"].ToString())) ? true : false; } catch { }
        return valu;
    }
    public static bool IsApprove(string role)
    {
        bool valu = false;   if (HttpContext.Current.Session["role" + role.Trim() + "_Approve"] != null)
      try { valu = (bool.Parse(HttpContext.Current.Session["role" + role.Trim() + "_Approve"].ToString())) ? true : false; } catch { }
        return valu;
    }
    
    //=====================================================
    public static string showUserModules()
    {
        //<!--  { "USERS", "ACCOUNT", "ASSET", "ELIBRARY", "INVENTORY", "SCHOOL", "STAFF", "STUDENT" };  //-->
        //modTbl2
        string tr = " <table border='1' class='table modTbl2'><tr align='center'><th rowspan='2' style='width:130px;'> " +
            "<b><input type='checkbox' id='chkAllModules' onclick='chkAllModules();' /> " +
            "<label for='chkAllModules'>MODULES</label>  </b></th><th colspan='5' align='center'><b>ACCESS RIGHTS</b></th></tr>" +
            "<tr align='center'><th>ADD</th><th>VIEW</th><th>EDIT</th><th>SETTINGS</th> " +
            "<th " + ((UserSession.LevId != 1) ? "style='display:none;'" : "") + "> APPROVE </th></tr> ";
        int k = 0; string hidMods = "";
        foreach (string _role in Role.ModulesCode)
        {
            k++;
            if (k > 1)
            {
                hidMods += "<input type='hidden' id='hidMod" + _role + "' value='" + ((Role.IsValid(_role)) ? 1 : 0) + "' /> ";
                tr += "<tr " + ((Role.IsValid(_role)) ? "" : "style='display:none;'") + " align='center'><th align='left'>" +
                    " <input type='checkbox' id='chk" + _role + "' onclick=\"chkBoxs('" + _role +
                    "');\" /><label for='chk" + _role + "'>" + _role + " </label></th> " +
                    "<td> " + ((Role.IsAdd(_role)) ? "<input type='checkbox' id='chk" + _role + "1' />" : " - ") + " </td> " +
          "<td> " + ((Role.IsView(_role)) ? "<input type='checkbox' id='chk" + _role + "2' />" : " - ") + "</td> " +
          "<td> " + ((Role.IsEdit(_role)) ? "<input type='checkbox' id='chk" + _role + "3' />" : " - ") + "</td> " +
          "<td> " + ((Role.IsSet(_role)) ? "<input type='checkbox' id='chk" + _role + "4' />" : " - ") + " </td> " +
          "<td " + ((UserSession.LevId != 1) ? "style='display:none;'" : "") + "> " +
              ((Role.IsApprove(_role)) ? "<input type='checkbox' id='chk" + _role + "5' />" : " - ") + " </td> </tr> ";
            }
        }
        tr += "</table> <input type='hidden' id='hidRoleMods' value='" + Role.ModuleCodes + "' />" + hidMods;
        return tr;
    }
} 

public class UserSession
{
    private SqlConnection _conn = new SqlConnection(Connect.CONN());
    private static SqlConnection conn = new SqlConnection(Connect.CONN());
    public string _error; 

    public static string getLevel(int levId)  {   return UserSession.getLevels()[levId]; }
    public static string[] getLevels()
    {
        string[] _users = { "ALL USERS", "Administrator", "Super User", "User" };  return _users;
    }

    public static DateTime idleSetTime
    {
        get
        {
            DateTime valu = DateTime.Now;
            try { valu = DateTime.Parse(HttpContext.Current.Session["sesIdleSetTime"].ToString()); }
            catch { idleSetTime = valu; } return valu;
        }
        set { HttpContext.Current.Session["sesIdleSetTime"] = value; }
    } 
     
    public static int idleMins
    {
        get {  int valu = 0; try { valu = int.Parse(HttpContext.Current.Session["sesIdleMins"].ToString()); } catch {
            AppSet.getValus(); valu = AppSet.idleMins; 
        } return valu;  }  set { HttpContext.Current.Session["sesIdleMins"] = value; }
    }
    public static int countIdleMins
    {
        get { int valu = 0; try { valu = int.Parse(HttpContext.Current.Session["sesCountIdleMins"].ToString()); } catch { } return valu;
        } set { HttpContext.Current.Session["sesCountIdleMins"] = value; }
    } 
     
    public static void setNew(int _userId, int _locId, string _nafIDNo, string _fullName, string _userNm, string _pwd, int _levId,
        string _phone, string _email, string _lastLogDt)
    {
        IsActive = true;   FullName = ""; IDNo = ""; Users.sendInventoryDueAlert();  

        UserId = _userId; LocId = _locId;   UserName = _userNm; PWD = _pwd; LevId = _levId; FullName = _fullName;
        IDNo = _nafIDNo.Trim();   Phone = _phone;    Email = _email;       LastLoginDate = _lastLogDt; 
        Role.startRole(_nafIDNo); RoleLocIDs = Role.getLocIDs(_nafIDNo);  AppSet.getValus();  UserSession.idleMins = AppSet.idleMins;
    }

    public static int UserId
    {
        get { int valu = 0; try { valu = int.Parse(HttpContext.Current.Session["sesUserId"].ToString()); }  catch { }
            return valu;
        }  set { HttpContext.Current.Session["sesUserId"] = value.ToString(); }
    }
    public static int LocId
    {
        get
        {
            int valu = 0; try { valu = int.Parse(HttpContext.Current.Session["sesLocId"].ToString()); }
            catch { }
            return valu;
        }
        set { HttpContext.Current.Session["sesLocId"] = value.ToString(); }
    }
    public static string IDNo
    {
        get
        {
            string valu = ""; try { valu = HttpContext.Current.Session["sesIDNo"].ToString(); }
            catch { } return valu;
        }
        set { HttpContext.Current.Session["sesIDNo"] = value; }
    }
    public static string FullName
    {
        get {
            string valu = ""; try { valu = HttpContext.Current.Session["sesFullName"].ToString(); } catch { } return valu;
        } set { HttpContext.Current.Session["sesFullName"] = value; }
    }

    public static string FullNameIDNo  {   get {  return FullName + " (" + IDNo + ")";  }   }

    public static string UserName
    {
        get { string valu = ""; try { valu = HttpContext.Current.Session["sesUserName"].ToString(); } catch { }  return valu;
        }  set { HttpContext.Current.Session["sesUserName"] = value; }
    }
    public static string PWD
    {
        get {  string valu = ""; try { valu = HttpContext.Current.Session["sesPWD"].ToString(); } catch { } return valu;
        } set { HttpContext.Current.Session["sesPWD"] = value; }
    }
    public static int LevId
    {
        get { int valu = 0; try { valu = int.Parse(HttpContext.Current.Session["sesLevId"].ToString()); } catch { }
            return valu;
        } set { HttpContext.Current.Session["sesLevId"] = value; }
    } 
    public static string LevelName {    get { return getLevels()[UserSession.LevId]; } set { }  }
      
    public static string Phone
    {
        get
        {
            string valu = ""; try { valu = HttpContext.Current.Session["sesPhone"].ToString(); }catch { } return valu;
        }
        set { HttpContext.Current.Session["sesPhone"] = value; }
    }
    public static string Email
    {
        get
        {
            string valu = ""; try { valu = HttpContext.Current.Session["sesEmail"].ToString(); }
            catch { } return valu;
        }
        set { HttpContext.Current.Session["sesEmail"] = value; }
    }
      
    public static string LastLoginDate
    {
        get {
            string valu = ""; try { valu = HttpContext.Current.Session["sesLastLoginDate"].ToString(); } catch { } return valu;
        } set { HttpContext.Current.Session["sesLastLoginDate"] = value; }
    }
     
    public static bool IsActive
    {
        get { bool valu = false;
            try { valu = (bool.Parse(HttpContext.Current.Session["sesIsActive"].ToString())) ? true : false; } catch { }
            return valu;
        } set { HttpContext.Current.Session["sesIsActive"] = value; }
    }

    public static bool IsFirstUser
    {
        get
        {
            bool valu = false;
            try { valu = (bool.Parse(HttpContext.Current.Session["sesIsFirstUser"].ToString())) ? true : false; } catch { }
            return valu;
        }
        set { HttpContext.Current.Session["sesIsFirstUser"] = value; }
    }


    public static void End() {   try { HttpContext.Current.Session.RemoveAll(); }  catch { }   }

    public static string browserInfo 
    {
        get {
            string valu = ""; try { valu = HttpContext.Current.Session["sesBrowserInfo"].ToString(); } catch { } return valu;
        } set { HttpContext.Current.Session["sesBrowserInfo"] = value; }
    }

    //=====================================================================================
    //=====================================================================================
    public static bool IsLoginTimeActive
    {
        get
        {
            bool valu = false;
            try { valu = (bool.Parse(HttpContext.Current.Session["sesIsLoginTimeActive"].ToString())) ? true : false; }
            catch { AppSet.getValus(); valu = AppSet.isLoginActive; } return valu;
        }
        set { HttpContext.Current.Session["sesIsLoginTimeActive"] = value; }
    }
    public static bool IsLogoutTimeActive
    {
        get
        {
            bool valu = false;
            try { valu = (bool.Parse(HttpContext.Current.Session["sesIsLogoutTimeActive"].ToString())) ? true : false; }
            catch { AppSet.getValus(); valu = AppSet.isLogoutActive; } return valu;
        }
        set { HttpContext.Current.Session["sesIsLogoutTimeActive"] = value; }
    }
    public static DateTime LoginTime
    {
        get {
            DateTime valu = DateTime.Now;
            try { valu = DateTime.Parse(HttpContext.Current.Session["sesLoginTime"].ToString()); }
            catch { AppSet.getValus(); valu = AppSet.loginTime; } return valu; 
        }
        set { HttpContext.Current.Session["sesLoginTime"] = value; }
    }
    public static DateTime LogoutTime
    {
        get
        {
            DateTime valu = DateTime.Now;
            try { valu = DateTime.Parse(HttpContext.Current.Session["sesLogoutTime"].ToString()); }
            catch { AppSet.getValus(); valu = AppSet.logoutTime; } return valu;
        }
        set { HttpContext.Current.Session["sesLogoutTime"] = value; }
    }

    public static bool isTimeToLogIn
    {
        get
        {
            if (!IsLoginTimeActive) return true;
            string[] nowTime = DateTime.Now.ToString("HH,mm").Split(',');
            int nowHrs = int.Parse(nowTime[0]);           int nowMins = int.Parse(nowTime[1]);
            string[] inTime = LoginTime.ToString("HH,mm").Split(',');
            int inHrs = int.Parse(inTime[0]);             int inMins = int.Parse(inTime[1]);
            if (nowHrs > inHrs) return true;   if (nowHrs >= inHrs && nowMins >= inMins) return true;
            return false;
        }
    }
    public static bool isTimeToLogOut
    {
        get
        {
            if (!IsLogoutTimeActive) return false;
            string[] nowTime = DateTime.Now.ToString("HH,mm").Split(',');
            int nowHrs = int.Parse(nowTime[0]);       int nowMins = int.Parse(nowTime[1]);
            string[] outTime = LogoutTime.ToString("HH,mm").Split(',');
            int outHrs = int.Parse(outTime[0]);       int outMins = int.Parse(outTime[1]);
            if (nowHrs > outHrs) return true;         if (nowHrs >= outHrs && nowMins >= outMins) return true;
            return false;
        }
    }
    public static int minsLeftToLogoutTime
    {
        get
        {            
            string[] nowTime = DateTime.Now.ToString("HH,mm").Split(',');
            int nowHrs = int.Parse(nowTime[0]); int nowMins = int.Parse(nowTime[1]);
            string[] outTime = LogoutTime.ToString("HH,mm").Split(',');
            int outHrs = int.Parse(outTime[0]); int outMins = int.Parse(outTime[1]);
 
            int minsLeft = ((outHrs * 60) + outMins) - ((nowHrs * 60) + nowMins);   return minsLeft;
        } 
    }

    //----------------
    public static DataTable RoleLocIDs
    {
        get
        {
            DataTable valu = new DataTable();
            try
            {
                if (HttpContext.Current.Session["sesRoleLocIDs"] != null)
                    valu = (DataTable)HttpContext.Current.Session["sesRoleLocIDs"];
            }
            catch { }
            return valu;
        }
        set { HttpContext.Current.Session["sesRoleLocIDs"] = value; }
    }
    



}


