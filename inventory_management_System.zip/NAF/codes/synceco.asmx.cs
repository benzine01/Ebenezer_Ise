﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
 
using System.IO;
using System.Text;
using System.Data;
  
namespace NAF.codes
{
    /// <summary>
    /// Summary description for synceco
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    
    [System.Web.Script.Services.ScriptService]
    public class synceco : System.Web.Services.WebService
    {

        private string timeoutMsg = "<font color='red'>session timeout, please login...</font>";

        [WebMethod(EnableSession = true)]
        public string setSnagType(string name)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;      name = name.Trim();
            if (name.Length < 3) return "<font color='red'><i>Enter the Snag Type Name</i></font>";

            bool isAdded = ECO.setSnagType(name);
            if (isAdded) return "<font color='green'>Successfully Added Type: " + name.Trim() + " </font>";
            else return "<font color='red'> " + Inventory.error + "</i></font>";
        }

        [WebMethod(EnableSession = true)]
        public string setSnagAlertNos(string loc, string typ, string phone, string email)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;
            int locId = 0, typId = 0; try { locId = int.Parse(loc.Trim()); } catch { }   try { typId = int.Parse(typ.Trim()); } catch { }
            if (phone.Length < 11) return "<font color='red'>Enter the Phone Number(s)...</font>";
            bool isAdded = ECO.setSnagAlertNos(locId, typId, phone, email, UserSession.FullNameIDNo); 
            if (isAdded) return "<font color='green'>Successfully Added Alert Phone(s)/Email(s) </font>";
            else return "<font color='red'>Couldnot add Phone(s)/Email(s), <small> Error:<i> " + Inventory.error + "</i></small></font>";
        }
        
        [WebMethod(EnableSession = true)]
        public string getSnagAlertNos(string loc, string typ)
        {
            int locId = 0, typId = 0;  try { locId = int.Parse(loc.Trim()); } catch { } try { typId = int.Parse(typ.Trim()); } catch { }
            DataTable TBL = ECO.getSnagAlertNos(locId, typId);
            StringBuilder tbl = new StringBuilder();
            tbl.Append("<div class='tblHead' style='width:400px;align:center;'> </div>" +
                    "<table  style='font-size:11px; font-weight:100px;' cellpadding='0' cellspacing='0' border='0' " +
                    " class='display' id='jqPhoneEmailsTBL'> <thead> <tr align='left'>" +
                    " <th>LOCATION </th> <th>TYPE</th>  <th>PHONE NUMBER(S)</th>  " +
                    " <th>EMAIL ADDRESS(ES)</th> <th>REGISTERED BY </th><th>REG. DATE </th> <th> </th> </tr></thead><tfoot> " +
                    " <tr align='left'> <th>LOCATION </th> <th>TYPE</th> <th>PHONE NUMBER(S)</th>  " +
                    " <th>EMAIL ADDRESS(ES)</th> <th>REGISTERED BY </th><th>REG. DATE </th> </tr></tfoot> <tbody>");
            foreach (DataRow dr in TBL.Rows)
            {
                string regDt = "";
                try { regDt = DateTime.Parse(dr["RegDate"].ToString()).ToString("yyyy MMM dd, hh:mm tt"); } catch { }
                string locNm = dr["Location"].ToString(), typeNm = dr["typeName"].ToString();
                if (locNm.Length < 3) locNm = "ALL LOCATIONS"; if (typeNm.Length < 3) typeNm = "ALL TYPES";
                
                tbl.Append("<tr align='left'> <td>" + locNm + "</td><td>" + typeNm + "</td><td>" +
                   dr["phone"].ToString() + " </td><td> " + dr["email"].ToString() + "</td> <td>" + dr["RegIDNo"].ToString() + 
                   " </td><td> " + regDt + "</td><td><a href='javascript:deleteAlertNo(" + dr["Id"].ToString() +
                   ");'><img src='../images/delete.gif' alt='delete' /></a><span id='" + dr["Id"].ToString() + "'></span></td></tr>");
            }
            Context.Session["GridAlertPhoneTBL"] = TBL;
            tbl.Append("</tbody></table><input type='hidden' id='hidPhonelocTypIds' value='" + loc + "," + typ + "' /> ");
            return tbl.ToString();
        }

        [WebMethod(EnableSession = true)]
        public string deleteSnagAlertNo(string id, string locTyp)
        {
            if (!UserSession.IsActive) return this.timeoutMsg;         string loc = "", typ = "";
            try { loc = locTyp.Split(',')[0].Trim(); } catch { }       try { typ = locTyp.Split(',')[1].Trim(); } catch { }
            int tblId = 0; try { tblId = int.Parse(id.Trim()); } catch { }
            ECO.deleteSnagAlertNos(tblId);      return getSnagAlertNos(loc, typ);
        }
              


    }
}
