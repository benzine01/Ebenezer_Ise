﻿//$('#txtPhone').keyup(function () { testPhone('#txtPhone'); });   $('#txtEmail').keyup(function () { testEmail('#txtEmail'); });
var jsPg = 'appset';


$(function () {
    $("#modAddUser").dialog({ height: 'auto', width: 'auto', autoOpen: false, modal: true,
        buttons: { Save: function () { addUser(); }, Cancel: function () { clearUser(); $(this).dialog("close"); } }
    });
    //
    $("#modalUserRole").dialog({ height: 'auto', width: '440px', autoOpen: false, modal: false
       // buttons: { Cancel: function () { $(this).dialog("close"); } }
    });   
   
    $('#txtIDNo').keyup(function () { $('#txtIDNo_').html(''); if ($.trim($('#txtIDNo').val()).length < 3) $('#txtIDNo_').html('*'); });
    $('#txtFullNm').keyup(function () { testName('#txtFullNm'); }); 
    $('#txtPhone').keyup(function () { testPhone('#txtPhone'); });
    $('#txtEmail').keyup(function () { testEmail('#txtEmail'); });
});

////chkAllModules_(), chkAllModules_
function chkAllModules_() {
    var valu = document.getElementById('chkAllModules_').checked;  var moduls = $.trim($('#hidRoleModules').val()).split(',');  
    for (var k = 0; k < moduls.length; k++) {     var mods = moduls[k];
        try { document.getElementById('chk' + mods).checked = valu; } catch (e) { } try { chkBoxs_(mods); } catch (e) { }
    }
}
function chkBoxs_(modul) {
    /* //hidUserLevId  hidModStaff,hidModFreight,hidModSalary,hidModAccount,hidModInv,hidModAsset  chkBoxs('Staff')  chkStaff1 */
    var chkId = 'chk' + modul;   var valu = false; try { valu = document.getElementById(chkId).checked; } catch (e) { }
    var levId = 0;   try { levId = parseInt($('#hidUserLevId').val()); } catch (e) { }
    for (var k = 1; k <= 5; k++) { var _id = chkId + k; try { document.getElementById(_id).checked = valu; } catch (e) { } }
    if (levId != 1) { try { var chk5 = chkId + '5'; document.getElementById(chk5).checked = false; } catch (e) { } }
}
function updateUserRoles(id) {
    //hidnLocIds_,  selAccessLoc_,chkUpdRoleLoc(k)
    var accessLoc = $('#selAccessLoc_').val();   //accessloc:   1->all loc, 2->specific loc, 3->staff loc
    var nLocs = 0; try { nLocs = parseInt($.trim($('#hidnLocIds_').val())) } catch (e) { };
    
    if (nLocs.length < 1 || nLocs == "" || nLocs == "0") nLocs = 0;
    var locIDs = ""; //i,2,3,2,
    if (accessLoc == "2" || accessLoc == 2) {  var countLoc = 0;
        for (var k = 1; k <= nLocs; k++) {  var chkId = 'chkUpdRoleLoc' + k;
            try { if (document.getElementById(chkId).checked == true) { locIDs += $.trim($('#' + chkId).val()) + ","; countLoc++; } 
            } catch (e) { }
        } if (countLoc < 1) { alert('Please Select the Access Locations!!!'); return; }
    }
   // alert('Locs: ' + nLocs + ', LOC IDS: ' + locIDs);return;

    var curUserLevId = $('#hidUserLevId').val();     var modCodes = ""; var modCodeValus = ""; var countMods = 0;
    var updModuls = $.trim($('#hidRoleModules').val()).split(',');
    for (var k = 0; k < updModuls.length; k++) {
        var code = ""; try { code = updModuls[k]; } catch (e) { } 
        if (code.length > 2) {
            var _chkId = 'chk' + code; var _nK = 0; var _mValus = "";
            for (var i = 1; i <= 5; i++) {
                var _valu = "0"; try { _valu = (document.getElementById(_chkId + i).checked == true) ? "1" : "0"; } catch (e) { }
                if ((curUserLevId != 1 || curUserLevId != '1') && i == 5) _valu = "0";
                _mValus += _valu + ","; if (_valu == "1") _nK++;
            }
            if (_nK > 0) { modCodes += code + ","; modCodeValus += _mValus + ";"; countMods++; }
        }
    }
    if (countMods < 1) { var confValu = confirm('No Module item selected, Do you want to continue?'); if (!confValu) return; }

    if (id.length < 1 || id == "0") {  alert('Unable to get User information to continue process!!!');  return;
    } else {
        clearUser();
        var jd = '{"id":"' + id + '", "acsLoc":"' + accessLoc + '", "locs":"' + locIDs + 
             '", "modCodes":"' + modCodes + '", "modValus":"' + modCodeValus + '" }';
        get_sync2("updateUserRole", jd, 'divEditRoleProgress', fxnUpdateRole, jsPg);         
    }
}
function fxnUpdateRole(msg) {   $('#divViewUserRole').html(msg.d);  }


//var appModuls = $.trim($('#hidRoleMods').val()).split(','); 
function chkAllModules() {   
    var modula = $.trim($('#hidRoleMods').val()).split(',');  
    var valu = document.getElementById('chkAllModules').checked;    
    for (var k = 0; k < modula.length; k++) { var mods = modula[k]; 
   try { document.getElementById('chk' + mods).checked = valu; } catch (e) { } try { chkBoxs(mods); } catch (e) { }
    }
}
function chkBoxs(modul) {
    /* //hidUserLevId  hidModStaff,hidModFreight,hidModSalary,hidModAccount,hidModInv,hidModAsset  chkBoxs('Staff')  chkStaff1 */
    var hidModValu = $.trim($('#hidMod' + modul).val()); var chkId = 'chk' + modul;
    var valu = false; try { valu = document.getElementById(chkId).checked; } catch (e) { }
    var levId = 0; try { levId = parseInt($('#hidUserLevId').val()); } catch (e) { }
    if (hidModValu == "0" || hidModValu == 0) valu = false;
    for (var k = 1; k <= 5; k++) { var _id = chkId + k; try { document.getElementById(_id).checked = valu; } catch (e) { } }
    if (levId != 1) { try { var chk5 = chkId + '5'; document.getElementById(chk5).checked = false; } catch (e) { } }
}

////drpOficLoc,txtIDNo,txtFullNm,txtPhone,txtEmail,selUserLev,selAccessLoc,chkUserLoc
function addUser() {  clearUser_();       var idno = $.trim($('#txtIDNo').val());
    var oficLoc = $.trim($('#drpOficLoc').val());    var fullnm = $.trim($('#txtFullNm').val());
    var phone = $.trim($('#txtPhone').val());        var email = $.trim($('#txtEmail').val());    
    if(oficLoc.length < 1){    alert('Select the Officers Location');  return;
    }else if(idno.length < 3){  alert('Please Enter the Officer NAF Number');   $('#txtIDNo').focus();   return;
    }else if(fullnm.length < 3 || !testName('#txtFullNm')){  alert('Please Enter the Full Name');   $('#txtFullNm').focus();   return;    
    }else if(phone.length < 11 || !testPhone('#txtPhone')){   
                  alert('Please Enter the Phone Number eg 07030378600');  $('#txtPhone').focus(); return;
    }else if(email.length > 1 && !testEmail('#txtEmail')){   alert('Please Enter the Email eg info@naf.gov.ng');
                $('#txtEmail').focus();  return;
    } //else{ }
    var lev =  $('#selUserLev').val(); var accessLoc = $('#selAccessLoc').val(); //accessloc:  1->all loc, 2->specific loc, 3->staff loc
    var nLocs = 0;   try { nLocs = parseInt($.trim($('#hidnLocIds').val())) } catch (e) { };
    if (nLocs.length < 1 || nLocs == "" || nLocs == "0") nLocs = 0;
    var locIDs = ""; //i,2,3,2,
    if (accessLoc == "2" || accessLoc == 2) {   var countLoc = 0;
        for (var k = 0; k < nLocs; k++) {       var chkId = 'chkUserLoc_' + k;
            try {
     if (document.getElementById(chkId).checked == true) { locIDs += $.trim($('#' + chkId).val()) + ","; countLoc++; }} catch (e) { }
        }   if (countLoc < 1) { alert('Please Select the Access Locations!!!'); return; }
     }
       // 1,0,1,0,1;  1,0,1,0,1;   1,0,1,0,1; 1,0,1,0,1;1,0,1,0,1
      //(ADD,VIEW,EDIT,SETTINGS,APPROVE) chkStaff1,chkFreight1,chkSalary1,chkAccount1,chkInventory1,chkAsset1
      /* hidUserLevId  hidModStaff,hidModFreight,hidModSalary,hidModAccount,hidModInv,hidModAsset  chkBoxs('Staff')  chkStaff1 */
      //var modules = "Staff,Freight,Salary,Account,Inventory,Asset".split(',');
     var curUserLevId = $('#hidUserLevId').val();   var modCodes = ""; var modCodeValus = ""; var countMods = 0;
     var modula = $.trim($('#hidRoleMods').val()).split(',');  
     for (var k = 0; k < modula.length; k++) {
         var code = ""; try { code = modula[k]; } catch (e) { }
         var hidValu = "0"; try { hidValu = $.trim($('#hidMod' + code).val()); } catch (e) { }
         if ((hidValu == "1" || hidValu == 1) && code.length > 2) {
             var _chkId = 'chk' + code; var _nK = 0; var _mValus = "";
             for (var i = 1; i <= 5; i++) {
                 var _valu = "0"; try { _valu = (document.getElementById(_chkId + i).checked == true) ? "1" : "0"; } catch (e) { }
                 if ((curUserLevId != 1 || curUserLevId != '1') && i == 5) _valu = "0";
                 _mValus += _valu + ","; if (_valu == "1") _nK++;
             } if (_nK > 0) { modCodes += code + ","; modCodeValus += _mValus + ";"; countMods++; }
         }
     }
     if (countMods < 1) { var confValu = confirm('No Module item selected, Do you want to continue?'); if (!confValu) return; }
     
    clearUser();  
    var jdt = '{ "oficeLoc":"' + oficLoc + '", "idno":"' + idno + '", "fullnm":"' + fullnm + '", "phone":"' + phone + 
            '", "email":"' + email + '", "lev":"' + lev + '", "acsLoc":"' + accessLoc + '", "locs":"' + locIDs +
            '", "modCodes":"' + modCodes + '", "modValus":"' + modCodeValus + '" }'; sync2("setUser", jdt, 'divUser', jsPg);  
     
}
function clearUser() {    clearUser_(); $('#txtIDNo').val('');
    $('#txtFullNm').val('');  $('#txtPhone').val(''); $('#txtEmail').val('');
    try { document.getElementById('chkAllModules').checked = false; chkAllModules(); } catch (e) { }
} function clearUser_() {   $('#divUser').html(''); $('#txtIDNo_').html(''); $('#txtFullNm_').html(''); $('#txtPhone_').html('');
    $('#txtEmail_').html('');
 }

//drpViewUserLoc,selViewUserLev,getUsers(),divUsersFbck
function getUsers() {
    var div = 'divUsersFbck'; var loc = $.trim($('#drpViewUserLoc').val()); var lev = $.trim($('#selViewUserLev').val());
    if (loc.length < 1) {alert('Please Select the Location!!!'); return; }
    var jd = '{"loc":"' + loc + '", "lev":"' + lev +'" }';   get_sync2('getUsers', jd, div, fxnViewUsers, jsPg);
}
function fxnViewUsers(msg) {
    $('#divJSusers').html(''); $('#divUsersFbck').html(msg.d);   try { jqTBL2('jqUsersTBL', 350); } catch (e) { } 
}


//deleteUser(" + _Id.ToString() + ");  viewRoles(" + _Id.ToString() + ")  
//lockUnlockUser(" + activeId + "," + _Id.ToString() + ");
function fxnJSusers(msg) { $('#divJSusers').html(''); getUsers(); }
function deleteUser(id) {   var conf = confirm("Do You want to Delete User?"); if (!conf) return;
    var jd = '{"id":"' + id + '"}'; get_sync2('deleteUser', jd, 'divJSusers', fxnJSusers, jsPg);  }
function viewRoles(id) {
    openDialog('modalUserRole');   var jd = '{"id":"' + id + '"}'; sync2('viewUserRoles', jd, 'divViewUserRole', jsPg);
}

function lockUnlockUser(status, id) {
    var task = (status == 1) ? "Open/Unlock" : "Lock"; var conf = confirm("Do You want to " + task + " User?"); if (!conf) return;
    var jd = '{"status":"' + status + '", "id":"' + id + '"}'; get_sync2('lockUnlockUser', jd, 'divJSusers', fxnJSusers, jsPg);
}


 

//============ USER SETTINGS ==============================
//modalLoginOutTimer,divModLogTimer,selLogIn,txtLoginTime, selLogOut,txtLogoutTime
 $(function () {
    $("#modalLoginOutTimer").dialog({ height: 'auto', width: 'auto', autoOpen: false, modal: true,
        buttons: { Save: function () { setLogTimer(); }, Cancel: function () { clearLogTimer(); $(this).dialog("close"); } }
    });  
    getLogTimerInfo();
    $("#modalMaxUsers").dialog({ height: 'auto', width: 'auto', autoOpen: false, modal: true,
        buttons: { Save: function () { setMaxAppUsers(); }, Cancel: function () { clearMaxAppUsers(); $(this).dialog("close"); } }
    });
    getMaxAppUsers();
     $("#modSms").dialog({ height: 'auto', width: 'auto', autoOpen: false, modal: true,
        buttons: { Save: function () { setSMS(); }, Cancel: function () { clearSMS(); $(this).dialog("close"); } }
    });
    getSmsInfo(); 
     $("#modEmail").dialog({ height: 'auto', width: 'auto', autoOpen: false, modal: true,
        buttons: { Save: function () { setEMAIL(); }, Cancel: function () { clearEMAIL(); $(this).dialog("close"); } }
    });
    getEmailInfo();

    $('#txtSmsTit').keyup(function () { if ($.trim($('#txtSmsTit').val()).length < 3) $('#txtSmsTit_').html('*'); 
           else $('#txtSmsTit_').html(''); }); 
    $('#txtSmsSesID').keyup(function () { if ($.trim($('#txtSmsSesID').val()).length < 30) $('#txtSmsSesID_').html('*'); 
           else $('#txtSmsSesID_').html(''); });
    $('#txtSmtpEmail').keyup(function () { testEmail('#txtSmtpEmail'); });

});

function setLogTimer(){
    var div = 'divModLogTimer';  ////inHr, inMins,inAM
    var inAct = $('#selLogIn').val();      var outAct = $('#selLogOut').val();  
    var inTime = $('#inHr').val() + ',' + $('#inMins').val() + ',' + $('#inAM').val();
    var outTime = $('#outHr').val() + ',' + $('#outMins').val() + ',' + $('#outAM').val();  var mins = $.trim($('#txtIdleMins').val());
    var jd = '{"inAct":"' + inAct + '", "inTime":"' + inTime + '", "outAct":"' + outAct + '", "outTime":"' + outTime +
         '", "idleMins":"' + mins + '" }';
    get_sync2('setLogInOutTimer', jd, 'divModLogTimer', fxnLogInfo, jsPg);  
} function fxnLogInfo(msg){ clearLogTimer(); $('#divModLogTimer').html(msg.d);  getLogTimerInfo(); }
function clearLogTimer(){
    $('#divModLogTimer').html('');    $('#inHr').val('1');    $('#inMins').val('0');    $('#inAM').val('0');
    $('#outHr').val('1');    $('#outMins').val('0');          $('#outAM').val('0');
    $('#selLogIn').val('0'); hideDiv('in1'); hideDiv('in2'); $('#selLogOut').val('0'); hideDiv('out1'); hideDiv('out2');
    $('#txtIdleMins').val('');
}
function getLogTimerInfo() { sync2('getLogInOutTimer', '{}', 'divLogInfo', jsPg); }

 //modalMaxUsers,divModMaxUsers,  txtMaxAdmin,txtMaxSuper,txtMaxUser
 function setMaxAppUsers(){
    var adm = $('#txtMaxAdmin').val();  var superU = $('#txtMaxSuper').val();  var user = $('#txtMaxUser').val();
    var jd = '{"adminU":"' + adm + '", "superU":"' + superU + '", "user":"' + user + '" }';
    get_sync2('setMaxAppUsers', jd, 'divModMaxUsers', fxnMaxAppUsers, jsPg);  
 }
 function fxnMaxAppUsers(msg) { clearMaxAppUsers(); $('#divModMaxUsers').html(msg.d); getMaxAppUsers(); }
 function clearMaxAppUsers(){  $('#divModMaxUsers').html('');  $('#txtMaxAdmin').val('');  $('#txtMaxSuper').val(''); 
     $('#txtMaxUser').val('');
 }
 function getMaxAppUsers() { sync2('getMaxAppUsersInfo', '{}', 'divMaxUsersInfo', jsPg); }

 function setSMS(){     //modSms,divModSms,txtSmsTit,txtSmsSesID
    var title = $.trim($('#txtSmsTit').val());    var sesID = $.trim($('#txtSmsSesID').val());
    if(title.length < 3){   $('#txtSmsTit_').html('*');  $('#txtSmsTit').focus(); return;
    }else if(sesID.length < 30){ $('#txtSmsSesID_').html('*');  $('#txtSmsSesID').focus(); return;
    } else { var jd = '{"tit":"' + title + '", "sesID":"' + sesID + '"}'; get_sync2('setSms', jd, 'divModSms', fxnSmsSet, jsPg); }    
 } function fxnSmsSet(msg) { clearSMS(); $('#divModSms').html(msg.d); getSmsInfo(); }
 function clearSMS(){   $('#divModSms').html('');   $('#txtSmsTit_').html(''); $('#txtSmsTit').val(''); $('#txtSmsSesID').val('');
 } function getSmsInfo() { sync2('getSmsInfo', '{}', 'divSmsSet', jsPg); }

 function setEMAIL(){ //divSetEmail,txtSmtpServer,txtSmtpPort,txtSmtpEmail,txtSmtpPWD,txtSmtpDisp,setEmailSetting()
      $('#divSetEmail').html(''); $('#txtSmtpEmail').html('');
       var server = $('#txtSmtpServer').val();    var port = $('#txtSmtpPort').val();
       var email = $('#txtSmtpEmail').val(); var pwd = $('#txtSmtpPWD').val(); var disp = $('#txtSmtpDisp').val();
       if (!testEmail('#txtSmtpEmail')) { $('#txtSmtpEmail_').html('*'); $('#txtSmtpEmail').focus(); return; }
       var jDt = '{ "serva":"' + server + '", "port":"' + port + '","email":"' + email + '","pwd":"'
            + pwd + '","dispName":"' + disp + '" }'; get_sync2('setEmail', jDt, 'divSetEmail', fxnEmailSet, jsPg);
 }
 function fxnEmailSet(msg){ clearEMAIL();  $('#divSetEmail').html(msg.d); getEmailInfo();   }
 function clearEMAIL(){  $('#txtSmtpServer').val(''); $('#txtSmtpPort').val('');
    $('#txtSmtpEmail').val('');   $('#txtSmtpPWD').val('');   $('#txtSmtpDisp').val(''); 
 }
 function getEmailInfo() { sync2('getEmailInfo', "{}", "divEmailSetInfo", jsPg); }
 //===============================================================================


 $(function () { 
    $("#modLocation").dialog({ height: 'auto', width: 'auto', autoOpen: false, modal: true,
        buttons: { Save: function () { setLocation(); }, Cancel: function () { clearLocation(); $(this).dialog("close"); } }
    });  
    
    $("#modAirCraft").dialog({ height: 'auto', width: 'auto', autoOpen: false, modal: true,
        buttons: { Save: function () { setCraft(); }, Cancel: function () { clearCraft(); $(this).dialog("close"); } }
    });
      
 });
  
  function setLocation(){
    var name = $.trim($('#txtLocNm').val());
    if(name.length < 3) { alert('Please Enter the Location Name...'); return;
    }else{ $('#txtLocNm').val(''); var jd = '{ "name":"' + name + '" }';  sync2('setLocation', jd, 'divModLoc', jsPg);  }
  }
  function clearLocation(){ $('#divModLoc').html(''); $('#txtLocNm').val(''); }

  function setCraft(){   //divModCraft,drpAirLoc,txtCallSign,txtAirNm
    var div = 'divModCraft';       var loc = $.trim($('#drpAirLoc').val());
    var calSign = $.trim($('#txtCallSign').val());   var name = $.trim($('#txtAirNm').val());
    if(loc.length < 1){ alert('Please Select the Location'); return;
    }else if(calSign.length < 3){   alert('Please Enter the Aircraft Call Sign'); return;
    }else if(name.length < 3) {   alert('Please Enter the Aircraft Name'); return;
    }else{ clearCraft();
        var jd = '{ "loc":"' + loc + '", "callSign":"' + calSign + '", "name":"' + name + '" }';  sync2('setAircraft', jd, div, jsPg);
    }
  }
  function clearCraft(){  $('#divModCraft').html(''); $('#txtCallSign').val(''); $('#txtAirNm').val('');    }
   
 //=======================================================================================
 function getAuditTrail(){
     var modul = $.trim($('#drpTrailModules').val());     var action = $.trim($('#drpTrailAction').val());
     var frmDt = $.trim($('#txtTrailFrmDt').val());       var toDt = $.trim($('#txtTrailToDt').val());
     if(frmDt.length < 10){       alert('Select the From Date');  $('#txtTrailFrmDt').focus(); return;
     }else if(toDt.length < 10){  alert('Select the To Date');  $('#txtTrailToDt').focus(); return;      
     }else{
         var jd = '{"modul":"' + modul + '", "action":"' + action + '", "frmDt":"' + frmDt + '", "toDt":"' + toDt + '" }';
         get_sync2('getTrail', jd, 'divViewAuditTrail', fxnTrail, jsPg);
     } //drpTrailModules,drpTrailAction,txtTrailFrmDt,txtTrailToDt,getAuditTrail()
 }

 function fxnTrail(msg) { $('#divViewAuditTrail').html(msg.d); jqTBL2('jqAuditTBL', 400); }      

 