﻿var jsPg = 'air';


$(function () {

    $("#div_addTakeOff").dialog({ height: 'auto', width: 'auto', autoOpen: false, modal: true,
        buttons: { Save: function () { addTakeOff(); }, Cancel: function () { clearTakeOff(); $(this).dialog("close"); } }
    });
    //onChangeCraft();
    /*  $('#txtPhone').keyup(function () { testPhone('#txtPhone'); });
    $('#txtStfNm').keyup(function () { testName('#txtStfNm'); });
    $('#smsPhones').keyup(function () { testPhone('#smsPhones'); });
    $('#txtStfIDNo').keyup(function () {  $('#txtStfIDNo_').html(''); if ($.trim(this.value).length < 3) $('#txtStfIDNo_').html('*');
    });   $('#tkYr').val()   $('#selLndYr').val();*/    
    $('#tkYr').keyup(function () {
        $('#tkYr_').html(''); var yr = $.trim(this.value); if (isNaN(yr) || yr < 2000) $('#tkYr_').html('*');
    });
    $('#selLndYr').keyup(function () {
        $('#selLndYr_').html(''); var yr = $.trim(this.value); if (isNaN(yr) || yr < 2000) $('#selLndYr_').html('*');
    });
});

function onChangeCraft() {
    try { getCraftStatus(); } catch (e) { $('#divCraftCurStatus').html(e); }
    try { getCraftLastFlight(); } catch (e) { $('#divCraftLastFlightInfo').html(e); }  
}
function getCraftStatus() {
    var sign = $('#drptkCraft').val(); $('#divCraftCurStatus').html(''); if (sign.length < 2) return;
    var jd = '{"calSign":"' + sign + '"}';  sync2('getCraftStatus', jd, 'divCraftCurStatus', jsPg); 
}
function getCraftLastFlight() {
    $('#divCraftLastFlightInfo').html('');   var sign = $('#drptkCraft').val(); if (sign.length < 2) return;
    var jd = '{"calSign":"' + sign + '"}'; sync2('getCraftLastFlight', jd, 'divCraftLastFlightInfo', jsPg);
}


function addTakeOff() {
    //drptkCraft,selTask, txtTaskName,txtTkLoc,  tkDay,tkMth,tkYr, tkHr,tkMins, seltAPm    
    // txtLndloc,selLndDay,selLndMth,selLndYr,selLndHr,selLndMins,selLndAPm,  txtSptHr,txtSptMins 
    //selIsSnag,txtRmk, divAddTakeOff, divTakeOffInfo 
    var cSign = $('#drptkCraft').val(); var task = $('#selTask').val();
    var name = $('#txtTaskName').val(); var tLoc = $('#txtTkLoc').val();
    //var tDay = $('#tkDay').val(); var tMth = $('#tkMth').val(); var tYr = $('#tkYr').val(); var tAPm = $('#seltAPm').val();
    var tHr = $('#tkHr').val();   var tMins = $('#tkMins').val();

    var lLoc = $('#txtLndloc').val();
    //var lDay = $('#selLndDay').val(); var lMth = $('#selLndMth').val(); var lYr = $('#selLndYr').val(); 
    //var lAPm = $('#selLndAPm').val();
    var lHr = $('#selLndHr').val();  var lMins = $('#selLndMins').val(); 

    var spHr = $.trim($('#txtSptHr').val());    var spMins = $('#txtSptMins').val();
    var isSnag = $('#selIsSnag').val();         var rmk = $.trim($('#txtRmk').val());

    if (cSign.length < 3) {       alert('Select the Aircraft'); $('#drptkCraft').focus(); return;
    } else if (name.length < 3) { alert('Enter the Task Name'); $('#txtTaskName').focus(); return;
    } else if (tLoc.length < 3) { alert('Enter the Take-Off Location'); $('#txtTkLoc').focus(); return;
    } else if (lLoc.length < 3) { alert('Enter the Landing Location'); $('#txtLndloc').focus(); return;
    } else if (spHr.length < 1) { alert('Enter the Spent Hour'); $('#txtSptHr').focus(); return;   }

    var jd = '{"sign":"' + cSign + '", "task":"' + task + '", "name":"' + name + '", "tLocNm":"' + tLoc + '", "tHr":"' + tHr + '", "tMins":"' + tMins + '",  "lLocNm":"' + lLoc + '", "lHr":"' + lHr + '", "lMins":"' + lMins + '", "spHr":"' + spHr + '", "spMins":"' + spMins + '", "isSnag":"' + isSnag + '", "rmk":"' + rmk + '" }'; clearTakeOff();
    get_sync2('setTakeOff', jd, 'divAddTakeOff', fxnTakeOff, jsPg); 
}
function fxnTakeOff(msg) { $('#divAddTakeOff').html(msg.d); onChangeCraft(); }
function clearTakeOff() {
    $('#divAddTakeOff').html('');  $('#txtTaskName').val('');  $('#txtTkLoc').val('');    $('#txtLndloc').val('');
    $('#txtSptHr').val(''); $('#txtSptMins').val('0'); $('#txtRmk').val('');
}

 

$(function () {
    /*  $('#txtPhone').keyup(function () { testPhone('#txtPhone'); });
    $('#txtStfIDNo').keyup(function () {  $('#txtStfIDNo_').html(''); if ($.trim(this.value).length < 3) $('#txtStfIDNo_').html('*');
    });   $('#tkYr').val()   $('#selLndYr').val();
    $('#tkYr').keyup(function () {
        $('#tkYr_').html(''); var yr = $.trim(this.value); if (isNaN(yr) || yr < 2000) $('#tkYr_').html('*');
    }); */

    $('#tkHr').change(function () { computeSpentDt(); });
    $('#tkMins').change(function () { computeSpentDt(); });
    $('#selLndHr').change(function () { computeSpentDt(); });
    $('#selLndMins').change(function () { computeSpentDt(); });
    
});
/* tkDay,tkMth,tkYr, tkHr,tkMins, seltAPm    
// txtLndloc,selLndDay,selLndMth,selLndYr,selLndHr,selLndMins,selLndAPm,  txtSptHr,txtSptMins 
//selIsSnag,txtRmk, divAddTakeOff, divTakeOffInfo */
function computeSpentDt() {
    var tHr = 0, tMin = 0; var lHr = 0, lMin = 0;    
   /* try { tYr = parseInt($.trim($('#tkYr').val())); } catch (e) { }
    try { tMth = parseInt($.trim($('#tkMth').val())); } catch (e) { }
    try { tDay = parseInt($.trim($('#tkDay').val())); } catch (e) { }     
    if ($('#seltAPm').val() == '1' || $('#seltAPm').val() == 1) tHr += 12;  */
    try { tHr = parseInt($.trim($('#tkHr').val())); } catch (e) { }
    try { tMin = parseInt($.trim($('#tkMins').val())); } catch (e) { }
    try { lHr = parseInt($.trim($('#selLndHr').val())); } catch (e) { }
    try { lMin = parseInt($.trim($('#selLndMins').val())); } catch (e) { }

    var sHr = 0, sMin = 0;
    sHr = lHr - tHr;
    if (tMin > lMin) { sHr = sHr - 1; sMin = (60 + lMin) - tMin; } else sMin = lMin - tMin;
    $('#txtSptHr').val(sHr); $('#txtSptMins').val(sMin);
    //var str = "Take Off Time[Hr:" + tHr + ", Mins:" + tMin + "] landed Hr: " + lHr + ", Mins: " + lMin + ", (HR:" + sHr + ", Mins: " + sMin + " )";
    //$('#divAddTakeOff').html(str);
}


function viewAircraftStatus() {//drpViewCraftLoc
    var loc = $('#drpViewCraftLoc').val(); var jd = '{"loc":"' + loc + '"}';
    get_sync2('getAircraftStatus', jd, 'divViewCraftStatus', fxnCraftStatus, jsPg);
}
function fxnCraftStatus(msg) { $('#divViewCraftStatus').html(msg.d); jqTBL('craftStatusTBL'); }


//=======================================================================================
function getAuditTrail() {
    var modul = $.trim($('#hidModule').val()); var action = $.trim($('#drpTrailAction').val());
    var frmDt = $.trim($('#txtTrailFrmDt').val()); var toDt = $.trim($('#txtTrailToDt').val());
    if (frmDt.length < 10) {
        alert('Select the From Date'); $('#txtTrailFrmDt').focus(); return;
    } else if (toDt.length < 10) {
        alert('Select the To Date'); $('#txtTrailToDt').focus(); return;
    } else {
        var jd = '{"modul":"' + modul + '", "action":"' + action + '", "frmDt":"' + frmDt + '", "toDt":"' + toDt + '" }';
        get_sync2('getTrail', jd, 'divViewAuditTrail', fxnTrail, 'appset');
    }
}

function fxnTrail(msg) { $('#divViewAuditTrail').html(msg.d); jqTBL2('jqAuditTBL', 400); }      

 