﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NAF
{
    public partial class authuser : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
            if (!IsPostBack)
            {
                AppSet.set();
                string browserInfo = UserSession.browserInfo; UserSession.End(); UserSession.IsActive = false;
                UserSession.browserInfo = browserInfo;
                txtUsername.Value = ""; txtPWD.Value = ""; txtUsername.Focus();
            }
            else { UserSession.IsActive = false; this.loginUser(); }
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            this.loginUser();
        }

        private void loginUser()
        {
            bool ValidateUser = false;
            try { CaptchaControl1.ValidateCaptcha(txtCaptcha.Value.Trim()); ValidateUser = CaptchaControl1.UserValidated; }
            catch { }

            string UserNm = txtUsername.Value.Trim(); string PWD = txtPWD.Value.Trim();
            txtCaptcha.Value = ""; txtUsername.Value = ""; txtPWD.Value = "";

            if (!ValidateUser)
            {
                divErr.InnerHtml = "<font color='red'><i>Wrong Verification Code...</i></font>";
                txtUsername.Focus(); return;
            }
            else
            {
                Users obj = new Users(); bool IsLoginValid = obj.loginUser(UserNm, PWD);
                if (IsLoginValid && UserSession.IsActive)
                {
                    int admLevId = UserSession.LevId;       //1,2,3     Admin, Super, User  
                    if (admLevId == 1 || admLevId == 2 || admLevId == 3) Response.Redirect("app/portal.aspx"); 
                    else divErr.InnerHtml = "<font color='red'><i>Unknown User Level..." + obj._error + " </i></font>";
                } 
                divErr.InnerHtml = obj._error + Users.error;
                //ScriptManager.RegisterStartupScript(this, this.GetType(), "alertWrngEntry",
                //     "javascript:alert('Wrong Entry'); location.href='authuser.aspx';  ", true);
            }
            txtUsername.Focus();
        }

    }
}