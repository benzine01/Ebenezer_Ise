<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000"><div align = 'center'><br><br><br><br><br><br><br><br><br><br><br>
  <br>
  <br>
</div>
<div align = 'center'>
<table width="320" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFCC">
  <tr> 
    <td width="320" height="37" valign="top" align="center"> 
      <?php 
	  include("connect.php");
			  $username = $_POST['username'];
			  $password = $_POST['password'];
			  $name = $_POST['name'];
			  $post = $_POST['post'];
			   // Check if the username exists
  				$usernameinuse = mysql_query("SELECT * FROM user WHERE username = '$username' ");
  				$isusernameinuse = mysql_num_rows($usernameinuse);

 	  
			  if ($username == ''){
			  echo"<font color='red'>Please state your username<br>";}
			  if($password == ''){
			  echo"<font color='red'>Please state your password<br>";}
			  if($name == ''){
			  echo"<font color='red'>Please state your name<br>";}
			  if($post == ''){
			  echo"<font color='red'>Please state your post";
			  }else 
			  if ($isusernameinuse == 1) {
      		  echo "<font color='red'>The username you selected is already been registered.<BR>Try Choose different username.";
			  }else{
			  echo"<b>[</b> $username <b>]</b><br><font color='red'>Registration Successful!</font>";
			  mysql_query("INSERT INTO user VALUE ('$username','$password','$name','$post')");
			  }
			   ?>
      <br>
      <a href="javascript:history.back(-1);">Back</a> </td>
  </tr>
</table></div>
</body>
</html>
