<?php

  $time = time();

  // Say that user is logged out
  $loggedout = true;

  // If there is a cookie
  if (isset($_COOKIE['cookie_info'])) {

      // Delete the cookie
      setcookie ("cookie_info", "", $time - 3600);

      // Use Connect Script
      include("connect.php");

      // Include the validation of user file
      include("validateuser.php");

      // If user and password are correct
      if (validateuser() == true) {
 
          // Use cookie and Extract the cookie data (Username and Password)
          $cookie_info = explode("-", $_COOKIE['cookie_info']);
          $namecookie = $cookie_info[0];
          $passcookie = $cookie_info[1];

          // Get details of user from Database and put them in variables
          $query = mysql_query("SELECT * FROM user WHERE username = '$namecookie'");
          $name= mysql_result($query,0,0);

      //The user is not logged out yet
          $loggedout = false;
      }

      // If user and password are not correct print error message
      else {
          echo "Incorrect username/password";
          exit;
      }
}

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Logout</title>
</head>

<body>
<div align="center"><br> <br> <br> <br> <br>
  <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="80" height="58">
    <param name=movie value="images/Movie2.swf">
    <param name=quality value=high>
    <embed src="images/Movie2.swf" quality=high pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="80" height="58">
    </embed> 
  </object><br>
   <br>
  <?php

  // If user is logged out then print message
  if ($loggedout == false) {
      echo "  <b>You are now logged out. <br><br><a href='index2.php'>Click here to log in again.</a><br><br> or<br><br>";?> <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="100" height="22">
    <param name=movie value="images/close.swf">
    <param name=quality value=high>
    <embed src="images/close.swf" quality=high pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="100" height="22">
    </embed> 
  </object><?php
	  } 

?>
  </div>
</html>