
<script language="JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && document.getElementById) x=document.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<body onLoad="MM_preloadImages('images/createNewDown.PNG','images/updatelocationDown.PNG','images/deletefileDown.PNG')" >
<table width="758" border="0" cellpadding="0" cellspacing="0"  >
  <tr> 
    <td width="2" height="19"></td>
    <td valign="top" colspan="6"><a href="system_files.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image2','','images/updatelocationDown.PNG',1)"><img name="Image2" border="0" src="images/updatelocationUp.PNG" width="150" height="19" alt="Update File Location"></a></td>
    <td width="2"></td>
    <td valign="top" colspan="2"><a href="system_files_createNew.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image1','','images/createNewDown.PNG',1)"><img name="Image1" border="0" src="images/createNewUp.PNG" width="150" height="19" alt="Create New File"></a></td>
    <td width="150" valign="top"><a href="system_files_delete.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image3','','images/deletefileDown.PNG',1)"><img name="Image3" border="0" src="images/deletefileDown.PNG" width="150" height="19"></a></td>
    <td width="100"></td>
    <td width="18"></td>
    <td width="17" rowspan="6" valign="top">&nbsp;</td>
    <td width="37"></td>
    <td valign="top" rowspan="6"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0" background="images/BG.PNG">
        <tr> 
          <td width="128" height="91"></td>
        </tr>
      </table>
    </td>
    <td width="4"></td>
  </tr>
  <tr> 
    <td height="32"></td>
    <td width="1"></td>
    <td width="26"></td>
    <td colspan="2" rowspan="2" valign="top">&nbsp;</td>
    <td width="29"></td>
    <td width="82"></td>
    <td></td>
    <td width="42"></td>
    <td width="108"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="6"></td>
    <td></td>
    <td valign="top" rowspan="2">&nbsp;</td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="13"></td>
    <td></td>
    <td width="2"></td>
    <td valign="top" colspan="2" rowspan="6"> 
      <div align="center"> 
        <p><b><font color="#CCCCCC">D</font></b></p>
        <p><font color="#CCCCCC"><b>E</b></font></p>
        <p><font color="#CCCCCC"><b>L</b></font></p>
        <p><font color="#CCCCCC"><b>E</b></font></p>
        <p><font color="#CCCCCC"><b>T</b></font></p>
        <p><font color="#CCCCCC"><b>E</b></font></p>
      </div>
    </td>
    <td></td>
    <td></td>
    <td></td>
    <td colspan="3" rowspan="2" valign="top"> 
      <table width="100%" border="1" cellpadding="1" cellspacing="1">
        <tr> 
          <td width="358" height="20" valign="top" bgcolor="#6B6C9C"> 
            <div align="center"><b><font color="#FFFFFF">Delete File</font></b></div>
          </td>
        </tr>
      </table>
    </td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="14"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="14"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="28"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td width="128"></td>
    <td></td>
  </tr>
  <tr> 
    <td height="156"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td colspan="3" valign="top"> 
      <form name="form1" method="post" action="system_files_delete.php">
        <p align="center"> <br>
          <b><font size="2">File Number or Name:</font></b> <br>
          <input type="text" name="filenoname">
          <br>
          <br>
          <input type="submit" name="Submit" value="  Delete  ">
        </p>
      </form>
    </td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="26"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td colspan="3" valign="top"> 
      <div align = 'center'> 
        <?php 
	include("connect.php");
	$fnoname = $_POST['filenoname'];
	
	
	$idindb = mysql_query("SELECT * FROM files where fileno = '$fnoname' ");
  	$isidindb = mysql_num_rows($idindb);
	$idindb2 = mysql_query("SELECT * FROM files where filename = '$fnoname' ");
  	$isidindb2 = mysql_num_rows($idindb2);
	//echo"$isidindb $isidindb2";
	if ($fnoname == ''){
	echo "<font color='red'>Input the file number <b>OR</b> name to delete";
	} 
	else
	if ($isidindb == 1){
		echo "<font color='red'>File</font> [ <b>$fnoname</b> ]<font color='red'> is deleted";
	mysql_query("DELETE FROM `files` WHERE fileno = '$fnoname' ");
	}else if ($isidindb2 == 1){
	echo "<font color='red'>File</font> [ <b>$fnoname</b> ]<font color='red'> is deleted";
	mysql_query("DELETE FROM `files` WHERE filename = '$fnoname' ");
	}else {
	echo "<font color='red'>File</font> [ <b>$fnoname</b> ]<font color='red'> is not exist";
	mysql_query("DELETE FROM `files` WHERE fileno = '$fnoname' OR filename = '$fnoname' ");
	}
?>
      </div>
    </td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="51"></td>
    <td></td>
    <td></td>
    <td></td>
    <td width="10"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
</table>
