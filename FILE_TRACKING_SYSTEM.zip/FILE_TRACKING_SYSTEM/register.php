<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000">

<table width="439" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="72" height="180"></td>
    <td width="10" valign="top" rowspan="2"> 
      <div align="center"> 
        <p><font size="2"><b><font color="#CCCCCC">R<br>
          E<br>
          G<br>
          I<br>
          S<br>
          T<br>
          R<br>
          A<br>
          T<br>
          I<br>
          O<br>
          N</font></b></font></p>
      </div>
    </td>
    <td width="276" rowspan="3" valign="top"> 
      <form name="form1" method="post" action="reg_act.php">
        <div align="center"><font size="2">Username</font><br>
          <input type="text" name="username">
          <br>
          <font size="2">Password</font><br>
          <input type="password" name="password">
          <br>
          <font size="2">Name</font><br>
          <input type="text" name="name">
          <br>
          <font size="2">Post</font><br>
          <input type="text" name="post">
          <br>
          <br>
          <input type="reset" name="Reset" value="  Reset  ">
          <input type="submit" name="Submit2" value="Register">
        </div>
      </form>
    </td>
    <td width="10" valign="top"> 
      <div align="center"><font size="2"><b><font color="#CCCCCC">R<br>
        E<br>
        G<br>
        I<br>
        S<br>
        T<br>
        R<br>
        A<br>
        T<br>
        I<br>
        O<br>
        N</font></b></font></div>
    </td>
    <td width="71"></td>
  </tr>
  <tr> 
    <td height="19"></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="60"></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
</table>
</body>
</html>
