
<script language="JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && document.getElementById) x=document.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<body onLoad="MM_preloadImages('images/createNewDown.PNG','images/updatelocationDown.PNG','images/deletefileDown.PNG')" >
<table width="758" border="0" cellpadding="0" cellspacing="0"  >
  <tr> 
    <td width="2" height="19"></td>
    <td colspan="5" valign="top"><a href="system_files.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image2','','images/updatelocationDown.PNG',1)"><img name="Image2" border="0" src="images/updatelocationUp.PNG" width="150" height="19" alt="Update File Location"></a></td>
    <td width="2"></td>
    <td valign="top" colspan="2"><a href="system_files_createNew.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image1','','images/createNewDown.PNG',1)"><img name="Image1" border="0" src="images/createNewDown.PNG" width="150" height="19" alt="Create New File"></a></td>
    <td width="150" valign="top"><a href="system_files_delete.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image3','','images/deletefileDown.PNG',1)"><img name="Image3" border="0" src="images/deletefileUp.PNG" width="150" height="19"></a></td>
    <td width="100"></td>
    <td width="16"></td>
    <td width="22" rowspan="5" valign="top">&nbsp;</td>
    <td width="38"></td>
    <td width="128" rowspan="4" valign="top"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0" background="images/BG.PNG">
        <tr> 
          <td width="128" height="91"></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="38"></td>
    <td width="26"></td>
    <td width="1"></td>
    <td width="9" valign="top">&nbsp;</td>
    <td width="30"></td>
    <td width="84"></td>
    <td></td>
    <td width="42"></td>
    <td width="108"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="27"></td>
    <td></td>
    <td></td>
    <td colspan="2" rowspan="6" valign="top"> 
      <div align="center"> 
        <p><b><font color="#CCCCCC">C</font></b></p>
        <p><font color="#CCCCCC"><b>R</b></font></p>
        <p><font color="#CCCCCC"><b>E</b></font></p>
        <p><font color="#CCCCCC"><b>A</b></font></p>
        <p><font color="#CCCCCC"><b>T</b></font></p>
        <p><font color="#CCCCCC"><b>E</b></font></p>
      </div>
    </td>
    <td></td>
    <td></td>
    <td></td>
    <td colspan="3" valign="top"> 
      <table width="100%" border="1" cellpadding="1" cellspacing="1">
        <tr> 
          <td width="358" height="20" valign="middle" bgcolor="#6B6C9C"> 
            <div align="center"><b><font color="#FFFFFF">Create New File </font></b></div>
          </td>
        </tr>
      </table>
    </td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td height="7"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="1"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="1"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="20"></td>
    <td valign="top">&nbsp;</td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td colspan="3" valign="top" rowspan="3"> 
      <form name="form1" method="post" action="system_files_createNew.php">
        <p align="center"> <br>
          <b><font size="2">File Number:</font></b> 
          <input type="text" name="fileno">
          <br>
          <br>
          <b><font size="2">File Name:</font></b> <font size="2">&nbsp;</font>&nbsp;&nbsp; 
          <input type="text" name="filename">
          <br>
          <br>
          <b><font size="2">File Description:</font></b><br>
          <textarea name="filedesc" rows="3"></textarea>
          <br>
          <br>
          <input type="submit" name="Submit" value="  Create  ">
        </p>
        <div align = 'center'> 
          <?php 
	include("connect.php");
		
	$fno = $_POST['fileno'];
	$fname = $_POST['filename'];
	$fdesc = $_POST['filedesc'];
	$currentdatetime = mysql_query('select now()');
	$curdatetime = mysql_result($currentdatetime,0);
	$idindb = mysql_query("SELECT * FROM files where fileno = '$fno' ");
  	$isidindb = mysql_num_rows($idindb);
	
	$idindb2 = mysql_query("SELECT * FROM files where filename = '$fname' ");
  	$isidindb2 = mysql_num_rows($idindb2);
  //echo"$isidindb";
	if ($fno == ''){
	echo "<font color='red'>Input the file number and name to create";
	} else
	if ($isidindb == 1){
		echo "File [ <b>$fno</b> ]<font color='red'> is already in the database";
	}else if ($fname == ''){
	echo "<font color='red'>Input the file name to create";
	}else if ($isidindb2 == 1){
	echo "File [ <b>$fname</b> ]<font color='red'> is already in the database";
	}else {
	echo "File [ <b>$fno - $fname</b> ] is saved into the database.";
	mysql_query("INSERT INTO `files` VALUES ('$fno','$fname','$fdesc','File Room','$curdatetime','')");
	
	}
?>
        </div>
      </form>
    </td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="220"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="80"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
</table>
