<?php
// If there is no cookie presesnt
  if (!isset($_COOKIE['cookie_info'])) {

      // Variables that data come from the form
      $username = $_POST["user"];
      $password = $_POST["pass"];

      // Check if username and password where submitted
      if (!$username) {
          echo "<center><b>Please Enter Your Username <br><br><a href='index2.php'>Back</a>"; exit;
      }
      if (!$password) {
          echo "<center><b>Please Enter Your Password <br><br><a href='index2.php'>Back</a>"; exit;
      }

      // Use Connect Script
      include("connect.php");

      // MD5 Username and Password
      //$username = MD5($username);
     //$password = MD5($password);

      // Check if username exists. If not then say no such username.
      $issuchusername = mysql_query("SELECT * FROM user WHERE username = '$username'");
      $usernamelogin = mysql_num_rows($issuchusername);

      // If username exists
      if ($usernamelogin == 1) {

          $issuchpassword = mysql_query("SELECT * FROM user WHERE username = '$username' AND password = '$password'");
          $passwordlogin = mysql_num_rows($issuchpassword);

          // If password is correct
          if ($passwordlogin == 1) {

              $time = time();
              $cookie_data = $username.'-'.$password;
              if(setcookie ("cookie_info",$cookie_data, $time+3600)==TRUE) {
              }
              else {
                  echo "You computer does not support cookies. <BR> To view other pages after logged in you need to have cookies enabled.<BR>";
              }

          }
          else {
              echo "<center><b>Incorrect Username/Password <br><br><a href='index2.php'>Back</a>";
              exit;
          }
      }
      else {
          echo "<center><b>Incorrect Username/Password <br><br><a href='index2.php'>Back</a>";
          exit;
      }
  }
  // End if no cookie present

?>
<html>
<head>
<title>..::: File-Track System :::.. by ReVo</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && document.getElementById) x=document.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>
<body bgcolor="#FFFFFF" text="#000000" onLoad="MM_preloadImages('images/files_down.PNG','images/help_down.PNG','images/icon2.PNG','images/foldericondownsearch.PNG','images/foldericonpersondown.PNG','images/foldericonlocdown.PNG','images/foldericondownhelp.PNG','images/search_down.PNG','images/loc_down.PNG','images/PERSON_down.PNG')">
<div align = 'center'>
  <table width="762" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
    <tr> 
      <td valign="middle" colspan="2" align="center" height="65"> 
        <div align="left"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="80" height="58">
            <param name=movie value="images/Movie2.swf">
            <param name=quality value=high>
            <embed src="images/Movie2.swf" quality=high pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="80" height="58">
            </embed> 
          </object></div>
      </td>
      <td valign="middle" colspan="9" bgcolor="#FFFFFF" align="center"> 
        <div align="left"> <img src="images/ftrack.PNG" width="289" height="56" alt="File-Track System"> 
        </div>
      </td>
      <td valign="middle" align="center" colspan="2"><a href="logout.php">Logout</a></td>
      <td width="1"></td>
    </tr>
    <tr> 
      <td height="73" width="2"></td>
      <td valign="top" colspan="2" align="center"><a href="system_files.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('files','','images/files_down.PNG',1)"><img name="files" border="0" src="images/files_up.PNG" width="150" height="19" alt="Update Files Location"></a><a href="system_files.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('icon1','','images/icon2.PNG',1)"><br>
        <img name="icon1" border="0" src="images/icon1.PNG" width="70" height="52" alt="Update Files Location"></a></td>
      <td width="2"></td>
      <td width="150" valign="top" align="center"><a href="system_search_bynumber.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image11','','images/search_down.PNG',1)"><img name="Image11" border="0" src="images/search_up.PNG" width="150" height="19" alt="Search Files"></a><br>
        <a href="system_search_bynumber.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('iconsearch','','images/foldericondownsearch.PNG',1)"><img name="iconsearch" border="0" src="images/foldericonupsearch.PNG" width="68" height="54" alt="Search Files"></a></td>
      <td width="2"></td>
      <td width="150" valign="top"> 
        <div align="center"><a href="system_locations.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image12','','images/loc_down.PNG',1)"><img name="Image12" border="0" src="images/loc_up.PNG" width="150" height="19" alt="Files at Location"></a><br>
          <a href="system_locations.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('locationicon','','images/foldericonlocdown.PNG',1)"><img name="locationicon" border="0" src="images/foldericonlocup.PNG" width="68" height="54" alt="Files at Location"></a></div>
      </td>
      <td width="2"></td>
      <td width="150" valign="top"> 
        <div align="center"><a href="?page=person" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image13','','images/PERSON_down.PNG',1)"><img name="Image13" border="0" src="images/PERSON_down.PNG" width="150" height="19" alt="Files at Person"></a><br>
          <a href="?page=person" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('personicon','','images/foldericonpersondown.PNG',1)"><img name="personicon" border="0" src="images/foldericonpersonup.PNG" width="68" height="54" alt="Files at Person"></a></div>
      </td>
      <td width="2"></td>
      <td valign="top" colspan="2"> 
        <div align="center"><a href="system_help.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('help','','images/help_down.PNG',1)"><img name="help" border="0" src="images/help_up.PNG" width="150" height="19" alt="Need Help?"></a><br>
          <a href="system_help.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('helpicon','','images/foldericondownhelp.PNG',1)"><img name="helpicon" border="0" src="images/foldericonuphelp.PNG" width="68" height="54" alt="Need Help?"></a></div>
      </td>
      <td width="1"></td>
      <td></td>
    </tr>
    <tr> 
      <td height="39"></td>
      <td valign="top" colspan="12"> 
        <div align="center"> 
          <hr>
          <?php 
		 switch($_GET['page']) {
				case "files":
				//echo "Files";
				include ('files.php');
				break;
				case "search":
				//echo "Search";
				include ('searchbynumber.php');
				break;
				case "location":
				//echo "Locations";
				include ('locations.php');
				break;
				case "person":
				//echo "Persons";
				include ('persons.php');
				break;
				case "help":
				//echo "Help";
				include ('help.php');
				break;
				default:
				//echo "Persons Default";
				include ('persons.php');
				break;
				}
		?>
        </div>
      </td>
      <td></td>
    </tr>
    <tr> 
      <td height="1"></td>
      <td width="79"></td>
      <td width="71"></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td width="62"></td>
      <td width="88"></td>
      <td></td>
      <td></td>
    </tr>
  </table>
</div>
</body>
</html>
