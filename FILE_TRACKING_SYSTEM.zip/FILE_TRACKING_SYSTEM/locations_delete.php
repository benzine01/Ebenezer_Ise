
<script language="JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && document.getElementById) x=document.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<body onLoad="MM_preloadImages('images/createnewpersonDown.PNG','images/deletelocDown.PNG','images/filesatLocationDown.PNG')" >
<table width="758" border="0" cellpadding="0" cellspacing="0"  >
  <tr> 
    <td width="2" height="19"></td>
    <td valign="top" colspan="3"><a href="system_locations.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image4','','images/filesatLocationDown.PNG',1)"><img name="Image4" border="0" src="images/filesatLocationUp.PNG" width="150" height="19" alt="Files at the specific location"></a></td>
    <td width="2"></td>
    <td width="150" valign="top"><a href="system_locations_createnew.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image2','','images/createnewpersonDown.PNG',1)"><img name="Image2" border="0" src="images/createnewpersonUp.PNG" width="150" height="19" alt="Create New Location"></a></td>
    <td width="150" valign="top"><a href="system_locations_delete.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image3','','images/deletelocDown.PNG',1)"><img name="Image3" border="0" src="images/deletelocDown.PNG" width="150" height="19" alt="Delete Location"></a></td>
    <td width="160"></td>
    <td width="10"></td>
    <td width="129" rowspan="4" valign="top"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0" background="images/BGlocation.PNG">
        <tr> 
          <td width="129" height="89"></td>
        </tr>
      </table>
    </td>
    <td width="5"></td>
  </tr>
  <tr> 
    <td height="47"></td>
    <td width="32"></td>
    <td width="35"></td>
    <td width="83"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td height="3"></td>
    <td></td>
    <td rowspan="3" valign="top"> 
      <div align="center"> 
        <p><b><font color="#CCCCCC">D</font></b></p>
        <p><font color="#CCCCCC"><b>E</b></font></p>
        <p><font color="#CCCCCC"><b>L</b></font></p>
        <p><font color="#CCCCCC"><b>E</b></font></p>
        <p><font color="#CCCCCC"><b>T</b></font></p>
        <p><font color="#CCCCCC"><b>E</b></font></p>
      </div>
    </td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="27"></td>
    <td></td>
    <td></td>
    <td colspan="4" valign="top"> 
      <table width="100%" border="1" cellpadding="1" cellspacing="0">
        <tr> 
          <td width="462" height="20" valign="top" bgcolor="#6B6C9C"> 
            <div align="center"><font color="#FFFFFF"><b>Delete Location</b></font></div>
          </td>
        </tr>
      </table>
    </td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="198"></td>
    <td></td>
    <td></td>
    <td colspan="4" valign="top" rowspan="2"> 
      <form name="formdelete" method="post" action="system_locations_delete.php">
        <p align="center">&nbsp;</p>
        <p align="center"> <b>Location : </b> 
          <select name="select1">
            <?php 
					  
					include("connect.php");
					$query = "SELECT * FROM location";
					$result = mysql_query($query);
					echo "<option selected>[ Choose Location ]</option>";
					while($row = mysql_fetch_array($result))
						{
							$loc = $row[0];
							echo "<option>$loc</option>";
						}
			
					?>
          </select>
          <br>
          <br>
          <input type="submit" name="Submit" value="  Delete  ">
        </p>
      </form>
      <div align='center'> 
        <?php 
	include("connect.php");
	$location = $_POST['select1'];
	$idindb = mysql_query("SELECT * FROM location WHERE location = '$location' ");
  $isidindb = mysql_num_rows($idindb);
  //echo"$isidindb";
	if ($location == '' OR $location == '[ Choose Location ]'){
	echo "<font color='red'>Select the location to delete";
	} else
	if ($isidindb == 0){
		echo "[ <b>$location</b> ]<font color='red'> is NOT in the database";
	}else {
	echo "[ <b>$location</b> ] is deleted from the database.";
	mysql_query("DELETE FROM `location` where location = '$location' ");
	}
?>
      </div>
    </td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td height="34"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="72"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
</table>
