
<script language="JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && document.getElementById) x=document.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<body onLoad="MM_preloadImages('images/createNewDown.PNG','images/updatelocationDown.PNG','images/deletefileDown.PNG')" >
<table width="758" border="0" cellpadding="0" cellspacing="0"  >
  <tr> 
    <td width="2" height="19"></td>
    <td valign="top" colspan="8"><a href="system_files.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image2','','images/updatelocationDown.PNG',1)"><img name="Image2" border="0" src="images/updatelocationDown.PNG" width="150" height="19"></a></td>
    <td width="2"></td>
    <td width="150" valign="top"><a href="system_files_createNew.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image3','','images/createNewDown.PNG',1)"><img name="Image3" border="0" src="images/createNewUp.PNG" width="150" height="19" alt="Create New File"></a></td>
    <td width="2"></td>
    <td width="150" valign="top"><a href="system_files_delete.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image4','','images/deletefileDown.PNG',1)"><img name="Image4" border="0" src="images/deletefileUp.PNG" width="150" height="19"></a></td>
    <td width="166"></td>
    <td width="2"></td>
    <td width="6"></td>
    <td width="128" rowspan="4" valign="top"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0" background="images/BG.PNG">
        <tr> 
          <td width="132" height="91"></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="15"></td>
    <td width="16"></td>
    <td width="6"></td>
    <td width="23"></td>
    <td width="5" rowspan="2" valign="top">&nbsp;</td>
    <td width="22"></td>
    <td width="50"></td>
    <td width="11"></td>
    <td width="17"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="23"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td colspan="6" valign="top"> 
      <table width="100%" border="1" cellpadding="0" cellspacing="0">
        <tr> 
          <td width="483" height="21" valign="top" bgcolor="#6B6C9C"> 
            <div align="center"><b><font color="#FFFFFF">Check Current File Location</font></b></div>
          </td>
        </tr>
      </table>
    </td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="40"></td>
    <td valign="top">&nbsp;</td>
    <td></td>
    <td colspan="3" rowspan="6" valign="top"> 
      <div align="center"> 
        <p><b><font color="#CCCCCC">U</font></b></p>
        <p><font color="#CCCCCC"><b>P</b></font></p>
        <p><font color="#CCCCCC"><b>D</b></font></p>
        <p><font color="#CCCCCC"><b>A</b></font></p>
        <p><font color="#CCCCCC"><b>T</b></font></p>
        <p><font color="#CCCCCC"><b>E</b></font></p>
      </div>
    </td>
    <td></td>
    <td></td>
    <td colspan="6" rowspan="2" valign="top"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr> 
          <td width="487" height="120" valign="top"> 
            <form name="form3" method="post" action="system_files.php">
              <div align="center"><br>
                <b><font size="2">File Number or Name:</font></b><br>
                <input type="text" name="finoname">
                <br>
                <br>
                <input type="submit" name="Submit4" value="  Check  ">
              </div>
            </form>
          </td>
        </tr>
      </table>
    </td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="97"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="57"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td colspan="7" valign="top"> 
      <table width="100%" border="1" cellpadding="1" cellspacing="1">
        <tr> 
          <td width="481" height="2"></td>
        </tr>
        <tr> 
          <td height="23" valign="top" bgcolor="#AAABC6"> 
            <div align="center"><font color="#FFFFFF"><b>Current File Location</b></font></div>
          </td>
        </tr>
        <tr> 
          <td height="22" valign="top" bgcolor="#FFFFCC"> 
            <div align="center"><b>[</b> 
              <?PHP
			   include("connect.php");
	$fnn = $_POST['finoname'];
	$query = mysql_query("SELECT * FROM files WHERE fileno = '$fnn' ");
			$fno = mysql_result($query,0,0);     
 		  	$fname = mysql_result($query,0,1);         
		  	$floc = mysql_result($query,0,3);
				$fres = mysql_result($query,0,5);
	$query2 = mysql_query("SELECT * FROM files WHERE filename = '$fnn' ");
			$fno2 = mysql_result($query2,0,0);     
 		  	$fname2 = mysql_result($query2,0,1);         
		  	$floc2 = mysql_result($query2,0,3);
			$fres2 = mysql_result($query2,0,5);	
	$idindb = mysql_query("SELECT * FROM files WHERE filename = '$fnn' OR fileno = '$fnn' ");
	$isidindb = mysql_num_rows($idindb);
	
	if ($fnn == ''){
		echo "<font color='red'>Input the File Number or File Name.</font>";
		} else
		if ($isidindb == 0){
		echo "<font color='red'>The File Does Not Exist</font>";
		}else {			
		echo"<b><font color='red'> $fno$fno2 - $fname$fname2 - $floc$floc2 - $fres$fres2 </font></b>";}
			?>
              <b>] </b></div>
          </td>
        </tr>
        <tr> 
          <td height="2"></td>
        </tr>
      </table>
    </td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="7"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="24"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td colspan="6" valign="top"> 
      <table width="100%" border="1" cellpadding="0" cellspacing="0">
        <tr> 
          <td width="483" height="21" valign="top" bgcolor="#6B6C9C"> 
            <div align="center"><b><font color="#FFFFFF">Set New File Location</font></b></div>
          </td>
        </tr>
      </table>
    </td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="3"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td colspan="6" valign="top" rowspan="4"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <form name="form2" method="post" action="system_files_setact.php">
          <tr> 
            <td valign="top" height="48" colspan="2"> 
              <div align="center"><b><font size="2"> New Location:</font></b><br>
                <select name="select1">
                  <?php 
					  
					include("connect.php");
					$query = "SELECT * FROM location";
					$result = mysql_query($query);
					echo "<option selected> [ Choose Location ] </option>";
					while($row = mysql_fetch_array($result))
						{
							$loc = $row[0];
							echo "<option>$loc</option>";
						}
			
					?>
                </select>
                <font size="2"><b> </b></font> </div>
            </td>
            <td width="239" rowspan="2" valign="top"> 
              <div align="center"><font size="2"><b>Comments (Optional):</b></font> 
                <br>
                <textarea name="komen" rows="3"></textarea>
              </div>
            </td>
            <td width="2"></td>
          </tr>
          <tr> 
            <td height="51" colspan="2" valign="top"> 
              <div align="center"><font size="2"><b>Person Responsible:<br>
                </b></font><b><font size="2"> 
                <select name="select2">
                  <?php 
					$query = "SELECT * FROM person";
					$result = mysql_query($query);
					echo "<option selected>[ Choose Person ]</option>";
					while($row = mysql_fetch_array($result))
						{
							$file = $row[0];
							echo "<option>$file</option>";
						}
			
					?>
                </select>
                </font></b></div>
            </td>
            <td></td>
          </tr>
          <tr> 
            <td height="33" width="2"></td>
            <td colspan="3" valign="top"> 
              <div align="center"><b><font size="2"> </font></b> <b><font size="2"> 
                </font></b> 
                <input type="reset" name="Submit3" value="  Clear  ">
                <input type="submit" name="Submit2" value="Update">
                <b><font size="2"> 
                <?php
			
				echo "<table border='0' width='0' id='table1' height='0'>
    				<tr>
     			   	<td> <input type='hidden' name='fno' value='$fno$fno2'/></td>
        			</tr>
					<tr>
     			   	<td> <input type='hidden' name='fname' value='$fname$fname2'/></td>
        			</tr>
					</table>";
					$date = date("D",time()) . " | " . date("d",time()) . "-" . date ("m", time()) . "-" . date("y",time());
					$fno = $_POST['fno'];
					$fname = $_POST['fname'];
					$location = $_POST['select1'];
					$responsible = $_POST['select2'];
					$comment = $_POST['komen'];
					$initiator = $name ;
									
			  ?>
                </font></b></div>
            </td>
          </tr>
          <tr> 
            <td height="1"></td>
            <td width="244"></td>
            <td></td>
            <td></td>
          </tr>
        </form>
      </table>
    </td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="11"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td height="29"></td>
    <td colspan="6" valign="top"><b><font size="2"> </font></b></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td height="90"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
</table>
