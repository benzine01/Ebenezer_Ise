
<html>
<head>
<title>..::: File-Track System :::.. by ReVo</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && document.getElementById) x=document.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>
<body bgcolor="#FFFFFF" text="#000000" onLoad="MM_preloadImages('images/LOGIN_down.PNG','images/REGISTER_DOWN.PNG')">
<div align = 'center'>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p><br></p>
  <table width="747" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
    <tr> 
      <td height="58" valign="top" colspan="7" bgcolor="#FFFFFF"> 
        <div align="center"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="80" height="58">
            <param name=movie value="images/Movie2.swf">
            <param name=quality value=high>
            <embed src="images/Movie2.swf" quality=high pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="80" height="58">
            </embed> 
          </object><img src="images/ftrack.PNG" width="289" height="56" alt="File-Track System"></div>
      </td>
    </tr>
    <tr> 
      <td height="19" width="2"></td>
      <td width="225"></td>
      <td width="150"></td>
      <td width="4"></td>
      <td width="150"></td>
      <td width="2"></td>
      <td width="214"></td>
    </tr>
    <tr> 
      <td height="19"></td>
      <td valign="middle" align="center">&nbsp;</td>
      <td valign="top"> 
        <div align="center"><a href="?page=login" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('LOGIN','','images/LOGIN_down.PNG',1)"><img name="LOGIN" border="0" src="images/LOGIN_UP.PNG" width="150" height="19"></a></div>
      </td>
      <td></td>
      <td valign="top"> 
        <div align="center"><a href="?page=register" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('register','','images/REGISTER_DOWN.PNG',1)"><img name="register" border="0" src="images/REGISTER_up.PNG" width="150" height="19"></a></div>
      </td>
      <td></td>
      <td valign="top">&nbsp;</td>
    </tr>
    <tr> 
      <td height="37"></td>
      <td colspan="6" valign="top"> 
        <div align="center"> <br>
          <?php 
		 switch($_GET['page']) {
				case "login":
				echo " ";
				include ('login.php');
				break;
				case "register":
				echo "";
				include ('register.php');
				break;
				default:
				echo " ";
				include('login.php');
				break;
				}
		?>
        </div>
      </td>
    </tr>
  </table>
</div>
</body>
</html>
