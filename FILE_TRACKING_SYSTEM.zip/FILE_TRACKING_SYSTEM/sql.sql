CREATE DATABASE `fts` ;

CREATE TABLE `movement` (
  `filesNo` varchar(25) NOT NULL,
  `filesName` varchar(30) NOT NULL,
  `location` varchar(255) NOT NULL,
  `responsible` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  `initiated` varchar(255) NOT NULL,
  `datetime` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `user` (
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `name` varchar(255) NOT NULL,
  `post` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `person` (
  `responsible` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `location` (
  `location` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `files` (
  `fileno` varchar(25) NOT NULL,
  `filename` varchar(25) NOT NULL,
  `filedesc` varchar(255) NOT NULL,
  `currentloc` varchar(30) NOT NULL,
  `datecreate` varchar(25) NOT NULL,
  `currentresponsible` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



