add table (sql.sql) in database first and change connection setting in connect.php

Author : Ebenezer Ise
E-mail : bcodess15@gmail.com