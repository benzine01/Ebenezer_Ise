<?php

/***************************************************************************
 *                         Connect to MySQL Server                         *
 ***************************************************************************/

$dbh=mysql_connect ("localhost", "root", "dah7717") or die ('I cannot connect to the database because: ' . mysql_error());
mysql_select_db ("fts");

?>