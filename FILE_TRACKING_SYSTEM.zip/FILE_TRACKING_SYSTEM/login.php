
<form name="form1" method="post" action="system.php">
  <div align="center"><font size="2">Username</font><br>
    <input type="text" name="user"><br>
    <font size="2">Password</font><br>
    <input type="password" name="pass">
    <br><br>
    <input type="submit" name="Submit" value=" Login ">
  </div>
</form>
<div align="center"></div>
  