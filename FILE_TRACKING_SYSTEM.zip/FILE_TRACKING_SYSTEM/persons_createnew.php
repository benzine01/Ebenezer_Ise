
<script language="JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && document.getElementById) x=document.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<body onLoad="MM_preloadImages('images/filesatpersonDown.PNG','images/createnewpersonDown.PNG','images/deleteDown.PNG')" >
<table width="758" border="0" cellpadding="0" cellspacing="0"  >
  <tr> 
    <td width="2" height="19"></td>
    <td valign="top" colspan="3"><a href="system_persons.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image1','','images/filesatpersonDown.PNG',1)"><img name="Image1" border="0" src="images/filesatpersonUp.PNG" width="150" height="19" alt="Files at Person"></a></td>
    <td width="2"></td>
    <td width="150" valign="top"><a href="system_persons_createnew.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image2','','images/createnewpersonDown.PNG',1)"><img name="Image2" border="0" src="images/createnewpersonDown.PNG" width="150" height="19"></a></td>
    <td width="150" valign="top"><a href="system_persons_delete.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image3','','images/deleteDown.PNG',1)"><img name="Image3" border="0" src="images/deleteUp.PNG" width="150" height="19" alt="Delete Name"></a></td>
    <td width="160"></td>
    <td width="15"></td>
    <td width="129" rowspan="3" valign="top"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0" background="images/BGperson.PNG">
        <tr> 
          <td width="129" height="89"></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="50"></td>
    <td width="27"></td>
    <td width="41"></td>
    <td width="82"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="27"></td>
    <td></td>
    <td rowspan="2" valign="top">
      <div align="center">
        <p><b><font color="#CCCCCC">C</font></b></p>
        <p><font color="#CCCCCC"><b>R</b></font></p>
        <p><font color="#CCCCCC"><b>E</b></font></p>
        <p><font color="#CCCCCC"><b>A</b></font></p>
        <p><font color="#CCCCCC"><b>T</b></font></p>
        <p><font color="#CCCCCC"><b>E</b></font></p>
      </div>
    </td>
    <td></td>
    <td colspan="4" valign="top"> 
      <table width="100%" border="1" cellpadding="1" cellspacing="0">
        <tr> 
          <td width="462" height="20" valign="top" bgcolor="#6B6C9C"> 
            <div align="center"><font color="#FFFFFF"><b>Create New Person Responsible</b></font></div>
          </td>
        </tr>
      </table>
    </td>
    <td></td>
  </tr>
  <tr> 
    <td height="216"></td>
    <td></td>
    <td></td>
    <td colspan="4" valign="top"> 
      <form name="formcreatenew" method="post" action="system_persons_createnew.php">
        <p align="center">&nbsp;</p>
        <p align="center"> <b>Name : </b> 
          <input type="text" name="personresponsible">
          <br>
          <br>
          <input type="submit" name="Submit" value="  Create  ">
        </p>
      </form>
      <div align='center'> 
        <?php 
	include("connect.php");
	$person = $_POST['personresponsible'];
	$idindb = mysql_query("SELECT * FROM person where responsible = '$person' ");
  $isidindb = mysql_num_rows($idindb);
  //echo"$isidindb";
	if ($person == ''){
	echo "<font color='red'>Input the name to create";
	} else
	if ($isidindb == 1){
		echo "[ <b>$person</b> ]<font color='red'> is already in the database";
	}else {
	echo "[ <b>$person</b> ] is saved into the database.";
	mysql_query("INSERT INTO `person` ( `responsible` ) VALUES ('$person')");
	}
?>
      </div>
    </td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="69"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
</table>
