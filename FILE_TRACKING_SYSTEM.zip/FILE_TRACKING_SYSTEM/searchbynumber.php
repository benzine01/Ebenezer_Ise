 
<body >
<table width="758" border="0" cellpadding="0" cellspacing="0"  >
  <tr> 
    <td width="31" height="34"></td>
    <td width="22"></td>
    <td width="9" rowspan="2" valign="top">&nbsp;</td>
    <td width="4"></td>
    <td width="69"></td>
    <td width="482"></td>
    <td width="3"></td>
    <td width="6"></td>
    <td width="132" rowspan="4" valign="top"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0" background="images/BGsearch.PNG">
        <tr> 
          <td width="132" height="91"></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="23"></td>
    <td></td>
    <td></td>
    <td></td>
    <td valign="top" rowspan="2"> 
      <table width="100%" border="1" cellpadding="1" cellspacing="1">
        <tr> 
          <td width="474" height="23" valign="top" bgcolor="#6B6C9C"> 
            <div align="center"><b><font color="#FFFFFF">Search File</font></b></div>
          </td>
        </tr>
      </table>
    </td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="9"></td>
    <td colspan="3" rowspan="8" valign="top"> 
      <div align="center"> 
        <p><b><font color="#CCCCCC">S</font></b></p>
        <p><font color="#CCCCCC"><b>E</b></font></p>
        <p><font color="#CCCCCC"><b>A</b></font></p>
        <p><font color="#CCCCCC"><b>R</b></font></p>
        <p><font color="#CCCCCC"><b>C</b></font></p>
        <p><font color="#CCCCCC"><b>H</b></font></p>
      </div>
    </td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="25" valign="top">&nbsp;</td>
    <td></td>
    <td rowspan="2" valign="top"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr> 
          <td valign="top" width="482" height="137"> 
            <form name="formS1" method="post" action="system_search_bynumber.php">
              <div align="center"><br>
                <b><font size="2">File Number or Name:</font></b><br>
                <input type="text" name="fname">
                <br>
                <br>
                <input type="submit" name="SubmitS1" value=" Search ">
              </div>
            </form>
          </td>
        </tr>
      </table>
    </td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="112"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="18"></td>
    <td></td>
    <td valign="top"> 
      <div align="center"> 
        <?php 
	  	include("connect.php");
		$nameno = $_POST['fname'];
		
		// Get details of files from Database and put them in variables
    $query = mysql_query("SELECT * FROM files WHERE filename = '$nameno'");
          $fno = mysql_result($query,0,0);     
 		  $fname = mysql_result($query,0,1);         
		  $floc = mysql_result($query,0,3);
		  $fres = mysql_result($query,0,5);
    $query2 = mysql_query("SELECT * FROM files WHERE fileno = '$nameno'");
          $fno2 = mysql_result($query2,0,0);     
 		  $fname2 = mysql_result($query2,0,1);         
		  $floc2 = mysql_result($query2,0,3);
		  $fres2 = mysql_result($query2,0,5);
$idindb = mysql_query("SELECT * FROM files WHERE filename = '$nameno' OR fileno = '$nameno' ");
$isidindb = mysql_num_rows($idindb);
		
		
		if ($nameno == ''){
		echo "<font color='red'>Please make sure you input the file name or number.";
		} else
		if ($isidindb == 0){
		echo "<font color='red'>The File Does Not Exist";
		}else {echo "<b>[ $nameno ]</b>";}
		  ?>
      </div>
    </td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="18"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="60"></td>
    <td></td>
    <td colspan="2" valign="top"> 
      <table width="100%" border="1" cellpadding="1" cellspacing="1">
        <tr> 
          <td height="2" width="477"></td>
        </tr>
        <tr> 
          <td valign="top" bgcolor="#AAABC6" height="23"> 
            <div align="center"><font color="#FFFFFF"><b>Current File Location</b></font></div>
          </td>
        </tr>
        <tr> 
          <td height="2"></td>
        </tr>
        <tr> 
          <td height="22" valign="top" bgcolor="#FFFFCC"> 
            <div align="center"> 
              <?PHP
			  echo"<b>[ <font color='red'>"; 
			echo"<b>$fno2$fno - </b>";
			echo"<b>$fname2$fname - </b>";
			echo"<b>$floc2$floc - </b>";
			echo"<b>$fres2$fres</b>";
			echo"</font><b> ]";
			?>
            </div>
          </td>
        </tr>
        <tr> 
          <td height="3"></td>
        </tr>
      </table>
    </td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="16"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="76"></td>
    <td></td>
    <td rowspan="2" valign="top"> 
      <form name="form1" method="post" action="history.php">
        <div align="center"><b>File Number:</b> 
          <?php echo "$fno$fno2"; ?>
          <b>&nbsp;&nbsp;&nbsp;File Name:</b> 
          <?php echo "$fname$fname2"; ?>
          <br>
          <br>
          <input type="submit" name="Submit" value="History">
          <?php
			
				echo "<table border='0' width='0' id='table1' height='0'>
    				<tr>
     			   	<td> <input type='hidden' name='fno' value='$fno$fno2'/></td>
        			</tr>
					<tr>
     			   	<td> <input type='hidden' name='fname' value='$fname$fname2'/></td>
        			</tr>
					</table>";					
					$fno = $_POST['fno'];
					$fname = $_POST['fname'];														
			  ?>
        </div>
      </form>
    </td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="14"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
</table>
