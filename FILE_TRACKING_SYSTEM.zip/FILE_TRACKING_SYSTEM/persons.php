
<script language="JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && document.getElementById) x=document.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<body onLoad="MM_preloadImages('images/filesatpersonDown.PNG','images/createnewpersonDown.PNG','images/deleteDown.PNG')" >
<table width="758" border="0" cellpadding="0" cellspacing="0"  >
  <tr> 
    <td width="2" height="19"></td>
    <td valign="top" colspan="5"><a href="system_persons.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image1','','images/filesatpersonDown.PNG',1)"><img name="Image1" border="0" src="images/filesatpersonDown.PNG" width="150" height="19" alt="Files at Person"></a></td>
    <td width="2"></td>
    <td valign="top" colspan="2"><a href="system_persons_createnew.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image2','','images/createnewpersonDown.PNG',1)"><img name="Image2" border="0" src="images/createnewpersonUp.PNG" width="150" height="19"></a></td>
    <td width="2"></td>
    <td width="150" valign="top"><a href="system_persons_delete.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image3','','images/deleteDown.PNG',1)"><img name="Image3" border="0" src="images/deleteUp.PNG" width="150" height="19"></a></td>
    <td width="46"></td>
    <td width="22" rowspan="3" valign="top">&nbsp;</td>
    <td width="70"></td>
    <td width="20"></td>
    <td width="15"></td>
    <td valign="top" rowspan="4" width="129"> 
      <table width="100%" border="0" cellpadding="0" cellspacing="0" background="images/BGperson.PNG">
        <tr> 
          <td width="132" height="89"></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="40"></td>
    <td width="34"></td>
    <td width="32"></td>
    <td width="29"></td>
    <td width="20"></td>
    <td width="35"></td>
    <td></td>
    <td width="1"></td>
    <td width="149"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="10"></td>
    <td></td>
    <td rowspan="7" valign="top"> 
      <div align="center"> 
        <p><b><font color="#CCCCCC">F</font></b></p>
        <p><font color="#CCCCCC"><b>I</b></font></p>
        <p><font color="#CCCCCC"><b>L</b></font></p>
        <p><font color="#CCCCCC"><b>E</b></font></p>
        <p><font color="#CCCCCC"><b>@</b></font></p>
      </div>
    </td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="23"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td colspan="9" rowspan="2" valign="top"> 
      <table width="100%" border="1" cellpadding="1" cellspacing="0">
        <tr> 
          <td width="456" height="23" valign="middle" bgcolor="#6B6C9C"> 
            <div align="center"><font color="#FFFFFF"><b>Current File(s) at Specific 
              Person </b></font></div>
          </td>
        </tr>
      </table>
    </td>
    <td></td>
  </tr>
  <tr> 
    <td height="2"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="23"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="68"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td colspan="9" valign="top" rowspan="4"> 
      <form name="form1" method="post" action="system_persons.php">
        <div align="center"> 
          <p><br>
            <b>Name: </b> 
            <select name="select">
              <?php 
					  
					include("connect.php");
					$query = "SELECT * FROM person";
					$result = mysql_query($query);
					echo "<option selected>[Choose Person]</option>";
					while($row = mysql_fetch_array($result))
						{
							$person = $row[0];
							echo "<option>$person</option>";
						}
			
					?>
            </select>
            <br>
            <br>
            <input type="submit" name="Submit" value="  Check  ">
          </p>
        </div>
      </form>
      <div align='center'> 
        <?php 
	include("connect.php");
	$person = $_POST['select'];
	$resindb = mysql_query("SELECT * FROM files WHERE currentresponsible = '$person' ");
 	$isresindb = mysql_num_rows($resindb);
  	//echo"$isidindb";
	if ($person == '[Choose Person]' OR $person == ''){
	echo "<font color='red'>Select name to check File With the Person";
	}else if ($isresindb == '0'){
	echo "<font color='red'>There is no files given to</font> [ <b>$person</b> ]";
	}else {
	echo " File(s) with [ <b>$person</b> ]<br>";
	}
?>
      </div>
    </td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="63"></td>
    <td></td>
    <td rowspan="5" valign="top"> 
      <p align="center"><b><font color="#CCCCCC">P</font></b></p>
      <p align="center"><font color="#CCCCCC"><b>E</b></font></p>
      <p align="center"><font color="#CCCCCC"><b>R</b></font></p>
      <p align="center"><font color="#CCCCCC"><b>S</b></font></p>
      <p align="center"><font color="#CCCCCC"><b>O</b></font></p>
      <p align="center"><font color="#CCCCCC"><b>N</b></font></p>
    </td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="1"></td>
    <td></td>
    <td></td>
    <td valign="top" rowspan="2"> 
      <?php 
				include("connect.php");
				$query2 = "SELECT * FROM files WHERE currentresponsible = '$person'";
				$result2 = mysql_query($query2);
		?>
    </td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="18"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="44"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td colspan="6" valign="top"> 
      <table width="100%" border="1" cellpadding="0" cellspacing="0">
        <tr> 
          <td width="127" height="21" valign="middle" align="center" bgcolor="#AAABC6"><b>File 
            Number</b></td>
          <td width="176" valign="middle" align="center" bgcolor="#AAABC6"><b>File 
            Name</b></td>
          <td valign="top" width="128" bgcolor="#AAABC6"> 
            <div align="center"><b>File Description</b></div>
          </td>
        </tr>
        <?php
					while($row = mysql_fetch_array($result2)){
							$no = $row[0];
							$name = $row[1];
							$fdesc = $row[2];
							echo "<tr>";
							?>
        <tr> 
          <td valign="top" height="21" bgcolor="#FFFFCC"> 
            <?php echo "<center>$no";	
							?>
          <td valign="top" bgcolor="#FFFFCC"> 
            <?php echo " <center>$name";
							?>
          <td valign="top" bgcolor="#FFFFCC"> 
            <?php echo " <center>$fdesc";
							echo "</tr>";
							} ?>
      </table>
    </td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="83"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="18"></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
  </tr>
</table>
