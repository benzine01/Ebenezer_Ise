CORE DEVELOPERS
===============

* Jacob Rief
* René Fleschenberg

CONTRIBUTORS
============

* abelradac
* Adrien Lemaire
* airtonix
* Aleš Kocjančič
* Anders Petersson
* Andrés Reyes Monge
* Arturo Fernandez
* Audrey Roy
* Benjamin Wohlwend
* Ben Lopatin
* Bojan Mihelac
* Chris Morgan
* Dino Perovic
* fivethreeo
* German Larrain
* Hamza Khchine
* ikresoft
* Issac Kelly
* Jacek Mitręga
* Jonas Obrist
* Justin Steward
* Kristian Øllegaard
* maltitco
* Maltsev Artyom
* Martin Ogden
* Mike Yumatov
* Mikhail Kolesnik
* Nicolas Pascal
* Pavel Zhukov
* Pedro Gracia
* Per Rosengren
* Raúl Cumplido
* Roberth Solís
* Rolo Mawlabaux
* rubengrill
* Simon Luijk
* Sławomir Ehlert
* Stephen Muss
* Thomas Woolford

RETIRED CORE DEVELOPERS
=======================

* Chris Glass (chrisglass)
* Martin Brochhaus
