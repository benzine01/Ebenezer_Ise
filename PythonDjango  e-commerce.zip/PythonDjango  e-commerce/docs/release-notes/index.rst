.. _release-notes:

=============
Release Notes
=============

.. toctree::
    :maxdepth: 3
    :reversed:

    0.9
    0.10
    0.11
