.. _howto/secure-catalog:

================================
How to secure your catalog views
================================

Chances are that you don't want to allow your users to browse all views of
the shop as anonymous users.