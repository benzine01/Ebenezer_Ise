.. _howto/handling-discounts:

==================
Handling Discounts
==================

Generally, this is how you implement a "bulk rebate" module, for instance.
