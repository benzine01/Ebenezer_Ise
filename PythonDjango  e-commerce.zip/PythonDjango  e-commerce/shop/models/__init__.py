# -*- coding: utf-8 -*-
from shop.models.notification import Notification, NotificationAttachment
