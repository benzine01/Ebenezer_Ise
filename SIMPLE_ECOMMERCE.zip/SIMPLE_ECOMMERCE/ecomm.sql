-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Inang: localhost
-- Waktu pembuatan: 12 Mei 2013 pada 08.31
-- Versi Server: 5.5.24-log
-- Versi PHP: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Basis data: `ecomm`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `cat_id` varchar(4) NOT NULL,
  `kategori` varchar(30) NOT NULL,
  `keterangan` varchar(60) NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `category`
--

INSERT INTO `category` (`cat_id`, `kategori`, `keterangan`) VALUES
('CL01', 'cloth', 'pakaian dan sepatu sporty'),
('EL01', 'electronic', 'komputer dan handphone aksesoris');

-- --------------------------------------------------------

--
-- Struktur dari tabel `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `user_ip` varchar(20) NOT NULL,
  `Email` varchar(10) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `address` varchar(60) NOT NULL,
  `city` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `zip` varchar(8) NOT NULL,
  `order_total` float NOT NULL,
  `cc_num` varchar(20) NOT NULL,
  `cc_type` varchar(20) NOT NULL,
  `cc_exp` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `customer`
--

INSERT INTO `customer` (`user_ip`, `Email`, `firstname`, `lastname`, `address`, `city`, `state`, `zip`, `order_total`, `cc_num`, `cc_type`, `cc_exp`) VALUES
('127.0.0.1', 'aghanata@y', 'AGha', 'NAta', 'jl.bratasena 02/04', 'pamulang', 'banten', '12123', 700000, '2313-1233-3414-3444', 'master', '11-04-2015');

-- --------------------------------------------------------

--
-- Struktur dari tabel `orderlist`
--

CREATE TABLE IF NOT EXISTS `orderlist` (
  `user_ip` varchar(20) NOT NULL,
  `item_id` varchar(20) NOT NULL,
  `jumlah` int(11) NOT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `orderlist`
--

INSERT INTO `orderlist` (`user_ip`, `item_id`, `jumlah`) VALUES
('127.0.0.1', 'C002', 40),
('127.0.0.1', 'E002', 20),
('127.0.0.1', 'E003', 20);

-- --------------------------------------------------------

--
-- Struktur dari tabel `stock`
--

CREATE TABLE IF NOT EXISTS `stock` (
  `item_id` varchar(7) NOT NULL,
  `item_nm` varchar(30) NOT NULL,
  `stock` mediumint(9) NOT NULL,
  `price` float(10,2) NOT NULL,
  `file_nm` char(60) NOT NULL,
  `notes` varchar(100) NOT NULL,
  `cat_id` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `stock`
--

INSERT INTO `stock` (`item_id`, `item_nm`, `stock`, `price`, `file_nm`, `notes`, `cat_id`) VALUES
('C001', 'Sepatu Convers', 5, 200000.00, '', 'Persediaan Terbatas!', 'CL01'),
('E002', 'mp3 player', 20, 200000.00, '', 'Persediaan Terbatas!', 'EL01'),
('E003', 'Flash Drive', 20, 180000.00, '', 'Persediaan Terbatas!', 'EL01'),
('C002', 'Linuxer T-Shirt', 20, 30000.00, '', 'Persediaan Terbatas!', 'CL01');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
