<html>
<head>
<title>Shopping Basket</title>
<STYLE>
tr {
BORDER-RIGHT:  #aaaaaa 1px solid;
BORDER-TOP:    #eeeeee 1px solid;
BORDER-LEFT:   #eeeeee 1px solid;
BORDER-BOTTOM: #aaaaaa 1px solid;
background-color: #DDDDDD}
.notfirst:hover {
    background-color: #8888FF;
}
td {
BORDER-RIGHT:  #aaaaaa 1px solid;
BORDER-TOP:    #eeeeee 1px solid;
BORDER-LEFT:   #eeeeee 1px solid;
BORDER-BOTTOM: #aaaaaa 1px solid;
}
.table1 {
BORDER-RIGHT:  #cccccc 0px;
BORDER-TOP:    #cccccc 0px;
BORDER-LEFT:   #cccccc 0px;
BORDER-BOTTOM: #cccccc 0px;
BACKGROUND-COLOR: #D4D0C8;
}
.td1 {
BORDER-RIGHT:  #cccccc 0px;
BORDER-TOP:    #cccccc 0px;
BORDER-LEFT:   #cccccc 0px;
BORDER-BOTTOM: #cccccc 0px;
font: 7pt Verdana;
}
.tr1 {
BORDER-RIGHT:  #cccccc 0px;
BORDER-TOP:    #cccccc 0px;
BORDER-LEFT:   #cccccc 0px;
BORDER-BOTTOM: #cccccc 0px;
}
table {
BORDER-RIGHT:  #eeeeee 1px outset;
BORDER-TOP:    #eeeeee 1px outset;
BORDER-LEFT:   #eeeeee 1px outset;
BORDER-BOTTOM: #eeeeee 1px outset;
BACKGROUND-COLOR: #D4D0C8;
}
input {
BORDER-RIGHT:  #ffffff 1px solid;
BORDER-TOP:    #999999 1px solid;
BORDER-LEFT:   #999999 1px solid;
BORDER-BOTTOM: #ffffff 1px solid;
BACKGROUND-COLOR: #e4e0d8;
font: 8pt Verdana;
}
select {
BORDER-RIGHT:  #ffffff 1px solid;
BORDER-TOP:    #999999 1px solid;
BORDER-LEFT:   #999999 1px solid;
BORDER-BOTTOM: #ffffff 1px solid;
BACKGROUND-COLOR: #e4e0d8;
font: 8pt Verdana;
}
submit {
BORDER-RIGHT:  buttonhighlight 2px outset;
BORDER-TOP:    buttonhighlight 2px outset;
BORDER-LEFT:   buttonhighlight 2px outset;
BORDER-BOTTOM: buttonhighlight 2px outset;
BACKGROUND-COLOR: #e4e0d8;
width: 30%;
}
textarea {
BORDER-RIGHT:  #ffffff 1px solid;
BORDER-TOP:    #999999 1px solid;
BORDER-LEFT:   #999999 1px solid;
BORDER-BOTTOM: #ffffff 1px solid;
BACKGROUND-COLOR: #e4e0d8;
font: Fixedsys bold;
}
BODY {
  margin-top: 10px;
  margin-right: 1px;
  margin-bottom: 1px;
  margin-left: 1px;	
  padding: 0;
  margin: 0;
  background: #f8f7e5 url(hello.png) no-repeat center top;
  width: 100%;
  display: table;
  opacity: .5;
}
A:link {COLOR:blue; TEXT-DECORATION: underline overline}
A:visited { COLOR:blue; TEXT-DECORATION: underline overline}
A:active {COLOR:blue; TEXT-DECORATION: none}
A:hover {color:blue;TEXT-DECORATION: none}
#divMenu {font-family:arial,helvetica; font-size:12pt; font-weight:bold}
#divMenu a{text-decoration:none;}
#divMenu a:hover{color:red;}
</STYLE>

<script type="text/javascript">
<!--
function hapus(itemid){
	var r=confirm("Anda yakin akan menghapus "+itemid)
	if (r==true)
	{
		window.location="/e-comm/basket.php?action=deleting&id="+itemid;
	}	
}

function update(itemid,jumlah){	
	var r=confirm("Anda yakin akan meng-update "+itemid)
	if (r==true)
	{
		var myTextField = document.getElementById(jumlah).value;
		window.location="/e-comm/basket.php?action=updating&id="+itemid+"&jum="+myTextField;
	}
}

function notEmpty(jumlah){
	var myTextField = document.getElementById(jumlah);
	alert("You entered: " + myTextField.value)	
}

function CekOut(){
	window.location="/e-comm/cekout.php";
}
//-->
</script>
</head>

<body>
<hr><center>Shopping Basket</center><hr><br>
<form name=transaction action="<?php echo $_SERVER['PHP_SELF'];?>" method=GET>
<table border=1 align=center>
<tr>
	<td align=center><b>Item</b></td>
	<td align=center><b>Nama Item</b></td>
	<td align=center><b>Jumlah</b></td>
	<td align=center><b>Harga</b></td>
	<td align=center><b>Subtotal</b></td>
	<td align=center><b>Command(s)</b></td>
</tr>
<tr>
<?php
	$strSQL="SELECT * FROM orderlist";
	include "opendb.php";
	$i=0;
	while ($row=mysql_fetch_row($qry)) {		
		//session_start();
		$_SESSION['itemid'] = $row[1];
		$_SESSION['amt'] = $row[2];
		echo "<tr class =\"notfirst\"><td align=center>".$_SESSION['itemid']."</td>\n";
		echo "<td align=center>".search_itemname($_SESSION['itemid'])."</td>\n";
		echo "<td align=center><input size=2 type=\"text\" id=\"iAmt".$i."\" value=\"".$_SESSION['amt']."\"></td>\n";
		echo "<td align=center>".search_itemprice($_SESSION['itemid'])."</td>\n";
		$subtotal = search_itemprice($_SESSION['itemid']) * $_SESSION['amt'];
		echo "<td align=center>".$subtotal."</td>\n";
		$grandtotal = $subtotal;
		echo "<td align=center><input type=button value='UPDATE' onClick=update('".$_SESSION['itemid']."','iAmt".$i."')> | <input type=button value='HAPUS' onClick=hapus(\"".$_SESSION['itemid']."\")></td></tr>\n";	
		$i++;
	}
	echo "<tr><td align=center colspan=6><b>Total ".$i." Item US$ ".$grandtotal."</b></td></tr>\n";	
	echo "</table></form>\n";

	function search_itemname($itemid)
	{		
		$strSQL="SELECT * FROM `stock` WHERE `item_id` = '".$itemid."'";
		include "opendb.php";
		//session_start();
		while ($row=mysql_fetch_row($qry)) {
			$_SESSION['itemnm'] = $row[1];			
		}
		return $_SESSION['itemnm'];
	}

	function search_itemprice($itemid)
	{		
		$strSQL="SELECT * FROM `stock` WHERE `item_id` = '".$itemid."'";
		include "opendb.php";
		//session_start();
		while ($row=mysql_fetch_row($qry)) {
			$_SESSION['price']= $row[3];
		}
		return $_SESSION['price'];
	}

	// menjalankan session
	session_start();
	
	if(isset($_GET['action']) && isset($_GET['id'])){
		if ($_GET['action']=="updating"){
			$strSQL = "UPDATE `orderlist` SET `jumlah`=".$_GET['jum']." WHERE `item_id` = '".$_GET['id']."'";
			include "opendb.php";
			echo "<script>alert('updated')</script>";
			//echo "<script>alert('Reload Page')</script>";
		}
		if ($_GET['action']=="deleting"){
			$strSQL = "DELETE FROM `orderlist` WHERE `item_id` = '".$_GET['id']."'";
			include "opendb.php";
			echo "<script>alert('deleted')</script>";
		}		
	}
	
	echo "<BR>\n";
	echo "<center><input type=submit name=submit onClick=CekOut() value='Cek Out'></center>\n";
	// End of html ----
	echo "</body></html>";
?>