<html>
<head>
<title>Check Out</title>
<STYLE>
tr {
BORDER-RIGHT:  #aaaaaa 1px solid;
BORDER-TOP:    #eeeeee 1px solid;
BORDER-LEFT:   #eeeeee 1px solid;
BORDER-BOTTOM: #aaaaaa 1px solid;
background-color: #DDDDDD}
.notfirst:hover {
    background-color: #8888FF;
}
td {
BORDER-RIGHT:  #aaaaaa 1px solid;
BORDER-TOP:    #eeeeee 1px solid;
BORDER-LEFT:   #eeeeee 1px solid;
BORDER-BOTTOM: #aaaaaa 1px solid;
}
.table1 {
BORDER-RIGHT:  #cccccc 0px;
BORDER-TOP:    #cccccc 0px;
BORDER-LEFT:   #cccccc 0px;
BORDER-BOTTOM: #cccccc 0px;
BACKGROUND-COLOR: #D4D0C8;
}
.td1 {
BORDER-RIGHT:  #cccccc 0px;
BORDER-TOP:    #cccccc 0px;
BORDER-LEFT:   #cccccc 0px;
BORDER-BOTTOM: #cccccc 0px;
font: 7pt Verdana;
}
.tr1 {
BORDER-RIGHT:  #cccccc 0px;
BORDER-TOP:    #cccccc 0px;
BORDER-LEFT:   #cccccc 0px;
BORDER-BOTTOM: #cccccc 0px;
}
table {
BORDER-RIGHT:  #eeeeee 1px outset;
BORDER-TOP:    #eeeeee 1px outset;
BORDER-LEFT:   #eeeeee 1px outset;
BORDER-BOTTOM: #eeeeee 1px outset;
BACKGROUND-COLOR: #D4D0C8;
}
input {
BORDER-RIGHT:  #ffffff 1px solid;
BORDER-TOP:    #999999 1px solid;
BORDER-LEFT:   #999999 1px solid;
BORDER-BOTTOM: #ffffff 1px solid;
BACKGROUND-COLOR: #e4e0d8;
font: 8pt Verdana;
}
select {
BORDER-RIGHT:  #ffffff 1px solid;
BORDER-TOP:    #999999 1px solid;
BORDER-LEFT:   #999999 1px solid;
BORDER-BOTTOM: #ffffff 1px solid;
BACKGROUND-COLOR: #e4e0d8;
font: 8pt Verdana;
}
submit {
BORDER-RIGHT:  buttonhighlight 2px outset;
BORDER-TOP:    buttonhighlight 2px outset;
BORDER-LEFT:   buttonhighlight 2px outset;
BORDER-BOTTOM: buttonhighlight 2px outset;
BACKGROUND-COLOR: #e4e0d8;
width: 30%;
}
textarea {
BORDER-RIGHT:  #ffffff 1px solid;
BORDER-TOP:    #999999 1px solid;
BORDER-LEFT:   #999999 1px solid;
BORDER-BOTTOM: #ffffff 1px solid;
BACKGROUND-COLOR: #e4e0d8;
font: Fixedsys bold;
}
BODY {
  margin-top: 10px;
  margin-right: 1px;
  margin-bottom: 1px;
  margin-left: 1px;	
  padding: 0;
  margin: 0;
  background: #f8f7e5 url(hello.png) no-repeat center top;
  width: 100%;
  display: table;
  opacity: .5;
}
A:link {COLOR:blue; TEXT-DECORATION: underline overline}
A:visited { COLOR:blue; TEXT-DECORATION: underline overline}
A:active {COLOR:blue; TEXT-DECORATION: none}
A:hover {color:blue;TEXT-DECORATION: none}
#divMenu {font-family:arial,helvetica; font-size:12pt; font-weight:bold}
#divMenu a{text-decoration:none;}
#divMenu a:hover{color:red;}
</STYLE>
</head>

<body>
<hr><center>Check Out</center><hr><br>
<center>Formulir Data Konsumen</center>
<form name="frmkons" method="post" action="thanks.php">
<table align=center>
<tr class=notfirst><td align=right>Nama Depan :</td><td><input text=text name=fname size=40></td></tr>
<tr class=notfirst><td align=right>Nama Keluarga :</td><td><input text=text name=lname size=40></td></tr>
<tr class=notfirst><td align=right>Email :</td><td><input text=text name=email size=40></td></tr>
<tr class=notfirst><td align=right>Alamat :</td><td><input text=text name=alamat size=40></td></tr>
<tr class=notfirst><td align=right>Kota :</td><td><input text=text name=kota size=40></td></tr>
<tr class=notfirst><td align=right>Propinsi :</td><td><input text=text name=prop size=40></td></tr>
<tr class=notfirst><td align=right>Kode Pos :</td><td><input text=text name=kdpos size=40></td></tr>
<tr class=notfirst><td align=right>Jumlah Pesan (US$) :</td><td><input text=text name=hrgtot size=40></td></tr>
<tr class=notfirst><td align=right>Credit Card Type :</td><td>	<select name="cctype"><option value="master">Master Card</option><option value="master">Visa</option></select></td></tr>
<tr class=notfirst><td align=right>Credit Card Number :</td><td><input text=text name=ccnum size=40></td></tr>
<tr class=notfirst><td align=right>Credit Card Expire Date :</td><td><input text=text name=ccexp size=40></td></tr>
</table>
<br>
<center><input type="submit" value="Proses">&nbsp;|&nbsp;<input type="reset" value="Hapus"></center>
</form>
</body>
</html>
