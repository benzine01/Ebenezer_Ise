<html>
<head>
<title> WEB E-COMM </title>
<style type="text/css">
<!--
A.ssmItems:link		{color:black;text-decoration:none;}
A.ssmItems:hover	{color:black;text-decoration:none;}
A.ssmItems:active	{color:black;text-decoration:none;}
A.ssmItems:visited	{color:black;text-decoration:none;}
//-->
</style>

<SCRIPT SRC="ssm.js" language="JavaScript1.2">

//Dynamic-FX slide in menu v6.5 (By maXimus, http://maximus.ravecore.com/)
//Updated July 8th, 03' for doctype bug
//For full source, and 100's more DHTML scripts, visit http://www.dynamicdrive.com

</SCRIPT>

<SCRIPT SRC="ssmItems.js" language="JavaScript1.2"></SCRIPT>
<style>
#divMenu {font-family:arial,helvetica; font-size:12pt; font-weight:bold}
#divMenu a{text-decoration:none;}
#divMenu a:hover{color:red;}
</style>

<STYLE>
tr {
BORDER-RIGHT:  #aaaaaa 1px solid;
BORDER-TOP:    #eeeeee 1px solid;
BORDER-LEFT:   #eeeeee 1px solid;
BORDER-BOTTOM: #aaaaaa 1px solid;
background-color: #DDDDDD}
.notfirst:hover {
    background-color: #8888FF;
}
td {
BORDER-RIGHT:  #aaaaaa 1px solid;
BORDER-TOP:    #eeeeee 1px solid;
BORDER-LEFT:   #eeeeee 1px solid;
BORDER-BOTTOM: #aaaaaa 1px solid;
}
.table1 {
BORDER-RIGHT:  #cccccc 0px;
BORDER-TOP:    #cccccc 0px;
BORDER-LEFT:   #cccccc 0px;
BORDER-BOTTOM: #cccccc 0px;
BACKGROUND-COLOR: #D4D0C8;
}
.td1 {
BORDER-RIGHT:  #cccccc 0px;
BORDER-TOP:    #cccccc 0px;
BORDER-LEFT:   #cccccc 0px;
BORDER-BOTTOM: #cccccc 0px;
font: 7pt Verdana;
}
.tr1 {
BORDER-RIGHT:  #cccccc 0px;
BORDER-TOP:    #cccccc 0px;
BORDER-LEFT:   #cccccc 0px;
BORDER-BOTTOM: #cccccc 0px;
}
table {
BORDER-RIGHT:  #eeeeee 1px outset;
BORDER-TOP:    #eeeeee 1px outset;
BORDER-LEFT:   #eeeeee 1px outset;
BORDER-BOTTOM: #eeeeee 1px outset;
BACKGROUND-COLOR: #D4D0C8;
}
input {
BORDER-RIGHT:  #ffffff 1px solid;
BORDER-TOP:    #999999 1px solid;
BORDER-LEFT:   #999999 1px solid;
BORDER-BOTTOM: #ffffff 1px solid;
BACKGROUND-COLOR: #e4e0d8;
font: 8pt Verdana;
}
select {
BORDER-RIGHT:  #ffffff 1px solid;
BORDER-TOP:    #999999 1px solid;
BORDER-LEFT:   #999999 1px solid;
BORDER-BOTTOM: #ffffff 1px solid;
BACKGROUND-COLOR: #e4e0d8;
font: 8pt Verdana;
}
submit {
BORDER-RIGHT:  buttonhighlight 2px outset;
BORDER-TOP:    buttonhighlight 2px outset;
BORDER-LEFT:   buttonhighlight 2px outset;
BORDER-BOTTOM: buttonhighlight 2px outset;
BACKGROUND-COLOR: #e4e0d8;
width: 30%;
}
textarea {
BORDER-RIGHT:  #ffffff 1px solid;
BORDER-TOP:    #999999 1px solid;
BORDER-LEFT:   #999999 1px solid;
BORDER-BOTTOM: #ffffff 1px solid;
BACKGROUND-COLOR: #e4e0d8;
font: Fixedsys bold;
}
BODY {
  margin-top: 10px;
  margin-right: 1px;
  margin-bottom: 1px;
  margin-left: 1px;	
  padding: 0;
  margin: 0;
  background: #f8f7e5 url(hello.png) no-repeat center top;
  width: 100%;
  display: table;
  opacity: .5;
}
A:link {COLOR:blue; TEXT-DECORATION: none}
A:visited { COLOR:blue; TEXT-DECORATION: none}
A:active {COLOR:blue; TEXT-DECORATION: none}
A:hover {color:blue;TEXT-DECORATION: none}
#divMenu {font-family:arial,helvetica; font-size:12pt; font-weight:bold}
#divMenu a{text-decoration:none;}
#divMenu a:hover{color:red;}
</STYLE>
<script type="text/javascript">
<!--
// validasi form
function pesan()
{
	var cek;
	cek = document.forms['stock'].elements['amt'].value;
	if (cek == 0)
	{
		window.alert("Anda tidak dapat memasukkan angka nol!")
	} 
	else
	{
		if (cek < 0)
		{
			window.alert("Anda tidak dapat memasukkan angka negatif!")
		}
		else
		{
			if (inNaN(cek))
			{
				window.alert("Anda tidak dapat memasukkan string atau karakter!")
			}
			else
			{
				document.forms['stock'].submit()
			}
		}
	}
}
-->
</script>
</head>
<body bgcolor=#FFFFFF>
<center>
<div>&nbsp;</div>
Selamat Datang<br>
<?php
echo "<hr>TOKO ONLINE<hr><br>\n";
echo "<b>Kami menyediakan barang-barang bermutu yang siap memenuhi kebutuhan anda.</b><br>\n";
echo "silahkan pilih kategori barang yang anda cari.<br><br>\n";
echo "<table border=0>\n";
$strSQL="SELECT * FROM category";
include "opendb.php";
while ($row=mysql_fetch_array($qry))
{
	echo "<tr class =\"notfirst\"\n><td align=center><a href=".$_SERVER['PHP_SELF']."?kat=".$row[0].">".$row[1]."</a></td></tr>\n";
}
echo "</table>";
echo "<br>";
if(isset($_GET['kat'])) {
	/* the items detail phps is start from here */
	$strSQL="SELECT * FROM stock where cat_id = '".$_GET['kat']."'";
	include "opendb.php";	
	while ($row=mysql_fetch_row($qry)){
		echo "<form name=stock action=\"".$_SERVER['PHP_SELF']."\" method=GET>\n";
		echo "<table border=0>\n";
		echo "<tr><td align=center colspan=2>DETAIL ITEM</td></tr>\n";
		echo "<tr><td width=280 align=center border=0><img src=\"$row[5]\"/></td>\n";
		echo "<td width=300>\n";
		echo "<table align=center width=300>\n";
		echo "<tr><td colspan=2 align=center><b>Detail Item</b></td></tr>\n";		
		echo "<tr class =\"notfirst\"\n><td>Item ID</td><td>".$row[0]."</td></tr>\n";
		echo "<input type=\"hidden\" name=\"itemid\" value=\"".$row[0]."\">";
		echo "<tr class =\"notfirst\"\n><td>Item Nm</td><td>".$row[1]."</td></tr>\n";
		echo "<input type=\"hidden\" name=\"itemnm\" value=\"".$row[1]."\">";
		echo "<tr class =\"notfirst\"\n><td>Stock</td><td>".$row[2]."</td></tr>\n";
		echo "<tr class =\"notfirst\"\n><td>Price</td><td>".$row[3]."/item</td></tr>\n";
		echo "<input type=\"hidden\" name=\"price\" value=\"".$row[3]."\">";	
		echo "<tr class =\"notfirst\"\n><td>Total Price</td><td>".(intval($row[2]))*(intval($row[3]))."</td></tr>\n";
		echo "<tr class =\"notfirst\"\n><td>Notes</td><td>".$row[5]."</td></tr>\n";
		echo "<tr><td>Ammount&nbsp;</td><td>&nbsp;<input text=text name=amt size=6>&nbsp;<input type=submit name=btnSubmit value=Beli onClick=pesan()></td></tr>\n";
		echo "</table>\n";
		echo "</td></tr>\n";
		echo "</table>\n";
		echo "</form>\n";
	}
}

// menjalankan session
session_start();

if (isset($_GET['amt'])){
	$_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
	$_SESSION['itemid'] = $_GET['itemid'];
	//$_SESSION['itemnm'] = $_GET['itemnm'];
	//$_SESSION['price'] = $_GET['price'];
	$_SESSION['amt'] = $_GET['amt'];
	//$_SESSION['subtotal'] = ($_SESSION['price'] * $_SESSION['amt']);
    
	$strSQL = "SELECT `user_ip`, `item_id`, `jumlah` FROM `orderlist` WHERE `user_ip` = '".$_SESSION['ip']."' AND `item_id` = '".$_SESSION['itemid']."'";
	include "opendb.php";
	$ketemu = mysql_fetch_row($qry);
	if (count($ketemu)==1) {;
		// menyimpan data ke database
		$strSQL = "INSERT INTO `orderlist`(`user_ip`, `item_id`, `jumlah`) VALUES ('".$_SESSION['ip']."', '".$_SESSION['itemid']."', ".$_SESSION['amt'].")";
		include "opendb.php";
		echo "<script>alert('saved')</script>";
	} else {		
		$strSQL = "UPDATE `orderlist` SET `user_ip`='".$_SESSION['ip']."',`item_id`='".$_SESSION['itemid']."',`jumlah`=".$_SESSION['amt'];
		include "opendb.php";
		echo "<script>alert('updated')</script>";
	}
}

/* end of phps */
echo "<p>";
echo "<div width=800px align=center><font face=Verdana size=-2><b>Copyright &copy 2013 By Nathan</b></font></div>\n";
echo "<p>";
echo "</body></html>";
?>
