<?php  $this->load->view('header');  ?>

<p><?php echo $message; ?></p>

<p><?php echo $no; ?>&nbsp;&nbsp;|&nbsp;&nbsp;<?php echo $yes; ?>

<?php $this->load->view('footer'); 
/* End of file delete.php */
/* Location: ./system/scaffolding/views/delete.php */
