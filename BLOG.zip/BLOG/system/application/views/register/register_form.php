<?php
$this->load->view('header');
$this->load->view('home/right_side');
$this->load->view('register/form');
$this->load->view('footer');
?>