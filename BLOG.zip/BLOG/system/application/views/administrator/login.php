<?php $this->load->view('administrator/header'); ?>
<?php $this->load->view('footer'); ?>