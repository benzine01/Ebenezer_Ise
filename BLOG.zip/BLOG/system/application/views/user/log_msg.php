<div id="left">
<?php $this->load->view('userpanel'); ?>
<p>You have successfully login..</p>
</div>