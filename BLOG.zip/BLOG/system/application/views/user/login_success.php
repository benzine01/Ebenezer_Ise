<?php
$this->load->view('header');
$this->load->view('user/log_msg');
$this->load->view('user/right_userlog');
$this->load->view('footer');
?>