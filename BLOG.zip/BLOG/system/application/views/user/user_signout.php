<?php
$this->load->view('header');
?>
<div id="left">
    <h2>You have successfully SIGNED OUT...</h2>
    </br>
    <?php $this->load->view('home/top_post'); ?>
     </div>
<?php
$this->load->view('home/right_side');
$this->load->view('footer');
?>