    <h2>User Panel</h2>
    <ul>
        <li>Post and Article</li>
        <li>Profile</li>
        <li><?php echo anchor('forum/comment_manager','Comment Manager');?></li>
        <li><?php echo anchor('forum/forum_manager','Forum Manager');?></li>
        <li>Inbox</li>
        <li>Send Message</li>
   </ul>