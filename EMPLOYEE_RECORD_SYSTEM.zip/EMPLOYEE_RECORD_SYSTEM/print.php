<html>
<head>
<title></title>
<script LANGUAGE="JavaScript">
function displayHTML(printContent) {
var inf = printContent;
win = window.open("print.htm", 'popup', 'toolbar = no, status = no');
win.document.write(inf);
}
</script>
</head>
<body>
<div id="printarea">Print this stuff.</div>
<a href="javascript:void(0);" onclick="displayHTML(printarea.innerHTML)">Print Preview</a>
</body>
</html>