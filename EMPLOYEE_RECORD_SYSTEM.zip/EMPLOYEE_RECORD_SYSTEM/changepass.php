<?php
session_start(); 

include 'db.php';  

$username = $_POST['username']; 
$password = $_POST['password']; 
$newpassword = $_POST['newpassword']; 
$confirmnewpassword = $_POST['confirmnewpassword']; 

$result = mysql_query("SELECT password FROM users WHERE username='$username'"); 
if(!$result)  
{  
echo "The username you entered does not exist";  
}  
else  
if($password!= mysql_result($result, 0))  
{  
echo "You entered an incorrect password";  
}  
if($newpassword=$confirmnewpassword)  
    $sql=mysql_query("UPDATE users SET password='$newpassword' where username='$username'");  
    if($sql)  
    {  
    echo "Congratulations You have successfully changed your password";  
    } 
else 
{  
echo "The new password and confirm new password fields must be the same";  
}   
?>