<?php 
header( 'Location: index.php' ) ;
	$con = odbc_connect('bj','','') or die ('I cannot connect to the database  because: ' . odbc_error()); 
?>
<?php

$ID = $_GET['ID'];



odbc_exec($con,"DELETE FROM data WHERE ID = $ID");
odbc_close($con);
?>