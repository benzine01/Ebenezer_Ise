<?php 
				
				session_start();
				
	//Check if loged in
	if ($_SESSION['Login']=="") {
		header("Location: index.php");			   
	}
	
	//Destroy Session after 30min
	if (!isset($_SESSION['CREATED'])) {
		$_SESSION['CREATED'] = time();
	} else if (time() - $_SESSION['CREATED'] > 900) {
		session_destroy();
		header("Location: index.php?msg=expire");
	}
				
				
				$ID = $_SESSION['ID'];
				
				 $con = odbc_connect('bj','','') or die ('I cannot connect to the database  because: ' . odbc_error()); 
				 
				 $get = odbc_exec($con,"SELECT * FROM data WHERE LastName=$ID");
				 
				 while ($row = odbc_fetch_array($get))
				 
				 {
				 $admin = $row ['Admin'];
				 $username = $row ['username'];
				 }
				 
				 if (@$username =='admin')
				 echo   '<a href="newuser.php" >Admin CP</a>';
				 
				?>