<?php
	
	session_start();
	//Check if loged in
	if ($_SESSION['Login']=="Ok") {
		header("Location: _index.php");			   
	}
	
	//Destroy Session after 30min
	if (!isset($_SESSION['CREATED'])) {
		$_SESSION['CREATED'] = time();
	} else if (time() - $_SESSION['CREATED'] > 900) {
		session_destroy();
		header("Location: index.php?msg=expire");
	}
	
	
	
	$Username = $_POST["username"];
	$Password = $_POST["password"];
	 $con = odbc_connect('bj','','') or die ('I cannot connect to the database  because: ' . odbc_error());
	//GET USER
	$query = "SELECT username, password, LastName, FirstName, MiddleName, ID FROM user WHERE username = '$Username' AND password = '$Password'"; 
	//*******************
	
	$rs = odbc_exec($con,$query);
	
	if(odbc_fetch_row($rs)>0) {
		$rec = odbc_fetch_array($rs);
		
		//Set Sessions
		$_SESSION['name'] =$rec['LastName'];
		$_SESSION['Fullname']=$rec["LastName"]." ".$rec["FirstName"]." ".$rec["MiddleName"];
		$_SESSION['User']=$rec['username'];
		$_SESSION['ID']=$rec['ID'];
		$_SESSION['Login']="Ok";
		$valLocation="_index.php";
		
		//************
	
	} else {
		$_SESSION['Fullname']="";
		$_SESSION['Login']="";
		$valLocation="index.php?msg=1";
	}
	
	
	header("Location: ".$valLocation);
?>
