
<?php


$con = odbc_connect('bj','','') or die ('I cannot connect to the database  because: ' . odbc_error()); 
echo "Upload your image";

if ($_POST['submit']);

{

//file attribute
$name = $_FILES ["myfile"]["name"];
$tmp_name = $_FILES ["myfile"]["tmp_name"];

if  ($name)
{


$location = "Image/$name";
move_uploaded_file($tmp_name,$location);



echo "...";

}
else 
die ("Please select a file");


}

?>

<form action = "" method ="POST" enctype = "multipart/form-data">
<input type = "file" name = "myfile"  > 
<input  type = "submit" name ="submit" value ="upload">

</form> 
