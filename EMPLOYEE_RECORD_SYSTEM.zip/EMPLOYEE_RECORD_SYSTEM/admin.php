<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by Free CSS Templates
http://www.freecsstemplates.org
Released for free under a Creative Commons Attribution 2.5 License

Name       : Compressed 
Description: A three-column, fixed-width template fit for 1024x768 screen resolutions.
Version    : 1.0
Released   : 20080524

-->

<?php 
				
				session_start();
				
	//Check if loged in
	if ($_SESSION['Login']=="") {
		header("Location: index.php");			   
	}
	
	//Destroy Session after 30min
	if (!isset($_SESSION['CREATED'])) {
		$_SESSION['CREATED'] = time();
	} else if (time() - $_SESSION['CREATED'] > 900) {
		session_destroy();
		header("Location: index.php?msg=expire");
	}
				
				
				
				 
				?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7"/>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Admin CP</title>
<meta name="keywords" content="" />
<meta name="description" content="" />

<script type="text/javascript" language="javascript">
	
		
		
		function confirmDelete() {
			valConfirm = confirm('Are you sure you want to delete this record?');
			if (valConfirm) {
				return true;
			} else {
				return false;
			}
		}
		
		</script>
		
<script LANGUAGE="JavaScript">
function displayHTML(printContent) {
var inf = printContent;
win = window.open("print.htm", 'popup', 'toolbar = no, status = no');
win.document.write(inf);
}
</script>

<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
	<div id="logo">
		<h1><a href="#">Inforesta </a></h1>
		<h2>Admin CP</h2>
		
	</div>
<!-- end #header -->
<div id="page">
	<!-- start sidebar1 -->
	<div id="sidebar1" class="sidebar">
		<ul>
			<li id="search">
			
				<h2>Search</h2>
				
				<form id="searchform" method="post" action="_index.php?go">
					<div>
						<input type="text" name="name" id="searchform" size="15" />
						<br />
						<input name="submit" type="submit" value="Search" />
					</div>
				</form><br />
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<?php 
				
				
				
				
				
				
				
				$ID = $_SESSION['User'];
				
				 $con = odbc_connect('bj','','') or die ('I cannot connect to the database  because: ' . odbc_error()); 
				 
				 $get = odbc_exec($con,"SELECT * FROM data WHERE username ='$ID'");
				 
				 while ($row = odbc_fetch_array($get))
				 
				 {
				 $admin = $row ['Admin'];
				 $username = $row ['username'];
				 }
				 
				 if (@$username = $admin)
				 echo   '<a href="admin.php" >Admin CP</a>';
				
				
								 
				?><br />
 
	 
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="new.php" >Add Employee</a><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="password.php" >Change Password</a><br />
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="logout.php" onclick="return confirm('Are you sure you want to log out?')">Admin Logout</a>
				
					
					
		
					
			
			</li>
			
			<li id="archives">
				
			</li>
		</ul>
	</div>
	
	<div id="content">
	<div class="bgtop">
	<div class="bgbtm">
		<div class="post">
		  <h1 class="title"><a href="#" rel="bookmark" title="Permanent Link to About This Template">Admin CP</a>			</h1>
			<div class="entry">
		   
	
Here you can edit username and password<br>
</b>
</body> 
	</html> 
	
	<br />
	


<?php
	
	
	
	$con = odbc_connect('bj','','') or die ('I cannot connect to the database  because: ' . odbc_error()); 
	$query = "SELECT * FROM user WHERE Admin = '1' ";
$result = odbc_exec($con,$query);
//$row = mysql_fetch_assoc($result);
while ($row = odbc_fetch_array($result)){
 
 echo "<table><tr> <td><b>User Name	</b>	<br>&nbsp;&nbsp;".$row['username'];
 
echo "</td>";
 echo "<td><b>Password</b><br>&nbsp;&nbsp;".$row['password'];
 echo "</td>";
  echo '<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="edit.php?ID='.$row['ID'].'" ><br>Edit</a>'; 
  echo '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="delete_user.php?ID='.$row['ID'].'" onClick="javascript: return confirmDelete();">Delete</a>';

echo "</tr>";



echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";

  echo "</table>";
 echo "<br>";
 
}


?>


<a href="new_user.php" >Add New User

 </p>
	
	 
	<html>
	


     <!--<img id="floatingImg" src="bj.jpg" alt="" />

<style type="text/css">
img#floatingImg {
position: absolute;
left: 600px;
top:360px;
width:90px;
height:90px;

}
</style>-->
<!--<h2>A Heading Level 2</h2>
				<p>This paragraph is followed by a sample unordered list:</p>
				<ul>
					<li><a href="#">Consectetuer adipiscing elit</a></li>
					<li><a href="#">Metus aliquam pellentesque</a></li>
					<li><a href="#">Urnanet non molestie semper</a></li>
					<li><a href="#">Proin gravida orci porttitor</a></li>
				</ul>
				<h3>Heading Level 3</h3>
				<p>While this one is followed by a blockquote:</p>
				<blockquote>
					<p>&ldquo;Donec leo, vivamus nibh in augue praesent a lacus at  urna congue rutrum. Quisque dictum integer nisl risus, sagittis  convallis, rutrum id, congue, and nibh.&rdquo;</p>-->
				</blockquote>
			</div>
			<!--<p class="tags"><strong>Tags: </strong><a href="#">vivamus</a> <a href="#">nibh</a> <a href="#">in augue</a> <a href="#">praesent</a></p>-->
			<!--<p class="links">Posted in <a href="#" title="View all posts in Free WP Themes" rel="category">Uncategorized</a> &nbsp;&nbsp;|&nbsp;&nbsp; <a href="#" title="Edit post">Edit</a> &nbsp;&nbsp;|&nbsp;&nbsp; <a href="#" title="Comment on About This Theme">4 Comments</a></p>-->
		</div>
	</div>
	</div>
	</div>
<!-- end content -->
	<!-- start sidebar2 -->
	<!--<div id="sidebar2" class="sidebar">
		<ul>
			<li id="recent-posts">
				<h2><!--Recent Posts--></h2>
				
					
						<!--<h3><a href="#">Aliquam Libero</a></h3>
						<p>Nullam  ante orci, eget, tempus quis, ultrices in, est. Curabitur sit amet  nulla. Nam in massa. Sed vel tellus. Curabitur sem urna, consequat vel,  suscipit in, mattis placerat, nulla. Sed ac leo. Pellentesque  imperdiet. <a href="#">More&hellip;</a></p>
					</li>
					<li>
						<h3><a href="#">Semper Vestibulum</a></h3>
						<p>Donec  leo, vivamus fermentum nibh in augue praesent a lacus at urna congue  rutrum. Quisque dictum integer nisl risus, sagittis convallis, rutrum  id, congue, and nibh. <a href="#">More&hellip;</a></p>
					</li>
					<li>
						<h3><a href="#">Etiam Malesuada</a></h3>
						<p>Donec  leo. Vivamus fermentum nibh in augue. Praesent a lacus at urna congue  rutrum. Nulla enim eros, porttitor eu, tempus id, varius non, nibh.  <a href="#">More&hellip;</a></p>
					</li>-->
				</ul>
			
		</ul>
	</div>
	<!-- end sidebar2 -->
	<div style="clear: both;">&nbsp;</div>
</div>
<!-- end page -->
<div id="footer">

	<p class="legal"><b>Best Viewed in Google Chrome / Firefox</p>
</div>
</body>
</html>
	