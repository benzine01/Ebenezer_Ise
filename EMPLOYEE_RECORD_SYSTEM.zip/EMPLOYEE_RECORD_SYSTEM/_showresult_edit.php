<?php


   //this will NOT work, the browser received the HTML tag before the script


 header( 'Location: index.php' ) ;



session_start(); 


$con = odbc_connect('bj','','') or die ('I cannot connect to the database  because: ' . odbc_error()); 

if (@$_POST['submit']);

{

//file attribute
$name = @$_FILES ["myfile"]["name"];
$tmp_name = @$_FILES ["myfile"]["tmp_name"];



if  ($name)
{

$location = "Image/$name";
move_uploaded_file($tmp_name,$location);





}



}

$first = $_SESSION['firstname'];
$last = $_SESSION['lastname'];
$middle=$_SESSION['middle'];
$contact=$_SESSION['contact'];
$address=$_SESSION['address'];
$birthplace=$_SESSION['birthplace'];
$gender=$_SESSION['gender'];
$civil=$_SESSION['civil'];
$nation=$_SESSION['nation'];
$religion=$_SESSION['religion'];
@$height=$_SESSION['height'];
$weight=$_SESSION['weight'];
$sss=$_SESSION['sss'];
$phil=$_SESSION['philhealth'];
$tin=$_SESSION['tin'];
$pagibig=$_SESSION['pagibig'];
$account=$_SESSION['account'];
$status=$_SESSION['status'];
$feet=$_SESSION['feet'];
$inches=$_SESSION['inches'];
$birthdate=$_SESSION['birthdate'];

$location = "Image/$name";
move_uploaded_file($tmp_name,$location);

$query=("INSERT INTO data (Firstname, Lastname, MiddleName, Contact, Address, BirthPlace, Gender, CivilStatus, Nationality, Religion, Feet, Inches, SSS, Tin, Pagibig, Account, Status, BirthDate, Phil, Image )
VALUES ('$first','$last','$middle','$contact','$address','$birthplace','$gender','$civil','$nation','$religion','$feet','$inches','$sss','$tin','$pagibig','$account','$status','$birthdate','$phil','$location')");							 	   
$result=odbc_exec($con,$query) or 
	            die ("Error in Saving Guest ".mysql_error());
 





 
?>


