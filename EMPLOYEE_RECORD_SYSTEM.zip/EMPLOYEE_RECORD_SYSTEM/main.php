<?php
	session_start();
	//Check if loged in
	if ($_SESSION['Login']=="") {
		header("Location: index.php");			   
	}
	
	//Destroy Session after 30min
	if (!isset($_SESSION['CREATED'])) {
		$_SESSION['CREATED'] = time();
	} else if (time() - $_SESSION['CREATED'] > 900) {
		session_destroy();
		header("Location: index.php?msg=expire");
	}
	
?>
<?php require("include/header.php.inc"); ?>
    <div id="content">
        <strong>International Association of Registered Financial Consultant,</strong>
        <br /><br />
		<p> IARFC is an organization of proven financial professionals formed to foster public confidence in the financial planning profession, to help financial advisors exchange planning techniques, and to give deserved recognition to those practitioners who are truly qualified and committed to the professional process and education. The IARFC currently serves more than 8,000 members. </p>
    </div>
<?php require("include/footer.php.inc"); ?>
