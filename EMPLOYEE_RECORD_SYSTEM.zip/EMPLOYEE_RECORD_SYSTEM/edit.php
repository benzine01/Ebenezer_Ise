<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by Free CSS Templates
http://www.freecsstemplates.org
Released for free under a Creative Commons Attribution 2.5 License

Name       : Compressed 
Description: A three-column, fixed-width template fit for 1024x768 screen resolutions.
Version    : 1.0
Released   : 20080524

-->

<?php 
				
				session_start();
				
	//Check if loged in
	if ($_SESSION['Login']=="") {
		header("Location: index.php");			   
	}
	
	//Destroy Session after 30min
	if (!isset($_SESSION['CREATED'])) {
		$_SESSION['CREATED'] = time();
	} else if (time() - $_SESSION['CREATED'] > 900) {
		session_destroy();
		header("Location: index.php?msg=expire");
	}
				
				
				
				 
				?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Employee Record</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<script type="text/javascript" language="javascript">
	
		
		
		function confirmCancel() {
			valConfirm = confirm('Are you sure you want to cancel?');
			if (valConfirm) {
				return true;
			} else {
				return false;
			}
		}
		
		</script>
		
<script LANGUAGE="JavaScript">
function displayHTML(printContent) {
var inf = printContent;
win = window.open("print.htm", 'popup', 'toolbar = no, status = no');
win.document.write(inf);
}
</script>

<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
	<div id="logo">
		<h1><a href="#">Inforesta </a></h1>
		<h2>Edit User</h2>
	</div>
<!-- end #header -->
<div id="page">
	<!-- start sidebar1 -->
	<div id="sidebar1" class="sidebar">
		<ul>
			<li id="search">
				<h2>Search</h2>
				<form id="searchform" method="post" action="index.php?go">
					<div>
						<input type="text" name="name" id="searchform" size="15" />
						<br />
						<input name="submit" type="submit" value="Search" />
					</div>
				</form>
				<br />
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<?php 
				
				
				
				
				
				
				
				$ID = $_SESSION['User'];
				
				 $con = odbc_connect('bj','','') or die ('I cannot connect to the database  because: ' . odbc_error()); 
				 
				 $get = odbc_exec($con,"SELECT * FROM data WHERE username ='$ID'");
				 
				 while ($row = odbc_fetch_array($get))
				 
				 {
				 $admin = $row ['Admin'];
				 $username = $row ['username'];
				 }
				 
				 if (@$username = $admin)
				 echo   '<a href="admin.php" >Admin CP</a>';
				
				
								 
				?><br />
 
	 
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="new.php" >Add Employee</a><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="password.php" >Change Password</a><br />
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="logout.php" onclick="return confirm('Are you sure you want to log out?')">Admin Logout</a>
				
			</li>
			<li>
				<h2><!--Categories</h2>
				<ul>
					<li><a href="#" title="View all posts filed under Uncategorized">Uncategorized</a> (3) </li>
					<li><a href="#" title="View all posts filed under Lorem Ipsum">Lorem Ipsum</a> (42) </li>
					<li><a href="#" title="View all posts filed under Urna Congue Rutrum">Urna Congue Rutrum</a> (28) </li>
					<li><a href="#" title="View all posts filed under Augue Praesent">Augue Praesent</a> (55) </li>
					<li><a href="#" title="View all posts filed under Vivamus Fermentum">Vivamus Fermentum</a> (13) </li>
				</ul>
			</li>
			<li id="archives">
				<h2>Archives</h2>
				<ul>
					<li><a href="#">November 2007</a>&nbsp;(24)</li>
					<li><a href="#">October 2007</a>&nbsp;(31)</li>
					<li><a href="#">September 2007</a>&nbsp;(30)</li>
					<li><a href="#">August 2007</a>&nbsp;(31)</li>
					<li><a href="#">July 2007</a>&nbsp;(31)</li>
					<li><a href="#">June 2007</a>&nbsp;(30)</li>
					<li><a href="#">May 2007</a>&nbsp;(31)</li>
					<li><a href="#">April 2007</a>&nbsp;(30)</li>
					<li><a href="#">March 2007</a>&nbsp;(31)</li>
					<li><a href="#">February 2007</a>&nbsp;(28)</li>
					<li><a href="#">January 2007</a>&nbsp;(31)--></li>
				</ul>
			</li>
		</ul>
	</div>
	<!-- end sidebar1 -->
	<!-- start content -->
	<div id="content">
	<div class="bgtop">
	<div class="bgbtm">
		<div class="post">
		  <h1 class="title"><a href="#" rel="bookmark" title="Permanent Link to About This Template">Edit User</a>			</h1>
			<div class="entry">
		    <p>
</body> 
	</html> 
	<div id="printarea">
	

<?php
	
	
				
				
				
								 
			
 $con = odbc_connect('bj','','') or die ('I cannot connect to the database  because: ' . odbc_error()); 

$ID = "$_GET[ID]";         
$query = "SELECT * FROM user where ID = $_GET[ID]";
$result = odbc_exec($con,$query);
//$row = mysql_fetch_assoc($result);
while (@$row = odbc_fetch_array($result)){

?>


<form action="edit_user.php?ID=<?php echo $row['ID'];?>" method="post"/>
<table width="70%" border="0" align="center" cellpadding="2" cellspacing="2">
  <tr>
    <td width="33%" align="right"><font size="2" face="Arial"><strong>Username</strong></font></td>
    <td width="5%" align="center">:</td>
    <td width="62%"><input type='text' name='username' size=30 maxlength=15 value="<?php echo $row['username'];?>"></td>
  </tr>
  <tr>
    <td align="right"><font size="2" face="Arial"><strong>Password</strong></font></td>
    <td align="center">:</td>
    <td><input type='text' name='password' size=30 maxlength=50 value="<?php echo $row['password'];?>"></td>
  </tr>
  
</table><br />
<table>

    <td><tr>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' name="submit" value='  Next  '> 
	</form></tr>
	<tr>&nbsp;&nbsp;
	<form action="_index.php" method="post"/>
	<input type='submit' value='Cancel' onClick="javascript: return confirmCancel();"> </form></tr></td>
	</td><br /><br />
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Please Enter New Username and Password!
</table>



	</div>
	<html>

     <!--<img id="floatingImg" src="bj.jpg" alt="" />

<style type="text/css">
img#floatingImg {
position: absolute;
left: 600px;
top:360px;
width:90px;
height:90px;

}
</style>-->
<!--<h2>A Heading Level 2</h2>
				<p>This paragraph is followed by a sample unordered list:</p>
				<ul>
					<li><a href="#">Consectetuer adipiscing elit</a></li>
					<li><a href="#">Metus aliquam pellentesque</a></li>
					<li><a href="#">Urnanet non molestie semper</a></li>
					<li><a href="#">Proin gravida orci porttitor</a></li>
				</ul>
				<h3>Heading Level 3</h3>
				<p>While this one is followed by a blockquote:</p>
				<blockquote>
					<p>&ldquo;Donec leo, vivamus nibh in augue praesent a lacus at  urna congue rutrum. Quisque dictum integer nisl risus, sagittis  convallis, rutrum id, congue, and nibh.&rdquo;</p>-->
				</blockquote>
			</div>
			<!--<p class="tags"><strong>Tags: </strong><a href="#">vivamus</a> <a href="#">nibh</a> <a href="#">in augue</a> <a href="#">praesent</a></p>-->
			<!--<p class="links">Posted in <a href="#" title="View all posts in Free WP Themes" rel="category">Uncategorized</a> &nbsp;&nbsp;|&nbsp;&nbsp; <a href="#" title="Edit post">Edit</a> &nbsp;&nbsp;|&nbsp;&nbsp; <a href="#" title="Comment on About This Theme">4 Comments</a></p>-->
		</div>
	</div>
	</div>
	</div>
<!-- end content -->
	<!-- start sidebar2 -->
	<div id="sidebar2" class="sidebar">
		<ul>
			<li id="recent-posts">
				<h2><!--Recent Posts--></h2>
				<ul>
					<li>
						<!--<h3><a href="#">Aliquam Libero</a></h3>
						<p>Nullam  ante orci, eget, tempus quis, ultrices in, est. Curabitur sit amet  nulla. Nam in massa. Sed vel tellus. Curabitur sem urna, consequat vel,  suscipit in, mattis placerat, nulla. Sed ac leo. Pellentesque  imperdiet. <a href="#">More&hellip;</a></p>
					</li>
					<li>
						<h3><a href="#">Semper Vestibulum</a></h3>
						<p>Donec  leo, vivamus fermentum nibh in augue praesent a lacus at urna congue  rutrum. Quisque dictum integer nisl risus, sagittis convallis, rutrum  id, congue, and nibh. <a href="#">More&hellip;</a></p>
					</li>
					<li>
						<h3><a href="#">Etiam Malesuada</a></h3>
						<p>Donec  leo. Vivamus fermentum nibh in augue. Praesent a lacus at urna congue  rutrum. Nulla enim eros, porttitor eu, tempus id, varius non, nibh.  <a href="#">More&hellip;</a></p>
					</li>-->
				</ul>
			</li>
		</ul>
	</div>
	<!-- end sidebar2 -->
	<div style="clear: both;">&nbsp;</div>
</div>
<!-- end page -->
<div id="footer">

	<!--<p class="legal">&copy;2007 All Rights Reserved. Design by <a href="http://www.freecsstemplates.org/">Free CSS Templates</a></p>-->
</div>
</body>
</html>
<?php

}

?>