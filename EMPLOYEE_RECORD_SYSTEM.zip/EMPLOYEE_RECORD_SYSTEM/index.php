<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by Free CSS Templates
http://www.freecsstemplates.org
Released for free under a Creative Commons Attribution 2.5 License

Name       : Compressed 
Description: A three-column, fixed-width template fit for 1024x768 screen resolutions.
Version    : 1.0
Released   : 20080524

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Employee Record</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<script LANGUAGE="JavaScript">
function displayHTML(printContent) {
var inf = printContent;
win = window.open("print.htm", 'popup', 'toolbar = no, status = no');
win.document.write(inf);
}
</script>

<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
	<div id="logo">
		<h1><a href="#">Inforesta </a></h1>
		<h2>employee record</h2>
	</div>
<!-- end #header -->
<div id="page">
	<!-- start sidebar1 -->
	<div id="sidebar1" class="sidebar">
		<ul>
			
			<li>
				<h2><!--Categories</h2>
				<ul>
					<li><a href="#" title="View all posts filed under Uncategorized">Uncategorized</a> (3) </li>
					<li><a href="#" title="View all posts filed under Lorem Ipsum">Lorem Ipsum</a> (42) </li>
					<li><a href="#" title="View all posts filed under Urna Congue Rutrum">Urna Congue Rutrum</a> (28) </li>
					<li><a href="#" title="View all posts filed under Augue Praesent">Augue Praesent</a> (55) </li>
					<li><a href="#" title="View all posts filed under Vivamus Fermentum">Vivamus Fermentum</a> (13) </li>
				</ul>
			</li>
			<li id="archives">
				<h2>Archives</h2>
				<ul>
					<li><a href="#">November 2007</a>&nbsp;(24)</li>
					<li><a href="#">October 2007</a>&nbsp;(31)</li>
					<li><a href="#">September 2007</a>&nbsp;(30)</li>
					<li><a href="#">August 2007</a>&nbsp;(31)</li>
					<li><a href="#">July 2007</a>&nbsp;(31)</li>
					<li><a href="#">June 2007</a>&nbsp;(30)</li>
					<li><a href="#">May 2007</a>&nbsp;(31)</li>
					<li><a href="#">April 2007</a>&nbsp;(30)</li>
					<li><a href="#">March 2007</a>&nbsp;(31)</li>
					<li><a href="#">February 2007</a>&nbsp;(28)</li>
					<li><a href="#">January 2007</a>&nbsp;(31)--></li>
				</ul>
			</li>
		</ul>
	</div>
	<!-- end sidebar1 -->
	<!-- start content -->
	<div id="content">
	<div class="bgtop">
	<div class="bgbtm">
		<div class="post">
		  <h1 class="title"><a href="#" rel="bookmark" title="Permanent Link to About This Template">EMPLOYEE RECORD</a>			</h1>
			<div class="entry">
		   
</body> 
	</html> 
	
	<?php
	session_start();
	
	
	if (@$_SESSION["Login"]=="Ok") {
		header("Location: _index.php");			   
	}
	
?>
<?php require("include/header.php.inc"); ?>
<?php
	if (@$_GET['msg']=="expire") {
?>
	<script type="text/javascript" language="javascript">
		alert('Session expired.');
	</script>
<?php	
	}
?>
    

	
	

	
    
			</div>
			
		</div>
	</div>
	</div>
	</div>

				
					
						
	</div>
	<!-- end sidebar2 -->
	<div style="clear: both;">&nbsp;</div>
</div>
<!-- end page -->
<div id="footer">

	<p class="legal"><b>Best Viewed in Google Chrome / Firefox</p>
</div>
</body>
</html>
