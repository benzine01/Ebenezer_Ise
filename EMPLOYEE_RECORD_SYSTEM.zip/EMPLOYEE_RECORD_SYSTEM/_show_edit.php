<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by Free CSS Templates
http://www.freecsstemplates.org
Released for free under a Creative Commons Attribution 2.5 License

Name       : Compressed 
Description: A three-column, fixed-width template fit for 1024x768 screen resolutions.
Version    : 1.0
Released   : 20080524

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Employee Record</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<script type="text/javascript" language="javascript">
	
		
		
		function confirmSubmit() {
			valConfirm = confirm('Save Change?');
			if (valConfirm) {
				return true;
			} else {
				return false;
			}
		}
		
		</script>



<script type="text/javascript" language="javascript">

function goBack()
  {
  window.history.back()
  }
</script>
<script LANGUAGE="JavaScript">
function displayHTML(printContent) {
var inf = printContent;
win = window.open("print.htm", 'popup', 'toolbar = no, status = no');
win.document.write(inf);
}
</script>

<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
	<div id="logo">
		<h1><a href="#">Inforesta </a></h1>
		<h2>employee edit record</h2>
	</div>
<!-- end #header -->
<div id="page">
	<!-- start sidebar1 -->
	<div id="sidebar1" class="sidebar">
		<ul>
			<li id="search">
				<h2>Search</h2>
				<form id="searchform" method="post" action="index.php?go">
					<div>
						<input type="text" name="name" id="searchform" size="15" />
						<br />
						<input name="submit" type="submit" value="Search" />
					</div>
				</form>
			</li>
			<li>
				<h2><!--Categories</h2>
				<ul>
					<li><a href="#" title="View all posts filed under Uncategorized">Uncategorized</a> (3) </li>
					<li><a href="#" title="View all posts filed under Lorem Ipsum">Lorem Ipsum</a> (42) </li>
					<li><a href="#" title="View all posts filed under Urna Congue Rutrum">Urna Congue Rutrum</a> (28) </li>
					<li><a href="#" title="View all posts filed under Augue Praesent">Augue Praesent</a> (55) </li>
					<li><a href="#" title="View all posts filed under Vivamus Fermentum">Vivamus Fermentum</a> (13) </li>
				</ul>
			</li>
			<li id="archives">
				<h2>Archives</h2>
				<ul>
					<li><a href="#">November 2007</a>&nbsp;(24)</li>
					<li><a href="#">October 2007</a>&nbsp;(31)</li>
					<li><a href="#">September 2007</a>&nbsp;(30)</li>
					<li><a href="#">August 2007</a>&nbsp;(31)</li>
					<li><a href="#">July 2007</a>&nbsp;(31)</li>
					<li><a href="#">June 2007</a>&nbsp;(30)</li>
					<li><a href="#">May 2007</a>&nbsp;(31)</li>
					<li><a href="#">April 2007</a>&nbsp;(30)</li>
					<li><a href="#">March 2007</a>&nbsp;(31)</li>
					<li><a href="#">February 2007</a>&nbsp;(28)</li>
					<li><a href="#">January 2007</a>&nbsp;(31)--></li>
				</ul>
			</li>
		</ul>
	</div>
	<!-- end sidebar1 -->
	<!-- start content -->
	<div id="content">
	<div class="bgtop">
	<div class="bgbtm">
		<div class="post">
		  <h1 class="title"><a href="#" rel="bookmark" title="Permanent Link to About This Template">EMPLOYEE EDIT RECORD</a>			</h1>
			<div class="entry">
		    <p>
</body> 
	</html> 
	<div id="printarea">
	

<form action="_showresult_edit.php" method="post" enctype = "multipart/form-data">
<?php 
	
		


 // this starts the session 
 session_start(); 
 
 // this sets variables in the session 
 
  $_SESSION['firstname']= $_POST['firstname']; 
 $_SESSION['lastname']=$_POST['lastname']; 
 $_SESSION['middle']=$_POST['middle']; 
 $_SESSION['contact']=$_POST['contact']; 
 $_SESSION['address']=$_POST['address']; 
 $_SESSION['birthplace']=$_POST['birthplace']; 
 $_SESSION['birthdate']=$_POST['birthdate']; 
  @$_SESSION['gender']=$_POST['gender']; 
  @$_SESSION['civil']=$_POST['civil']; 
  $_SESSION['nation']=$_POST['nation'];
  $_SESSION['religion']=$_POST['religion'];
   //$_SESSION['height']=$_POST['height'];
    $_SESSION['weight']=$_POST['weight'];
	$_SESSION['sss']=$_POST['sss'];
	$_SESSION['philhealth']=$_POST['philhealth'];
 	$_SESSION['tin']=$_POST['tin'];
	$_SESSION['pagibig']=$_POST['pagibig'];
	$_SESSION['account']=$_POST['account'];
	$_SESSION['status']=$_POST['status'];
	$_SESSION['feet']=$_POST['feet'];
	$_SESSION['inches']=$_POST['inches'];
	
 
 
 
?>
<?php 

echo "<table>";
echo "<td><b>Name :</b>	".$_SESSION['lastname'] ; 
echo ",	"	.$_SESSION['firstname'];
 echo "&nbsp;"; 
 echo "" .$_SESSION['middle']; 
 echo "<br>"; 
 echo  "<b>Contact #</b>	:	" 	.$_SESSION['contact']; 
 echo "<br>";
  echo  "<b>Address</b>	:	" 	.$_SESSION['address']; 
  echo "</td>";
  
 echo "<br>";
  echo "</table>";
  echo "<br>";
  
 echo  "<b>Birth Date</b>	:	" 	.$_SESSION['birthdate']; 
 echo "<br>";
 echo  "<b>Birth Place</b>	:	" 	.$_SESSION['birthplace']; 
 echo "<br>";
  echo  "<b>Gender</b>	:	" 	.@$_SESSION['gender']; 
 echo "<br>";
  echo  "<b>Civil Status</b>	:	" 	.$_SESSION['civil']; 
 echo "<br>";
  echo  "<b>Nationality</b>	:	" 	.$_SESSION['nation']; 
 echo "<br>";
  echo  "<b>Religion</b>	:	" 	.$_SESSION['religion']; 
 echo "<br>";
 echo  "<b>Height</b>	:	" 	.$_SESSION['feet']; 
 echo "&nbsp;"; 
 echo "'" .$_SESSION['inches'];
 
 
 
 echo "<br>";
  echo  "<b>Weight</b>	:	" 	.$_SESSION['weight']; 
 echo "<br>";echo "<br>";
 echo  "<b>SSS #</b>	:	" 	.$_SESSION['sss']; 
 echo "<br>";
  echo  "<b>Philhealth #</b>	:	" 	.$_SESSION['philhealth']; 
 echo "<br>";
 echo  "<b>TIN #</b>	:	" 	.$_SESSION['tin']; 
  echo "&nbsp;";
  echo " - "; 
 echo "" .$_SESSION['status']; 
 echo "<br>";
 echo  "<b>Pagibig #</b>	:	" 	.$_SESSION['pagibig']; 
 echo "<br>";
 echo  "<b>Account #</b>	:	" 	.$_SESSION['account']; 
 echo "<br>";
 echo "<br>";
?>

<input type = "file" name = "myfile"  > <br /><br />

<input type="button" value=" Back " onClick="goBack()" />&nbsp;&nbsp;
<input type="submit" value ="Submit" onClick="javascript: return confirmSubmit();" />  </p>




	</div>
	<html>

	
     <!--<img id="floatingImg" src="bj.jpg" alt="" />

<style type="text/css">
img#floatingImg {
position: absolute;
left: 600px;
top:360px;
width:90px;
height:90px;

}
</style>-->
<!--<h2>A Heading Level 2</h2>
				<p>This paragraph is followed by a sample unordered list:</p>
				<ul>
					<li><a href="#">Consectetuer adipiscing elit</a></li>
					<li><a href="#">Metus aliquam pellentesque</a></li>
					<li><a href="#">Urnanet non molestie semper</a></li>
					<li><a href="#">Proin gravida orci porttitor</a></li>
				</ul>
				<h3>Heading Level 3</h3>
				<p>While this one is followed by a blockquote:</p>
				<blockquote>
					<p>&ldquo;Donec leo, vivamus nibh in augue praesent a lacus at  urna congue rutrum. Quisque dictum integer nisl risus, sagittis  convallis, rutrum id, congue, and nibh.&rdquo;</p>-->
				</blockquote>
			</div>
			<!--<p class="tags"><strong>Tags: </strong><a href="#">vivamus</a> <a href="#">nibh</a> <a href="#">in augue</a> <a href="#">praesent</a></p>-->
			<!--<p class="links">Posted in <a href="#" title="View all posts in Free WP Themes" rel="category">Uncategorized</a> &nbsp;&nbsp;|&nbsp;&nbsp; <a href="#" title="Edit post">Edit</a> &nbsp;&nbsp;|&nbsp;&nbsp; <a href="#" title="Comment on About This Theme">4 Comments</a></p>-->
		</div>
	</div>
	</div>
	</div>
<!-- end content -->
	<!-- start sidebar2 -->
	<div id="sidebar2" class="sidebar">
		<ul>
			<li id="recent-posts">
				<h2><!--Recent Posts--></h2>
				<ul>
					<li>
						<!--<h3><a href="#">Aliquam Libero</a></h3>
						<p>Nullam  ante orci, eget, tempus quis, ultrices in, est. Curabitur sit amet  nulla. Nam in massa. Sed vel tellus. Curabitur sem urna, consequat vel,  suscipit in, mattis placerat, nulla. Sed ac leo. Pellentesque  imperdiet. <a href="#">More&hellip;</a></p>
					</li>
					<li>
						<h3><a href="#">Semper Vestibulum</a></h3>
						<p>Donec  leo, vivamus fermentum nibh in augue praesent a lacus at urna congue  rutrum. Quisque dictum integer nisl risus, sagittis convallis, rutrum  id, congue, and nibh. <a href="#">More&hellip;</a></p>
					</li>
					<li>
						<h3><a href="#">Etiam Malesuada</a></h3>
						<p>Donec  leo. Vivamus fermentum nibh in augue. Praesent a lacus at urna congue  rutrum. Nulla enim eros, porttitor eu, tempus id, varius non, nibh.  <a href="#">More&hellip;</a></p>
					</li>-->
				</ul>
			</li>
		</ul>
	</div>
	<!-- end sidebar2 -->
	<div style="clear: both;">&nbsp;</div>
</div>
<!-- end page -->
<div id="footer">

	<!--<p class="legal">&copy;2007 All Rights Reserved. Design by <a href="http://www.freecsstemplates.org/">Free CSS Templates</a></p>-->
</div>
</body>
</html>
