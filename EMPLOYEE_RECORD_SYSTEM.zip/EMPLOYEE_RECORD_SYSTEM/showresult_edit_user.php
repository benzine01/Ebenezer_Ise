<?php


   //this will NOT work, the browser received the HTML tag before the script


header( 'Location: index.php' ) ;



session_start(); 


$con = odbc_connect('bj','','') or die ('I cannot connect to the database  because: ' . odbc_error()); 



$userame = $_SESSION['username'];
$password = $_SESSION['password'];


 



$query=("UPDATE user SET username ='$username', password ='$password'
WHERE ID = $ID");							 	   
$result=odbc_exec($con,$query) or 
	            die ("Error in Saving Guest ".odbc_error());
				echo "pogi";
				
 	

 
?>


