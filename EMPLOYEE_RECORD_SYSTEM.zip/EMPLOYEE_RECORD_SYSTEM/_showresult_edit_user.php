<?php


   //this will NOT work, the browser received the HTML tag before the script


 header( 'Location: index.php' ) ;



session_start(); 


$con = odbc_connect('bj','','') or die ('I cannot connect to the database  because: ' . odbc_error()); 



$username = $_SESSION['username'];
$password = $_SESSION['password'];
$admin=$_SESSION['admin'];




$query=("INSERT INTO user (username, password, admin )
VALUES ('$username','$password','$admin')");							 	   
$result=odbc_exec($con,$query) or 
	            die ("Error in Saving Guest ".mysql_error());
 





 
?>


