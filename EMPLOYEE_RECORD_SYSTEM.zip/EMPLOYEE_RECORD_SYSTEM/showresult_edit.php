<?php


   //this will NOT work, the browser received the HTML tag before the script


  header( 'Location: index.php' ) ;



session_start(); 


$con = odbc_connect('bj','','') or die ('I cannot connect to the database  because: ' . odbc_error()); 

if (@$_POST['submit']);

{

//file attribute
$name = @$_FILES ["myfile"]["name"];
$tmp_name = @$_FILES ["myfile"]["tmp_name"];



if  ($name)
{

$location = "Image/$name";
move_uploaded_file($tmp_name,$location);

$query=("UPDATE data SET Image ='$location'
WHERE ID = $ID");							 	   
$result=odbc_exec($con,$query) ;


echo "Your image has been uploaded";
}



}

$first = $_SESSION['firstname'];
$last = $_SESSION['lastname'];
$middle=$_SESSION['middle'];
$contact=$_SESSION['contact'];
$address=$_SESSION['address'];
$birthplace=$_SESSION['birthplace'];
$gender=$_SESSION['gender'];
$civil=$_SESSION['civil'];
$nation=$_SESSION['nation'];
$religion=$_SESSION['religion'];
@$height=$_SESSION['height'];
$weight=$_SESSION['weight'];
$sss=$_SESSION['sss'];
$phil=$_SESSION['philhealth'];
$tin=$_SESSION['tin'];
$pagibig=$_SESSION['pagibig'];
$account=$_SESSION['account'];
$status=$_SESSION['status'];
$feet=$_SESSION['feet'];
$inches=$_SESSION['inches'];


 



$query=("UPDATE data SET FirstName ='$first', LastName ='$last', MiddleName ='$middle', Contact ='$contact', Address ='$address', BirthPlace ='$birthplace', Gender ='$gender',CivilStatus ='$civil', Nationality ='$nation',Religion ='$religion',Feet ='$feet',Weight ='$weight',Inches ='$inches',SSS ='$sss',Tin ='$tin',Pagibig ='$pagibig',Account ='$account',Status ='$status',BirthDate ='$birthdate',Phil ='$phil'
WHERE ID = $ID");							 	   
$result=odbc_exec($con,$query) or 
	            die ("Error in Saving Guest ".odbc_error());
				
 	 if( $_SESSION['gender'] == "Gender" )
	
	{
		
		header('location: _index.php?error=1');
	} 	 

 
?>


